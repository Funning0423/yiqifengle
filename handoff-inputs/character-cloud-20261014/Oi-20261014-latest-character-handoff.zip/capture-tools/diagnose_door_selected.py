exec(open('capture-tools/inspect_structure.py').read().split('for side,lo')[0])
rep=json.load(open('poses/door-pose-camera-samples.json'));rows=[]
ids=np.arange(1503,2023);tris=F[np.all(np.isin(F,ids),1)]
def hits(v,tris):
 A=v[tris];low=A.min(1);high=A.max(1);pairs=[]
 for i in range(len(tris)):
  cand=np.where(np.all((low[i]<=high)&(high[i]>=low),axis=1))[0];cand=cand[cand>i]
  cand=[k for k in cand if not np.intersect1d(tris[i],tris[k]).size]
  for k in cand:
   hit=False
   for t1,t2 in [(A[i],A[k]),(A[k],A[i])]:
    e1=t2[1]-t2[0];e2=t2[2]-t2[0]
    for n in range(3):
     orig=t1[n];d=t1[(n+1)%3]-orig;h=np.cross(d,e2);det=np.dot(e1,h)
     if abs(det)<1e-10:continue
     inv=1/det;s=orig-t2[0];u=inv*np.dot(s,h);q=np.cross(s,e1);vv=inv*np.dot(d,q);tt=inv*np.dot(e2,q)
     if 1e-6<tt<1-1e-6 and u>1e-6 and vv>1e-6 and u+vv<1-1e-6:hit=True;break
    if hit:break
   if hit:pairs.append([i,k])
 return pairs
for fr in rep['frames']:
 ix=fr['frame'];nd={n['name']:n for n in fr['nodes']};T=np.array([nd[n]['translation'] for n in r.names]);Q=np.array([nd[n]['rotation'] for n in r.names]);Sc=np.array([nd[n]['scale'] for n in r.names]);ww=r.fk(T[None],Q[None],Sc[None])[0];v=r.skin({'P':P,'J':J,'W':W},ww);pairs=hits(v,tris);rows.append({'frame':ix,'state':fr['state'],'nonAdjacentSleeveTriangleIntersections':len(pairs),'trianglePairs':pairs})
print(json.dumps(rows,indent=2,default=lambda v:int(v)));Path('poses/recomputed-left-sleeve-intersections.json').write_text(json.dumps(rows,indent=2,default=lambda v:int(v)))
