import sys,numpy as np,collections,json
from pathlib import Path
sys.path.insert(0,'character-fix/art-src/animation/mocap/scripts');import rig as R
p=Path('character-fix/creator-build-project/assets/bundles/region_island/character/chr_b_r5g2_lod0_anim_pass2_INTERIM_s1_grokbot2.glb');r=R.Rig(str(p));pr=next(m for m in r.J['meshes'] if m['name']=='LOD0_G2_BODY')['primitives'][0];a=pr['attributes'];P=R.acc(r.J,r.BIN,a['POSITION']);F=R.acc(r.J,r.BIN,pr['indices']).astype(int).reshape(-1,3);J=R.acc(r.J,r.BIN,a['JOINTS_0']).astype(int);W=R.acc(r.J,r.BIN,a['WEIGHTS_0']);N=R.acc(r.J,r.BIN,a['NORMAL'])
for side,lo,hi,palo,pahi in [('L',1503,2023,2758,2844),('R',2023,2543,2994,3080)]:
 ids=np.arange(lo,hi);h=r.idx['hand.'+side];f=r.idx['forearm.'+side];u=r.idx['upper_arm.'+side];adj={int(i):set() for i in ids};ec=collections.Counter()
 for tri in F[np.all(np.isin(F,ids),1)]:
  for x,y in zip(tri,np.roll(tri,-1)):adj[x].add(y);adj[y].add(x);ec[tuple(sorted((x,y)))]+=1
 boundary=set(v for e,c in ec.items() if c==1 for v in e);hw=np.linalg.inv(r.ibm[h])[:3,3];start=min(boundary,key=lambda i:np.linalg.norm(P[i]-hw));ring={start};q=[start]
 while q:
  x=q.pop()
  for y in adj[x]&boundary-ring:ring.add(y);q.append(y)
 layers=[sorted(ring)];seen=set(ring)
 while len(seen)<len(ids):
  nxt=set(y for x in layers[-1] for y in adj[x])-seen
  if not nxt:break
  layers.append(sorted(nxt));seen.update(nxt)
 print(side,'layer sizes',[len(x) for x in layers])
 for k,ix in enumerate(layers):
  fw=((J[ix]==f)*W[ix]).sum(1); print(k, 'center',P[ix].mean(0).round(4),'f range',fw.min().round(4),fw.max().round(4),'spread',np.ptp(fw).round(4))
 palm=np.arange(palo,pahi);T=F[np.all(np.isin(F,palm),1)];degree=collections.Counter(T.ravel());print('palm high degree',[(i,c,P[i].round(4).tolist()) for i,c in degree.items() if c>=10]);print('cuff to palm',np.linalg.norm(P[layers[0]].mean(0)-P[palm].mean(0)))
Path('evidence/structure-input.txt').write_text('see captured stdout')
