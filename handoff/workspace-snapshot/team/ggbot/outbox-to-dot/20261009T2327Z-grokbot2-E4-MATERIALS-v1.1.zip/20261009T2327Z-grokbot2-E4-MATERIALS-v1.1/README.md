# E4 自定义材质移植草案 v1.1：草甸风草 + 不受光天空 + MeadowInstancer 修改（Cocos Creator 3.8.8 / 微信小游戏）

GGbot（grokbot2）· 2026-10-09 · 草案，**没有在 Creator 编辑器、微信开发者工具或真机上跑过**。
这台电脑上能验的都验了：用 Creator 3.8.8 安装包自带的官方 effect 编译器编译，用 glslang 按 WebGL1 / WebGL2 编译并链接所有宏组合，用 CPU 参考实现对照美术公式和 v0.8 真实网格，MeadowInstancer 用 cc 桩在 Node 里跑。结果见 `selftest/out/selftest-results.md`：**69 通过 / 0 失败 / 6 未运行**。
没碰 0007 / 0008 的任何文件。

## v1.1 更新内容（相对 v1）

按美术负责人对 v1 问题的答复，加上 Grok Bot 追加的三项：

| # | 改动 | 文件 |
|---|---|---|
| 1 | **风向定为世界空间**（默认）。整片草沿 windDir 一起倒，丛与丛之间靠 COLOR_0.g 相位区分。`WIND_SPACE 1`（模板本地）只保留做对比 | effect 注释、参数表 |
| 2 | windDir 默认改成美术 README（2026-10-09 修订版）主风向 W = (0.944, −0.330) 的归一化值 **(0.94398, −0.32999)** | meadow-grass-wind.effect |
| 3 | COLOR_0.b 改成“无意义的导出常量，忽略，保留”。COLOR_0 实际是 UNSIGNED_SHORT 归一化，和美术 README 修订版一致 | effect 注释、参数表 |
| 4 | **不走静态合批**，只用 GPU 实例化。`WIND_PHASE_ORIGIN` 换成 `WIND_PHASE_PER_VERTEX`：默认关，即按实例原点算相位。逐顶点相位只保留，文档里不再推荐。draw call 表里删掉了静态合批那一行 | effect、参数表、README |
| 5 | 调色板贴图 **关 mipmap**：导入设置和 `.meta` 写法见参数表第四节 | MATERIAL-PARAMS.md |
| 6 | **夜景图成为默认夜晚路径**：`USE_NIGHT_TEXTURE` 换成 `SKY_NIGHT_TINT_ONLY`（默认关，默认就会采样 nightTexture）；nightTint 默认改成白色。接入的是美术交付的 `tex_meadow_sky_night_2048x1024.png` | sky-unlit.effect、参数表 |
| 7 | **修正 bug：地平线雾方向反了**。v1 按“v 从底往上量”写，horizonV = 0.143。核实后确认 Cocos 里 v 是从贴图顶边往下量，地平线在 v = 0.857，所以 v1 的雾会跑到天顶。已改成 `h = smoothstep(horizonV − horizonWidth, horizonV, v)`，默认 horizonV = 0.857，约定写进了 effect 注释 | sky-unlit.effect |
| 8 | **MeadowInstancer 改动**：① 按材质里的风参数和网格的 max(COLOR_0.a) 扩大每个实例的包围盒，草尖不会在屏幕边缘突然出现；② 切档换材质后重设 a_root_color。切档或改风参数时两者都会重算 | `scripts/MeadowInstancer.ts`、`patches/0001-…diff` |
| 9 | GrassWindQuality.ts 新增：全局事件 `grassWindEvents`、`setGrassWindParams()`（改参数会同步到各档的运行时材质）、包围盒工具函数 | scripts/GrassWindQuality.ts |
| 10 | 修正 v1 数据：v0.8 草尖最大位移是 **0.81 m**，解析上界 0.851 m。v1 写的 0.69 m 只采了 4 个时刻，偏小。实例化后顶点数是 6.8 万（v1 有一处误写成 8.8 万） | 文档、自测 |
| 11 | 顺手修了原型的一个编译错误：`renderer.scene.ShadowCastingMode` 在 3.8.8 不存在，改成 `MeshRenderer.ShadowCastingMode` | MeadowInstancer.ts |

v1 → v1.1 的完整差异见 `patches/0002-E4-v1-to-v1.1.diff`。

## 包内容

| 文件 | 说明 |
|---|---|
| `effects/meadow-grass-wind.effect` | 草甸草丛：COLOR_0 驱动的世界空间风动（3 档）+ 根→尖混色 + 可选的逐顶点简单光照 |
| `effects/sky-unlit.effect` | 天空球：按 UV 采样，不受光、不写深度、推到远平面；白天图 + 夜景图昼夜混合，可选地平线雾 / 慢速滚动 / 跟随相机 |
| `scripts/GrassWindQuality.ts` | 按微信机型档位自动选 `WIND_QUALITY`、运行时切档（保住实例化合批）、改风参数、包围盒工具 |
| `scripts/MeadowInstancer.ts` | 原型 `team/ggbot/prototypes/MeadowInstancer.ts` 的 v1.1 修改版 |
| `patches/0001-MeadowInstancer-wind-bounds-root-color.diff` | 对现有 `team/ggbot/prototypes/MeadowInstancer.ts`（SHA256 917f9ea0…1e44）的 git diff，在 `/workspace/wechat-game` 下 `git apply --check` 通过 |
| `patches/0002-E4-v1-to-v1.1.diff` | 本包 v1 → v1.1 的差异 |
| `MATERIAL-PARAMS.md` | 材质参数表（宏、属性、默认值、范围、UV 约定）、COLOR_0 约定、调色板导入设置 |
| `selftest/` | Node 自测脚本和输出（`out/`） |
| `SHA256SUMS.txt` | 包内全部文件的 SHA256 |

**不带 `.meta`**：直接放进工程，Creator 会自己生成 `.meta` 和 UUID。
**不带贴图**：天空白天图、夜景图用美术和预研已有的文件（路径和 SHA 见第六节），避免一张图出现两份。

### MeadowInstancer.ts 归属

`team/ggbot/prototypes/MeadowInstancer.ts` 是 **GGbot 自己的原型**：第五批交付里加入，登记在 `team/ggbot/README.md` 和 `team/ggbot/SHA256SUMS.txt`。它不是 Oi 的工程文件，也不是 Grok Bot 的美术文件。游戏工程 `src/QIFENGLE-COCOS-5b449fa-SOURCE/creator-build-project` 里还没有这个文件。
为了不让 `team/ggbot/SHA256SUMS.txt` 对不上，**原文件没有直接改**。修改版放在 `scripts/`，同时给了正式 diff。要合进去，在 `/workspace/wechat-game` 下执行 `git apply patches/0001-…diff`，然后更新 `team/ggbot/SHA256SUMS.txt` 里对应的那一行。

## 一、放到工程哪里

| 文件 | 位置 | 原因 |
|---|---|---|
| 两个 `.effect` | `assets/effects/`（主包） | 草甸、海岛、天空之城都会用天空。WebGL1 + WebGL2 两套 GLSL 源码合计：草约 53 KB、天空约 16 KB，未压缩 |
| `GrassWindQuality.ts`、`MeadowInstancer.ts` | `assets/scripts/render/`（主包脚本，**两个文件放同一目录**） | MeadowInstancer 用 `import … from './GrassWindQuality'` |
| 草 / 天空材质 `.mtl` | `assets/bundles/region_meadow/materials/` | 跟 GLB 和贴图一起走 `region_meadow` 远程包 |
| 白天天空图 | `assets/bundles/region_meadow/textures/tex_meadow_sky_2048x1024.jpg` | 来源：`team/ggbot/reports/meadow/sky/meadow_sky_2048x1024.jpg`（SHA256 cc4dafd6…4e9e） |
| 夜景天空图 | `assets/bundles/region_meadow/textures/tex_meadow_sky_night_2048x1024.png` | 来源：`team/art/outbox-to-dot/20261009T2323Z-grokbot2-MEADOW-SKY-NIGHT-v0.1.png`（SHA256 57b4f29d…3d4d2f，已核对） |

## 二、在 Creator 里接入

1. **草材质** `mat_meadow_grass_wind.mtl`，Effect 选 `meadow-grass-wind`：
   - Defines：勾 `USE_INSTANCING`、`USE_INSTANCE_ROOT_COLOR`；`WIND_QUALITY` 设 **1**（数值宏默认是 0，也就是静止）；`GRASS_LIGHTING` 设 1。`WIND_SPACE`、`WIND_PHASE_PER_VERTEX` 保持默认（世界空间、按实例原点算相位）。
   - `mainTexture` 拖 `meadow_palette_256`，该贴图要先关 mipmap（参数表第四节）。其余参数用默认值，就是美术 README 的公式和配色。
2. 在 GLB 的材质映射里把 `M_meadow_grass_wind` 换成上面的材质。5 个草模板**共用这一个材质资源**：不要用 `getMaterialInstance()`，也不要单独给某个 renderer 改属性，否则实例化合批会被拆开。要改风参数，用 `setGrassWindParams(material, {...})`。
3. 草和花的 MeshRenderer 不投影。MeadowInstancer 生成的节点会自动设置。
4. **天空材质** `mat_meadow_sky.mtl`，Effect 选 `sky-unlit`：
   - `mainTexture` 拖白天图，`nightTexture` 拖夜景图；Defines 里 `SKY_FOLLOW_CAMERA` 设 1。
   - 要地平线雾就勾 `USE_HORIZON_FOG`，`horizonV` 保持 0.857。
   - 把它映射给 `M_meadow_sky`。
   - 昼夜过渡：脚本插值 `material.setProperty('nightBlend', 0…1)`。
   - 场景 Skybox 保持关闭，相机 ClearFlags 用 SOLID_COLOR。
   - 海岛 `env_sky_dome`：`SKY_SOURCE` 设 1（顶点色渐变），勾 `SKY_NIGHT_TINT_ONLY`，用 nightTint 压色。
5. 花簇（F0–F2）继续用 builtin-standard，材质勾 `USE_INSTANCING`。
6. 场景里挂 `MeadowInstancer`（草甸根节点）和 `GrassWindQualityAuto`（任意节点，target 指草甸根节点）。

### MeadowInstancer v1.1 做了什么

- **包围盒**：每生成一个实例，调用 `applyGrassWindBounds(renderer)`。
  - 读这个 renderer 当前材质里实际的 windStrength、amplitudeScale、各项权重、bendDrop 和 `WIND_QUALITY`，再读网格 a_color 的 max(a)，按网格缓存。
  - 算出位移上界：水平 `|d|max = strength·scale·maxA·(waveWeight + [高档] swayWeight + gustStrength)`，竖直 `bendDrop·|d|max`。
  - 把模型本地包围盒各方向扩 `√(水平² + 竖直²) / 最小缩放`，再加 2% 余量，然后 `model.createBoundingShape(min, max)` + `updateWorldBound()`。
  - 关档（WIND_QUALITY 0）时还原成网格原包围盒。v0.8 各模板的本地扩展量是 0.48–0.99 m（缩放小的实例扩得多）。
- **重算时机**：全局 `grassWindEvents` 上的 `grass-wind-quality-applied`（`applyGrassWindQuality` 每次都会发）和 `grass-wind-params-changed`（`setGrassWindParams` 发）。收到后对每个实例先重设 `a_root_color`（换材质时引擎会把实例属性清零），再重算包围盒。单个实例出错只打 warning，不影响其他实例。`onDestroy` 时注销监听。
- **已知限制**：
  - 引擎在 MeshRenderer **重新启用**或**换 mesh** 时，会把包围盒重置成网格原值（`_updateModels`）。草甸节点如果会被隐藏后再显示，显示后要调一次 `meadowInstancer.onWindChanged()`。
  - 节点在未激活状态下生成时，model 还不存在，这次跳过，下一次事件时再算。

## 三、画质档位（WIND_QUALITY）

| 档 | 顶点运算 | 用在 |
|---|---|---|
| 0 关 | 无（预处理后不含任何风代码，和静态网格走同一条路径） | 明确无法运行的设备、性能兜底 |
| 1 低 | 1 个 sin | 默认、未知机型、中低端机 |
| 2 高 | 4 个 sin（行波 + 整体摆动 + 阵风 2 个） | 高端机 |

自动选档的阈值来自微信《设备档位下的用户分布》（2026-03-04）：

| 条件 | 结果 |
|---|---|
| 没有 wx、benchmarkLevel 为 -1 或未知 | 低（modelLevel = 1 时升到高） |
| 0 / -2 | 关 |
| Android ≥ 30 / iOS ≥ 36 | 高 |
| 其余 | 低 |

读取顺序：`wx.getDeviceBenchmarkInfo`（基础库 ≥ 3.4.5，800 ms 超时）→ `getDeviceInfo` → `getSystemInfoSync`。

切档的做法：每一档复制一份运行时共享材质，所有草的 renderer 都换成同一份，实例化合批不会断。原因是 3.8.8 里共享材质不能 `recompileShaders`。切档会编译新的 shader 变体，可能卡一帧，所以只在进场或设置界面切。

## 四、光照选择

草用逐顶点半 Lambert：法线往 +Y 混 0.5，双面一致；加天空 / 地面半球环境光。片元里只有 1 次贴图采样和几次 mix，没用 builtin-standard 的 PBR。`GRASS_LIGHTING 0` = 完全不受光。草不接收实时阴影，也不投影。场景开了雾会自动生效。

## 五、draw call 和实例化

| 情况 | 草的 draw call |
|---|---|
| MeadowInstancer 展开 + 材质开 `USE_INSTANCING`（**唯一推荐路径**） | **5**（5 个模板各 1 个）；花 3 个；天空 1 个 |
| 材质没开实例化 | 1,000 |
| WebGL1 设备不支持 `ANGLE_instanced_arrays` | 引擎自动退化到 1,000。建议启动时打一条日志 |

不用静态合批：合批后每实例根色会丢，世界矩阵也不再是实例的。`WIND_PHASE_PER_VERTEX` 只是保留下来，项目里不开。切 `WIND_QUALITY` 不增加 draw call。包围盒扩大以后，视锥剔除会稍微保守一点（屏幕外 ≤ 1 m 的草也会画），这是有意的取舍。

## 六、贴图导入设置

| 项 | 白天图 / 夜景图（都是 2048×1024） | 调色板 `meadow_palette_256` |
|---|---|---|
| Mipmap | **关** | **关**（美术负责人确认） |
| 过滤 | linear | linear（看到色块串色就改 nearest） |
| Wrap | u = repeat（接缝连续，开滚动也需要）；v = clamp-to-edge | clamp-to-edge |
| 色彩空间 | sRGB，shader 里 `SRGBToLinear` | sRGB |
| 压缩 | ASTC 5×5 或 6×6 → Android 兜底 ETC2 RGB → PNG/JPG。夜景图暗部渐变多，先看有没有色带 | 建议不压缩 |

夜景图核对结果（自测）：SHA256 `57b4f29d316f7d2546dd20c4c7fd410b9859c410d4fccd371325ca0bfe3d4d2f`，2048×1024 RGB 无 alpha。地平线辉光最亮的一行是第 879 行，理论位置 877.7，吻合。左右接缝平均差 0.59，相邻列平均差 0.57，可以认为无缝。

**显存**（每张，无 mip）：RGBA8 8.0 MiB / ASTC 4×4 2.0 / 5×5 1.3 / 6×6 0.89 / ETC2 1.0 MiB。v1.1 默认加载白天 + 夜景两张，ASTC 6×6 合计约 1.8 MiB，未压缩合计 16 MiB。天空之城如果不需要夜晚，勾 `SKY_NIGHT_TINT_ONLY` 并不拖夜景图，可以省一张。

**UV 约定**（详见参数表）：Cocos 里 v = 0 是贴图顶行。Creator 3.8.8 导入 glTF 不翻转 v，已用本机 Creator 3.8.8 导入的 98,797 个顶点逐个核对；引擎上传贴图也不翻转。草甸天空球的地平线在 v = 0.857（第 878 行）。

## 七、自测（`selftest/`）

运行方法：
1. `bash selftest/cc-compiler-setup/setup.sh selftest/.cc-effect-compiler`（从本机 Creator 3.8.8 取出官方 effect 编译器，包里不分发）
2. `node selftest/run-selftest.js`

依赖：glslangValidator；Python 3 + Pillow + numpy（夜景图检查用）。

| 组 | 内容 | 结果 |
|---|---|---|
| a 结构 | YAML、入口函数、property↔UBO、std140、varying；v1.1 默认路径（相位取实例原点、默认采样夜景图）；effect 默认值和 CPU 参考一致、windDir = 归一化的 W；**UV 约定实测**（Creator 3.8.8 导入不翻转 v，引擎上传不翻转） | 通过 |
| b 编译 | 官方编译器 0 错误 0 警告；glslang 编译并链接：草 392 个宏组合 × 2 = 784 个程序，天空 104 × 2 = 208 个 | 通过 |
| c CPU 参考 | 根部 0、有界、关档无风代码、相位、行波、连续、与美术公式一致、float32 精度、v0.8 真实数据（max 0.809 m）；**天空雾带**：用真实天空球 UV 验证地平线那一圈 h = 1、往下全雾、往上单调变淡；**夜景图**：SHA、尺寸、地平线行、接缝 | 通过 |
| d TS | GrassWindQuality.ts 严格类型检查；分档 13 例；wx 5 种情况；切档共用同一份材质 | 通过 |
| e MeadowInstancer | 两个文件一起严格类型检查；1,000 个实例 × 真实顶点 × 60 个时刻，410 万个位移后的顶点**全部在扩展后的包围盒内**（最小余量 0.26 m）；maxA 从 uint16 顶点数据读出，与 GLB 一致；切档后包围盒按档重算，关档还原，强度翻倍时扩展量也翻倍；切三次档后 1,000 个根色都重设正确；防错；注销监听 | 通过 |
| 反向对照 | 故意改坏 4 处 shader 都被查出；不扩包围盒时 17 万个样本顶点出界；不监听事件时根色全部丢失；v1 的雾带写法在真实 UV 上把雾放到了天顶 | 通过 |
| not_run | Creator 编辑器导入 / 材质面板；构建 + 压缩纹理；DevTools / 真机渲染；实际 draw call；帧时间；画面观感 | 未运行 |

UV 实测用的是本机 `/tmp/projA`（Creator 3.8.8 已导入的工程）。这个目录不在了，那一项会记为 not_run，不会算失败。

## 八、还没定的

1. 天空之城要不要夜景图？不要的话就用 `SKY_NIGHT_TINT_ONLY`，请给一个 nightTint。
2. 白天天空图用已缩好的 2048×1024，还是美术重新出图？
3. 建议美术下次导出时，把 GLB 里调色板的采样器 minFilter 改成 LINEAR，这样导入后不用再手动关 mipmap。
4. 光照强度（lightScale / ambientScale）要美术在 Creator 里对着场景调。
5. 地平线雾带宽度（默认 0.12，约 12.6°）要等看过画面再定。
