# E4 材质参数表 v1.1（meadow-grass-wind / sky-unlit）

GGbot（grokbot2）· 2026-10-09 · v1.1 按美术负责人答复修改 · 对应 Cocos Creator 3.8.8。默认值和范围都写在 `.effect` 里；这里是给美术和接入的人看的说明。
颜色属性全部按 **sRGB 拾色**（面板里看到的就是实际颜色），shader 里再转线性。没有用引擎的 `linear: true`：3.8.8 里 effect 自带的默认值不会经过 sRGB→线性转换（`Pass.resetUniform` 直接上传），只有材质里保存过的值才转，默认颜色会偏亮。

## 一、COLOR_0 约定（美术侧契约，草模板必须满足）

`meadow-grass-wind` 把 COLOR_0（Cocos 里叫 `a_color`）当 **风数据**，不是乘色。

| 通道 | 含义 | 取值 | v0.8 实测（5 个草模板，`meadow_grass_clump_templates_v0_8.glb`） |
|---|---|---|---|
| r | 弯曲权重：根 0 → 尖 1。位移按 r² 放大，根部固定 | 0–1；根部顶点必须正好 0 | 每个模板只有 4 个值：0 / 0.4 / 0.75 / 1.0（每片叶 4 圈）；r = 0 的顶点都在 y = −0.05 m（埋进地面 5 cm） |
| g | 相位偏移 / 2π（同一丛里不同叶子错开） | 0–1 | 0.000–0.999，每模板 8–9 个不同值 |
| b | **无意义，忽略，预留**（美术负责人确认：导出常量） | 任意 | 恒为 0.4193 |
| a | 振幅 / `amplitudeScale`（默认 1.5 m） | 0–1 | T0 0.504–0.737；T1 0.456–0.639；T2 0.435–0.568；T3 0.300–0.449；T4 0.239–0.390 |

- 存储格式：v0.8 实际是 **UNSIGNED_SHORT 归一化**（美术 README 写的是 FLOAT），shader 里同样是 0–1 的 vec4，没有影响；`MeadowInstancer` 读包围盒用的 max(a) 时两种格式都支持。
- 每个模板的 max(a)（包围盒按这个算）：T0 0.737 / T1 0.639 / T2 0.568 / T3 0.449 / T4 0.390。
- 花簇模板（F0/F1/F2）没有 COLOR_0，用 `M_meadow_palette`（builtin-standard），不挂风材质。
- 每实例根色 `_ROOT_COLOR`（线性 RGB）：Cocos 导入器不读 `EXT_mesh_gpu_instancing`，由 `MeadowInstancer` 用 `setInstancedAttribute('a_root_color', [r, g, b, 1])` 传，材质要勾 `USE_INSTANCING` + `USE_INSTANCE_ROOT_COLOR`。1,000 个实例的线性均值 (0.109, 0.387, 0.031)，转 sRGB = #5DA731，这就是 `rootColor` 的默认兜底值。

## 二、meadow-grass-wind.effect

### 宏（材质面板 Defines）

| 宏 | 取值 | 默认 | 说明 |
|---|---|---|---|
| `USE_INSTANCING` | 开/关 | 关 | **草必须开**。同 mesh + 同一个共享材质的 MeshRenderer 合成一次实例化 draw call |
| `USE_INSTANCE_ROOT_COLOR` | 开/关 | 关 | **草必须开**。根色用每实例 `a_root_color`（只在 `USE_INSTANCING` 下生效）；关：所有草用同一个 `rootColor` |
| `WIND_QUALITY` | 0 / 1 / 2 | **0** | 0 关（静态，不做任何顶点运算）；1 低（单个行波正弦）；2 高（美术原公式两项 + 阵风）。引擎里数值宏默认取范围第一个值，所以**材质里要手动设 1 或 2**，或者用 `GrassWindQualityAuto` 运行时设 |
| `WIND_SPACE` | 0 / 1 | **0（定稿）** | 0 世界空间：整片草沿 `windDir` 一起倒，丛与丛的差异来自 COLOR_0.g 相位 + 实例原点的空间相位（美术负责人确认用这个）；1 模板本地 +X（美术早期写法，已被美术废弃，仅保留做对比） |
| `WIND_PHASE_PER_VERTEX` | 开/关 | 关 | v1.1 取代 v1 的 `WIND_PHASE_ORIGIN`。关（默认）= 用实例原点算空间相位，整丛同相，GPU 实例化路径。开 = 用顶点世界坐标，只给合并网格用；**项目不走静态合批，不要开** |
| `GRASS_LIGHTING` | 0 / 1 | 0 | 0 不受光（颜色 = 根→尖混色 × mainColor）；1 逐顶点半 Lambert + 天空/地面环境光 |
| `USE_ALPHA_TEST` | 开/关 | 关 | v0.8 草是实体几何（opaque），不需要；以后换插片草时再开 |
| `CC_USE_FOG` 等 | 引擎管 | — | 场景雾开了会自动生效 |

草甸草丛材质（定稿）：`USE_INSTANCING=1, USE_INSTANCE_ROOT_COLOR=1, WIND_QUALITY=1（运行时由 GrassWindQualityAuto 按机型改）, GRASS_LIGHTING=1`；`WIND_SPACE`、`WIND_PHASE_PER_VERTEX` 保持默认。

### 属性

| 属性 | 默认 | 范围 | 写入 | 说明 |
|---|---|---|---|---|
| mainTexture | white | — | sampler | 调色板 `meadow_palette_256`（sRGB），按 TEXCOORD_0 采样 |
| tilingOffset | (1,1,0,0) | — | GrassWindVS.tilingOffset | UV 缩放/偏移 |
| mainColor | (1,1,1,1) | 颜色 | GrassWindFS.mainColor | 整体乘色；a 乘到透明度（只对 alpha test 有意义） |
| tipColor | (0.769,0.902,0.353) = #C4E65A | 颜色 | GrassWindFS.tipColor | 草尖调色（美术 README） |
| tipMix | 0.6 | 0–1 | colorParams.y | tip = mix(调色板色, tipColor, tipMix) |
| rootBlendStart | 0.05 | −1–1 | colorParams.z | 根→尖混合：smoothstep(start, end, COLOR_0.r) |
| rootBlendEnd | 0.95 | −1–2 | colorParams.w | start/end 都设成负数 = 不要根色，全用 tip |
| alphaThreshold | 0.5 | 0–1 | colorParams.x | 仅 `USE_ALPHA_TEST` |
| rootColor | (0.364,0.655,0.194) = #5DA731 | 颜色 | GrassWindVS.rootColor | 根色兜底（未开每实例根色时） |
| windDir | (0.94398, −0.32999) | 任意非零 | windDirSpeed.xy | 世界 XZ 风向（x, z），shader 内再归一化。默认 = 美术 README v0.8（2026-10-09 修订）主风向 W = (0.944, −0.330) 的归一化，世界空间定稿 |
| windSpeed | 6.5 m/s | 0–30 | windDirSpeed.z | 风浪推进速度；周期 = 波长 / 速度 = 4 s |
| windWavelength | 26 m | 1–200 | windDirSpeed.w | 风浪波长（美术 26 m） |
| windStrength | 1.0 | 0–3 | windShape.x | 总倍率；0 = 不动（但顶点运算仍在，想省就设 WIND_QUALITY 0） |
| amplitudeScale | 1.5 m | 0–3 | windShape.y | COLOR_0.a 的米制换算（美术 1.5 m） |
| waveWeight | 0.36 | 0–1 | windShape.z | 行波项权重（美术 0.36） |
| swayWeight | 0.26 | 0–1 | windShape.w | 整体摆动项（美术 0.26），仅 WIND_QUALITY 2 |
| gustStrength | 0.15 | 0–1 | gustParams.x | 阵风权重，仅 WIND_QUALITY 2；**设 0 = 与美术公式逐项一致** |
| gustFreq | 0.12 Hz | 0–2 | gustParams.y | 阵风频率 |
| gustWavelength | 40 m | 1–200 | gustParams.z | 阵风团大小 |
| bendDrop | 0.3 | 0–1 | gustParams.w | y −= bendDrop × d × r（美术 0.3） |
| normalUpBlend | 0.5 | 0–1 | lightParams.x | 法线往 +Y 混，草丛受光更柔、双面一致（GRASS_LIGHTING） |
| wrapLighting | 0.5 | 0–1 | lightParams.y | 0 Lambert，1 半 Lambert |
| lightScale | 0.318（1/π） | 0–4 | lightParams.z | 主光倍率，默认与 builtin-standard 漫反射同量级 |
| ambientScale | 1.0 | 0–4 | lightParams.w | 环境光倍率 |

### 位移公式（shader 原文的意思）

```
A   = windStrength * amplitudeScale * COLOR_0.a                       // 米
k   = 2π / windWavelength ;  ωt = k * windSpeed * t                    // t = cc_time.x（秒）
ph  = k * dot(P, dir) + 2π * COLOR_0.g                                 // P = 实例原点 XZ（默认）；WIND_PHASE_PER_VERTEX 时为顶点世界 XZ
w   = waveWeight * sin(ph − ωt)                                        // WIND_QUALITY ≥ 1
w  −= swayWeight * sin(ωt)                                             // WIND_QUALITY 2
w  += gustStrength * max(0, sin(gk·dot(P,dir) − 2π·gustFreq·t)) * (0.5 + 0.5·sin(0.588·gk·dot(P,perp) + 0.37·2π·gustFreq·t))   // WIND_QUALITY 2，gk = 2π/gustWavelength
d   = A * r² * w                                                       // r = COLOR_0.r，根部 r = 0 时 d = 0
世界空间：worldPos.xz += dir * d ; worldPos.y −= bendDrop * d * r
```

- |d| ≤ A·r²·(waveWeight + [WIND_QUALITY 2] swayWeight + gustStrength)；默认权重和 0.77，所以草尖位移不超过 `windStrength × amplitudeScale × a`。
- 用 v0.8 实际数据算（0–9 s 每 0.15 s 采样）：草尖水平位移最大 0.81 m，竖直最大 0.24 m；解析上界 1.5 × 0.737 × 0.77 = 0.851 m（v1 报告的 0.69 m 只采了 4 个时刻，偏小）。
- `MeadowInstancer` 按这个上界（从材质实际参数 + 网格 max(a) 算，不写死）扩大每个实例的包围盒，见 README 第二节。
- 默认参数（世界空间）、`gustStrength = 0`、`WIND_QUALITY 2` 时，位移量 d 和美术 README（2026-10-09 修订版）的公式一致：windDir 取精确归一化的 W 误差 < 1e−9 m，effect 里 5 位小数的默认值误差 0.03 mm（自测 C6）。

## 三、sky-unlit.effect

### 宏

| 宏 | 取值 | 默认 | 说明 |
|---|---|---|---|
| `SKY_SOURCE` | 0 / 1 / 2 | 0 | 0 贴图（草甸 `meadow_sky`）；1 只用顶点色（海岛 `env_sky_dome` 的渐变）；2 贴图 × 顶点色 |
| `SKY_FOLLOW_CAMERA` | 0 / 1 | 0 | 1 = 天空球中心跟随相机 XZ（美术约定，**建议设 1**） |
| `SKY_NIGHT_TINT_ONLY` | 开/关 | 关 | v1.1 取代 v1 的 `USE_NIGHT_TEXTURE`。关（默认）= **夜景图路径**：采样 `nightTexture`（美术给的 2048×1024 夜景天空，和白天图 UV 对齐），按 nightBlend 混。开 = 没有夜景图的天空（如海岛顶点色天空）：夜晚 = 白天颜色 × nightTint |
| `USE_UV_SCROLL` | 开/关 | 关 | u 方向慢速滚动（贴图 u 要 REPEAT） |
| `USE_HORIZON_FOG` | 开/关 | 关 | 地平线附近混到场景雾颜色 `cc_fogColor`（不走引擎雾，天空在 280 m 外，用引擎雾会整片变成雾色） |

### 属性

| 属性 | 默认 | 范围 | 写入 | 说明 |
|---|---|---|---|---|
| mainTexture | grey | — | sampler | 白天天空图（sRGB），按 TEXCOORD_0 采样 |
| nightTexture | black | — | sampler | **夜景天空图（默认夜晚路径）**：`tex_meadow_sky_night_2048x1024.png`（美术 2026-10-09 交付，SHA256 57b4f29d…3d4d2f，2048×1024 RGB，和白天图同一套 UV，地平线辉光在第 878 行附近，左右无缝）。导入设置同白天图（关 mipmap）。没拖图时是黑色，nightBlend 保持 0 就看不出来 |
| tilingOffset | (1,1,0,0) | — | SkyVS.tilingOffset | |
| dayTint | (1,1,1,1) | 颜色 | SkyFS.dayTint | 白天图乘色 |
| nightTint | (1,1,1,1) | 颜色 | SkyFS.nightTint | 夜景图乘色（v1.1 默认改成白色，夜景图原样显示）；`SKY_NIGHT_TINT_ONLY` 时用它把白天压成夜色，例如 (0.32,0.38,0.62) |
| nightBlend | 0 | 0–1 | skyParams.x | 0 白天 → 1 夜晚；昼夜过渡时用脚本插值（`setProperty('nightBlend', x)`）。颜色 = mix(白天图×dayTint, 夜景图×nightTint, nightBlend) × intensity |
| intensity | 1.0 | 0–4 | skyParams.y | 整体亮度 |
| scrollSpeed | 0.002 | ±0.05 | skyVSParams.x | 每秒滚动多少 u（0.002 ≈ 8 分钟一圈）；仅 USE_UV_SCROLL |
| horizonFog | 0 | 0–1 | horizonParams.x | 地平线雾强度；仅 USE_HORIZON_FOG |
| horizonV | **0.857** | 0–1 | horizonParams.y | 地平线所在 v，**从贴图顶边往下量**（见下方 UV 约定）。草甸天空球 v = 1 − (仰角+15°)/105°，仰角 0° → 90/105 = 0.857（第 878 行）。v1 的 0.143 是按“从底往上”算的，方向错了 |
| horizonWidth | 0.12 | 0.001–1 | horizonParams.z | 雾从地平线往上（v 变小的方向）淡出的 v 宽度；0.12 ≈ 仰角 12.6°。地平线及以下（v ≥ horizonV）始终全雾 |

**UV 约定（v1.1 核实，写进了 effect 注释）**：shader 里的 v = `a_texCoord.y` = GLB 里 TEXCOORD_0 的原值，**0 = 贴图顶行（天顶），往下变大**。依据：
1. glTF 规定 UV 原点在左上；
2. Creator 3.8.8 导入 glTF 不翻转 v：本机已用 Creator 3.8.8 导入的工程里 `combined_visual_m.glb` 的 13 个网格、98,797 个顶点，导入后的 `a_texCoord` 和 GLB 原值完全相同，没有一个是 1−v（自测 a-structure）；
3. 引擎在 WebGL1/WebGL2 上传贴图时 `UNPACK_FLIP_Y_WEBGL = false`（`cocos/gfx/webgl/webgl-swapchain.ts`、`webgl2/webgl2-swapchain.ts`），图片第一行就是 v = 0。
美术 README 里写的 “v = (仰角+15°)/105°” 是从底边往上量的，GLB 里存的是 1 − 它。雾带公式：`h = smoothstep(horizonV − horizonWidth, horizonV, v)`，地平线 h = 1，往上淡出（自测用真实天空球 UV 验过）。

渲染状态（effect 里写死）：`priority: max - 10`、`depthTest: true`、`depthWrite: false`、`cullMode: none`、顶点 z 推到远平面（`0.99999·w`，与引擎内置 skybox 相同）。

## 四、调色板贴图 `meadow_palette_256`（v1.1）

美术负责人确认：**关 mipmap**。调色板是色块拼图，mipmap 会把相邻色块混在一起，远处的草会串色。

| 项 | 设置 |
|---|---|
| Mipmap | **关**（Creator 贴图面板 Mip Filter = none） |
| 过滤 | min / mag = linear（和 GLB 采样器一致）；如果在 Creator 里看到色块边缘串色，改成 nearest |
| Wrap | clamp-to-edge（GLB 采样器原值） |
| 压缩 | 建议不压缩（256×256 RGBA8 = 256 KiB）；块压缩可能让色块颜色偏移，要压就先对比 |

`.meta` 写法：调色板嵌在 GLB 里时，Creator 给它生成一个 `texture` 子资源（`UnnamedTexture-N.texture`，`imageUuidOrDatabaseUri` 指向 `…@<id>` 的 `meadow_palette_256.image`），GLB 采样器是 LINEAR_MIPMAP_LINEAR，所以默认 `mipfilter` 是 `"linear"`。在 Creator 里选中 GLB → 展开该 texture 子资源 → Mip Filter 改 none → 应用，`.meta` 里对应项变成：

```json
"userData": { "wrapModeS": "clamp-to-edge", "wrapModeT": "clamp-to-edge", "minfilter": "linear", "magfilter": "linear", "mipfilter": "none", "anisotropy": 0, ... }
```

（字段名取自本项目 `creator-build-project` 里已有的 `combined_visual_m.glb.meta` 和 `pieces.png.meta`。）在编辑器里改，不要手改 `.meta`。最好让美术下次导出时把 GLB 采样器 minFilter 改成 LINEAR（9729），这样导入就不需要再手动改。
