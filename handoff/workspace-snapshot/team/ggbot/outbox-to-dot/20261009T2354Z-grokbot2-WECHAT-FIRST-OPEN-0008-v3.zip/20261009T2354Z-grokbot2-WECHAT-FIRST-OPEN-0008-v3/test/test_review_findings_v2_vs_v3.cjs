'use strict';
/**
 * 0008 v3 — cloud review findings (OI-0008-0005B-CLOUD-REVIEW 0008, P1-01…06), each replayed against the EXACT v2 code
 * (test/v2-baseline, SHA list in V2-SOURCE-SHA256SUMS.txt) and against v3 (tools/). Same fakes, same build, same finalizer
 * (Oi 12ef697 + 0008-v2 patch). A scenario passes when v2 shows the recorded misjudgement AND v3 gives the correct verdict.
 * DRY RUN: fake CLI + fake automation server + real miniprogram-automator 0.12.1 client. Not DevTools behaviour.
 *   QF_MINIPROGRAM_AUTOMATOR_MODULE=<dir> node test/test_review_findings_v2_vs_v3.cjs <evidenceOutDir> [scenarioFilter]
 */
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), crypto = require('crypto');
const ROOT = path.resolve(__dirname, '..'), FX = path.join(__dirname, 'fixtures');
const OUT = path.resolve(process.argv[2] || fs.mkdtempSync(path.join(os.tmpdir(), 'qf0008v3-review-')));
const FILTER = process.argv[3] ? new RegExp(process.argv[3]) : null;
fs.mkdirSync(OUT, {recursive: true});
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qf0008v3-rw-'));
const repo = path.join(tmp, 'repo'); fs.mkdirSync(path.join(repo, 'tools'), {recursive: true});
fs.copyFileSync(path.join(FX, 'oi-finalize_wechat_local-12ef697.cjs'), path.join(repo, 'tools/finalize_wechat_local.cjs'));
cp.execFileSync('git', ['init', '-q'], {cwd: repo});
cp.execFileSync('git', ['apply', path.join(ROOT, '0008-v2-finalize_wechat_local.patch')], {cwd: repo});
const FINALIZER = path.join(repo, 'tools/finalize_wechat_local.cjs');
const AUDIT = {v2: path.join(__dirname, 'v2-baseline/wechat_first_open_audit.cjs'), v3: path.join(ROOT, 'tools/wechat_first_open_audit.cjs')};
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const build = path.join(tmp, 'build'); fs.mkdirSync(build);
fs.copyFileSync(path.join(FX, 'oi-r6efg/g-project.config.json'), path.join(build, 'project.config.json')); // Oi's real G config (official template condition, enhance=false)
fs.writeFileSync(path.join(build, 'game.json'), JSON.stringify({deviceOrientation: 'portrait'}, null, 2));
fs.copyFileSync(path.join(FX, 'fake-build-game.js'), path.join(build, 'game.js'));

const IDE_ONLY_ERROR = '[game.json 文件内容错误] fake IDE-only error written to WeappLog';
const S = [
  // finding, id, env (fake knobs), prep(logDir), v2 expected (the misjudgement), v3 expected, extra checks
  {finding: 'a', id: 'a1-log-root-is-WeappLog-dir', layout: 'direct', env: {QF_FAKE_LOG_LAYOUT: 'direct', QF_FAKE_WEAPPLOG_ERROR: IDE_ONLY_ERROR}, v2: 'PASS', v3: 'FAIL', why: 'v2 only scans *below* a dir named WeappLog, so a root that IS the WeappLog dir yields 0 files'},
  {finding: 'a', id: 'a2-log-root-created-late', lateRoot: true, env: {QF_FAKE_WEAPPLOG_ERROR: IDE_ONLY_ERROR}, v2: 'FAIL', v3: 'FAIL', v2Correct: true, why: 'already fixed in v2 (delta read when the root appears during the run); kept as regression'},
  {finding: 'a', id: 'a3-log-truncated-then-error', preLog: 65536, env: {QF_FAKE_LOG_TRUNCATE: '1', QF_FAKE_WEAPPLOG_ERROR: IDE_ONLY_ERROR}, v2: 'PASS', v3: 'FAIL', why: 'v2 skips a file whose size <= old size; the post-truncation error is never read'},
  {finding: 'a', id: 'a4-log-truncated-no-error', preLog: 65536, env: {QF_FAKE_LOG_TRUNCATE: '1'}, v2: 'PASS', v3: 'BLOCKED', why: 'a truncation is a possible gap: v3 must not PASS on incomplete capture'},
  {finding: 'a', id: 'a5-error-after-9MiB', env: {QF_FAKE_LOG_BIG_MIB: '9', QF_FAKE_WEAPPLOG_ERROR: IDE_ONLY_ERROR}, v2: 'PASS', v3: 'FAIL', why: 'v2 reads at most 8 MiB per file and silently drops the rest'},
  {finding: 'b', id: 'b1-other-window-notice-allowlisted', env: {QF_FAKE_NO_WEAPPLOG: '1', QF_FAKE_FOREIGN: '1', QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE: '1'}, v2: 'PASS_WITH_ALLOWLISTED_IDE_NOTICE', v3: 'BLOCKED', why: 'another window\'s log lines stood in for this project; this project\'s log channel was never proven'},
  {finding: 'b', id: 'b2-other-window-notice-attributed-to-us', env: {QF_FAKE_NO_WEAPPLOG: '1', QF_FAKE_FOREIGN: '1'}, v2: 'FAIL', v3: 'BLOCKED', why: 'v2 blames this project for another window\'s notice'},
  {finding: 'b', id: 'b3-other-window-healthy-only', env: {QF_FAKE_NO_WEAPPLOG: '1', QF_FAKE_FOREIGN: 'healthy'}, v2: 'PASS', v3: 'BLOCKED', why: 'only another window writes WeappLog; v2 never asks whether this project reached the log'},
  {finding: 'c', id: 'c1-cli-auto-exit-7', env: {QF_FAKE_CLI_LINGER_MS: '3000', QF_FAKE_CLI_EXIT: '7'}, v2: 'PASS', v3: 'BLOCKED', why: 'v2 ignores the CLI exit code once automator is connected'},
  {finding: 'c', id: 'c2-resident-cli-late-error', env: {QF_FAKE_CLI_LINGER_MS: '21000', QF_FAKE_CLI_LATE_LINE: '[game.json 文件内容错误] fake CLI error printed while resident', QF_FAKE_CLI_LATE_AT_MS: '3000'}, v2: 'PASS', v3: 'FAIL', why: 'v2 Promise.race(15 s) replaces the live CLI output with a placeholder'},
  {finding: 'c', id: 'c3-cli-close-exit-5', env: {QF_FAKE_CLOSE_EXIT: '5'}, v2: 'PASS', v3: 'BLOCKED', why: 'v2 does not check that its own window was closed'},
  {finding: 'd', id: 'd1-no-log-dir-at-all', noLogDir: true, env: {QF_FAKE_NO_WEAPPLOG: '1'}, v2: 'PASS', v3: 'BLOCKED', why: 'no log channel at all and no positive control, yet v2 PASSes'},
  {finding: 'd', id: 'd2-log-dir-without-own-lines', env: {QF_FAKE_NO_WEAPPLOG: '1'}, v2: 'PASS', v3: 'BLOCKED', why: 'log root exists but this project never wrote to it'},
  {finding: 'e', id: 'e1-resident-cli-manifest', env: {QF_FAKE_CLI_LINGER_MS: '21000'}, v2: 'PASS', v3: 'BLOCKED', v2ManifestBroken: true, why: 'v2 writes the manifest while its CLI child still runs; the child\'s exit later appends run.log'},
  {finding: 'control', id: 'z1-clean-run', env: {}, v2: 'PASS', v3: 'PASS', v2Correct: true, why: 'sanity: everything proven → both PASS'},
];

function verifySums(dir) {
  const f = path.join(dir, 'SHA256SUMS.txt'); if (!fs.existsSync(f)) return {ok: false, why: 'no SHA256SUMS.txt'};
  const bad = []; for (const l of fs.readFileSync(f, 'utf8').trim().split('\n')) { const i = l.indexOf('  '), p = l.slice(i + 2); if (!fs.existsSync(path.join(dir, p)) || sha(path.join(dir, p)) !== l.slice(0, i)) bad.push(p); }
  return {ok: !bad.length, mismatched: bad};
}
let port = 10100;
const results = [];
for (const s of S) {
  if (FILTER && !FILTER.test(s.id)) continue;
  const row = {finding: s.finding, scenario: s.id, why: s.why, expectV2: s.v2, expectV3: s.v3};
  for (const ver of ['v2', 'v3']) {
    const sd = path.join(tmp, s.id, ver); fs.mkdirSync(sd, {recursive: true});
    let logDir = path.join(sd, 'devtools-userdata');
    if (s.layout === 'direct') { logDir = path.join(sd, 'devtools-userdata', 'WeappLog'); fs.mkdirSync(logDir, {recursive: true}); }
    else if (s.noLogDir) logDir = path.join(sd, 'does-not-exist');
    else if (!s.lateRoot) fs.mkdirSync(logDir, {recursive: true});
    if (s.preLog) { const f = path.join(logDir, 'fakehash0008/WeappLog/logs/fake-devtools.log'); fs.mkdirSync(path.dirname(f), {recursive: true}); fs.writeFileSync(f, ('[2026-10-09T00:00:00Z] old line from an earlier session\n').repeat(Math.ceil(s.preLog / 52))); }
    const out = path.join(OUT, s.id, ver);
    const e = {...process.env, QF_FIRST_OPEN_DRY_RUN: '1', QF_WECHAT_CLI: path.join(__dirname, 'fake-wechat-cli.cjs'), QF_WECHAT_BUILD_DIR: build, QF_FINALIZER: FINALIZER,
      QF_FIRST_OPEN_WORK_ROOT: path.join(sd, 'copies'), QF_FIRST_OPEN_OUT: out, QF_AUTO_PORT: String(port), QF_FIRST_OPEN_SETTLE_MS: '2500', QF_FIRST_OPEN_LAUNCH_TIMEOUT_MS: '20000',
      QF_DEVTOOLS_LOG_DIR: logDir, QF_FAKE_STATE_DIR: path.join(sd, 'fake-state'), QF_CLI_DRAIN_MS: '2000', QF_WEAPPLOG_SETTLE_MS: '500',
      QF_FAKE_NO_NOTICE: '1', QF_FAKE_SCENARIO: '', QF_FIRST_OPEN_CASES: '', QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE: '', QF_DEVTOOLS_QUIT_FIRST: '', ...s.env};
    port += 2;
    const t0 = Date.now();
    const r = cp.spawnSync(process.execPath, [AUDIT[ver]], {env: e, encoding: 'utf8', timeout: 240000});
    let v = null; try { v = JSON.parse(fs.readFileSync(path.join(out, 'verdict.json'), 'utf8')); } catch {}
    const after = verifySums(out);
    let stdoutJson = null; try { stdoutJson = JSON.parse(r.stdout.trim().split('\n').pop()); } catch {}
    row[ver] = {status: v && v.status, exit: r.status, reason: v && v.reason, manifestAfterExit: after, selfCheck: stdoutJson && stdoutJson.selfCheck, ms: Date.now() - t0};
    fs.writeFileSync(path.join(out, '..', `${ver}-stdout-stderr.txt`), `exit=${r.status}\n--- stdout\n${r.stdout}\n--- stderr\n${r.stderr}`);
  }
  const v2wrong = row.v2.status === s.v2 && (s.v2ManifestBroken ? !row.v2.manifestAfterExit.ok : true);
  const v3right = row.v3.status === s.v3 && row.v3.manifestAfterExit.ok && row.v3.selfCheck && row.v3.selfCheck.ok;
  row.ok = v2wrong && v3right;
  row.v2Misjudged = !s.v2Correct;
  results.push(row);
  console.log(`${row.ok ? 'PASS' : 'FAIL'} [${s.finding}] ${s.id}: v2=${row.v2.status}${row.v2.manifestAfterExit.ok ? '' : ' (manifest broken after exit: ' + row.v2.manifestAfterExit.mismatched.join(',') + ')'} expected ${s.v2}${s.v2Correct ? '' : ' (misjudged)'} | v3=${row.v3.status} expected ${s.v3}, manifest ${row.v3.manifestAfterExit.ok ? 'ok' : 'BROKEN'}\n      v3 reason: ${row.v3.reason}`);
}
const passed = results.filter((x) => x.ok).length;
fs.writeFileSync(path.join(OUT, 'review-findings-summary.json'), JSON.stringify({scope: 'DRY RUN (fake CLI/server, real automator client). v2 = exact 0008-v2 code in test/v2-baseline; v3 = tools/.', passed, total: results.length, results}, null, 2));
console.log(`\n${passed}/${results.length} passed`);
process.exit(passed === results.length ? 0 : 1);
