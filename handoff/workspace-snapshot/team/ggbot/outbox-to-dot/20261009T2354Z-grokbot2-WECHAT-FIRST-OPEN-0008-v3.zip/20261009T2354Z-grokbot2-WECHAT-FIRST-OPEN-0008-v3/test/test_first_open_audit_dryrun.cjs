'use strict';
/**
 * 0008 v3 dry-run of tools/wechat_first_open_audit.cjs: FAKE CLI + fake automation server, REAL miniprogram-automator client,
 * REAL finalizer = Oi 12ef697 + 0008-v2 patch (git apply here). Proves plumbing/verdict logic only — NOT DevTools behaviour.
 *   QF_MINIPROGRAM_AUTOMATOR_MODULE=<dir> node test/test_first_open_audit_dryrun.cjs [outDir]
 */
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), crypto = require('crypto'), assert = require('assert');
const ROOT = path.resolve(__dirname, '..'), FX = path.join(__dirname, 'fixtures');
const OUT = path.resolve(process.argv[2] || fs.mkdtempSync(path.join(os.tmpdir(), 'qf0008v2-dry-')));
fs.mkdirSync(OUT, {recursive: true});
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qf0008v2-dryw-'));
const repo = path.join(tmp, 'repo'); fs.mkdirSync(path.join(repo, 'tools'), {recursive: true});
const ORIGINAL = path.join(FX, 'oi-finalize_wechat_local-12ef697.cjs');
fs.copyFileSync(ORIGINAL, path.join(repo, 'tools/finalize_wechat_local.cjs'));
cp.execFileSync('git', ['init', '-q'], {cwd: repo});
cp.execFileSync('git', ['apply', path.join(ROOT, '0008-v2-finalize_wechat_local.patch')], {cwd: repo});
const PATCHED = path.join(repo, 'tools/finalize_wechat_local.cjs');
function mkBuild(name, cfg) {
  const b = path.join(tmp, name); fs.mkdirSync(path.join(b, 'subpackages/resources'), {recursive: true});
  fs.copyFileSync(cfg, path.join(b, 'project.config.json'));
  fs.writeFileSync(path.join(b, 'game.json'), JSON.stringify({deviceOrientation: 'portrait', subpackages: [{name: 'resources', root: 'subpackages/resources/'}]}, null, 2));
  fs.copyFileSync(path.join(FX, 'fake-build-game.js'), path.join(b, 'game.js'));
  fs.writeFileSync(path.join(b, 'subpackages/resources/game.js'), '// fake subpackage\n');
  return b;
}
const TEMPLATE = path.join(FX, 'creator388-template-from-oi.project.config.json');
const build = mkBuild('wechatgame-r6-audio', path.join(FX, 'oi-r6startup/audio-project.config.json'));
const buildTpl = mkBuild('wechatgame-creator388-template', TEMPLATE);
const activeCfg = path.join(tmp, 'active.json'); const ac = JSON.parse(fs.readFileSync(TEMPLATE, 'utf8')); ac.condition.miniprogram = {current: 0, list: [{pathName: 'pages/index/index'}]}; fs.writeFileSync(activeCfg, JSON.stringify(ac, null, 2));
const buildActive = mkBuild('wechatgame-active', activeCfg);
const buildLink = mkBuild('wechatgame-symlink', path.join(FX, 'oi-r6startup/audio-project.config.json')); fs.symlinkSync('/etc/hostname', path.join(buildLink, 'linked.txt'));
const treeHash = (d) => { const h = crypto.createHash('sha256'); const walk = (r) => { for (const e of fs.readdirSync(path.join(d, r), {withFileTypes: true}).sort((a, b) => a.name.localeCompare(b.name))) { const p = path.join(r, e.name); if (e.isDirectory()) walk(p); else if (e.isSymbolicLink()) { h.update(p + '->' + fs.readlinkSync(path.join(d, p))); } else { h.update(p); h.update(fs.readFileSync(path.join(d, p))); } } }; walk(''); return h.digest('hex'); };
const builds = [build, buildTpl, buildActive, buildLink], hashes0 = builds.map(treeHash);
const srcs = (v, i = 0) => [...new Set(v.variants[i].errors.map((e) => e.source))];
const nsrcs = (v, i = 0) => [...new Set((v.variants[i].knownNotice || []).map((e) => e.source))];

let port = 9820;
const foreignState = path.join(tmp, 'fake-state');
const cases = [
  {name: '01-default-notice-weapplog-unattributed', env: {}, expect: 'BLOCKED', check: (v) => { assert.match(v.reason, /not attributable to this project \(weapplog:known-ide-notice\)/); assert.strictEqual(v.variants[0].errors.length, 0); }},
  {name: '02-default-notice-allowlisted', env: {QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE: '1'}, expect: 'PASS_WITH_ALLOWLISTED_IDE_NOTICE', exit: 3, check: (v) => assert.match(v.reason, /0 own, 1 not attributable/)},
  {name: '03-default-zero-red', env: {QF_FAKE_NO_NOTICE: '1'}, expect: 'PASS', check: (v) => { const c = v.variants[0].channels; assert.ok(c.weappLog.ownCanary && c.shim.canaryAtBoot && c.automatorConsole.lateCanary && c.cli.launchOk && c.cli.closeOk); }},
  {name: '04-diag-appid', env: {QF_FIRST_OPEN_CASES: 'default,diag-appid', QF_FIRST_OPEN_DIAG_APPID: 'touristappid'}, expect: 'BLOCKED', check: (v) => { assert.strictEqual(v.diagnostics[0].status, 'PASS'); assert.match(v.variants[1].steps.diagnostic, /touristappid/); }},
  {name: '05-diag-appid-missing', env: {QF_FIRST_OPEN_CASES: 'default,diag-appid'}, expect: 'BLOCKED', check: (v) => assert.match(v.diagnostics[0].reason, /QF_FIRST_OPEN_DIAG_APPID/)},
  {name: '06-notice-own-late', env: {QF_FAKE_NOTICE_CHANNEL: 'late'}, expect: 'FAIL', check: (v) => { const s = nsrcs(v); assert.ok(s.includes('automator.console.error') && s.includes('shim.console.error'), s.join()); assert.strictEqual(v.variants[0].errors.length, 0); }},
  {name: '07-notice-own-late-allowlisted', env: {QF_FAKE_NOTICE_CHANNEL: 'late', QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE: '1'}, expect: 'PASS_WITH_ALLOWLISTED_IDE_NOTICE', exit: 3},
  {name: '08-babel-helper', env: {QF_FAKE_SCENARIO: 'babel', QF_FAKE_NO_NOTICE: '1'}, expect: 'FAIL', check: (v) => assert.ok(srcs(v).includes('automator.console.error'))},
  {name: '09-boot-error-before-connect', env: {QF_FAKE_SCENARIO: 'game-error', QF_FAKE_NO_NOTICE: '1'}, expect: 'FAIL', check: (v) => assert.ok(srcs(v).includes('shim.console.error'))},
  {name: '10-exception', env: {QF_FAKE_SCENARIO: 'exception', QF_FAKE_NO_NOTICE: '1'}, expect: 'FAIL', check: (v) => assert.ok(srcs(v).includes('automator.exception') && srcs(v).includes('shim.wx.onError'))},
  {name: '11-console-not-forwarded', env: {QF_FAKE_SCENARIO: 'no-log-forward', QF_FAKE_NO_NOTICE: '1'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /console channel not proven/)},
  {name: '12-connect-fail', env: {QF_FAKE_SCENARIO: 'connect-fail', QF_FIRST_OPEN_LAUNCH_TIMEOUT_MS: '4000'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /connect/)},
  {name: '13-cli-missing', env: {QF_WECHAT_CLI: '/nonexistent/cli'}, expect: 'BLOCKED'},
  {name: '14-open-mode', env: {QF_FIRST_OPEN_MODE: 'open', QF_FAKE_NO_NOTICE: '1'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /open mode/)},
  {name: '15-no-loadscene', env: {QF_FAKE_SCENARIO: 'no-loadscene', QF_FAKE_NO_NOTICE: '1'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /LoadScene/)},
  {name: '16-creator388-template-source', env: {QF_WECHAT_BUILD_DIR: buildTpl, QF_FAKE_NO_NOTICE: '1'}, expect: 'PASS', check: (v) => assert.deepStrictEqual(v.variants[0].steps.removedConditionReportedByFinalizer, JSON.parse(fs.readFileSync(TEMPLATE, 'utf8')).condition)},
  {name: '17-active-condition-source', env: {QF_WECHAT_BUILD_DIR: buildActive}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /finalizer refused/)},
  {name: '18-oi-original-finalizer-compatible', env: {QF_FINALIZER: ORIGINAL, QF_FAKE_NO_NOTICE: '1'}, expect: 'PASS'},
  {name: '19-cases-must-start-default', env: {QF_FIRST_OPEN_CASES: 'diag-appid'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /must start with "default"/)},
  {name: '20-global-quit-refused', env: {QF_DEVTOOLS_QUIT_FIRST: '1'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /QF_DEVTOOLS_QUIT_FIRST was removed/)},
  {name: '21-ignore-regex-refused', env: {QF_FIRST_OPEN_IGNORE_ERROR_REGEX: '.*'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /IGNORE_ERROR_REGEX was removed/)},
  {name: '22-invalid-numeric-env', env: {QF_FIRST_OPEN_SETTLE_MS: '-5'}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /QF_FIRST_OPEN_SETTLE_MS must be an integer/)},
  {name: '23-other-window-left-open', env: {QF_FAKE_NO_NOTICE: '1'}, otherWindow: true, expect: 'PASS', check: (v, ctx) => { assert.ok(ctx.otherAlive, 'the pre-opened other window must still be running'); assert.ok(!/\bquit\b/.test(ctx.cliCalls), 'no quit call'); }},
  {name: '24-symlink-in-build', env: {QF_WECHAT_BUILD_DIR: buildLink}, expect: 'BLOCKED', check: (v) => assert.match(v.reason, /symlinks/)},
];
const summary = [];
for (const c of cases) {
  const out = path.join(OUT, c.name);
  const env = {...process.env, QF_FIRST_OPEN_DRY_RUN: '1', QF_WECHAT_CLI: path.join(__dirname, 'fake-wechat-cli.cjs'), QF_WECHAT_BUILD_DIR: build, QF_FINALIZER: PATCHED,
    QF_FIRST_OPEN_WORK_ROOT: path.join(tmp, 'copies'), QF_FIRST_OPEN_OUT: out, QF_AUTO_PORT: String(port), QF_FIRST_OPEN_SETTLE_MS: '2500',
    QF_DEVTOOLS_LOG_DIR: path.join(tmp, 'devtools-userdata'), QF_FAKE_STATE_DIR: path.join(tmp, 'fake-state'), QF_FIRST_OPEN_LAUNCH_TIMEOUT_MS: '20000',
    QF_FAKE_SCENARIO: '', QF_FAKE_NO_NOTICE: '', QF_FAKE_NOTICE_CHANNEL: '', QF_FIRST_OPEN_CASES: '', QF_FIRST_OPEN_DIAG_APPID: '', QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE: '', ...c.env};
  env.QF_FAKE_CLI_CALL_LOG = path.join(tmp, `cli-calls-${c.name}.log`);
  port += 3;
  const ctx = {};
  let other = null;
  if (c.otherWindow) { // a window this audit did NOT open (same fake IDE): must survive the run
    other = mkBuild('other-window-' + c.name, path.join(FX, 'oi-r6startup/audio-project.config.json'));
    cp.spawnSync(path.join(__dirname, 'fake-wechat-cli.cjs'), ['auto', '--project', other, '--auto-port', String(port + 50)], {env: {...env, QF_FAKE_CLI_CALL_LOG: path.join(tmp, 'other-window-open.log')}});
  }
  const t0 = Date.now();
  const r = cp.spawnSync(process.execPath, [path.join(ROOT, 'tools/wechat_first_open_audit.cjs')], {env, encoding: 'utf8', timeout: 180000});
  let v = null, ok = false, err = null;
  try {
    v = JSON.parse(fs.readFileSync(path.join(out, 'verdict.json'), 'utf8'));
    assert.strictEqual(v.status, c.expect, `status ${v.status}: ${v.reason}`);
    assert.strictEqual(r.status, c.exit !== undefined ? c.exit : {PASS: 0, FAIL: 1, BLOCKED: 2}[c.expect], 'exit code');
    if (other) { const key = Buffer.from(path.resolve(other)).toString('hex').slice(-40); const pidf = path.join(tmp, 'fake-state', key + '.pid'); ctx.otherAlive = fs.existsSync(pidf) && (() => { try { process.kill(Number(fs.readFileSync(pidf, 'utf8')), 0); return true; } catch { return false; } })(); }
    ctx.cliCalls = fs.existsSync(env.QF_FAKE_CLI_CALL_LOG) ? fs.readFileSync(env.QF_FAKE_CLI_CALL_LOG, 'utf8') : '';
    assert.ok(!/^quit\b/m.test(ctx.cliCalls), 'v3 must never call quit');
    if (c.check) c.check(v, ctx);
    for (const line of fs.readFileSync(path.join(out, 'SHA256SUMS.txt'), 'utf8').trim().split('\n')) { const [h, p] = line.split(/  /); assert.strictEqual(crypto.createHash('sha256').update(fs.readFileSync(path.join(out, p))).digest('hex'), h, p); }
    assert.ok(fs.readFileSync(path.join(out, 'run.log'), 'utf8').split('\n').filter(Boolean).every((l) => /^\d{4}-\d\d-\d\dT[\d:.]+Z \+\d+\.\ds /.test(l)), 'timestamps');
    assert.strictEqual(v.dryRun, true);
    ok = true;
  } catch (e) { err = e.message.split('\n')[0]; }
  summary.push({case: c.name, expect: c.expect, got: v && v.status, exit: r.status, ok, reason: v && v.reason, error: err, ms: Date.now() - t0});
  console.log(`${ok ? 'PASS' : 'FAIL'} ${c.name}: expect ${c.expect}, got ${v && v.status} (exit ${r.status}) — ${v && v.reason}${err ? ' !! ' + err : ''}`);
}
const copies = fs.existsSync(path.join(tmp, 'copies')) ? fs.readdirSync(path.join(tmp, 'copies')) : [];
const uniq = new Set(copies).size === copies.length && copies.every((n) => /^QFFirstOpen-\d{8}T\d{9}Z-[0-9a-f]{4}-[0-9a-f]{6}-(default|diag-appid)$/.test(n));
const untouched = builds.map(treeHash).every((h, i) => h === hashes0[i]);
summary.push({case: 'unique-copy-names', ok: uniq, copies: copies.length}, {case: 'source-builds-untouched', ok: untouched});
console.log(`${uniq ? 'PASS' : 'FAIL'} unique copy dir names (${copies.length})`);
console.log(`${untouched ? 'PASS' : 'FAIL'} source build dirs byte-identical after all runs`);
const passed = summary.filter((s) => s.ok).length;
fs.writeFileSync(path.join(OUT, 'dryrun-summary.json'), JSON.stringify({scope: 'v3 DRY RUN: fake CLI + fake automation server; real miniprogram-automator 0.12.1 client; real Oi finalizer 12ef697 + 0008-v2 patch', passed, total: summary.length, summary}, null, 2));
console.log(`\n${passed}/${summary.length} passed`);
// test cleanup of FAKE servers only (the fake CLI's quit; the audit itself never sends quit)
try { cp.spawnSync(path.join(__dirname, 'fake-wechat-cli.cjs'), ['quit'], {env: {...process.env, QF_FAKE_STATE_DIR: path.join(tmp, 'fake-state')}}); } catch {}
process.exit(passed === summary.length ? 0 : 1);
