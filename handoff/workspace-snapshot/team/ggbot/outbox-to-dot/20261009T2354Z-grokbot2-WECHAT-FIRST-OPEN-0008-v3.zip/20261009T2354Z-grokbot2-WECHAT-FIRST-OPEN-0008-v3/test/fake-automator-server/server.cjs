'use strict';
/**
 * FAKE DevTools automation endpoint for dry-runs. Speaks the JSON-over-websocket protocol used by miniprogram-automator 0.12.1
 * (Tool.getInfo, App.enableLog, App.callFunction, App.captureScreenshot, App.exit, Tool.close; events App.logAdded, App.exceptionThrown).
 * Runs the project's game.js in a node vm with a fake `wx` + console.
 * MODEL (fake only, not DevTools truth): the R6 app.json notice is printed for every open (as in Oi's A/D runs) unless
 * QF_FAKE_NO_NOTICE=1 or the project appid differs from wx3bdd911c5c06f591 (simulates candidate H2 being true).
 * Default channel: BEFORE game.js and before automation logging (WeappLog only, worst case). QF_FAKE_NOTICE_CHANNEL=late: 1 s after start.
 */
const fs = require('fs'), path = require('path'), vm = require('vm');
const [project, portStr, readyFile] = process.argv.slice(2);
const automatorDir = process.env.QF_MINIPROGRAM_AUTOMATOR_MODULE;
const WebSocket = require(require.resolve('ws', {paths: [automatorDir || process.cwd(), __dirname]}));
const scenario = process.env.QF_FAKE_SCENARIO || 'clean';
const logRoot = process.env.QF_DEVTOOLS_LOG_DIR;
// v3 review knobs (fake only): QF_FAKE_LOG_LAYOUT=direct (QF_DEVTOOLS_LOG_DIR is the WeappLog dir itself), QF_FAKE_LOG_TRUNCATE=1
// (truncate the shared log at window start), QF_FAKE_LOG_BIG_MIB=<n> (append n MiB filler first), QF_FAKE_WEAPPLOG_ERROR=<text>
// (an IDE-only error line tagged with this project's path, never sent to the console), QF_FAKE_FOREIGN=1 (another window writes
// its own lines + the app.json notice into other-window.log; =healthy: only healthy lines).
const logBase = logRoot ? (process.env.QF_FAKE_LOG_LAYOUT === 'direct' ? logRoot : path.join(logRoot, 'fakehash0008', 'WeappLog')) : null;
const logFile = logBase && !process.env.QF_FAKE_NO_WEAPPLOG ? path.join(logBase, 'logs', 'fake-devtools.log') : null;
const wlog = (line) => { if (!logFile) return; fs.mkdirSync(path.dirname(logFile), {recursive: true}); fs.appendFileSync(logFile, `[${new Date().toISOString()}] ${line}\n`); };
if (logFile && process.env.QF_FAKE_LOG_TRUNCATE === '1' && fs.existsSync(logFile)) fs.writeFileSync(logFile, '');
if (logFile && Number(process.env.QF_FAKE_LOG_BIG_MIB || 0)) { fs.mkdirSync(path.dirname(logFile), {recursive: true}); const row = 'x'.repeat(65535) + '\n'; fs.appendFileSync(logFile, row.repeat(16 * Number(process.env.QF_FAKE_LOG_BIG_MIB))); }
if (logBase && /^(1|healthy)$/.test(process.env.QF_FAKE_FOREIGN || '')) {
  const other = path.join(logBase, 'logs', 'other-window.log'); fs.mkdirSync(path.dirname(other), {recursive: true});
  fs.appendFileSync(other, `[${new Date().toISOString()}] fake IDE open project /Users/oi/OtherWindowProject\n[${new Date().toISOString()}] [console.log] OI_OTHER_WINDOW_READY\n` + (process.env.QF_FAKE_FOREIGN === '1' ? `[${new Date().toISOString()}] [console.error] [app.json 或自定义编译条件错误] app.json 中未定义自定义编译中指定的启动页面 (env: macOS,mg,2.02.2608080; lib: 3.17.3)\n` : ''));
}

const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const pc = readJson(path.join(project, 'project.config.json')) || {};
const pv = readJson(path.join(project, 'project.private.config.json'));
const effective = pv && pv.condition ? pv.condition : pc.condition;
const conditionOk = process.env.QF_FAKE_NO_NOTICE === '1' || pc.appid !== 'wx3bdd911c5c06f591'; void effective;

let sock = null, logEnabled = false;
const send = (o) => { if (sock && sock.readyState === 1) sock.send(JSON.stringify(o)); };
const mkConsole = (level) => (...a) => {
  wlog(`[console.${level}] ${a.map(String).join(' ')}`);
  if (logEnabled && scenario !== 'no-log-forward') send({method: 'App.logAdded', params: {type: level, args: a.map((x) => (typeof x === 'object' ? JSON.stringify(x) : String(x)))}});
};
const fakeConsole = {log: mkConsole('log'), info: mkConsole('info'), warn: mkConsole('warn'), error: mkConsole('error'), debug: mkConsole('debug')};
const errorHandlers = [];
const sandbox = {console: fakeConsole, setTimeout, clearTimeout, Promise, Date, JSON, Math,
  wx: {onError: (f) => errorHandlers.push(f), onUnhandledRejection: () => {}, getSystemInfoSync: () => ({platform: 'devtools', SDKVersion: '3.17.3'})},
  __FAKE_SCENARIO__: scenario};
const ctx = vm.createContext(sandbox);

wlog(`fake IDE open project ${project} (scenario=${scenario}, conditionOk=${conditionOk})`);
if (process.env.QF_FAKE_WEAPPLOG_ERROR) setTimeout(() => wlog(`[${project}] ${process.env.QF_FAKE_WEAPPLOG_ERROR}`), 300);
const NOTICE = '[app.json 或自定义编译条件错误] app.json 中未定义自定义编译中指定的启动页面 (env: macOS,mg,2.02.2608080; lib: 3.17.3)';
if (!conditionOk && process.env.QF_FAKE_NOTICE_CHANNEL !== 'late') fakeConsole.error(NOTICE);
if (!conditionOk && process.env.QF_FAKE_NOTICE_CHANNEL === 'late') setTimeout(() => fakeConsole.error(NOTICE), 1000);
if (scenario === 'babel') setTimeout(() => fakeConsole.error("Error: MiniProgramError\nmodule '@babel/runtime/helpers/Objectvalues.js' is not defined, require args is '../../@babel/runtime/helpers/Objectvalues'"), 1000);
try { vm.runInContext(fs.readFileSync(path.join(project, 'game.js'), 'utf8'), ctx, {filename: 'game.js'}); }
catch (e) { fakeConsole.error('game.js threw: ' + e.message); }
if (scenario === 'exception') setTimeout(() => { const err = {message: 'FakeError: thrown in game loop', stack: 'at fakeLoop (game.js:1)'}; errorHandlers.forEach((f) => f(err)); send({method: 'App.exceptionThrown', params: err}); }, 1500);

const wss = new WebSocket.Server({host: '127.0.0.1', port: Number(portStr)}, () => fs.writeFileSync(readyFile, 'ok'));
wss.on('connection', (ws) => {
  sock = ws;
  ws.on('message', async (raw) => {
    const {id, method, params} = JSON.parse(String(raw));
    const reply = (result) => ws.send(JSON.stringify({id, result}));
    const fail = (message) => ws.send(JSON.stringify({id, error: {message}}));
    try {
      if (method === 'Tool.getInfo') return reply({SDKVersion: '3.17.3'});
      if (method === 'App.enableLog') { logEnabled = true; return reply({}); }
      if (method === 'App.callFunction') {
        const fn = vm.runInContext('(' + params.functionDeclaration + ')', ctx);
        return reply({result: await fn(...(params.args || []))});
      }
      if (method === 'App.captureScreenshot') return reply({data: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='});
      if (method === 'App.exit' || method === 'Tool.close') { reply({}); if (method === 'Tool.close') setTimeout(() => process.exit(0), 100); return; }
      return fail('fake: unsupported ' + method);
    } catch (e) { return fail(e.message); }
  });
});
setTimeout(() => process.exit(0), 10 * 60 * 1000).unref();
