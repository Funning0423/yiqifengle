'use strict';
// E4 v1.2：Node 测试共用的最小 'cc' 桩。只模拟测试相关的 3.8.8 引擎行为，出处：
//  - director.tick 阶段顺序                  cocos/game/director.ts 767–808（BEFORE_UPDATE → startPhase → updatePhase → systems.update
//                                            → lateUpdatePhase → AFTER_UPDATE → _deferredDestroy → systems.postUpdate → BEFORE_DRAW → root.frameMove → AFTER_DRAW）
//  - root.frameMove → _frameMoveProcess      cocos/root.ts 764–801（scenes[i].update 读节点变换算 worldBounds / 剔除 → BEFORE_COMMIT → BEFORE_RENDER → render）
//  - 事件监听按注册顺序；off 用 fastRemoveAt（与最后一个交换）  cocos/core/event/callbacks-invoker.ts
//  - MeshRenderer.setSharedMaterial → 实例属性块重建为 0  render-scene/scene/model.ts _updateInstancedAttributes
//  - Pass._syncBatchingScheme：无 INSTANCED_ARRAYS 时关 USE_INSTANCING   render-scene/core/pass.ts 794–803
const qrot = (q, v) => { const { x, y, z, w } = q; const ix = w * v[0] + y * v[2] - z * v[1], iy = w * v[1] + z * v[0] - x * v[2], iz = w * v[2] + x * v[1] - y * v[0], iw = -x * v[0] - y * v[1] - z * v[2];
  return [ix * w + iw * -x + iy * -z - iz * -y, iy * w + iw * -y + iz * -x - ix * -z, iz * w + iw * -z + ix * -y - iy * -x]; };
const qinv = (q) => ({ x: -q.x, y: -q.y, z: -q.z, w: q.w });

module.exports = function makeCC (opts = {}) {
  const FormatType = { NONE: 0, UNORM: 1, SNORM: 2, UINT: 3, INT: 4, UFLOAT: 5, FLOAT: 6 };
  const FormatInfos = { 1: { name: 'RGBA16UI', size: 8, count: 4, type: FormatType.UINT }, 2: { name: 'RGBA32F', size: 16, count: 4, type: FormatType.FLOAT }, 3: { name: 'RGBA8', size: 4, count: 4, type: FormatType.UNORM } };
  class Vec3 { constructor (x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; } set (x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
    static transformMat4 (out, v, m) { const p = m.node.toWorld([v.x, v.y, v.z]); return out.set(p[0], p[1], p[2]); } }
  class Vec4 { constructor (x = 0, y = 0, z = 0, w = 0) { this.set(x, y, z, w); } set (x, y, z, w) { this.x = x; this.y = y; this.z = z; this.w = w; return this; } }
  class Quat extends Vec4 { constructor (x = 0, y = 0, z = 0, w = 1) { super(x, y, z, w); } }
  class Color { constructor (r = 0, g = 0, b = 0, a = 255) { this.r = r; this.g = g; this.b = b; this.a = a; } }
  // CallbacksInvoker 语义：on 追加到末尾；off = fastRemoveAt（与最后一个交换）；once 触发后移除
  class EventTarget {
    constructor () { this.h = []; }
    on (t, f, tg, once = false) { this.h.push({ t, f, tg, once }); }
    once (t, f, tg) { this.on(t, f, tg, true); }
    _rm (i) { const last = this.h.length - 1; this.h[i] = this.h[last]; this.h.length = last; }
    off (t, f, tg) { for (let i = this.h.length - 1; i >= 0; i--) { const x = this.h[i]; if (x.t === t && (!f || x.f === f) && x.tg === tg) this._rm(i); } }
    targetOff (tg) { for (let i = this.h.length - 1; i >= 0; i--) if (this.h[i].tg === tg) this._rm(i); }
    emit (t, ...a) { for (const x of this.h.slice()) if (x.t === t) { if (x.once) { const i = this.h.indexOf(x); if (i >= 0) this._rm(i); } x.f.apply(x.tg, a); } }
  }
  const TransformBit = { NONE: 0, POSITION: 1, ROTATION: 2, SCALE: 4, TRS: 7 };
  const NodeEventType = { TRANSFORM_CHANGED: 'transform-changed' };
  class Node extends EventTarget {
    constructor (name = '') { super(); this.name = name; this.children = []; this.parent = null; this.layer = 1; this.active = true; this.isValid = true; this.comps = []; this.pos = [0, 0, 0]; this.rot = { x: 0, y: 0, z: 0, w: 1 }; this.scl = [1, 1, 1]; this.writes = 0; }
    addChild (c) { c.parent = this; this.children.push(c); }
    get position () { return new Vec3(...this.pos); } get rotation () { return new Quat(this.rot.x, this.rot.y, this.rot.z, this.rot.w); } get scale () { return new Vec3(...this.scl); }
    setPosition (p, y, z) { this.pos = typeof p === 'number' ? [p, y, z] : [p.x, p.y, p.z]; this.writes++; this.emit(NodeEventType.TRANSFORM_CHANGED, TransformBit.POSITION); }
    setRotation (q) { this.rot = { x: q.x, y: q.y, z: q.z, w: q.w }; this.emit(NodeEventType.TRANSFORM_CHANGED, TransformBit.ROTATION); }
    setScale (s) { this.scl = [s.x, s.y, s.z]; this.emit(NodeEventType.TRANSFORM_CHANGED, TransformBit.SCALE); }
    localToParent (v) { const r = qrot(this.rot, [v[0] * this.scl[0], v[1] * this.scl[1], v[2] * this.scl[2]]); return [r[0] + this.pos[0], r[1] + this.pos[1], r[2] + this.pos[2]]; }
    toWorld (v) { let p = this.localToParent(v); for (let n = this.parent; n; n = n.parent) p = n.localToParent(p); return p; }
    fromWorld (p) { const chain = []; for (let n = this.parent; n; n = n.parent) chain.unshift(n); let v = p;
      for (const n of chain) { const d = [v[0] - n.pos[0], v[1] - n.pos[1], v[2] - n.pos[2]]; const r = qrot(qinv(n.rot), d); v = [r[0] / n.scl[0], r[1] / n.scl[1], r[2] / n.scl[2]]; } return v; }
    get worldPosition () { return new Vec3(...this.toWorld([0, 0, 0])); }
    setWorldPosition (x, y, z) { const v = typeof x === 'number' ? [x, y, z] : [x.x, x.y, x.z]; this.setPosition(...this.fromWorld(v)); }
    get worldScale () { let s = [...this.scl]; for (let n = this.parent; n; n = n.parent) s = s.map((v, k) => v * n.scl[k]); return new Vec3(...s); }
    get worldMatrix () { return { node: this }; }
    getComponent (C) { return this.comps.find(c => c instanceof C) || null; }
    getComponentsInChildren (C) { const out = []; const w = (n) => { for (const c of n.comps) if (c instanceof C) out.push(c); n.children.forEach(w); }; w(this); return out; }
    addComponent (C) { const c = new C(); c.node = this; this.comps.push(c); if (c._onAdded) c._onAdded(); return c; }
    destroy () { this.isValid = false; for (const c of this.children) c.destroy(); }
  }
  class Component { constructor () { this.isValid = true; this.enabled = true; } get enabledInHierarchy () { return this.enabled && this.node && this.node.active; } }
  class Camera extends Component { constructor () { super(); this.priority = 0; } }
  class Model {
    constructor (node) { this.node = node; this.local = null; this.world = null; this.bsCalls = 0; this.inst = {}; }
    createBoundingShape (min, max) { this.bsCalls++; this.local = { min: [min.x, min.y, min.z], max: [max.x, max.y, max.z] }; }
    updateWorldBound () { const { min, max } = this.local; const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < 8; i++) { const p = this.node.toWorld([i & 1 ? max[0] : min[0], i & 2 ? max[1] : min[1], i & 4 ? max[2] : min[2]]); for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], p[k]); hi[k] = Math.max(hi[k], p[k]); } }
      this.world = { min: lo, max: hi }; }
  }
  class MeshRenderer extends Component {
    constructor () { super(); this._mesh = null; this.sharedMaterials = [null]; this.model = null; this.shadowCastingMode = 1; this.instances = []; }
    _onAdded () { if (this.node.active) this.model = new Model(this.node); }
    get mesh () { return this._mesh; }
    set mesh (m) { this._mesh = m; if (this.model && m) { const s = m.struct; this.model.createBoundingShape(s.minPosition, s.maxPosition); this.model.updateWorldBound(); } }
    get sharedMaterial () { return this.sharedMaterials[0]; }
    setSharedMaterial (m, i) { this.sharedMaterials[i] = m; if (this.model) this.model.inst = {}; }
    // v1.3：只有实际生效的 USE_INSTANCING（材质宏开 且 设备有 INSTANCED_ARRAYS，pass.ts _syncBatchingScheme）才有实例属性块
    setInstancedAttribute (name, v) { const m = this.sharedMaterials[0]; if (this.model && m && m.passes[0].defines.USE_INSTANCING && features.instancedArrays) this.model.inst[name] = Array.from(v); }
    // 着色器实际走的根色分支（effect：#if USE_INSTANCING && USE_INSTANCE_ROOT_COLOR → a_root_color，否则 uniform rootColor）
    rootBranch () { const d = this.sharedMaterials[0].passes[0].defines; return (d.USE_INSTANCING && features.instancedArrays && d.USE_INSTANCE_ROOT_COLOR) ? 'a_root_color' : 'uniform'; }
    getMaterialInstance (i) { if (!this.instances[i]) { const mi = new Material(); mi.copy(this.sharedMaterials[i] || new Material()); this.instances[i] = mi; } return this.instances[i]; }
  }
  MeshRenderer.ShadowCastingMode = { OFF: 0, ON: 1 };
  const DEF = { windStrength: 1.0, amplitudeScale: 1.5, waveWeight: 0.36, swayWeight: 0.26, gustStrength: 0.15, bendDrop: 0.3 };
  const allMaterials = [];
  class Material {
    constructor () { this.effectAsset = {}; this.effectName = 'db://assets/effects/meadow-grass-wind'; this.name = 'mat_meadow_grass_wind'; this.props = {}; this.passes = [this._pass({})]; this.destroyed = false; allMaterials.push(this); }
    _pass (defines) { const self = this; return { defines, getHandle: (k) => (k in DEF ? Object.keys(DEF).indexOf(k) + 1 : 0), getUniform: (h) => { const k = Object.keys(DEF)[h - 1]; return k in self.props ? self.props[k] : DEF[k]; } }; }
    setProperty (k, v) { if (this.destroyed) throw new Error('setProperty on destroyed material'); this.props[k] = v; }
    copy (src, o) { this.effectAsset = src.effectAsset; this.effectName = src.effectName; this.props = { ...src.props }; this.passes = [this._pass({ ...src.passes[0].defines, ...(o && o.defines) })]; }
    destroy () { this.destroyed = true; return true; }
  }
  class MaterialInstance extends Material { recompileShaders (o) { Object.assign(this.passes[0].defines, o); } }
  const prop = (...a) => (typeof a[1] === 'string' ? undefined : () => undefined);

  // director：按 director.ts tick 的顺序跑一帧；frameMove 里先 scene.update（调用 onSceneUpdate 钩子 = “画面用的变换”）再 BEFORE_COMMIT
  const Director = { EVENT_BEFORE_UPDATE: 'director_before_update', EVENT_AFTER_UPDATE: 'director_after_update', EVENT_BEFORE_DRAW: 'director_before_draw',
    EVENT_AFTER_DRAW: 'director_after_draw', EVENT_BEFORE_COMMIT: 'director_before_commit', EVENT_BEFORE_RENDER: 'director_before_render', EVENT_BEGIN_FRAME: 'director_begin_frame', EVENT_END_FRAME: 'director_end_frame' };
  const features = { instancedArrays: opts.instancing !== false };
  const director = new EventTarget();
  director.root = { device: { hasFeature: (f) => (f === 'INSTANCED_ARRAYS' ? features.instancedArrays : true) } };
  director.scene = null; director.getScene = () => director.scene;
  director.comps = []; director.systems = []; director.onSceneUpdate = null;
  director.tick = function (dt) {
    this.emit(Director.EVENT_BEGIN_FRAME); this.emit(Director.EVENT_BEFORE_UPDATE);
    for (const c of this.comps) if (c.update && c.enabledInHierarchy !== false) c.update(dt);
    for (const s of this.systems) if (s.update) s.update(dt);
    for (const c of this.comps) if (c.lateUpdate && c.enabledInHierarchy !== false) c.lateUpdate(dt);
    this.emit(Director.EVENT_AFTER_UPDATE);
    for (const s of this.systems) if (s.postUpdate) s.postUpdate(dt);
    this.emit(Director.EVENT_BEFORE_DRAW);
    if (this.onSceneUpdate) this.onSceneUpdate();          // root._frameMoveProcess: scenes[i].update(stamp)
    this.emit(Director.EVENT_BEFORE_COMMIT); this.emit(Director.EVENT_BEFORE_RENDER);
    this.emit(Director.EVENT_AFTER_DRAW); this.emit(Director.EVENT_END_FRAME);
  };
  const cc = { _decorator: { ccclass: () => (c) => c, property: prop }, Component, Camera, EventTarget, Node, MeshRenderer, Material, Mesh: class {}, JsonAsset: class {}, Texture2D: class {}, Quat, Vec3, Vec4, Color,
    director, Director, NodeEventType, TransformBit,
    renderer: { MaterialInstance, scene: { ShadowCastingMode: { OFF: 0, ON: 1 } } }, gfx: { FormatType, FormatInfos, AttributeName: { ATTR_COLOR: 'a_color' }, Feature: { INSTANCED_ARRAYS: 'INSTANCED_ARRAYS' } } };
  return { cc, Model, features, allMaterials, DEF };
};

// 把 runtime/scripts 下的 TS 转成 CJS，'cc' 用桩，'./X' 互相引用
module.exports.loadScripts = function loadScripts (ts, dir, cc, names) {
  const fs = require('fs'), ps = require('path'), Module = require('module'); const req = {};
  const compile = (name) => { if (req[name]) return req[name];
    const js = ts.transpileModule(fs.readFileSync(ps.join(dir, name + '.ts'), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2017, experimentalDecorators: true } }).outputText;
    const m = new Module(name); m.paths = module.paths; const orig = m.require.bind(m);
    m.require = (id) => (id === 'cc' ? cc : id.startsWith('./') ? compile(id.slice(2)) : orig(id)); m._compile(js, name + '.js'); req[name] = m.exports; return m.exports; };
  for (const n of names) compile(n); return req;
};
