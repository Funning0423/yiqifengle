# E4 自定义材质移植草案 v1.3.1：草甸风草 + 不受光天空 + 天空跟随 + 无实例化兜底（Cocos Creator 3.8.8 / 微信小游戏）

GGbot（grokbot2）· 2026-10-09 · 草案，**没有在 Creator 编辑器、微信开发者工具或真机上跑过**。
这台电脑上能验的都验了：
- 用 Creator 3.8.8 安装包自带的官方 effect 编译器编译；
- 用 glslang 按 WebGL1 / WebGL2 编译并链接所有宏组合；
- 用 CPU 参考实现对照美术公式和 v0.8 真实网格；
- 4 个脚本用 cc 桩在 Node 里跑，director 帧顺序和 3.8.8 源码逐项比对过。

结果见 `tools/selftest/out/selftest-results.md`：**139 通过 / 0 失败 / 12 未运行**（v1.3 是 98 / 0 / 9）。
Oi 的独立检查 `team/oi/e4v12rev/independent-checks.cjs`（未改动，SHA256 `ce4e03c3…e15a`）对 v1.3.1 包根目录运行：**15 通过 / 0 失败**，输出原样存于 `tools/selftest/out/oi-independent-checks-v1.3.1.json`。
0007：只改了 `RegionCameraData.ts` 里 meadow 这一条数据，以补丁形式交付（`tools/patches/0007-meadow-pose/`，没有提交到任何 0007 分支）；0008 没碰。

## 包结构（v1.2 重排）

| 目录 | 放进工程？ | 内容 |
|---|---|---|
| `runtime/effects/` | **导入** → `assets/effects/` | `meadow-grass-wind.effect`、`sky-unlit.effect` |
| `runtime/scripts/` | **导入** → `assets/scripts/render/`（5 个文件放**同一目录**，互相 `import './…'`） | `GrassWindQuality.ts`、`GrassFallback.ts`、`MeadowInstancer.ts`、`SkyFollowCamera.ts`、`BakedGroundTexture.ts`（v1.3.1 新） |
| `runtime/textures-meta/`（v1.3.1） | `.meta` **放到美术贴图旁边**；预设**合并**进工程设置 | `tex_meadow_ground_grassoff_1024.jpg.meta`（贴图本身用美术包里的，不重复分发）、`texture-compress-preset.e4-meadow-ground-astc6x6.json` |
| `docs/` | 不导入 | `MATERIAL-PARAMS.md` 参数表 |
| `tools/patches/` | **不导入** | `0001-…diff`（对原型 MeadowInstancer）、`0002-E4-v1-to-v1.1.diff`、`0003-E4-v1.1-to-v1.2.diff`、`0004-E4-v1.2-to-v1.3.diff`、`0005-E4-v1.3-to-v1.3.1.diff`；`0007-meadow-pose/`（对 0007 v1.3 的单条数据补丁 + 打过补丁的 `RegionCameraData.ts` 副本） |
| `tools/selftest/` | **不导入**（Node 脚本，放进 assets 会被 Creator 当成脚本编译） | 自测脚本、cc 桩、输出 `out/` |
| `README.md`、`SHA256SUMS.txt` | 不导入 | |

**运行时导入只有 `runtime/effects/` 和 `runtime/scripts/`**（Oi 审查第三项），外加 v1.3.1 的一份贴图 `.meta`。不带 `.mtl` / GLB / JSON / 贴图，脚本和 effect 的 `.meta` 由 Creator 导入时生成；材质、GLB、实例 JSON、贴图用工程和美术已有的文件（见第二节），避免出现两份。

## v1.3 → v1.3.1 更新内容

输入（都已核对）：
- 美术包 `team/art/outbox-to-dot/20261010T0122Z-grokbot2-MEADOW-v0.8.1-BAKE-GROUNDTEX-CAMPOSE.zip`，SHA256 `0bbe1d68a1040bff0f6e04c26047f9c2c997c4bbd0ba70e5579685310c6d76bd`，与旁边的 SHA 清单一致；包内 SHA256SUMS 36 / 36 OK。
- **草甸位姿定稿**：Grok Bot `team/art/outbox-to-dot/20261010T0127Z-grokbot2-meadow_camera_pose-v0.8.1a.json`（**v0.8.1a**，SHA256 `12525f15cc76715b2190de837156dafdbc3c2ded79fa72c34e64933337c6b3ef`）。`team/cinematic/inbox/meadow_camera_pose.json` 与它逐字节相同（SHA 相同，cmp 一致）。position (-4, 24, 62)、target (0.3151, 3.4577, -0.6059)、vFOV 45；上方向 +Y，不带 rotation。
- **运镜bot 构图交叉检查**：`team/cinematic/work/meadow-pose-check/`（SHA256SUMS 本身的 SHA256 `c1d1deff…5214`；清单里 19 条全部 OK）。在 (-4, 24, 62) 下 0.46 和 0.75 两个比例都通过，角色盒离底部按钮带（NDC y = -0.5）余量 0.053（`check_alt_x-4.json`）。

| # | 改动 | 文件 |
|---|---|---|
| 1 | **烘焙草色地面贴图接入**：`tex_meadow_ground_grassoff_1024.jpg`（1024² RGB，与 `meadow_ground_v0_8_1024.jpg` 同一套 UV，不翻转）。导入设置：mipmap 开（mipfilter linear，三线性）、wrap S/T = clamp-to-edge、ASTC 6×6（含 mip 626,288 B ≈ 0.60 MiB），写进 `.meta` 和压缩预设（第八节） | `runtime/textures-meta/` |
| 2 | **从“场景直接引用”改成“关草时才加载”**：去掉 `@property(Texture2D) bakedGroundTexture`，改存 `bakedGroundBundle`（默认 `region_meadow`）+ `bakedGroundTexturePath`（默认 `textures/tex_meadow_ground_grassoff_1024/texture`）。关草 → 加载；**加载完成前地面保持当前贴图**；成功后 addRef 并换上；恢复草 / 区域卸载 → 换回原贴图并 decRef；加载失败 → 地面不变、警告、下次关草重试；快速开关用代数作废过期回调，过期回调拿到的贴图 addRef 后立刻 decRef（不泄漏、不会贴错） | 新 `BakedGroundTexture.ts`；`MeadowInstancer.ts` |
| 3 | **关草的触发**：`'budget'`（无实例化兜底超预算，粘滞）、`'quality'`（WIND_QUALITY 切到 OFF 关草，切回 LOW/HIGH 恢复）、`'manual'`（`setGrassOff(off)` 默认）。任一原因在 = 关草；`setGrassOff(false, 'all')` 清掉全部原因。**说明**：v1.3 里 WIND_QUALITY = OFF 只是“草不摆动”，草照样画。任务说“画质关或无实例化兜底时关草”，所以 v1.3.1 默认把 OFF 也当关草（`grassOffWhenWindQualityOff` = true）；要回到 v1.3 行为就把它设成 false | `MeadowInstancer.ts` |
| 4 | **草甸位姿写进 0007 `RegionCameraData.ts` 的 meadow 那一条**（stops[id=meadow]，与海岛 `yunjing-final` 同一 AuthoredPose 格式），**定稿**：status `'final'`；source 写明 Grok Bot v0.8.1a（SHA `12525f15…b3ef`）和运镜bot `meadow-pose-check`（0.46 / 0.75 通过，余量 0.053）。只改这一条，其他 stop、海岛 / 家的位姿和切换开关都没动 | `tools/patches/0007-meadow-pose/` |
| 5 | 自测新增 i（按需加载 I1–I9，其中 I1–I7 各配一个跑在 v1.3 原代码上的对照，必须失败）、j（贴图尺寸 / UV / 朝向 / .meta）、k（位姿过 0007 真实 CameraPose.ts，21 项）。cc 桩加了 `Material.getProperty` 和可注入的 `assetManager` | `tools/selftest/` |

v1.3 → v1.3.1 完整差异：`tools/patches/0005-E4-v1.3-to-v1.3.1.diff`。

### 1. 贴图核对（`tools/selftest/ground-tex-check.py`，结果 `out/ground-tex-check.json`）

- **尺寸**：1024 × 1024，RGB，JPEG，SHA256 `bb369d4d…d530`（与美术清单一致）；v0.8 地面图也是 1024²。
- **UV**：读 v0.8 GLB 的 `meadow_terrain`（6,561 个顶点；材质 `M_meadow_terrain`，baseColor 用 TEXCOORD_0 采 `meadow_ground_v0_8_1024`）。全部顶点满足 u = (x + 80) / 160、v = (z + 80) / 160（Cocos 坐标，v = 0 是贴图顶行），最大误差 2.4e-8。按上下翻转算的误差是 1.0。Creator 3.8.8 导入 glTF 不翻转 v（v1.1 已用本机导入实测）。所以新图只要和 v0.8 图同一朝向就能直接替换。
- **朝向**：23 个 `walk_path` 锚点按上面的公式取像素，原样读取时 23 / 23 落在土路色上；上下翻转只有 6 个，左右翻转只有 4 个。河和河岸那片美术保留了 v0.8 原图，与 v0.8 图几乎相同的像素原样有 6.5%，上下翻转 0.02%，左右翻转 0.12%。结论：**不需要翻转**，顶行 = 游戏 z = -80（风车那一侧），和美术说明一致。
- 只有地形（`meadow_terrain`）换贴图。河岸 `meadow_river_bank` 在 GLB 里也采同一张 v0.8 图，它保持原样，美术的烘焙图在河和河岸范围内本来就沿用了 v0.8 的像素。`groundRenderer` 拖 `meadow_terrain` 的 MeshRenderer。

### 2. 按需加载的时序

| 事件 | 地面 | 烘焙贴图引用 |
|---|---|---|
| 进场（草开） | 原贴图 | 不加载，场景里也没有引用 |
| 关草 | 加载期间**仍是原贴图** | 加载中 |
| 加载成功 | 换成烘焙贴图 | addRef，引用 1 |
| 加载失败 | 原贴图，`console.warn` | 无（state = failed，下次关草重试） |
| 恢复草 | 换回原贴图 | decRef，引用 0，由 assetManager 释放 |
| 区域卸载（onDestroy） | 换回原贴图（地面还在的话） | decRef；之后才到的回调直接丢弃 |
| 关 / 开 / 关…，回调乱序到达 | 只贴最后一次请求的结果 | 过期的 addRef 后立刻 decRef |

注意：换贴图用的是 `groundRenderer.getMaterialInstance(0)`，只在第一次真正换上时才创建实例。之后地面不再和其他用同一材质的物体合批（只有地面这一个 renderer）。

### 3. 草甸位姿与区域世界偏移

- 0007 补丁里的数据（以补丁交付，没提交到任何分支）：
  `{ id: 'meadow', pose: { position: [-4, 24, 62], target: [0.3151, 3.4577, -0.6059], fovVerticalDeg: 45, rootOffset: [0, 0, 0], status: 'final', source: '…v0.8.1a (sha256 12525f15…b3ef); 运镜bot meadow-pose-check…' } }`
- **草甸根在区域世界里的位置：没找到。** 0007 v1.3 工程里没有 `region_meadow` bundle，也没有草甸场景 / 预制体或放置代码：`stops` 目前只是数据，代码里没人读；`enterRegion('meadow')` 进的是棋盘关卡，不是 3D 草甸。设计文档（0007 v1 / v1.1 / v1.3）里也没有草甸的世界坐标。所以 position / target 按美术给的“草甸根局部坐标”写（`meadow_greybox_v0_8.glb` 的 scene_root 在原点、单位变换），并加了显式字段 `rootOffset: [0, 0, 0]`，约定 **世界坐标 = 局部坐标 + rootOffset**（只平移；草甸根如果还有旋转 / 缩放，这个约定不够用，要另改）。旁证：海岛模型也在原点，如果几个区域共处一个世界，草甸一定要有非零偏移；接入时由放草甸的一方填 rootOffset。
- 校验（k 组，用 0007 自己的 `CameraPose.ts`，去掉类型后在 Node 里跑，没有改 0007 代码）：`assertAuthoredPose` 通过；偏移取 [0,0,0]、[120,0,0]、[0,-5,300]、[-37.5,2,-64] 时 `validateCameraPose` 都返回 null，`applyCameraPose` 都成功写入，roll（right.y）约 1e-17，远小于 0.001。由位姿推出的 forward 与运镜bot 的 `forward_cocos` 相差不到 1e-5（俯仰 -18.13°，偏航 3.94°）。用 0007 的 `characterBox` / `frameCheck` 复算运镜bot 的角色盒：0.46 和 0.75 下 y_min 都是 -0.447，离 -0.5 的余量 0.053，`frameCheck` 通过。另有反向对照：带 roll、缺 target、手写 rotation 都会被拒绝。
- **天空球的下半部分必须保持地平线色**：运镜bot 指出，这个镜头里看得见的天际线是地形山脊（NDC y 0.29–0.66），低于真地平线（y ≈ 0.79），所以山脊上方露出的是天空球**地平线以下**的部分（v > 0.857）。实测现有贴图：v0.8 白天图地平线一行约 (100,181,210)，往下逐渐变浅，最底行约 (141,200,218)；夜景图地平线约 (113,135,178)，往下逐渐变暗，最底行约 (82,100,142)。两张图在地平线以下都**不是**地平线色，交给美术处理。`SKY_NIGHT_TINT_ONLY`（天空之城）在地平线以下本来就保持 nightHorizon，不受影响。`USE_HORIZON_FOG` 在地平线以下是最浓的雾，也能盖住，但颜色是雾色。

## v1.2 → v1.3 更新内容（Oi v1.2 复审 `team/oi/e4v12rev/INTEGRATION-MEMO.txt`）

| # | 改动 | 文件 |
|---|---|---|
| 1 | **无实例化时花簇也减量 50%**：草、花各做一次确定性选择，规则相同（小路边缘 / 视点优先，无锚点时均匀抽稀），花保留 round(150 × 0.5) = 75。关草仍只关草。新属性 `flowerKeepRatio`=0.5 | `MeadowInstancer.ts`、`GrassFallback.ts`（`FLOWER_FALLBACK_KEEP_RATIO`） |
| 2 | **`forceNoInstancing` 真正切到非实例化分支**：展开节点改用资源材质的副本，副本只把 `USE_INSTANCING` 设 false（草、花都换）；rootColor #60AE32 设在副本上，资源材质不改；切档的各档副本从它复制、同样非实例化；卸载时销毁 | `MeadowInstancer.ts` |
| 3 | **包围盒刷新改为检测最终 worldScale**：每个 BEFORE_DRAW 读草甸根的 `worldScale`（含所有祖先），变了才刷新（祖先 `setScale` 不会给后代发 TRANSFORM_CHANGED，v1.2 的监听漏掉）。去掉 TRANSFORM_CHANGED 监听；`onEnable` 和新加的 `markBoundsDirty()`（外部换 mesh 等）合并到同一次刷新。常驻 1 个 BEFORE_DRAW 监听，每帧读一次 worldScale | `MeadowInstancer.ts` |
| 4 | **README 收紧天空跟随承诺**：删掉“晚写那一帧画面不受影响 / GPU 管第二个相机兜底”的说法（被 CPU 剔除的模型 shader 不运行）；写明 before-draw 接入合同和多相机限制（第三节）。代码行为不变：verify 仍只计数 + 警告 | README、`SkyFollowCamera.ts` / `sky-unlit.effect` 注释、参数表 |
| 5 | **计数统一为 round**：两个选择分支的保留数都 = `Math.round(N × ratio)`（.5 进位）。均匀抽稀改成第 k 个保留序号 = floor((k + 0.5) × N / target)，N = 5、0.3 → 2（v1.2 是 1） | `GrassFallback.ts`、参数表、README、自测 |
| 6 | **共享材质所有权**（复审“仍需接入合同”一项）：`retainGrassWindMaterial` / `releaseGrassWindMaterialRef` 按原材质计数，多个区域共用一个草材质时，最后一个卸载才销毁各档副本 | `GrassWindQuality.ts`、`MeadowInstancer.ts` |
| 7 | 自测：cc 桩的 `setInstancedAttribute` 只在实际生效的 USE_INSTANCING 下保存（和引擎一致），新增 `rootBranch()` 报告 shader 实际走的根色分支；新增 6 项（含 2 个反向对照） | `tools/selftest/` |

v1.2 → v1.3 完整差异：`tools/patches/0004-E4-v1.2-to-v1.3.diff`。

### Oi v1.2 复审逐项对应

| 复审项 | 改动 | 测试 | 结果 |
|---|---|---|---|
| E4-12-01 花 50% 没实现（README 说花不减） | 更新 #1：实现 50%，README / 参数表改成“花 round(N×0.5)” | 自测 g：MeadowInstancer 无实例化集成 = 草 300 + **花 75**，花逐丛与纯函数选择一致、两次一致；关草时 75 丛花不受影响；无锚点抽稀 草 300 / 花 75；forceNoInstancing 草 300 / 花 75。Oi：`requested flower 50 percent exists` | 自测通过；Oi pass（75） |
| E4-12-02 forceNoInstancing 只改标志，USE_INSTANCING 仍 true → 黑根 | 更新 #2：换成 USE_INSTANCING = false 的材质副本 | 自测 g：副本宏 / 属性、shader 实际分支 = uniform、副本上 rootColor #60AE32、资源材质不改、切档仍非实例化、卸载销毁；反向对照 G2（USE_INSTANCING 仍 true 不写属性 → a_root_color 分支 = 黑根）。Oi：`forceNoInstancing selects actual non-instanced shader branch` | 自测通过；Oi pass（USE_INSTANCING=false） |
| E4-12-03 祖先缩放不触发包围盒重算 | 更新 #3：检测最终 worldScale | 自测 h：两层祖先 setScale(0.5) → 下一帧刷新 1 次、包围盒按新最小世界缩放重算、根色重设；不变帧 0 次；markBoundsDirty 1 次；只 1 个常驻监听；反向对照 H2（祖先缩放时草甸根收不到 TRANSFORM_CHANGED）。Oi：`ancestor-scale automatically queues grass bounds refresh`、`own meadow-root scale queues refresh`（恰好 1 次） | 自测通过；Oi pass（1 / 1） |
| E4-12-04 晚写只告警不修复；“GPU 兜底”说法不成立；多相机 | 更新 #4：删掉承诺，写合同和限制（第三节）；行为保持“只告警” | 自测 f：BEFORE_DRAW 晚写不调 syncAll → 10/10 帧不一致被计数；调 syncAll → 0/10（合同成立的证据）。Oi：`late write is warning-only, not repaired`、`main-camera sky sync … keeps Y` | 自测通过；Oi pass。多相机未实现（文档限制） |
| E4-12-05 抽稀 floor 与文档 round 不一致 | 更新 #5 | 自测 g：10 组 N × ratio 两个分支保留数都 = round 且置 true 个数相等（5×0.3→2、3×0.5→2、11×0.25→3 …）。Oi：`stride selection matches documented round(N*ratio)` | 自测通过；Oi pass（2） |
| 复审接入条件：材质副本共享所有权 | 更新 #6 | 自测 h：两区域共享 → 先卸载的不销毁、最后一个销毁；Oi：`destroy stops spawned nodes and releases variants` | 自测通过；Oi pass |
| 复审接入条件：直接替换单个 mesh 不在监听覆盖内 | `markBoundsDirty()` + 文档合同（换 mesh 的一方调用） | 自测 h（markBoundsDirty → 刷新 1 次） | 通过；自动检测 mesh 替换未实现 |

## v1.1 → v1.2 更新内容（保留备查）

| # | 改动 | 文件 |
|---|---|---|
| 1 | **天空 CPU 剔除**：新增 `SkyFollowCamera.ts`，每帧在 director `EVENT_BEFORE_DRAW` 把天空节点世界 X/Z 设成相机的（Y、UV、贴图不动），节点包围盒跟着相机走。BEFORE_COMMIT 核对有没有更晚的写入（计数 + 警告一次），`SkyFollowCamera.syncAll()` 给契约外的 BEFORE_DRAW 写入者用。和 shader 的 GPU 跟随不重复位移（第三节） | `runtime/scripts/SkyFollowCamera.ts`、sky-unlit 注释 |
| 2 | **无实例化兜底**（美术决定：减量，不关）：`supportsInstancing()` 用 `device.hasFeature(INSTANCED_ARRAYS)` 检测；不支持时只展开约 30% 草丛（靠近小路边缘 / 视点优先，确定性），统一根色 #60AE32；帧时间持续超预算（40 ms / 5 s / 80%）才整片关草，并换烘焙草色地面贴图（留槽，美术后续提供）。设备下限写进第四节 | `runtime/scripts/GrassFallback.ts`（新）、`MeadowInstancer.ts` |
| 3 | `rootColor` 默认改成调色板草绿行中间色 **#60AE32**（v1.1 是实例均值 #5DA731） | meadow-grass-wind.effect |
| 4 | **_ROOT_COLOR 校验**：展开前逐实例检查，缺失 / 非法填中间绿（线性），打警告计数；不会出现没设属性时的 0 = 黑根 | `MeadowInstancer.ts`、`GrassFallback.validateRootColors` |
| 5 | **apply 时序**：展开完成后如果已经切过档（`getAppliedGrassWindQuality()`，自动画质组件先跑完 / 区域异步加载），立即对新节点 apply 当前档；`onEnable`、根节点缩放变化 → 合并到下一个 BEFORE_DRAW 重算包围盒 + 重设根色（解决 v1.1 “已知限制”里重新显示要手动调 onWindChanged 的问题） | `MeadowInstancer.ts`、`GrassWindQuality.ts` |
| 6 | **卸载释放**：`releaseGrassWindQualityMaterials(base, restore)` 把模板换回原材质、`destroy()` 各档运行时材质副本、清缓存；`MeadowInstancer.onDestroy` 注销 grassWindEvents / director / 节点三类监听，展开节点先停用再 destroy（destroy 延迟到下一帧，停用避免本帧还用已销毁的副本） | `GrassWindQuality.ts`、`MeadowInstancer.ts` |
| 7 | **模板节点非单位 TRS**：展开节点挂在复制了模板局部 TRS 的 `*_expanded` 容器下（实例 TRS 是相对模板节点的）。v0.8 的模板节点都是单位变换，结果不变 | `MeadowInstancer.ts` |
| 8 | **天空之城夜空两色渐变**：`SKY_NIGHT_TINT_ONLY` 时夜晚 = mix(nightZenith, nightHorizon, clamp(v / horizonV)) × nightTint，线性空间插值；默认 #101430 → #7086B1，地平线 v = 0.857，以下保持地平线色。新增两个属性，SkyFS UBO 4 → 6 个 vec4（天空 UBO 合计 96 B → 128 B） | sky-unlit.effect、参数表 |
| 9 | 包结构重排：`runtime/`、`docs/`、`tools/` | 全部 |
| 10 | 自测：新增 f-sky-follow / g-fallback / h-lifecycle 三组和夜空渐变 CPU 检查；4 个 TS 一起严格类型检查；cc 桩抽成 `cc-stub.js` | `tools/selftest/` |

v1.1 → v1.2 完整差异：`tools/patches/0003-E4-v1.1-to-v1.2.diff`。

### Oi 审查（`team/oi/e4v11rev/INTEGRATION-MEMO.txt`）逐项对应

| 审查项 | v1.2 改动 | 自测（`tools/selftest/out/selftest-results.md`） |
|---|---|---|
| 1 天空只有 GPU 跟随，CPU 包围盒不动 → 可能被整片剔除 | 更新 #1 `SkyFollowCamera`（BEFORE_DRAW） | f-sky-follow：3.8.8 源码阶段顺序；零帧延迟（6 个写入阶段 × 30 帧，最大单帧跳 410 m）；不重复位移；剔除（对照：不跟随 132/180 帧相机在包围盒外）；契约外写入检测 + syncAll；注销。反向对照 F1：lateUpdate 跟随有 90/180 帧落后 |
| 2 无实例化退化（根色、约 1000 draw） → 要设备下限或减量 / 关闭兜底 | 更新 #2、#3，第四节设备下限 | g-fallback：30% 选择（真实 v0.8 数据、确定性、小路 / 视点优先）、均匀抽稀 + 遮罩钩子、触发条件、MeadowInstancer 无实例化集成、统一根色路径、关草 + 地面贴图槽 |
| 3a 运行时只导入 effects / scripts，两个 TS 同目录 | 更新 #9，包结构表 | e-meadow-instancer：4 个 TS 同目录一起类型检查 |
| 3b 依赖 JSON / 模板名 / 单材质槽；展开节点是兄弟节点，非单位 TRS | 更新 #7；依赖写在第二节 | h-lifecycle：非单位 TRS（平移 + 旋转 90° + 缩放 2，误差 0） |
| 3c `_ROOT_COLOR` 缺失 = 黑根 | 更新 #4 | h-lifecycle：validateRootColors 单测；MeadowInstancer 缺 41 + 非法 2 → 43 个填中间绿、黑根 0 |
| 3d 重建 / 父缩放 / 重新显示后要重算包围盒和根色 | 更新 #5 | h-lifecycle：重新启用 / 缩放 → 下一个 BEFORE_DRAW 刷新一次，不残留监听 |
| 3e 自动画质组件只在 start 扫一次 → 异步加载 / 新增草要显式 apply | 更新 #5 | h-lifecycle：先切档后加载 → 新草直接用该档共享材质 |
| 3f 画质材质副本卸载时要显式 destroy | 更新 #6 | h-lifecycle：销毁 2 个副本、模板复原、监听 0、缓存清空、再进区域重新生成；反向对照 H1 |
| 接入备注：海岛 `SKY_SOURCE=1` + `SKY_NIGHT_TINT_ONLY`；nightTint 白色不压暗；horizonFog 默认 0 | v1.2 起 tint-only 夜晚 = 两色渐变 × nightTint（第二节第 4 步说明海岛要自己设两色）；horizonFog 默认仍 0 | c-cpu-reference：夜空渐变（v=0 → #101430、v=0.857 → #7086B1、以下 = 地平线色）；反向对照 G1 |
| 预算：两张天空图 16 MiB / ASTC 6×6 ≈ 1.785 MiB；UBO 草 144 B / 天空 96 B | 天空 UBO 变 128 B；草不变 | b-glslang 天空 104 × 2 = 208 个程序编译链接 |

美术决定（“减量，不关；中间绿；超预算才关草换烘焙贴图”）对应更新 #2 / #3 和 g-fallback 组；运镜 bot 的要求（读相机必须在当帧最后一次写入之后，含动画驱动写入，零帧延迟自测）对应更新 #1 和 f-sky-follow 组。

## 一、放到工程哪里

| 文件 | 位置 | 原因 |
|---|---|---|
| `runtime/effects/*.effect` | `assets/effects/`（主包） | 草甸、海岛、天空之城都会用天空。WebGL1 + WebGL2 两套 GLSL 源码合计：草约 53 KB、天空约 16 KB（v1.2 略增），未压缩 |
| `runtime/scripts/*.ts`（4 个） | `assets/scripts/render/`（主包脚本，**同一目录**） | 互相 `import './GrassWindQuality'` / `'./GrassFallback'` |
| 草 / 天空材质 `.mtl` | `assets/bundles/region_meadow/materials/` | 跟 GLB 和贴图一起走 `region_meadow` 远程包 |
| 白天天空图 | `assets/bundles/region_meadow/textures/tex_meadow_sky_2048x1024.jpg` | 来源：`team/ggbot/reports/meadow/sky/meadow_sky_2048x1024.jpg`（SHA256 cc4dafd6…4e9e） |
| 夜景天空图 | `assets/bundles/region_meadow/textures/tex_meadow_sky_night_2048x1024.png` | 来源：`team/art/outbox-to-dot/20261009T2323Z-grokbot2-MEADOW-SKY-NIGHT-v0.1.png`（SHA256 57b4f29d…3d4d2f，已核对） |
| 实例 JSON | `region_meadow` 包，绑到 `MeadowInstancer.instances` | `team/ggbot/reports/meadow/meadow_instances_v0_8.json` |

### MeadowInstancer.ts 归属

`team/ggbot/prototypes/MeadowInstancer.ts` 是 **GGbot 自己的原型**（第五批交付，登记在 `team/ggbot/README.md` 和 `team/ggbot/SHA256SUMS.txt`），不是 Oi 的工程文件，也不是美术文件。游戏工程里还没有这个文件。**原文件没有直接改**；修改版在 `runtime/scripts/`，正式 diff 是 `tools/patches/0001-…diff`（v1.3 重新生成，对原型 SHA256 917f9ea0…1e44，在 `/workspace/wechat-game` 下 `git apply --check` 通过）。合进去以后要更新 `team/ggbot/SHA256SUMS.txt` 对应行；diff 里 `MeadowInstancer.ts` 引用的 `GrassWindQuality` / `GrassFallback` 两个文件也要放在同目录。

## 二、在 Creator 里接入

1. **草材质** `mat_meadow_grass_wind.mtl`，Effect 选 `meadow-grass-wind`：
   - Defines：勾 `USE_INSTANCING`、`USE_INSTANCE_ROOT_COLOR`；`WIND_QUALITY` 设 **1**（数值宏默认 0 = 静止）；`GRASS_LIGHTING` 设 1。`WIND_SPACE`、`WIND_PHASE_PER_VERTEX` 保持默认。
   - `mainTexture` 拖 `meadow_palette_256`（先关 mipmap，参数表第四节）。`rootColor` 默认已是 #60AE32。
2. GLB 材质映射里把 `M_meadow_grass_wind` 换成上面的材质。5 个草模板**共用这一个材质资源**；不要用 `getMaterialInstance()`，要改风参数用 `setGrassWindParams(material, {...})`。**每个草模板节点只能有 1 个材质槽**（MeadowInstancer 只复制第 0 槽）。
3. 草和花不投影（MeadowInstancer 生成的节点自动设）。
4. **天空材质**：
   - 草甸 `mat_meadow_sky.mtl`（Effect `sky-unlit`）：`mainTexture` 白天图、`nightTexture` 夜景图，`SKY_FOLLOW_CAMERA` 设 1；要地平线雾勾 `USE_HORIZON_FOG`；映射给 `M_meadow_sky`；昼夜过渡 `setProperty('nightBlend', 0…1)`。
   - **天空之城**：勾 `SKY_NIGHT_TINT_ONLY`（不拖夜景图），nightZenith / nightHorizon 用默认 #101430 / #7086B1，`horizonV` 0.857，nightTint 白色。
   - 海岛 `env_sky_dome`：`SKY_SOURCE` 1。如果也勾 `SKY_NIGHT_TINT_ONLY`，**v1.2 起夜晚是两色渐变**而不是“白天 × nightTint”，海岛要的夜色请在海岛材质里改 nightZenith / nightHorizon（或不勾这个宏、nightBlend 保持 0）。
   - 场景 Skybox 保持关闭，相机 ClearFlags 用 SOLID_COLOR。
5. **天空球节点挂 `SkyFollowCamera`**，`cameraNode` **显式**拖真正的主相机（不填 = 场景里 priority 最小的启用相机，有多个相机时不要依赖它）。`followY` 保持关。在 BEFORE_DRAW 里写相机的代码必须遵守第三节的接入合同。
6. 花簇（F0–F2）继续用 builtin-standard，勾 `USE_INSTANCING`。
7. 草甸根节点挂 `MeadowInstancer`（`instances` 绑实例 JSON）；任意节点挂 `GrassWindQualityAuto`（target 指草甸根节点）。兜底相关属性：`fallbackKeepRatio` 0.3、`flowerKeepRatio` 0.5，`groundRenderer` 拖地形 `meadow_terrain` 的 MeshRenderer。烘焙地面贴图**不要拖进场景**（v1.3.1 起按需加载）：把美术的 `tex_meadow_ground_grassoff_1024.jpg` 和本包的 `.meta` 一起放到 `assets/bundles/region_meadow/textures/`，`bakedGroundBundle` / `bakedGroundTexturePath` 保持默认（路径留空 = 只关草不换地面）。`grassOffWhenWindQualityOff` 默认 true。在支持实例化的设备上验收兜底：勾 `forceNoInstancing`（会真的换成非实例化材质）。
   - 缩放合同：草甸根及其祖先可以运行时缩放（自动检测）；展开出来的 `*_expanded` 容器和实例节点不要被别的脚本改缩放 / 换 mesh，必须改时改完调 `markBoundsDirty()`。
   - 兜底的小路 / 视点取自草甸 GLB 里的锚点节点 `walk_path_00…22`、`player_spawn`、`region_interaction_point`、`windmill_door_point`（`anchors_v0_8.json` 里也有，坐标和实例 JSON 同一套）；镜头默认 / 区域视点定稿后拖进 `extraViews`。

### MeadowInstancer v1.3.1 行为一览

- 展开：每组模板一个 `<模板节点名>_expanded` 容器（复制模板局部 TRS），按 JSON 生成 MeshRenderer 节点，共享 mesh + 材质，模板节点隐藏。
- 根色：逐实例校验 `_ROOT_COLOR` → `setInstancedAttribute('a_root_color', …)`；无实例化时不设，用统一 rootColor。
- 包围盒：每个实例按材质里实际风参数和网格 max(COLOR_0.a) 扩大（v1.1 逻辑不变）。
- 重算时机：切档 / 改风参数事件；每个 BEFORE_DRAW 检测草甸根最终 `worldScale`（含祖先）变化；`onEnable`；`markBoundsDirty()`（后三者合并为下一个 BEFORE_DRAW 的一次刷新）。
- 展开后补一次 apply 当前档。
- 无实例化：草 round(N×0.3) + 花 round(N×0.5) 选择 + 统一根色 + `update` 里 `FrameBudgetMonitor` → `setGrassOff(true)`（也可手动调 `setGrassOff`）。`forceNoInstancing` 时展开节点用 USE_INSTANCING = false 的材质副本。`report` 字段记录根色缺失 / 非法数、草 / 花保留数、规则、强制副本数。
- 关草（v1.3.1）：原因 budget / quality / manual，任一原因在就关草；关草时按需加载烘焙地面贴图（第“v1.3 → v1.3.1”节表 2），`groundTextureState` 可读状态和计数。
- 卸载：先换回地面原贴图、释放烘焙贴图、作废进行中的加载，再注销监听、停用并销毁展开节点、销毁强制副本；资源材质的各档副本按使用者计数，最后一个使用者卸载时（`releaseMaterialsOnDestroy`，默认开）模板复原并销毁。

## 三、天空跟随的时序依据（Cocos 3.8.8 源码）

`cocos/game/director.ts` `tick()`（767 起）：

| 行 | 阶段 | 谁会在这里写相机 |
|---|---|---|
| 776 | emit BEFORE_UPDATE | |
| 778 / 780 | `startPhase` / 组件 `updatePhase` | **0007 v1.3 `WorldFlowComponent.update`（WorldFlowComponent.ts:131）推进流程 → `createCameraTrack` 每帧采样 → `applyCameraPose`（CameraPose.ts:138，唯一相机写入者）** |
| 783 | 各 System `update` | **AnimationManager（`registerSystem(..., SystemPriority.HIGH)`，animation-manager.ts:173）——运镜 `cine_camera` 烘焙动画在这里写节点**；Tween 同理 |
| 786 | 组件 `lateUpdatePhase` | 任何用 lateUpdate 的脚本（彼此先后取决于 executionOrder） |
| 788 / 790 | emit AFTER_UPDATE、`_deferredDestroy` | |
| 794 | 各 System `postUpdate` | 物理同步等 |
| **798** | **emit BEFORE_DRAW ← SkyFollowCamera.sync** | |
| 800 | `root.frameMove(dt)` → `root.ts _frameMoveProcess`（764）：785 `scenes[i].update(stamp)`（模型 updateTransform → worldBounds；剔除用它）→ 794 emit BEFORE_COMMIT ← **SkyFollowCamera.verify** → 801 `pipeline.render` | |

结论：BEFORE_DRAW 在所有组件 / 动画系统 / postUpdate 写入之后、scene.update 之前，是最后一个公开钩子。0007 的 Promise `.then` 回调是微任务，在两帧之间执行，也早于 BEFORE_DRAW。所以天空读到的就是当帧最终相机位置（零帧延迟），硬切几百米也一样。

**为什么不用 executionOrder + lateUpdate**：只对 lateUpdate 阶段内部排序，管不到 AFTER_UPDATE 监听和 System.postUpdate；动画驱动的相机写入时机由系统决定，和组件 executionOrder 无关。

**为什么不靠“重新注册让自己排最后”**：`CallbacksInvoker` 移除监听用 `fastRemoveAt`（和最后一个交换），反复 off/on 会打乱别人的监听顺序，不做。改用下面的接入合同。

**接入合同（before-draw，v1.3 写明）**

| 谁 | 什么时候写相机（或相机的祖先节点） | 要做什么 |
|---|---|---|
| 组件 update / lateUpdate、动画（cine_camera）、Tween、AFTER_UPDATE 监听、System.postUpdate、帧间 Promise 回调（0007 `applyCameraPose` 都在这里） | BEFORE_DRAW 之前 | 什么都不用做 |
| 在 `director` `EVENT_BEFORE_DRAW` 监听里写相机的代码 | BEFORE_DRAW 中 | **写完在同一个监听里调用 `SkyFollowCamera.syncAll()`**（必须在 `root.frameMove` → `scene.update` 之前，也就是不能挪到 BEFORE_COMMIT / BEFORE_RENDER） |
| 在 `EVENT_BEFORE_COMMIT` / `BEFORE_RENDER` / `AFTER_DRAW` 里写相机 | scene.update 之后 | **不允许**。这一帧的包围盒已算完，任何同步都晚了 |

违反合同时 `verify`（BEFORE_COMMIT）只会让 `lateWrites` +1 并警告一次，**不修正**这一帧：天空包围盒仍在旧位置，相机跳得远时这一帧天空可能被 CPU 剔除（天空不画，露出相机清屏色），下一帧恢复。**v1.2 README 里“画面不受影响 / GPU 偏移兜底”的说法是错的，已删除**：被 CPU 剔除的模型根本不提交绘制，shader 里的 GPU 偏移不会运行。

**多相机限制**：每个 `SkyFollowCamera` 只跟一个相机。同一个天空节点被第二个相机看时，只有第二个相机离被跟随相机足够近（在天空球包围盒内）才保证不被剔除；不支持多个远离的相机共用一个天空节点。需要时给每个相机一个天空节点（各自挂 `SkyFollowCamera`、`cameraNode` 指各自相机，用 layer / visibility 让每个相机只看到自己的天空）。本包没有实现也没有测这种配置。

**和 GPU 跟随（`SKY_FOLLOW_CAMERA=1`）的关系**：shader 做 `worldPos.xz += cc_cameraPos.xz − matWorld[3].xz`（sky-unlit.effect 75 行）。节点已经在相机 XZ 时偏移恰好 0，不会位移两次。保留 GPU 跟随只为让顶点精确居中在当前绘制相机上；它不负责剔除。

## 四、无实例化兜底和设备下限

**设备下限（全量草）**：WebGL2，或 WebGL1 + `ANGLE_instanced_arrays`。依据：`gfx/webgl2/webgl2-device.ts:223` 恒置 `INSTANCED_ARRAYS`；`gfx/webgl/webgl-device.ts:220–221` 只在有该扩展时置位；`render-scene/core/pass.ts:794–803` `_syncBatchingScheme` 在没有这个 feature 时把 `USE_INSTANCING` 关掉，变成每丛 1 次 draw call、`a_root_color` 不存在。检测用公开 API `director.root.device.hasFeature(gfx.Feature.INSTANCED_ARRAYS)`（`gfx.deviceManager` 是 @internal，不用）。

**兜底策略（美术决定）**：

| 情况 | 草 | 根色 | 草 draw call（估算） |
|---|---|---|---|
| 支持实例化 | 1,000 丛全量 | 逐丛 `_ROOT_COLOR` | 5 |
| 不支持 | 草 **round(N×0.3) = 300 丛**、花 **round(N×0.5) = 75 簇**，离小路边缘 / 视点近的优先（v0.8 实测：保留草离路边缘平均 7.1 m，全部平均 19.8 m） | 统一 #60AE32 | 300（+ 花 75） |
| 不支持且帧时间仍超预算 | **整片关草**，地面换烘焙草色贴图（美术后续提供；没给图时只关草） | — | 0 |

关草触发（可调）：进场 3 s 后，连续 5 s 内超过 40 ms 的帧 ≥ 80%（单帧 > 0.5 s 视为切后台，清窗口），只触发一次，节点发 `'meadow-grass-off'`。关草只关草，花保持 75 簇。选择规则、遮罩钩子、参数表见 `docs/MATERIAL-PARAMS.md` 第五节。性能本身 not_run。

## 五、画质档位（WIND_QUALITY）

| 档 | 顶点运算 | 用在 |
|---|---|---|
| 0 关 | 无（预处理后不含任何风代码，和静态网格走同一条路径） | 明确无法运行的设备、性能兜底 |
| 1 低 | 1 个 sin | 默认、未知机型、中低端机 |
| 2 高 | 4 个 sin（行波 + 整体摆动 + 阵风 2 个） | 高端机 |

自动选档的阈值来自微信《设备档位下的用户分布》（2026-03-04）：

| 条件 | 结果 |
|---|---|
| 没有 wx、benchmarkLevel 为 -1 或未知 | 低（modelLevel = 1 时升到高） |
| 0 / -2 | 关 |
| Android ≥ 30 / iOS ≥ 36 | 高 |
| 其余 | 低 |

读取顺序：`wx.getDeviceBenchmarkInfo`（基础库 ≥ 3.4.5，800 ms 超时）→ `getDeviceInfo` → `getSystemInfoSync`。

切档的做法：每一档复制一份运行时共享材质，所有草的 renderer 都换成同一份，实例化合批不会断。原因是 3.8.8 里共享材质不能 `recompileShaders`。切档会编译新的 shader 变体，可能卡一帧，所以只在进场或设置界面切。

## 六、光照选择

草用逐顶点半 Lambert：法线往 +Y 混 0.5，双面一致；加天空 / 地面半球环境光。片元里只有 1 次贴图采样和几次 mix，没用 builtin-standard 的 PBR。`GRASS_LIGHTING 0` = 完全不受光。草不接收实时阴影，也不投影。场景开了雾会自动生效。

## 七、draw call 和实例化

| 情况 | 草的 draw call |
|---|---|
| MeadowInstancer 展开 + 材质开 `USE_INSTANCING`（**推荐路径**） | **5**（5 个模板各 1 个）；花 3 个；天空 1 个 |
| 材质没开实例化 | 1,000（配置错误） |
| 设备不支持实例化 | 兜底：草 300 + 花 75；超预算时关草 → 草 0、花 75（第四节） |

不用静态合批：合批后每实例根色会丢，世界矩阵也不再是实例的。包围盒扩大以后视锥剔除稍微保守一点（屏幕外 ≤ 1 m 的草也会画），这是有意的取舍。

## 八、贴图导入设置

| 项 | 白天图 / 夜景图（都是 2048×1024） | 调色板 `meadow_palette_256` |
|---|---|---|
| Mipmap | **关** | **关**（美术负责人确认） |
| 过滤 | linear | linear（看到色块串色就改 nearest） |
| Wrap | u = repeat（接缝连续，开滚动也需要）；v = clamp-to-edge | clamp-to-edge |
| 色彩空间 | sRGB，shader 里 `SRGBToLinear` | sRGB |
| 压缩 | ASTC 5×5 或 6×6 → Android 兜底 ETC2 RGB → PNG/JPG。夜景图暗部渐变多，先看有没有色带 | 建议不压缩 |

夜景图核对结果（自测）：SHA256 `57b4f29d316f7d2546dd20c4c7fd410b9859c410d4fccd371325ca0bfe3d4d2f`，2048×1024 RGB 无 alpha。地平线辉光最亮的一行是第 879 行，理论位置 877.7，吻合。左右接缝平均差 0.59，相邻列平均差 0.57，可以认为无缝。

**显存**（每张，无 mip）：RGBA8 8.0 MiB / ASTC 4×4 2.0 / 5×5 1.3 / 6×6 0.89 / ETC2 1.0 MiB。草甸默认加载白天 + 夜景两张，ASTC 6×6 合计约 1.8 MiB，未压缩合计 16 MiB。天空之城用 `SKY_NIGHT_TINT_ONLY` 两色渐变（v1.2），不拖夜景图，省一张。

**草甸烘焙地面贴图 `tex_meadow_ground_grassoff_1024.jpg`（v1.3.1，`.meta` 在 `runtime/textures-meta/`）**

| 项 | 设置 | `.meta` 里的字段 |
|---|---|---|
| 类型 | texture（子资源名 `texture`，按需加载路径 `textures/tex_meadow_ground_grassoff_1024/texture`） | `userData.type` = texture，`subMetas.6c48a.name` = texture |
| Mipmap | **开**，三线性 | `mipfilter` = linear，`minfilter` / `magfilter` = linear |
| Wrap | S / T 都 **clamp-to-edge**（地形 UV 正好 0–1） | `wrapModeS` / `wrapModeT` = clamp-to-edge |
| Alpha | 无 | `hasAlpha` = false |
| 压缩 | **ASTC 6×6**（含 mip 626,288 B ≈ **0.60 MiB**；不含 mip 467,856 B），Android 不支持 ASTC 时用 ETC2 RGB，再不行用 JPG | `userData.compressSettings` = { useCompressTexture: true, presetId: `e4-meadow-ground-astc6x6` } |

`texture-compress-preset.e4-meadow-ground-astc6x6.json` 里的 `userPreset` 和 `genMipmaps: true` 要**合并**进工程的 `settings/v2/packages/project.json` → `textureCompressConfig`，不要整文件覆盖。`.meta` 和预设都是照 3.8 工程里已有的 `pieces.png.meta` 格式和 Creator 3.8.8 builder 的类型声明（`UserCompressConfig`）手写的，没在 Creator 里导入过（not_run）。字段名如果和编辑器生成的不一样，以编辑器为准，在属性面板里按上表重新设一遍就行。uuid `cd5f4799-db47-4a3c-8c73-d6215d984a1f` 是新生成的，和工程里的冲突就删掉 uuid 让 Creator 重新生成，引用按路径加载，不依赖 uuid。

**UV 约定**（详见参数表）：Cocos 里 v = 0 是贴图顶行。Creator 3.8.8 导入 glTF 不翻转 v，已用本机 Creator 3.8.8 导入的 98,797 个顶点逐个核对；引擎上传贴图也不翻转。草甸天空球的地平线在 v = 0.857（第 878 行）。

## 九、自测（`tools/selftest/`）

运行方法（在 `tools/selftest/` 下）：
1. `bash cc-compiler-setup/setup.sh`：从本机 Creator 3.8.8 取出官方 effect 编译器，默认放到 `tools/selftest/.cc-effect-compiler`（包里不分发）
2. `node run-selftest.js`（可选 `--engine <Creator 3.8.8 engine 目录>`）

依赖：glslangValidator；Python 3 + Pillow + numpy（夜景图检查）；Creator 3.8.8 安装（官方编译器、TypeScript、cc.d.ts、引擎源码）。

| 组 | 内容 | 结果 |
|---|---|---|
| a 结构 | YAML、入口函数、property↔UBO、std140、varying；默认路径；默认值与 CPU 参考一致；UV 约定实测 | 通过 |
| b 编译 | 官方编译器 0 错误 0 警告；glslang 编译并链接：草 392 × 2 = 784 个程序，天空 104 × 2 = 208 个（含 v1.2 夜空渐变的 `SKY_NIGHT_TINT_ONLY` 全部组合，WebGL1 / WebGL2） | 通过 |
| c CPU 参考 | 风位移各项；天空雾带；夜景图；**v1.2 夜空两色渐变**：shader 两行机械翻译，v=0 → #101430、v=0.857 → #7086B1、v=0.9/0.95/1.0 → #7086B1、中点 = 线性平均、单调 | 通过 |
| d TS | GrassWindQuality 类型检查、分档、wx、切档共用材质 | 通过 |
| e MeadowInstancer | **5 个 TS 同目录一起**严格类型检查（v1.3.1 加 BakedGroundTexture）；包围盒覆盖 410 万个位移顶点；maxA；切档重算；根色重设；防错；注销 | 通过 |
| **f 天空跟随（v1.2）** | 3.8.8 源码阶段顺序逐项比对；cine_camera 式路径零帧延迟（update / 动画系统 / lateUpdate / AFTER_UPDATE / postUpdate / 帧间微任务各 30 帧，单帧最大跳 410 m，父节点有旋转、天空父节点缩放 2×）；GPU 偏移 = 0、不重复位移；剔除；BEFORE_DRAW 晚写检测 + syncAll；自动找相机、注销 | 通过 |
| **g 兜底（v1.2 / v1.3）** | 30% 选择（真实 1,000 丛 + 锚点）：确定性、阈值性、离路 / 视点最近的全保留；均匀抽稀；遮罩钩子；**v1.3 计数统一 round（10 组）**；触发条件 6 种帧序列；MeadowInstancer 无实例化集成（草 300、**花 75**，逐丛与纯函数一致、无 a_root_color、shader 实际走 uniform 分支、rootColor = #60AE32）；统一根色路径；关草 + 地面贴图槽 + 事件；无锚点退回抽稀（草 300 / 花 75）；**v1.3 forceNoInstancing 真换材质** | 通过 |
| **h 生命周期（v1.2 / v1.3）** | validateRootColors；缺失 / 非法根色填补；非单位模板 TRS；先切档后加载；重新启用 / 缩放刷新；**v1.3 祖先缩放（最终 worldScale）+ markBoundsDirty**；卸载释放副本和监听；**v1.3 共享材质计数** | 通过 |
| 反向对照 | 改坏 shader 4 处；不扩包围盒；不监听丢根色；v1 雾带方向；**F1** lateUpdate 跟随落后一帧；**G1** v 方向反了渐变颠倒；**H1** 不释放副本还在；**G2** 只改标志不换材质 → 黑根；**H2** 祖先缩放时根节点收不到 TRANSFORM_CHANGED | 通过 |
| **i 按需加载（v1.3.1）** | I1 场景不引用、进场不加载；I2 关草才加载、加载完前保持原贴图；I3 恢复草换回并 decRef；I4 失败保持原样 + 重试；I5 快速开关 + 乱序回调；I6 加载中 / 已换上时卸载；I7 WIND_QUALITY OFF 触发 / budget 粘滞 / 开关；I8 同步回调、重复回调、加载器抛异常、路径留空；I9 默认 assetManager 加载器路径 | 9 / 9 通过 |
| **i 对照（v1.3.1）** | I1–I7 跑在 v1.3 原文件（`controls/v1.3-runtime-scripts/`）上，**7 / 7 都失败**，失败原因记在结果里（例如 I3：“地面 = 原贴图；有过 decRef”未满足；I7：“OFF → 草禁用 + 加载”未满足） | 通过（= 对照确实失败） |
| **j 美术 v0.8.1（v1.3.1）** | 尺寸 / UV / 朝向（上文第 1 点）；`.meta` 与压缩预设静态检查 | 4 / 4 通过 |
| **k 草甸位姿（v1.3.1）** | 位姿 = v0.8.1a 文件（SHA 校验）= 运镜bot check 输入；运镜bot SHA256SUMS 19 / 19；0007 `assertAuthoredPose` / `validateCameraPose` / `applyCameraPose`（4 种偏移，roll < 0.001）；forward；0.46 / 0.75 `frameCheck` + 余量 0.053；3 个反向对照；其他 stop 不变 | 21 / 21 通过 |
| Oi 独立检查（v1.3.1） | `node independent-checks.cjs <包根目录>`（Oi 的脚本，未改）：15 / 15 通过 | 通过 |
| not_run（12） | 见下表 | 未运行 |

**not_run 清单（12）**

| # | 项 | 原因 |
|---|---|---|
| 1 | Creator 编辑器内导入 .effect / 生成 .meta / 材质面板显示 | 这台电脑没有能登录运行的 Creator 编辑器 |
| 2 | Creator 构建微信小游戏 + 压缩纹理（ASTC / ETC2） | 同上 |
| 3 | 微信开发者工具 / 真机上 WebGL1、WebGL2 的实际链接和渲染 | 没有 DevTools / 真机 |
| 4 | GPU 实例化实际合批（draw call 计数） | 需要 Creator 运行 + Profiler |
| 5 | 帧时间 / 顶点开销 / 低端机性能 | 需要真机 |
| 6 | 画面观感（风幅度、颜色、天空之城夜空渐变、兜底 30% 草） | 需要美术在 Creator 里看 |
| 7 | SkyFollowCamera 在真实 Creator 场景里配合 0007 applyCameraPose / 运镜动画 | 只在 Node 桩里验证 |
| 8 | 没有 ANGLE_instanced_arrays 的真实 WebGL1 设备上的兜底（draw call、帧时间、阈值） | 没有这类真机 |
| 9 | **v1.3.1** 烘焙地面贴图在 Creator 里的导入（.meta / 压缩预设是否生效、ASTC 6×6 实际体积和画质）以及关草时的画面观感 | 没有可运行的 Creator / 真机；.meta 是手写的 |
| 10 | **v1.3.1** 真实 assetManager / bundle 按需加载、decRef 后显存是否真的释放 | 只用可控加载器验证了引用计数和时序；默认加载器只在假 assetManager 上测了调用路径 |
| 11 | **v1.3.1 后续**：在 Cocos 里检查转动的风车叶片会不会扫过小路（位姿 (-4, 24, 62)） | 运镜bot 只做了静帧遮挡检查（帆在小路上方，没有逐帧测） |
| 12 | **v1.3.1** 草甸位姿在 Cocos / 真机上的实际构图（HUD 按钮的实际位置、草甸在区域世界里的实际偏移 rootOffset） | 交叉检查是在 Blender 里做的；0007 这边只写了数据并用 projectPoint 复算 |

另外，天空球地平线以下的颜色（见“v1.3 → v1.3.1”第 3 点）要在 Creator 里看画面确认，属于第 6 项。

说明：
- cc 桩（`cc-stub.js`）只模拟测试相关的引擎行为，出处写在文件头；director 帧顺序由 f 组第一项对照真实源码，源码顺序一变就会失败。
- UV 实测用本机 `/tmp/projA`（Creator 3.8.8 已导入的工程），目录不在时那一项记 not_run。

## 十、还没定的

1. （v1.3 已定）兜底时花减到 50%（75 簇）。
2. （v1.3.1 已定）草甸区域位姿已定稿，写进 0007 补丁（status final）。**草甸根在区域世界里的偏移没找到**，现在 rootOffset = [0,0,0]，接入时由放草甸的一方填。兜底的视点仍然用锚点；如果要把区域镜头位置也算作视点，往 `extraViews` 里拖一个放在 (-4, 24, 62) 的节点即可。
3. （v1.3.1 已接）烘焙草色地面贴图改为按需加载，换到 `groundRenderer` 的 `groundTextureProperty`（默认 `mainTexture`，地面材质属性名不同就改这里）。WIND_QUALITY = OFF 也会关草，可以用 `grassOffWhenWindQualityOff` 关掉。
9. （v1.3.1）天空球地平线以下要保持地平线色：现有白天图和夜景图在地平线以下都不是地平线色，需要美术处理（见“v1.3 → v1.3.1”第 3 点）。
4. 关草阈值 40 ms / 5 s / 80% 是起点，要真机定。
5. 海岛如果用 `SKY_NIGHT_TINT_ONLY`，夜色要按海岛另给两色（v1.2 行为变化，见第二节第 4 步）。
6. 多相机共用天空节点不支持（第三节）；多相机场景要按每相机一个天空节点做，并另测。
7. 直接替换展开节点的 mesh 不会被自动检测，改的一方调 `markBoundsDirty()`。
8. v1.1 遗留：白天天空图是否重出；GLB 调色板采样器 minFilter 改 LINEAR；光照强度、地平线雾宽度等看画面再定。

## 附：v1.1 更新内容（相对 v1，保留备查）

| # | 改动 | 文件 |
|---|---|---|
| 1 | **风向定为世界空间**（默认）。整片草沿 windDir 一起倒，丛与丛之间靠 COLOR_0.g 相位区分。`WIND_SPACE 1`（模板本地）只保留做对比 | effect 注释、参数表 |
| 2 | windDir 默认改成美术 README（2026-10-09 修订版）主风向 W = (0.944, −0.330) 的归一化值 **(0.94398, −0.32999)** | meadow-grass-wind.effect |
| 3 | COLOR_0.b 改成“无意义的导出常量，忽略，保留”。COLOR_0 实际是 UNSIGNED_SHORT 归一化，和美术 README 修订版一致 | effect 注释、参数表 |
| 4 | **不走静态合批**，只用 GPU 实例化。`WIND_PHASE_ORIGIN` 换成 `WIND_PHASE_PER_VERTEX`：默认关，即按实例原点算相位。逐顶点相位只保留，文档里不再推荐。draw call 表里删掉了静态合批那一行 | effect、参数表、README |
| 5 | 调色板贴图 **关 mipmap**：导入设置和 `.meta` 写法见参数表第四节 | MATERIAL-PARAMS.md |
| 6 | **夜景图成为默认夜晚路径**：`USE_NIGHT_TEXTURE` 换成 `SKY_NIGHT_TINT_ONLY`（默认关，默认就会采样 nightTexture）；nightTint 默认改成白色。接入的是美术交付的 `tex_meadow_sky_night_2048x1024.png` | sky-unlit.effect、参数表 |
| 7 | **修正 bug：地平线雾方向反了**。v1 按“v 从底往上量”写，horizonV = 0.143。核实后确认 Cocos 里 v 是从贴图顶边往下量，地平线在 v = 0.857，所以 v1 的雾会跑到天顶。已改成 `h = smoothstep(horizonV − horizonWidth, horizonV, v)`，默认 horizonV = 0.857，约定写进了 effect 注释 | sky-unlit.effect |
| 8 | **MeadowInstancer 改动**：① 按材质里的风参数和网格的 max(COLOR_0.a) 扩大每个实例的包围盒，草尖不会在屏幕边缘突然出现；② 切档换材质后重设 a_root_color。切档或改风参数时两者都会重算 | `scripts/MeadowInstancer.ts`、`patches/0001-…diff` |
| 9 | GrassWindQuality.ts 新增：全局事件 `grassWindEvents`、`setGrassWindParams()`（改参数会同步到各档的运行时材质）、包围盒工具函数 | scripts/GrassWindQuality.ts |
| 10 | 修正 v1 数据：v0.8 草尖最大位移是 **0.81 m**，解析上界 0.851 m。v1 写的 0.69 m 只采了 4 个时刻，偏小。实例化后顶点数是 6.8 万（v1 有一处误写成 8.8 万） | 文档、自测 |
| 11 | 顺手修了原型的一个编译错误：`renderer.scene.ShadowCastingMode` 在 3.8.8 不存在，改成 `MeshRenderer.ShadowCastingMode` | MeadowInstancer.ts |

v1 → v1.1 的完整差异见 `tools/patches/0002-E4-v1-to-v1.1.diff`。
