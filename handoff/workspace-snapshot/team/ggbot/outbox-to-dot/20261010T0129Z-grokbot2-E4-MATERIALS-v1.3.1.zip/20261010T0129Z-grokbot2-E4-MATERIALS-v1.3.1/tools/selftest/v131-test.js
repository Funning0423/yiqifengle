'use strict';
// E4 v1.3.1 Node 测试：
//  i-ground-ondemand  烘焙草色地面贴图按需加载（BakedGroundTexture.ts + MeadowInstancer）：I1–I7 在 v1.3.1 上必须通过；
//  i-ground-control   同一组 I1–I7 跑在 v1.3 原代码（controls/v1.3-runtime-scripts，v1.3 包里的原文件）上必须失败 = 证明测试能抓到旧行为；
//  j-art-v081         美术 v0.8.1 贴图核对（ground-tex-check.py：尺寸 / UV 公式 / 朝向）；
//  k-meadow-pose      草甸位姿过 0007 真实 CameraPose.ts（meadow-pose-test.mjs）。
const fs = require('fs'), ps = require('path'), cp = require('child_process');
const makeCC = require('./cc-stub');

module.exports = async function run (ctx) {
  const { ts, rec, INST, HERE } = ctx;
  const NEW = ps.join(HERE, '../../runtime/scripts'), OLD = ps.join(HERE, 'controls/v1.3-runtime-scripts');
  const G = 'i-ground-ondemand', GC = 'i-ground-control';
  if (!fs.existsSync(INST)) { rec(G, '按需加载测试', null, `找不到 ${INST}`); return; }
  const inst = JSON.parse(fs.readFileSync(INST, 'utf8'));
  const isGrass = (g) => String(g.template || '').startsWith('grass_') || !!(g.attrs && g.attrs._ROOT_COLOR);
  const groups = [inst.groups.find(isGrass), inst.groups.find(g => !isGrass(g))];

  class FakeTex { constructor (n) { this.name = n; this.refCount = 0; this.addRefs = 0; this.decRefs = 0; } addRef () { this.refCount++; this.addRefs++; return this; } decRef () { this.refCount--; this.decRefs++; if (this.refCount < 0) throw Error('decRef below 0: ' + this.name); return this; } }
  // 可控加载器：记下请求，测试决定何时 / 以什么结果回调
  const makeLoader = () => { const reqs = []; const f = (bundle, path, done) => reqs.push({ bundle, path, done }); f.reqs = reqs; return f; };

  // impl = 'new'（v1.3.1，按需加载）| 'old'（v1.3：场景直接引用 bakedGroundTexture，setGrassOff 立即换）
  const build = (dir, impl, opts = {}) => {
    const env = makeCC({ instancing: true }); const { cc } = env; const S = makeCC.loadScripts(ts, dir, cc, ['GrassWindQuality', 'GrassFallback', 'MeadowInstancer']);
    const { Node, MeshRenderer, Material, Vec3 } = cc;
    const base = new Material(); Object.assign(base.passes[0].defines, { WIND_QUALITY: 2, USE_INSTANCING: true, USE_INSTANCE_ROOT_COLOR: true });
    const flowerMat = new Material(); flowerMat.effectName = 'builtin-standard';
    const root = new Node('meadow_root');
    const mesh = (n) => ({ name: n, struct: { minPosition: new Vec3(-0.3, 0, -0.3), maxPosition: new Vec3(0.3, 0.6, 0.3), primitives: [], vertexBundles: [] }, readAttribute: () => null });
    const data = { groups: JSON.parse(JSON.stringify(groups)) };
    for (const g of data.groups) { const n = new Node(g.node); root.addChild(n); const r = n.addComponent(MeshRenderer); r.mesh = mesh(g.template); r.setSharedMaterial(isGrass(g) ? base : flowerMat, 0); }
    const origTex = new FakeTex('meadow_ground_v0_8_1024'); const gm = new Material(); gm.effectName = 'builtin-standard'; gm.props.mainTexture = origTex;
    const ground = new Node('meadow_terrain'); root.addChild(ground); const gr = ground.addComponent(MeshRenderer); gr.mesh = mesh('ground'); gr.setSharedMaterial(gm, 0);
    const comp = new S.MeadowInstancer.MeadowInstancer(); comp.node = root; comp.instances = { json: data };
    Object.assign(comp, { castShadows: false, fallbackKeepRatio: 0.3, flowerKeepRatio: 0.5, forceNoInstancing: false, viewAnchorNames: [], extraViews: [], frameBudgetMs: 40, budgetWindowSec: 5, budgetOverRatio: 0.8,
      groundRenderer: gr, groundTextureProperty: 'mainTexture', releaseMaterialsOnDestroy: true }, opts.props || {});
    const loader = makeLoader(); const texs = [];
    const nextTex = () => { const t = new FakeTex('tex_meadow_ground_grassoff_1024#' + texs.length); texs.push(t); return t; };
    if (impl === 'new') { comp.groundTextureLoader = opts.loader || loader; }
    else { comp.bakedGroundTexture = nextTex(); }        // v1.3：唯一能拿到贴图的方式 = 场景里直接拖引用（随场景加载）
    const warns = []; const w = console.warn; console.warn = (...a) => warns.push(a.map(String).join(' '));
    try { comp.start(); } finally { console.warn = w; }
    const groundTex = () => (gr.instances && gr.instances[0] ? gr.instances[0].props.mainTexture : gm.props.mainTexture);
    const grassRs = () => root.children.filter(n => /_expanded$/.test(n.name)).flatMap(h => h.children).filter(n => n.name.startsWith('grass_')).map(n => n.getComponent(MeshRenderer));
    const call = (f) => { const w2 = console.warn; console.warn = (...a) => warns.push(a.map(String).join(' ')); try { return f(); } finally { console.warn = w2; } };
    return { cc, S, comp, gr, root, origTex, loader, texs, nextTex, groundTex, grassRs, warns, call, impl };
  };
  const resolve = (T, i, tex) => T.call(() => T.loader.reqs[i].done(null, tex));
  const fail = (T, i) => T.call(() => T.loader.reqs[i].done(new Error('404 tex_meadow_ground_grassoff_1024'), null));
  const allZero = (T) => T.texs.every(t => t.refCount === 0);

  // 每个用例返回 {ok, why}；why 列出没满足的条件（旧代码失败时说明抓到的是哪一条）
  const check = (conds) => { const bad = Object.entries(conds).filter(([, v]) => !v).map(([k]) => k); return { ok: bad.length === 0, why: bad.length ? '未满足：' + bad.join('；') : '全部满足' }; };
  const cases = [
    ['I1 场景不直接引用烘焙贴图、进场（草开着）不加载：组件上没有贴图引用，加载器 0 次，贴图引用计数 0；源码里没有 @property(Texture2D)', (dir, impl) => {
      const T = build(dir, impl); const src = fs.readFileSync(ps.join(dir, 'MeadowInstancer.ts'), 'utf8');
      return check({ '组件属性里没有贴图对象': !Object.values(T.comp).some(v => v instanceof FakeTex), '进场加载 0 次': T.loader.reqs.length === 0, '源码无 @property(Texture2D)': !/@property\(\s*Texture2D\s*\)/.test(src), '地面是原贴图': T.groundTex() === T.origTex });
    }],
    ['I2 关草才加载，加载完成前地面保持原贴图；完成后换上并 addRef（引用 1），bundle / 路径 = region_meadow / textures/tex_meadow_ground_grassoff_1024/texture', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); const n = T.loader.reqs.length; const before = T.groundTex(); const grassOff = T.grassRs().every(r => r.enabled === false);
      let after = null, tex = null; if (n === 1) { tex = T.nextTex(); resolve(T, 0, tex); after = T.groundTex(); }
      const r0 = T.loader.reqs[0] || {};
      return check({ '关草后发起 1 次加载': n === 1, '加载中地面仍是原贴图': before === T.origTex, '草 renderer 已全部禁用': grassOff, '加载完成后地面 = 烘焙贴图': !!tex && after === tex, '引用计数 1': !!tex && tex.refCount === 1, '默认 bundle/路径': r0.bundle === 'region_meadow' && r0.path === 'textures/tex_meadow_ground_grassoff_1024/texture', 'state=applied': T.comp.groundTextureState && T.comp.groundTextureState.state === 'applied' });
    }],
    ['I3 恢复草：地面换回原贴图，烘焙贴图 decRef 到 0（交还 assetManager 释放）', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); if (T.loader.reqs.length) resolve(T, 0, T.nextTex());
      T.call(() => T.comp.setGrassOff(false));
      return check({ '地面 = 原贴图': T.groundTex() === T.origTex, '所有烘焙贴图引用 0': allZero(T), '有过 decRef': T.texs.some(t => t.decRefs > 0), '草 renderer 恢复': T.grassRs().every(r => r.enabled !== false) });
    }],
    ['I4 加载失败：地面保持原贴图、console.warn、state=failed、无引用；草仍关着；再次关草会重试并成功', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); const n1 = T.loader.reqs.length; if (n1) fail(T, 0);
      const st = T.comp.groundTextureState; const kept = T.groundTex() === T.origTex; const warned = T.warns.some(m => /加载失败/.test(m)); const stillOff = T.grassRs().every(r => r.enabled === false);
      T.call(() => { T.comp.setGrassOff(false); T.comp.setGrassOff(true); }); const n2 = T.loader.reqs.length; let tex = null; if (n2 === 2) { tex = T.nextTex(); resolve(T, 1, tex); }
      return check({ '发起了加载': n1 === 1, '失败后地面 = 原贴图': kept, 'warn': warned, 'state=failed': !!st && st.state === 'failed' && st.stats.failed === 1, '草仍关': stillOff, '重试发起第 2 次加载': n2 === 2, '重试成功换上': !!tex && T.groundTex() === tex && tex.refCount === 1 });
    }],
    ['I5 快速开关（关/开/关/开/关，回调乱序 3→1→2 到达）：只有最后一次请求的贴图贴上（引用 1），过期的 2 张 addRef 后立刻 decRef（引用 0）；再开草全部归 0；关→开后回调才到：地面不变、引用 0', (dir, impl) => {
      const T = build(dir, impl); T.call(() => { T.comp.setGrassOff(true); T.comp.setGrassOff(false); T.comp.setGrassOff(true); T.comp.setGrassOff(false); T.comp.setGrassOff(true); });
      const n = T.loader.reqs.length; let t1, t2, t3; let midOk = false, finalOk = false;
      if (n === 3) { t1 = T.nextTex(); t2 = T.nextTex(); t3 = T.nextTex(); const beforeAny = T.groundTex() === T.origTex; resolve(T, 2, t3); resolve(T, 0, t1); resolve(T, 1, t2);
        midOk = beforeAny && T.groundTex() === t3 && t3.refCount === 1 && t1.refCount === 0 && t2.refCount === 0 && T.comp.groundTextureState.stats.stale === 2; }
      T.call(() => T.comp.setGrassOff(false)); const back = T.groundTex() === T.origTex && allZero(T);
      T.call(() => { T.comp.setGrassOff(true); T.comp.setGrassOff(false); }); const m = T.loader.reqs.length; if (m === n + 1) { const t4 = T.nextTex(); resolve(T, m - 1, t4); finalOk = T.groundTex() === T.origTex && t4.refCount === 0; }
      return check({ '3 次关草 = 3 次加载': n === 3, '乱序回调后只贴最后一次请求的贴图、过期的引用 0': midOk, '开草后原贴图且全部引用 0': back, '开草后才到的回调被丢弃': finalOk });
    }],
    ['I6 区域卸载（onDestroy）：加载中卸载 → 之后的回调不写地面、贴图引用 0；已换上时卸载 → 地面换回原贴图、引用 0', (dir, impl) => {
      const A = build(dir, impl); A.call(() => A.comp.setGrassOff(true)); const nA = A.loader.reqs.length; A.call(() => A.comp.onDestroy()); let aOk = false;
      if (nA === 1) { const t = A.nextTex(); resolve(A, 0, t); aOk = A.groundTex() === A.origTex && t.refCount === 0; }
      const B = build(dir, impl); B.call(() => B.comp.setGrassOff(true)); if (B.loader.reqs.length) resolve(B, 0, B.nextTex()); const applied = B.groundTex() !== B.origTex; B.call(() => B.comp.onDestroy());
      return check({ '加载中卸载：发起过加载': nA === 1, '加载中卸载：回调不写地面、引用 0': aOk, '已换上后卸载：换回原贴图': applied && B.groundTex() === B.origTex, '已换上后卸载：引用 0': allZero(B) && B.texs.some(t => t.decRefs > 0) });
    }],
    ['I7 WIND_QUALITY 切 OFF = 关草（禁用草 + 加载烘焙地面），切回 LOW 恢复；无实例化超预算（budget）关草时切回 LOW 不恢复；grassOffWhenWindQualityOff=false 时 OFF 不关草（v1.3 行为）', (dir, impl) => {
      const T = build(dir, impl); const rs = T.grassRs(); T.call(() => T.S.GrassWindQuality.applyGrassWindQuality(rs, 0)); const off = rs.every(r => r.enabled === false) && T.loader.reqs.length === 1;
      if (T.loader.reqs.length) resolve(T, 0, T.nextTex()); T.call(() => T.S.GrassWindQuality.applyGrassWindQuality(rs, 1)); const on = rs.every(r => r.enabled !== false) && T.groundTex() === T.origTex && allZero(T);
      T.call(() => { T.comp.setGrassOff(true, 'budget'); T.S.GrassWindQuality.applyGrassWindQuality(rs, 0); T.S.GrassWindQuality.applyGrassWindQuality(rs, 2); }); const sticky = rs.every(r => r.enabled === false) && T.comp.grassOff === true;
      const U = build(dir, impl, { props: { grassOffWhenWindQualityOff: false } }); const urs = U.grassRs(); U.call(() => U.S.GrassWindQuality.applyGrassWindQuality(urs, 0)); const optOut = urs.every(r => r.enabled !== false) && U.loader.reqs.length === 0;
      return check({ 'OFF → 草禁用 + 加载': off, 'LOW → 草恢复、原贴图、引用 0': on, 'budget 关草粘滞（切 HIGH 不恢复）': sticky, '开关关掉时 OFF 不关草': optOut });
    }],
  ];
  const runCase = (dir, impl, f) => { try { return f(dir, impl); } catch (e) { return { ok: false, why: '异常：' + String(e && e.message || e) }; } };
  for (const [name, f] of cases) {
    const n = runCase(NEW, 'new', f); rec(G, name, n.ok, n.why);
    const o = runCase(OLD, 'old', f); rec(GC, `对照（v1.3 原代码必须失败）：${name.split(' ')[0]}`, !o.ok, `v1.3 结果：${o.ok ? '通过（对照无效！）' : '失败'} — ${o.why}`);
  }
  // I8 同步回调（贴图已在缓存）+ 回调被调两次 + 加载器抛异常
  {
    const T = build(NEW, 'new', { loader: (b, p, done) => { const t = new FakeTex('cached'); T8.push(t); done(null, t); done(null, t); } }); var T8 = [];
    T.call(() => T.comp.setGrassOff(true)); const ok1 = T8.length === 1 && T.groundTex() === T8[0] && T8[0].refCount === 1; T.call(() => T.comp.setGrassOff(false)); const ok2 = T.groundTex() === T.origTex && T8[0].refCount === 0;
    const X = build(NEW, 'new', { loader: () => { throw Error('boom'); } }); X.call(() => X.comp.setGrassOff(true)); const ok3 = X.groundTex() === X.origTex && X.comp.groundTextureState.state === 'failed';
    const Y = build(NEW, 'new', { props: { bakedGroundTexturePath: '' } }); Y.call(() => Y.comp.setGrassOff(true)); const ok4 = Y.loader.reqs.length === 0 && Y.grassRs().every(r => r.enabled === false) && Y.groundTex() === Y.origTex;
    rec(G, 'I8 同步回调（贴图已在缓存）立即换上、重复回调只算一次；加载器抛异常 = 加载失败（地面不变）；路径留空 = 只关草不加载', ok1 && ok2 && ok3 && ok4, `sync=${ok1}/${ok2} throw=${ok3} empty=${ok4}`);
  }
  // I9 默认加载器（assetManager）：bundle 已加载 → bundle.load(path, Texture2D)；未加载 → loadBundle 再 load；bundle 加载失败 / 没有 assetManager → 失败回调
  {
    const calls = []; const mkBundle = (name) => ({ name, load (p, type, cb) { calls.push([name, p, type && type.name]); cb(null, { p }); } });
    const am = { bundles: { region_meadow: mkBundle('region_meadow') }, getBundle (n) { return this.bundles[n] || null; }, loadBundle (n, cb) { calls.push(['loadBundle', n]); if (n === 'missing') cb(new Error('no bundle')); else { this.bundles[n] = mkBundle(n); cb(null, this.bundles[n]); } } };
    const env = makeCC({ instancing: true, assetManager: am }); const B = makeCC.loadScripts(ts, NEW, env.cc, ['BakedGroundTexture']).BakedGroundTexture;
    const out = []; const cb = (e, t) => out.push([e ? String(e.message) : null, t]);
    B.defaultGroundTextureLoader('region_meadow', 'textures/tex_meadow_ground_grassoff_1024/texture', cb); B.defaultGroundTextureLoader('other', 'x/texture', cb); B.defaultGroundTextureLoader('missing', 'x/texture', cb);
    const env2 = makeCC({ instancing: true }); const B2 = makeCC.loadScripts(ts, NEW, env2.cc, ['BakedGroundTexture']).BakedGroundTexture; B2.defaultGroundTextureLoader('region_meadow', 'p', cb);
    const ok = out.length === 4 && out[0][0] === null && out[0][1].p === 'textures/tex_meadow_ground_grassoff_1024/texture' && calls[0][2] === 'Texture2D' && calls.some(c => c[0] === 'loadBundle' && c[1] === 'other') && out[1][0] === null && out[2][0] === 'no bundle' && out[3][0] === 'assetManager unavailable';
    rec(G, 'I9 默认加载器：已加载的 bundle 直接 bundle.load(path, Texture2D)；未加载先 loadBundle；bundle 失败 / 没有 assetManager → 失败回调（不抛）', ok, JSON.stringify(calls));
  }

  // ---------------------------------------------------------------- J 美术 v0.8.1 贴图核对
  {
    const ART = ctx.ART081 || process.env.E4_ART081 || '/workspace/e4/art081/v0.8.1-bake';
    const V08 = ctx.V08 || process.env.E4_V08 || '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8';
    const args = [ps.join(HERE, 'ground-tex-check.py'), ps.join(ART, 'textures/tex_meadow_ground_grassoff_1024.jpg'), ps.join(V08, 'textures/meadow_ground_v0_8_1024.jpg'), ps.join(V08, 'meadow_greybox_v0_8.glb'), ps.join(V08, 'data/anchors_v0_8.json'), ps.join(HERE, 'out/ground-tex-check.json')];
    if (!args.slice(1, 5).every(fs.existsSync)) rec('j-art-v081', '烘焙贴图核对', null, '找不到美术 v0.8.1 / v0.8 文件：' + args.slice(1, 5).filter(p => !fs.existsSync(p)).join(', '));
    else {
      const r = cp.spawnSync('python3', args, { encoding: 'utf8' }); let R = null; try { R = JSON.parse(r.stdout); } catch (e) { /* */ }
      if (!R) rec('j-art-v081', '烘焙贴图核对', false, (r.stderr || '').slice(0, 400));
      else {
        rec('j-art-v081', `尺寸：${R.baked.size.join('×')} ${R.baked.mode} ${R.baked.format}（v0.8 地面 ${R.v08_ground.size.join('×')}），sha256 ${R.baked.sha256.slice(0, 8)}…`, R.baked.size[0] === 1024 && R.baked.size[1] === 1024 && R.baked.mode === 'RGB' && R.baked.sha256 === 'bb369d4d1512637e7e2863f521fb6e58f5a1c5f3e9d2252ac3aa99c77e19d530', '');
        rec('j-art-v081', `UV：v0.8 GLB meadow_terrain（${R.uv.vertices} 顶点，材质 ${R.uv.material} 用 TEXCOORD_${R.uv.baseColor_texCoord} 采 ${R.uv.baseColor_image}）满足 u=(x+80)/160、v=(z+80)/160，最大误差 ${R.uv.max_abs_err_u.toExponential(1)} / ${R.uv.max_abs_err_v_topdown.toExponential(1)}（若按上下翻转则误差 ${R.uv.max_abs_err_v_if_flipped}）`, R.uv.max_abs_err_u < 1e-4 && R.uv.max_abs_err_v_topdown < 1e-4 && R.uv.baseColor_texCoord === 0, '');
        const o = R.orientation;
        rec('j-art-v081', `朝向（不翻转）：${o.walk_path_points} 个 walk_path 锚点按该公式取像素，原样 ${o.dirt_hits_as_is} 个落在土路色上（上下翻 ${o.dirt_hits_if_v_flipped}、左右翻 ${o.dirt_hits_if_u_mirrored}）；与 v0.8 地面图逐像素几乎相同的比例原样 ${(o.near_equal_v08_fraction_as_is * 100).toFixed(2)}%（上下翻 ${(o.near_equal_v08_fraction_v_flipped * 100).toFixed(3)}%、左右翻 ${(o.near_equal_v08_fraction_u_mirrored * 100).toFixed(3)}%）`, R.ok, '');
      }
    }
  }
  // J4 .meta / 压缩预设（静态检查；Creator 里是否生效 not_run）
  {
    const M = ps.join(HERE, '../../runtime/textures-meta'); let ok = false, why = '';
    try {
      const meta = JSON.parse(fs.readFileSync(ps.join(M, 'tex_meadow_ground_grassoff_1024.jpg.meta'), 'utf8')); const sub = meta.subMetas['6c48a']; const u = sub.userData;
      const pre = JSON.parse(fs.readFileSync(ps.join(M, 'texture-compress-preset.e4-meadow-ground-astc6x6.json'), 'utf8')).textureCompressConfig;
      const p = pre.userPreset[meta.userData.compressSettings.presetId];
      let astc = 0, sz = 1024; for (;;) { const b = Math.ceil(sz / 6); astc += b * b * 16; if (sz === 1) break; sz >>= 1; }
      ok = meta.importer === 'image' && meta.userData.type === 'texture' && meta.userData.hasAlpha === false && sub.name === 'texture' && u.wrapModeS === 'clamp-to-edge' && u.wrapModeT === 'clamp-to-edge' && u.mipfilter === 'linear' && u.minfilter === 'linear'
        && meta.userData.compressSettings.useCompressTexture === true && !!p && !!p.options.miniGame.astc_6x6 && pre.genMipmaps === true && astc === 626288;
      why = `presetId=${meta.userData.compressSettings.presetId} miniGame=${Object.keys(p.options.miniGame)} ASTC6x6+mips=${astc} B (${(astc / 1048576).toFixed(2)} MiB)`;
    } catch (e) { why = String(e); }
    rec('j-art-v081', '.meta：image→texture 子资源 name=texture（按需加载路径 textures/tex_meadow_ground_grassoff_1024/texture）、wrap S/T = clamp-to-edge、mipfilter linear（mipmap 开，三线性）、hasAlpha false、compressSettings 指向预设 e4-meadow-ground-astc6x6（miniGame astc_6x6 → etc2_rgb → jpg，genMipmaps）；ASTC 6×6 含 mip = 626,288 B ≈ 0.60 MiB', ok, why);
  }
  // ---------------------------------------------------------------- K 草甸位姿 → 0007 CameraPose.ts
  {
    // 0007 的 CameraPose.ts 只读引用（0007 v1.3 树）；RegionCameraData.ts 用本包 tools/patches/0007-meadow-pose/ 里打过补丁的副本
    const CP = process.env.E4_0007_CAMERAPOSE || '/workspace/t0007/sim13/creator-build-project/assets/scripts/world-r1/CameraPose.ts';
    const RCD = ps.join(HERE, '../patches/0007-meadow-pose/RegionCameraData.ts.patched');
    let W = ctx.W0007 || process.env.E4_0007_WORLD_R1 || '';
    if (!W && fs.existsSync(CP) && fs.existsSync(RCD)) { W = fs.mkdtempSync(ps.join(require('os').tmpdir(), 'e4-0007-')); fs.copyFileSync(CP, ps.join(W, 'CameraPose.ts')); fs.copyFileSync(RCD, ps.join(W, 'RegionCameraData.ts')); }
    if (!W) W = ps.dirname(CP);
    const POSE = ctx.POSE || process.env.E4_MEADOW_POSE || '/workspace/wechat-game/team/art/outbox-to-dot/20261010T0127Z-grokbot2-meadow_camera_pose-v0.8.1a.json';
    const ANCH = ctx.ANCH || '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/data/anchors_v0_8.json';
    const CHK = ctx.CHK || process.env.E4_POSE_CHECK || '/workspace/wechat-game/team/cinematic/work/meadow-pose-check';
    const need = [ps.join(W, 'CameraPose.ts'), ps.join(W, 'RegionCameraData.ts'), POSE, ANCH, ps.join(CHK, 'SHA256SUMS')];
    if (!need.every(fs.existsSync)) rec('k-meadow-pose', '草甸位姿', null, '找不到：' + need.filter(p => !fs.existsSync(p)).join(', '));
    else {
      const r = cp.spawnSync('node', [ps.join(HERE, 'meadow-pose-test.mjs'), W, POSE, ANCH, CHK, ps.join(HERE, 'out/meadow-pose-test.json')], { encoding: 'utf8' });
      let R = null; try { R = JSON.parse(r.stdout.slice(r.stdout.indexOf('{'))); } catch (e) { /* */ }
      if (!R) rec('k-meadow-pose', '草甸位姿', false, (r.stderr || r.stdout || '').slice(0, 400));
      else for (const x of R.results) rec('k-meadow-pose', x.name, x.pass, JSON.stringify(x.detail || '').slice(0, 300));
    }
  }
};
