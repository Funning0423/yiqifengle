// 0007 v1.3 self-test: syntax (parseDiagnostics) + typecheck (cc stubbed) + pure-math/data/state-machine checks.
const ts=require(process.env.TS||'/tmp/ggts/node_modules/typescript'),fs=require('fs'),path=require('path');
const SRC=process.argv[2];const out={syntax:{},typecheck:null,tests:[]};let fail=0;
const ok=(name,cond,detail)=>{out.tests.push({name,pass:!!cond,detail});if(!cond)fail++;};
const files=['CameraPose.ts','RegionCameraData.ts','FirstsliceRoutes.ts','WorldFlowCore.ts','WorldFlowComponent.ts'];
for(const f of files){const sf=ts.createSourceFile(f,fs.readFileSync(path.join(SRC,f),'utf8'),ts.ScriptTarget.ES2020,true,ts.ScriptKind.TS);out.syntax[f]=sf.parseDiagnostics.length;if(sf.parseDiagnostics.length)fail++;}
// typecheck with a minimal 'cc' stub (decorators etc. as any)
{const stub=path.join(__dirname,'cc-stub.d.ts');fs.writeFileSync(stub,"declare module 'cc' { export const _decorator:any; export class Component{node:any;addComponent(c:any):any;} export class Prefab{} export function instantiate(p:any):any; export class Camera{node:any;fov:number;} export class Vec3{constructor(...a:any[]);x:number;y:number;z:number;} export class MeshRenderer{node:any;enabled:boolean;} export class Node{[k:string]:any} export const game:any; export class Game{static EVENT_HIDE:string;static EVENT_SHOW:string;} export class SkeletalAnimation{[k:string]:any} export class AnimationClip{[k:string]:any;static WrapMode:any} export class AnimationState{[k:string]:any} export const assetManager:any; export function isValid(o:any,s?:boolean):boolean; }\ndeclare module '../region/RegionAmbientAnimation' { export class RegionAmbientAnimation{clipUuids:string[];} }\n");
 const prog=ts.createProgram([...files.map(f=>path.join(SRC,f)),stub],{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS,strict:true,noEmit:true,experimentalDecorators:true,skipLibCheck:true,lib:['lib.es2020.d.ts','lib.dom.d.ts'],baseUrl:SRC});
 const d=ts.getPreEmitDiagnostics(prog).filter(x=>!x.file||files.includes(path.basename(x.file.fileName)));
 out.typecheck=d.map(x=>(x.file?path.basename(x.file.fileName)+':'+(x.file.getLineAndCharacterOfPosition(x.start).line+1)+' ':'')+ts.flattenDiagnosticMessageText(x.messageText,' '));if(d.length)fail++;}
// transpile pure modules
const tmp=path.join(__dirname,'js');fs.mkdirSync(tmp,{recursive:true});
for(const f of ['CameraPose.ts','RegionCameraData.ts','FirstsliceRoutes.ts','WorldFlowCore.ts','FirstsliceFacts.ts','CharacterReference.ts'])fs.writeFileSync(path.join(tmp,f.replace('.ts','.js')),ts.transpileModule(fs.readFileSync(path.join(SRC,f),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText);
const C=require(path.join(tmp,'CameraPose.js')),D=require(path.join(tmp,'RegionCameraData.js')),R=require(path.join(tmp,'FirstsliceRoutes.js')),W=require(path.join(tmp,'WorldFlowCore.js'));
const {FIRSTSLICE}=require(path.join(tmp,'FirstsliceFacts.js')),{CHARACTER_REFERENCE}=require(path.join(tmp,'CharacterReference.js'));
const near=(a,b,e=1e-6)=>a.every((v,i)=>Math.abs(v-b[i])<e);
// 1. lookAt equivalence: camera -Z points at target, +Y up-ish, no roll
for(const [n,v] of Object.entries({...D.REGION_CAMERA.island.variants,...Object.fromEntries(Object.entries(D.REGION_CAMERA.home.variants).map(([k,v])=>['home:'+k,v]))})){if(!v)continue;
 const q=C.rotationFromLookAt(v.position,v.target),f=C.rotate(q,[0,0,-1]),d=[v.target[0]-v.position[0],v.target[1]-v.position[1],v.target[2]-v.position[2]],l=Math.hypot(...d);
 ok('lookAt-forward '+n,near(f,d.map(x=>x/l),1e-9));ok('lookAt-noroll '+n,Math.abs(C.rotate(q,[1,0,0])[1])<1e-9&&C.rotate(q,[0,1,0])[1]>0);ok('valid '+n,C.validateCameraPose(C.fromLookAt(v))===null);}
// 2. horizon-keeping blends (no slerp)
{const A=D.REGION_CAMERA.island.variants['legacy-capsule'],B=D.REGION_CAMERA.island.variants['temporary-6m'];
 const m0=C.blendLookAt(A,B,0,'easeInOutCubic'),m1=C.blendLookAt(A,B,1,'easeInOutCubic');
 ok('blendLookAt endpoints',near(m0.position,A.position)&&near(m1.position,B.position)&&near(m1.rotation,C.fromLookAt(B).rotation,1e-12));
 let maxR=0;for(let i=0;i<=200;i++){const a=C.fromLookAt({position:[-0.58,1.65,1.6],target:[-0.2,1.1,2.6],fovVerticalDeg:55}),b=C.fromLookAt(B);const m=C.blendPoseHorizon(a,b,i/200,'easeInOutCubic');maxR=Math.max(maxR,Math.abs(C.rotate(m.rotation,[1,0,0])[1]));if(C.validateCameraPose(m))maxR=9;}
 ok('blendPoseHorizon (0006 §C helper) roll 0 over 201 samples',maxR<1e-9,maxR);
 ok('no slerp export',C.slerp===undefined&&C.blendPose===undefined);}
// 3. frame checks
const ch=D.REGION_CAMERA.islandCharacter,box=C.characterBox(ch.root,ch.heightM,ch.halfWidthM);const frames={};
for(const [n,fov] of [['legacy-capsule',45],['legacy-capsule',55],['temporary-6m',45],['temporary-6m',55]])for(const a of [.46,.75]){const p=C.fromLookAt({...D.REGION_CAMERA.island.variants[n],fovVerticalDeg:fov});const r=C.frameCheck(p,a,box);frames[`${n}@fov${fov}@${a}`]={x:[+r.minX.toFixed(3),+r.maxX.toFixed(3)],y:[+r.minY.toFixed(3),+r.maxY.toFixed(3)],pass:r.pass};}
out.frames=frames;ok('temporary-6m bbox in frame 0.46',frames['temporary-6m@fov45@0.46'].pass);ok('temporary-6m bbox in frame 0.75',frames['temporary-6m@fov45@0.75'].pass);ok('legacy fails (reproduces OI-FRAME-002 class)',!frames['legacy-capsule@fov45@0.46'].pass);
ok('6m distance',Math.abs(Math.hypot(...[-5.796-(-2.114),3.323-0.9,9.352-5.281]))-6<0.01);
// 4. routes read data; exit_path_17
const cfg=R.createFirstsliceRoutes(FIRSTSLICE,CHARACTER_REFERENCE);
ok('cameraIsland = temporary-6m data',near(cfg.cameraIsland.position,[-5.796,3.323,9.352])&&cfg.cameraIsland.fovVerticalDeg===45);
ok('cameraHome = oi-interim-standing data',near(cfg.cameraHome.position,[-1.1,1.5,-2.4])&&near(cfg.cameraHome.target,[.1,.86,-4.35])&&cfg.cameraHome.fovVerticalDeg===55);
ok('island root = exit_path_17 = data root',near(cfg.toIsland[cfg.toIsland.length-1],ch.root,1e-3),cfg.toIsland[cfg.toIsland.length-1]);
// 5. data-only switch
{const save=D.REGION_CAMERA.islandPoseSource;const warn=console.warn;let warned=0;console.warn=()=>warned++;
 D.REGION_CAMERA.islandPoseSource='yunjing-final';let e=D.islandPoseEntry();ok('yunjing-final null -> fallback temporary-6m + warn',e===D.REGION_CAMERA.island.variants['temporary-6m']&&warned===1);
 D.REGION_CAMERA.island.variants['yunjing-final']={position:[-8,6,12],target:[-2.1,.9,5.3],fovVerticalDeg:45,characterYawDeg:20,source:'test'};
 const c2=R.createFirstsliceRoutes(FIRSTSLICE,CHARACTER_REFERENCE);ok('yunjing-final data used w/o code change',near(c2.cameraIsland.position,[-8,6,12])&&Math.abs(c2.islandYawRad-20*Math.PI/180)<1e-12);
 D.REGION_CAMERA.island.variants['yunjing-final']=null;D.REGION_CAMERA.islandPoseSource=save;console.warn=warn;}
// 6. FULL motion-mode camera paths through the REAL createCameraTrack -> REAL applyCameraPose with a Cocos-like stub camera
const mkCam=(fov)=>{const cam={fov,writes:[],node:{p:[0,0,0],q:[0,0,0,1],setWorldPosition(x,y,z){this.p=[x,y,z];},setWorldRotation(x,y,z,w){this.q=[x,y,z,w];}}};
  const orig=Object.getOwnPropertyDescriptor(cam,'fov');let f=fov;Object.defineProperty(cam,'fov',{get(){return f;},set(v){f=v;cam.writes.push({p:[...cam.node.p],q:[...cam.node.q],fov:v});}});return cam;};
const errs=[];const realErr=console.error;console.error=(...a)=>errs.push(a.join(' '));const realWarn=console.warn;const warns=[];console.warn=(...a)=>warns.push(String(a[0])+" "+String(a[1])+" "+String(a[2]));
const legs=[
 ['home->toDoor0',[cfg.cameraHome,cfg.cameraToDoor[0]],null],
 ['toDoor(timed)',cfg.cameraToDoor,cfg.toDoor],
 ['inside->outside',[cfg.cameraInside,cfg.cameraOutside],cfg.outCrossing],
 ['outside->island',[cfg.cameraOutside,cfg.cameraIsland],cfg.toIsland],
 ['island->outside',[cfg.cameraIsland,cfg.cameraOutside],cfg.toThreshold],
 ['outside->inside',[cfg.cameraOutside,cfg.cameraInside],cfg.inCrossing],
 ['inside->home',[cfg.cameraInside,cfg.cameraHome],cfg.toSeat]];
const pathTests=[];
for(const [name,path,walk] of legs)for(const fps of ['n121',30,60])for(const startFov of [45,55]){
 const cam=mkCam(startFov);const tr=C.createCameraTrack(cam,path,'test:'+name);
 const seconds=walk?W.pathDuration(walk,cfg.speed):1;const ps=[];
 if(fps==='n121'){for(let i=0;i<=120;i++)ps.push(i/120);}else{let e=0;ps.push(0);while(e<seconds){e+=Math.min(1/fps,.1);ps.push(Math.min(1,e/seconds));}}
 for(const p of ps)tr.tick(p);
 // analytic max step: per segment |dpos|/dkey * max dp
 const timed=path.length>2&&path.every(k=>k.progress!==undefined);const key=j=>timed?path[j].progress:j/(path.length-1);
 let maxSpeed=0;for(let j=1;j<path.length;j++){const d=Math.hypot(...[0,1,2].map(k=>path[j].position[k]-path[j-1].position[k]));maxSpeed=Math.max(maxSpeed,d/Math.max(1e-9,key(j)-key(j-1)));}
 let maxDp=0;for(let i=1;i<ps.length;i++)maxDp=Math.max(maxDp,ps[i]-ps[i-1]);const bound=maxSpeed*maxDp*1.000001+1e-9;
 let maxRoll=0,maxQ=0,maxStep=0,maxFovStep=0;const w=cam.writes;
 for(let i=0;i<w.length;i++){const q=w[i].q;maxQ=Math.max(maxQ,Math.abs(Math.hypot(...q)-1));maxRoll=Math.max(maxRoll,Math.abs(C.rotate(q,[1,0,0])[1]));if(i){maxStep=Math.max(maxStep,Math.hypot(...[0,1,2].map(k=>w[i].p[k]-w[i-1].p[k])));maxFovStep=Math.max(maxFovStep,Math.abs(w[i].fov-w[i-1].fov));}}
 const endP=C.fromLookAt(path[path.length-1],startFov);const last=w[w.length-1];
 const r={leg:name,sampling:fps,startFov,samples:ps.length,accepted:tr.status.accepted,writes:w.length,aborted:tr.status.aborted,maxRoll,maxQuatNormErr:maxQ,maxStepM:+maxStep.toFixed(5),stepBoundM:+bound.toFixed(5),maxFovStepDeg:+maxFovStep.toFixed(4),endsAtEnd:near(last.p,endP.position,1e-9)&&near(last.q,endP.rotation,1e-9)};
 pathTests.push(r);
 ok(`path ${name} ${fps} fov${startFov}: all accepted`,r.accepted===r.samples&&r.writes===r.samples&&!r.aborted,r);
 ok(`path ${name} ${fps} fov${startFov}: unit quat + roll<1e-3`,maxQ<1e-9&&maxRoll<1e-3);
 ok(`path ${name} ${fps} fov${startFov}: step<=bound`,maxStep<=bound);
 ok(`path ${name} ${fps} fov${startFov}: ends at end pose`,r.endsAtEnd);
}
out.pathTests=pathTests;
// 7. forced rejections (Grok Bot policy): mid-path reject -> abort + write END pose; end also rejected -> last accepted
{const A={position:[-0.58,1.65,1.6],target:[-0.2,1.1,2.6],fovVerticalDeg:45,progress:0},M={position:[-3,2.5,5],target:[-1,1,4],fovVerticalDeg:120,progress:.5},B={...cfg.cameraIsland,progress:1};
 const cam=mkCam(45),tr=C.createCameraTrack(cam,[A,M,B],'test:forced');const n0=errs.length;let rejectAt=null;
 for(let i=0;i<=120;i++){const before=cam.writes.length;tr.tick(i/120);if(tr.status.aborted&&rejectAt===null)rejectAt=i/120;}
 const end=C.fromLookAt(B),last=cam.writes[cam.writes.length-1];const writesAfter=cam.writes.length;tr.tick(1);
 const r1={rejectAtProgress:rejectAt,aborted:tr.status.aborted,ended:tr.status.ended,reason:tr.status.abortReason,cameraAtEnd:near(last.p,end.position,1e-12)&&near(last.q,end.rotation,1e-12)&&last.fov===end.fovVerticalDeg,errorsLogged:errs.length-n0,noWritesAfterAbort:cam.writes.length===writesAfter};
 out.forcedMidReject=r1;ok('forced mid-path reject -> abort, camera EXACTLY at end pose, logged, no further writes',r1.aborted&&r1.ended==='end-pose'&&r1.cameraAtEnd&&r1.errorsLogged>=1&&r1.noWritesAfterAbort&&rejectAt>0&&rejectAt<1,r1);
 const Bbad={...B,fovVerticalDeg:120};const cam2=mkCam(45),tr2=C.createCameraTrack(cam2,[A,Bbad],'test:forced-end');let lastOk=null;
 for(let i=0;i<=120;i++){const n=cam2.writes.length;tr2.tick(i/120);if(!tr2.status.aborted&&cam2.writes.length>n)lastOk=cam2.writes[cam2.writes.length-1];}
 const fin=cam2.writes[cam2.writes.length-1];const r2={aborted:tr2.status.aborted,ended:tr2.status.ended,cameraAtLastAccepted:!!lastOk&&near(fin.p,lastOk.p,1e-12)&&near(fin.q,lastOk.q,1e-12)&&fin.fov===lastOk.fov,lastAcceptedFov:lastOk&&lastOk.fov};
 out.forcedEndReject=r2;ok('end pose also rejected -> last accepted pose re-written',r2.aborted&&r2.ended==='last-accepted'&&r2.cameraAtLastAccepted,r2);
 const D2={position:[0,1,0],target:[0,1,0],fovVerticalDeg:45,progress:.5};const cam3=mkCam(45),tr3=C.createCameraTrack(cam3,[A,D2,B],'test:degenerate');for(let i=0;i<=120;i++)tr3.tick(i/120);
 const l3=cam3.writes[cam3.writes.length-1];ok('degenerate look-at mid-path -> abort + end pose',tr3.status.aborted&&tr3.status.ended==='end-pose'&&near(l3.p,end.position,1e-12),tr3.status);}
// 8. authored contract: target mandatory, rotation rejected
{let e1='',e2='';try{C.assertAuthoredPose({position:[0,1,0],rotation:[0,0,0,1],fovVerticalDeg:45},'x');}catch(e){e1=String(e);}try{C.assertAuthoredPose({position:[0,1,0],target:[0,0,-1],rotation:[0,0,0,1],fovVerticalDeg:45},'y');}catch(e){e2=String(e);}
 ok('authored pose without target rejected',/needs position/.test(e1));ok('authored rotation rejected',/derived/.test(e2));}
console.error=realErr;console.warn=realWarn;out.loggedErrors=errs.length;out.rejectWarnings=warns;
// 9. six entries on the real WorldFlow state machine with fake lease/character/level
(async()=>{
 const cams=[];const resets=[];let pendingLevel=null;
 const lease={setLayers(){},setDoor(){},setCamera(p){cams.push(p);},animateDoor:async()=>{},animateCamera:async(path)=>{cams.push(path[path.length-1]);},cancelTransient(){},assertStaticWorld(){},dispose(){}};
 const std=CHARACTER_REFERENCE;
 const character={calibrated:true,coordinates:{units:'m',up:'+Y',forward:'+Z',rootMotion:'controller-only',standingRoot:cfg.seat.standingControllerRoot,seatedRoot:cfg.seat.seatedControllerRoot,seatYawRad:cfg.seat.yawRad,clearanceRadiusM:.15},
  advance(){},perform:(a,t)=>a.kind==='walk'&&slowWalk?new Promise(()=>{}):Promise.resolve(),cancelAndReset(p){resets.push(p);},setVisible(){},dispose(){}};
 let slowWalk=false;
 const levelLease={requestExit:()=>({ok:true}),hide(){},showPaused(){},resume:()=>({ok:true}),dispose(){}};
 const flow=new W.WorldFlow({config:cfg,mode:'fixed',character,levels:{enter:async()=>levelLease},loadWorld:async()=>lease});
 const last=()=>cams[cams.length-1],lastReset=()=>resets[resets.length-1];
 const isIsland=()=>last()===cfg.cameraIsland&&lastReset().kind==='standing'&&near(lastReset().controllerRoot,ch.root,1e-3)&&lastReset().yawRad===0;
 const isHome=()=>last()===cfg.cameraHome&&lastReset().kind==='seated';
 const rows=[];
 await flow.load();rows.push(['cold-start',flow.snapshot().state,isHome()]);
 await flow.leaveHome();rows.push(['leave-complete',flow.snapshot().state,isIsland()]);
 await flow.enterLevel('s1');flow.exitLevel();rows.push(['result-return',flow.snapshot().state,isIsland()]);
 flow.hide();flow.show();flow.resume();rows.push(['pause-resume(island)',flow.snapshot().state,isIsland()]);
 await flow.enterLevel('s1');flow.hide();flow.show();flow.resume();flow.exitLevel();rows.push(['pause-resume(level)->result-return',flow.snapshot().state,isIsland()]);
 slowWalk=true;const p=flow.returnHome();await new Promise(r=>setTimeout(r,5));flow.cancelTransition();await p;rows.push(['cancel(returnHome)->island',flow.snapshot().state,isIsland()]);
 slowWalk=false;await flow.returnHome();slowWalk=true;const p2=flow.leaveHome();await new Promise(r=>setTimeout(r,5));flow.cancelTransition();await p2;rows.push(['cancel(leaveHome)->home',flow.snapshot().state,isHome()]);
 out.sixEntries=rows;for(const r of rows)ok('entry '+r[0],r[2],r[1]);
 out.skip='not_run (no skip path before 0006 merges)';
 out.fail=fail;console.log(JSON.stringify(out,null,1));process.exit(fail?1:0);
})();
