# 0007 v1.3：地区镜头补丁说明（grokbot-2/ggbot）

基线：e87c409 加上 0005。替代被退回的 v1.2：v1.2 的补丁**不要打**；v1.3 的主补丁已经把 v1.2 和 v1.3 合成一个，直接打在 e87c409 + 0005 上。
不上传，不发布微信。终版小岛位姿仍以运镜bot 的 island_camera_pose.json 为准。

## 包内文件
- REGION-PAN-CAMERA-DESIGN-0007-v1.3.md：方案，开头有相对 v1.2 的变更记录
- 0001-0007-v1.3-camera-pose-single-writer.patch：主补丁（git format-patch），只改 world-r1/
- 0007-wib.diff：针对 e87c409 WorldIntegrationBoot.ts 的两处改动（第 57 行 mountWorld 的 FOV、第 82 行 paintNavigation 的相机写入）
- selftest_0007_v13.cjs、selftest_0007_v13-result.json：自测脚本和结果
- reproduce_0007_v13_lookat.py、oi-repro-adapted-v13-output.json：Oi 的复现脚本，只把插值换成 v1.3 规则，其他不变
- oi-repro-original-output.json：Oi 原脚本原样运行的输出（v1.2 的数学：6 个接受、115 个拒绝、跳变 9.18 m）
- repro_real_code.cjs、repro-real-code-v1.2-output.json、repro-real-code-v1.3-output.json：同一场景分别用 v1.2 和 v1.3 的**实际 CameraPose 代码**跑
- SHA256SUMS.txt

## 改了哪些文件（主补丁，路径相对于 creator-build-project/）
- 新增 assets/scripts/world-r1/CameraPose.ts（.meta）：CameraPose 和 AuthoredPose 类型、fromLookAt、assertAuthoredPose、保持地平线的插值（blendLookAt、sampleLookAtPath、blendPoseHorizon）、createCameraTrack（拒写时中止并写终点）、applyCameraPose（唯一写入方）、投影调试
- 新增 assets/scripts/world-r1/RegionCameraData.ts（.meta）：位姿数据表，包含 islandPoseSource、homePoseSource 两个开关和 frameLimits
- 修改 assets/scripts/world-r1/FirstsliceRoutes.ts：cameraHome 和 cameraIsland 从数据表读取，并用 assertAuthoredPose 校验；新增 islandYawRad
- 修改 assets/scripts/world-r1/WorldFlowComponent.ts：setCamera、animateCamera（经 createCameraTrack）、onDestroy 恢复都走 applyCameraPose；新增调试入口 __worldCamera
- 修改 assets/scripts/world-r1/WorldFlowCore.ts：只改了类型（Pose.fovVerticalDeg?、RouteConfig.islandYawRad?），pose() 读 islandYawRad；状态机不变
- 没有碰：ManagedMobileBoardUI.ts、NativeBoardUI.ts、WorldIntegrationBoot.ts、region/RegionLoader.ts、world-r2/MainlineHost.ts，以及 0005 的 scripts/audio/* 和 resources/audio_sfx/*（WorldIntegrationBoot.ts 只由 0007-wib.diff 单独改）

## 怎么打
在仓库根目录（creator-build-project 的上一级）执行：
    git am --directory=creator-build-project 0001-0007-v1.3-camera-pose-single-writer.patch
    git apply --check 0007-wib.diff && git apply 0007-wib.diff
如果 0007-wib.diff 因为 Oi 本地改过而打不上，就手动改这两处：
1. mountWorld（e87c409 第 57 行）：删掉 `if(this.characterPrefab)camera.fov=55;`，这一行其余部分不动。
2. paintNavigation（e87c409 第 82 行）：删掉整行
   `if(this.characterPrefab&&s.state==='home'){const camera=director.getScene()!.getComponentsInChildren(Camera)[0];camera.node.setWorldPosition(-1.1,1.5,-2.4);camera.node.lookAt(new Vec3(.1,.86,-4.35));}`
这两处的值（位置 -1.1,1.5,-2.4，看向 .1,.86,-4.35，FOV 55）现在是数据 home.variants["oi-interim-standing"]，进入 home 时由 restore() 经 applyCameraPose 写一次。mountWorld 里的 camera 就是传给 WorldFlowComponent 的 worldCamera；mountWorld 先执行，restore() 后执行并写入 FOV 55，所以 home 画面不变。

### 0007-wib.diff 全文（第 57 行很长，原样附上）
    diff --git a/creator-build-project/assets/scripts/WorldIntegrationBoot.ts b/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    --- a/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    +++ b/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    @@ -54,7 +54,7 @@
        if(effect==='builtin-standard'){mat.setProperty('albedo',c);mat.setProperty('roughness',1);}else mat.setProperty('mainColor',c);
        r.setMaterial(mat,0);r.node.active=true;}catch(e){console.error('Reference marker material failed (non-fatal)',e);}
      }
    - private mountWorld(){const scene=director.getScene()!;const reference=scene.getChildByName('FLOW_REFERENCE_PLACEHOLDER_NOT_B')!;if(this.characterPrefab){const girl=instantiate(this.characterPrefab);girl.name='B_INTERIM_DISPLAY_NO_SIT_WALK_CLIPS';reference.addChild(girl);girl.setScale(1,1,1);const dx=REF.standingRoot[0]-REF.seatedRoot[0],dz=REF.standingRoot[2]-REF.seatedRoot[2],yaw=-REF.seatYawRad;girl.setPosition(Math.cos(yaw)*dx+Math.sin(yaw)*dz,0,-Math.sin(yaw)*dx+Math.cos(yaw)*dz);girl.setRotationFromEuler(0,-REF.seatYawRad*180/Math.PI,0);for(const a of girl.getComponentsInChildren(SkeletalAnimation)){a.useBakedAnimation=true;const clip=a.clips.find(x=>x?.name==='idle_breathing_loop');if(clip){clip.wrapMode=AnimationClip.WrapMode.Loop;a.defaultClip=clip;a.play(clip.name);}}console.info('OI_INTERIM_CHARACTER',{sourceSha256:'054da436278dd48f1165e3c4f58be1ce100d85a4f86420725e4d6bbb46e99112',scale:1,displayOnly:true,motionAcceptance:false});}else this.applyMarkerMaterial();const camera=scene.getComponentsInChildren(Camera)[0];if(this.characterPrefab)camera.fov=55;camera.visibility&=~Layers.Enum.UI_2D;this.error='';
    + private mountWorld(){const scene=director.getScene()!;const reference=scene.getChildByName('FLOW_REFERENCE_PLACEHOLDER_NOT_B')!;if(this.characterPrefab){const girl=instantiate(this.characterPrefab);girl.name='B_INTERIM_DISPLAY_NO_SIT_WALK_CLIPS';reference.addChild(girl);girl.setScale(1,1,1);const dx=REF.standingRoot[0]-REF.seatedRoot[0],dz=REF.standingRoot[2]-REF.seatedRoot[2],yaw=-REF.seatYawRad;girl.setPosition(Math.cos(yaw)*dx+Math.sin(yaw)*dz,0,-Math.sin(yaw)*dx+Math.cos(yaw)*dz);girl.setRotationFromEuler(0,-REF.seatYawRad*180/Math.PI,0);for(const a of girl.getComponentsInChildren(SkeletalAnimation)){a.useBakedAnimation=true;const clip=a.clips.find(x=>x?.name==='idle_breathing_loop');if(clip){clip.wrapMode=AnimationClip.WrapMode.Loop;a.defaultClip=clip;a.play(clip.name);}}console.info('OI_INTERIM_CHARACTER',{sourceSha256:'054da436278dd48f1165e3c4f58be1ce100d85a4f86420725e4d6bbb46e99112',scale:1,displayOnly:true,motionAcceptance:false});}else this.applyMarkerMaterial();const camera=scene.getComponentsInChildren(Camera)[0];camera.visibility&=~Layers.Enum.UI_2D;this.error='';
      const owner=new Node('IsolatedWorldComposition');scene.addChild(owner);this.composition=owner.addComponent(WorldNativeComposition);this.composition.firstsliceModel=this.model;this.composition.worldCamera=camera;this.composition.smokeFixture=this.smokeFixture;
      (globalThis as any).__worldIntegration={snapshot:()=>this.composition.worldCommands().snapshot(),hostResult:()=>this.composition.lastHostReply(),useTestFixture:(namespace:string,journeyNamespace:string)=>this.composition.useIsolatedTestProfile(namespace,journeyNamespace),board:()=>this.board()?.diagnostics()||null,layout:()=>this.navLayout(),select:(stageId:string,seed:number)=>this.select(stageId,seed),leave:()=>this.composition.worldCommands().leaveHome(),returnHome:()=>this.composition.worldCommands().returnHome(),hide:()=>game.emit(Game.EVENT_HIDE),show:()=>game.emit(Game.EVENT_SHOW),resume:()=>this.composition.worldCommands().resume(),lateEnd:(index:number)=>this.board()?.lateEnd(index),navigationStatus:()=>({error:this.error,text:this.status.string}),mainline:()=>this.composition.mainlineStatus(),mainlineStorage:()=>this.composition.mainlineStorage(),gates:()=>this.composition.challengeGates(),enterMainlineStage:(id:string,seed:number)=>this.composition.enterMainlineStage(id,seed),scope:'Mainline new-player isolated Cocos storage; R5 isolated Cocos localStorage v1.2; read-only real mainline schema v1/v2/v3; missing or protected journey keeps new stages locked. Interim B displayed at scale1; reference controller only; no sit/walk/door clips or calibrated clothing acceptance.'};
      if(this.validationScenario==='skycity')this.scheduleOnce(()=>validateSkycity(this),3);
    @@ -79,7 +79,7 @@
       if(n>1&&first-(n-1)*step<floor){first=Math.min(d.boardCenter.y-158,floor+(n-1)*step);if(first-(n-1)*step<floor)step=Math.max(46,(first-floor)/(n-1));}
       keys.forEach((k,i)=>this.controls.get(k)!.setPosition(0,first-i*step,0));}
      private paintNavigation(){let s:any;try{s=this.composition.worldCommands().snapshot();}catch{return;}if(s.state==='home'&&!this.ready){const r=this.composition.attachCalibratedCharacter((this as any)._referenceAdapter);if(!r.ok){this.error=r.reason;return;}this.ready=true;}
    - if(this.characterPrefab&&s.state==='home'){const camera=director.getScene()!.getComponentsInChildren(Camera)[0];camera.node.setWorldPosition(-1.1,1.5,-2.4);camera.node.lookAt(new Vec3(.1,.86,-4.35));}
    + // 0007 v1.3 (GGbot): home camera is pose DATA now (world-r1/RegionCameraData.ts homePoseSource='oi-interim-standing', same -1.1,1.5,-2.4 -> .1,.86,-4.35, fov 55); only CameraPose.applyCameraPose writes the camera.
      this.notice.node.parent!.active=false;this.status.node.parent!.active=!!this.error;this.status.string=this.error||({home:'主页 · 参考角色流程',island:'海岛 · 选择地区旅程'} as any)[s.state]||s.state;
      const board=this.board(),b=board?.hostPresentation();const registered=s.state==='level'&&!s.needsResume&&b?.provider==='regional-r05'&&b.state==='result.saved'&&b.result?.completionRecorded;
      for(const [k,n]of this.controls)n.active=k==='resume'?s.needsResume:k==='mainNext'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&b.nextStageId):k==='chest'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&!b.readOnly&&b.journey.chests?.find((x:any)=>x.level===b.active.level)?.earned):k==='regionReward'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&!b.readOnly&&b.journey.regionRewards?.find((x:any)=>x.region===Math.floor(b.active.level/4))?.unlocked):k==='next'?!!(registered&&b.nextStageId):k==='claim'?!!(registered&&!b.nextStageId&&Object.keys(b.progress.records).filter(id=>id.startsWith('r05-'+b.active.region+'-')).length===4):!s.needsResume&&(k==='leave'?s.state==='home':k==='home'||['mainline','r4','tide','meadow','sky'].includes(k)?s.state==='island':false);

## 走路镜头的拒写处理（Grok Bot 定，代码在 CameraPose.createCameraTrack）
- 每个采样都按这个顺序算：位置、目标点、FOV 线性插值，再用 fromLookAt(up=+Y) 算旋转，最后经 applyCameraPose 写入。位姿之间不用四元数 slerp；roll 门限没有放宽，仍是 0.001。
- 遇到第一个被拒的采样（applyCameraPose 返回 false，或者 look-at 退化）：
  1. console.error 记下来源、progress 和原因（cameraWriteLog.trackAborts 加 1，lastAbort 记下详情）
  2. 中止这条轨道，后面的 tick 都不再写
  3. 立即经 applyCameraPose 写入终点位姿，画面不会停在半路
  4. 如果终点位姿也被拒：再记一条 console.error，然后重写最后一次被接受的位姿；如果一次都没被接受过，相机保持原样
- 走路本身（人物）不受影响，流程照常结束。
- 稳定态的 setCamera 如果被拒：console.error，相机保持原样。稳定位姿在路线创建时已经由 assertAuthoredPose 校验过，正常情况下不会被拒。

## 位姿契约（v1.3：target 必填）
- 作者给出的每一项位姿都必须写 position、target、fovVerticalDeg（米，Cocos 世界坐标），三项缺一不可。
- 不允许写 rotation：旋转一律由 fromLookAt 推出（up=+Y，roll 为 0），写了 rotation 会被 assertAuthoredPose 拒绝。
- 运镜bot 的 yunjing-final 也按这个格式交：position、target、fovVerticalDeg，再加 characterYawDeg。

## 开关（只改数据，不改代码）：world-r1/RegionCameraData.ts
- islandPoseSource：
  - "temporary-6m"：当前默认，是**临时**构图候选，相机离人物 6 m，FOV 45
  - "legacy-capsule"：旧机位，可以用来重现 OI-FRAME-002
  - "yunjing-final"：运镜bot 交付后填入 island.variants["yunjing-final"]，再把开关改过来。如果数据还是 null，会打警告并回退到 temporary-6m
- homePoseSource：
  - "oi-interim-standing"：默认，等于 Oi 现在的 home 取景，FOV 55
  - "legacy-capsule"：旧的 home 机位，FOV 45
- frameLimits：调试取景边界，默认 maxAbsX 0.7、minY -0.85、maxY 0.75。后续：等 Oi 把按钮移到底部 25% 以后，minY 改成 -0.5（只改数据）。

## 调试入口与 liveFrameCheck 的边界
- __worldCamera.sources()：查看当前开关
- __worldCamera.writes()：查看写入、拒写和中止的次数，以及最后一次中止的原因
- __worldCamera.frameCheck()：按数据位姿，算当前、0.46、0.75 三种宽高比下人物包围盒的投影
- __worldCamera.liveFrameCheck()：**只是日志检查，不是验收**。它读的是 cameraWriteLog.last（最后一次写入的位姿，不是读回的实际相机），用的是固定的人物包围盒（不是导入后的蒙皮边界），也不知道引擎的 viewport 和 HUD。不能拿它当真实遮挡、HUD 或安全区的验收。

## 自测
passed（离线，Node 跑真实的 TS 代码，Cocos 用 stub）：
- TypeScript 语法检查：5 个文件 parseDiagnostics 都是 0
- strict 类型检查（cc 用了 stub）：0 错误
- 断言一共 204 条，全部通过
- 整段路径：7 段 motion 镜头路径（home→toDoor0、toDoor 带时间的那段、inside→outside、outside→island、island→outside、outside→inside、inside→home），每段按三种采样（121 个归一化采样，按真实时长 30 fps 和 60 fps）、两种起步 FOV（45、55）各跑一次，一共 42 次，7334 个采样**全部**经过真实的 createCameraTrack 和 applyCameraPose：
  - 被接受 7334/7334，没有一次中止
  - 四元数长度误差最大 3.3e-16
  - roll（右轴 Y 的绝对值）最大 2.2e-16，门限是 0.001
  - 位置步长都不超过解析上界；全部里最大是 0.0806 m（home→toDoor0，1 s，30 fps）
  - outside→island 的最大步长：121 个采样时是 0.0791 m，60 fps 时是 0.0253 m；island→outside 在 60 fps 时是 0.0225 m
  - 每段最后一个写入都正好等于终点位姿
- 强制中途拒写：中间关键帧的 FOV 设成 120，在 progress 0.208 时被拒 → 轨道中止，console.error 记了 1 条，相机**正好停在终点位姿**（误差 < 1e-12），之后没有再写
- 终点也被拒：重写的是最后一次被接受的位姿（FOV 75）
- 中途 look-at 退化：轨道中止，然后写终点位姿
- 契约：没有 target 的作者位姿被拒；写了 rotation 的作者位姿被拒
- blendPoseHorizon（给 0006 §C 用）：201 个采样，roll < 1e-9
- 包围盒投影：temporary-6m 在 0.46 和 0.75 下都在 frameLimits 内；legacy-capsule 不在，能重现问题
- 用真实的 WorldFlow 状态机跑六个入口里的五个（跳过除外）：冷启动、出门完成、结算返回、暂停恢复（在岛上、在关卡中）、取消（两个方向），都通过
- Oi 的复现：
  - 原脚本原样运行：确认 v1.2 的问题（6 个接受、115 个拒绝、跳变 9.176 m）
  - 用 v1.2 的实际代码跑：同样是 6 个接受、115 个拒绝、跳变 9.176 m
  - 改编脚本（只把插值换成 v1.3 规则）：两个方向都是 121/121 接受，roll < 1e-16，最大跳变 0.0791 m
  - 用 v1.3 的实际代码跑：两个方向都是 121/121 接受，没有中止，最大跳变 0.0791 m
- 补丁检查：在 audio-0005 树上模拟 creator-build-project 目录结构，git apply --check 和 git am --directory=creator-build-project 都通过，自测在打完补丁的树上也是 204/204；补丁没有碰 Oi 的 5 个文件，也没有碰 0005 的文件
- 0007-wib.diff：在用 Oi 补丁 '+' 行和上下文重建的 e87c409 片段（第 1–93 行里能重建的 71 行，其余是占位）上，git apply --check、apply 和反向 check 都通过；应用以后，文件里不再有 camera.fov=、camera.node.setWorldPosition 或 camera.node.lookAt

not_run：
- Creator 构建、Web 预览、微信 DevTools、真机
- 在引擎里跑 fixed 和 motion 模式往返；真实 interim B 模型在窄屏和宽屏的截图；引擎里读回的 FOV 和位姿
- 逐帧投影日志（在引擎里）、遮挡射线（V6，未实现）、HUD 和安全区实测
- 跳过入口（0006 合并前没有）
- 现有 E8 浏览器测试（test_world_camera_audit.cjs、test_world_navigation_guard.cjs，需要 :8770 的构建产物）
- 0007-wib.diff 在真实的完整 e87c409 文件上 apply（这台机器上没有完整文件）
- world-r1 用的是 e2-0001e 的版本，模拟的是 e87c409 的结构；Oi 那份 4ba0580 的 world-r1 如果和它不同，git am 会报冲突，不会静默打错

## 本版不做（后续）
- 导航按钮移到底部 25%（Oi 的文件，需要另外交付并实测）。竖屏中央那一列按钮会挡住人物，见方案 §7.2。
- 0006 取消后的稳定态契约：硬切的时机、安全停姿和恢复时怎么接。
- frameLimits.minY 从 -0.85 收紧到 -0.5，等按钮移动以后再改。
