// Oi's scenario through the ACTUAL CameraPose.js (v1.2: samplePath+slerp; v1.3: createCameraTrack). Stub camera, 121 samples.
const C=require(process.argv[2]);const O={position:[-0.58,1.65,1.6],target:[-0.2,1.1,2.6]},I={position:[-5.796,3.323,9.352],target:[-2.114,0.9,5.281],fovVerticalDeg:45};
const res={};const w=console.warn,e=console.error;console.warn=()=>{};console.error=()=>{};
for(const [name,path] of [['outside->island',[O,I]],['island->outside',[I,O]]]){
 const cam={p:null,node:{setWorldPosition(x,y,z){cam.p=[x,y,z];},setWorldRotation(){}},fov:55};let acc=0,rej=0,prev=null,maxJump=0,minRY=0,maxRY=0;
 if(C.createCameraTrack){const tr=C.createCameraTrack(cam,path,'repro');for(let i=0;i<=120;i++){tr.tick(i/120);if(prev)maxJump=Math.max(maxJump,Math.hypot(...cam.p.map((v,k)=>v-prev[k])));prev=[...cam.p];}acc=tr.status.accepted;rej=121-acc;res[name]={version:'v1.3',accepted:acc,rejected:rej,aborted:tr.status.aborted,maxPositionJumpM:maxJump,maxAbsRightY:C.cameraWriteLog.last?Math.abs(C.rotate(C.cameraWriteLog.last.rotation,[1,0,0])[1]):null};}
 else{const keys=path.map(k=>C.fromLookAt(k,55));for(let i=0;i<=120;i++){const p=C.samplePath(keys,[undefined,undefined],i/120);const ry=C.rotate(p.rotation,[1,0,0])[1];minRY=Math.min(minRY,ry);maxRY=Math.max(maxRY,ry);if(C.applyCameraPose(cam,p,'repro'))acc++;else rej++;if(prev&&cam.p)maxJump=Math.max(maxJump,Math.hypot(...cam.p.map((v,k)=>v-prev[k])));if(cam.p)prev=[...cam.p];}res[name]={version:'v1.2',accepted:acc,rejected:rej,maxPositionJumpM:maxJump,rightYRange:[minRY,maxRY]};}
}
console.warn=w;console.error=e;console.log(JSON.stringify(res,null,1));
