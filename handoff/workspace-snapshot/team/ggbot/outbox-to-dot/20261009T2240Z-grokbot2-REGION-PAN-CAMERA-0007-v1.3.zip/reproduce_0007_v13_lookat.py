#!/usr/bin/env python3
"""ADAPTED by GGbot for 0007 v1.3 from Oi's reproduce_0007_slerp_roll.py (2233Z).
Only change: the interpolation is v1.3's rule (lerp position + lerp target, then look_at with up=+Y)
instead of quaternion slerp. Everything else (paths, roll check, 121-sample reject/retain emulation) is Oi's.

Original docstring: Read-only numeric reproduction of 0007 v1.2's slerp/roll rejection.

Run with Python 3, standard library only:
    python3 reproduce_0007_slerp_roll.py

Writes JSON to stdout only. Does not load/run the supplied patch, contact a
service, or modify any project. This is a mathematical reproduction, NOT a
Cocos, Web, WeChat DevTools, or physical-device test.
"""
import json
import math

SOURCE = {
    "drive_file_id": "19aWoRJG5TYmvD4q-5gm0ARbK3snMcRQM",
    "zip_name": "20261009T2227Z-grokbot2-REGION-PAN-CAMERA-0007-v1.2.zip",
    "zip_bytes": 30037,
    "zip_sha256": "3d5440effa7dc994446ea78356d151540da1e26f406f00a8d0808ba430a26cf8",
    "patch_sha256": "0c4b642f23b6765dc9c90a0bfdc4e45e45e10158315633ab4babb62e1ba3fdad",
}

# Supplied FirstsliceRoutes.cameraOutside and RegionCameraData.temporary-6m.
OUTSIDE_POSITION = (-0.58, 1.65, 1.6)
OUTSIDE_TARGET = (-0.2, 1.1, 2.6)
ISLAND_POSITION = (-5.796, 3.323, 9.352)
ISLAND_TARGET = (-2.114, 0.9, 5.281)
ROLL_RIGHT_Y_LIMIT = 1e-3


def norm(v):
    length = math.sqrt(sum(x * x for x in v))
    if length <= 1e-9:
        raise ValueError("zero vector/quaternion")
    return tuple(x / length for x in v)


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def look_at_quaternion(position, target):
    """Camera -Z faces target, +X horizontal; quaternion order x,y,z,w."""
    z = norm(tuple(p - t for p, t in zip(position, target)))
    x = norm(cross((0, 1, 0), z))
    y = cross(z, x)
    m00, m01, m02 = x[0], y[0], z[0]
    m10, m11, m12 = x[1], y[1], z[1]
    m20, m21, m22 = x[2], y[2], z[2]
    trace = m00 + m11 + m22
    if trace > 0:
        s = 0.5 / math.sqrt(trace + 1)
        q = ((m21-m12)*s, (m02-m20)*s, (m10-m01)*s, 0.25/s)
    elif m00 > m11 and m00 > m22:
        s = 2 * math.sqrt(1 + m00 - m11 - m22)
        q = (0.25*s, (m01+m10)/s, (m02+m20)/s, (m21-m12)/s)
    elif m11 > m22:
        s = 2 * math.sqrt(1 + m11 - m00 - m22)
        q = ((m01+m10)/s, 0.25*s, (m12+m21)/s, (m02-m20)/s)
    else:
        s = 2 * math.sqrt(1 + m22 - m00 - m11)
        q = ((m02+m20)/s, (m12+m21)/s, 0.25*s, (m10-m01)/s)
    return norm(q)


def slerp(a, b, t):
    """Shortest-path unit quaternion interpolation, as specified in patch."""
    dot = sum(x*y for x, y in zip(a, b))
    if dot < 0:
        dot, b = -dot, tuple(-x for x in b)
    if 1-dot > 1e-6:
        omega = math.acos(min(1, dot))
        sin_omega = math.sin(omega)
        s0 = math.sin((1-t)*omega) / sin_omega
        s1 = math.sin(t*omega) / sin_omega
    else:
        s0, s1 = 1-t, t
    return norm(tuple(s0*x+s1*y for x, y in zip(a, b)))


def camera_right_y(q):
    # Y component of q * (+X) * conjugate(q), identical to rotate(q,[1,0,0])[1].
    x, y, z, w = q
    return 2*(x*y+z*w)


def lerp3(a, b, t):
    return tuple(x + (y - x) * t for x, y in zip(a, b))


def v13_pose(t):
    """0007 v1.3 blendLookAt: lerp position and target, rotation = look_at(up=+Y)."""
    p = lerp3(OUTSIDE_POSITION, ISLAND_POSITION, t)
    return p, look_at_quaternion(p, lerp3(OUTSIDE_TARGET, ISLAND_TARGET, t))


def run(direction):
    rows = []
    for t in (0, .01, .1, .25, .5, .75, .9, .99, 1):
        tt = t if direction == "outside->island" else 1 - t
        _, q = v13_pose(tt)
        rows.append({"progress": t, "camera_right_y": camera_right_y(q),
                     "quaternion_norm": math.sqrt(sum(v*v for v in q)),
                     "applyCameraPose_would_reject": abs(camera_right_y(q)) > ROLL_RIGHT_Y_LIMIT})
    accepted, rejected, rendered = [], [], []
    last = None
    for i in range(121):
        t = i / 120
        tt = t if direction == "outside->island" else 1 - t
        p, q = v13_pose(tt)
        if abs(camera_right_y(q)) > ROLL_RIGHT_Y_LIMIT:
            rejected.append(t)
        else:
            last = p
            accepted.append(t)
        rendered.append(last)
    jumps = [math.dist(x, y) for x, y in zip(rendered, rendered[1:])]
    return {"samples": rows, "accepted_count": len(accepted), "rejected_count": len(rejected),
            "max_abs_camera_right_y": max(abs(r["camera_right_y"]) for r in rows),
            "largest_successive_position_jump_m": max(jumps)}


def main():
    a = look_at_quaternion(OUTSIDE_POSITION, OUTSIDE_TARGET)
    b = look_at_quaternion(ISLAND_POSITION, ISLAND_TARGET)
    v12_mid = camera_right_y(slerp(a, b, .5))
    fwd, rev = run("outside->island"), run("island->outside")
    assert fwd["rejected_count"] == 0 and rev["rejected_count"] == 0
    assert fwd["max_abs_camera_right_y"] < 1e-12 and rev["max_abs_camera_right_y"] < 1e-12
    straight = math.dist(OUTSIDE_POSITION, ISLAND_POSITION) / 120
    assert fwd["largest_successive_position_jump_m"] <= straight * (1 + 1e-9)
    print(json.dumps({
        "finding": "v1.3 rule (lerp position+target, look_at up=+Y): 121/121 accepted both directions, roll 0",
        "scope": "independent math + reject/retain emulation; no engine or device execution",
        "v1_2_slerp_midpoint_camera_right_y_for_reference": v12_mid,
        "uniform_step_m": straight,
        "outside_to_island": fwd, "island_to_outside": rev,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
