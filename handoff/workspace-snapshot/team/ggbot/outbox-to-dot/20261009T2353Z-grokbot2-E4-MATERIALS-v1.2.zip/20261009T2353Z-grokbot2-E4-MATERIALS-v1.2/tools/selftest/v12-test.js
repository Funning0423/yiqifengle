'use strict';
// E4 v1.2 Node 测试：f-sky-follow（SkyFollowCamera 时序 / 零帧延迟 / 剔除）、g-fallback（无实例化兜底：30% 选择、统一根色、关草触发）、
// h-lifecycle（_ROOT_COLOR 校验、晚到的展开也 apply 当前档、重新启用 / 缩放刷新、卸载释放材质副本和监听）。
// 'cc' 用 cc-stub.js；桩里 director.tick 的阶段顺序在 F0 里与真实 3.8.8 源码逐项比对。
const fs = require('fs'), ps = require('path');
const makeCC = require('./cc-stub');

module.exports = async function run (ctx) {
  const { ts, rec, INST, HERE, ENGINE } = ctx;
  const SCRIPTS = ps.join(HERE, '../../runtime/scripts');
  const ANCH = ctx.ANCH || '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/data/anchors_v0_8.json';
  const F = 'f-sky-follow', Gf = 'g-fallback', H = 'h-lifecycle';

  // ---------------------------------------------------------------- F0 引擎源码：阶段顺序（桩和结论都依赖它）
  {
    const dts = ps.join(ENGINE, 'cocos/game/director.ts'), rts = ps.join(ENGINE, 'cocos/root.ts');
    if (!fs.existsSync(dts) || !fs.existsSync(rts)) rec(F, '3.8.8 源码阶段顺序', null, '找不到引擎源码');
    else {
      const d = fs.readFileSync(dts, 'utf8').split('\n'), r = fs.readFileSync(rts, 'utf8').split('\n');
      const tickStart = d.findIndex(l => /public tick \(dt: number\)/.test(l));
      const find = (lines, from, re) => { for (let i = from; i < lines.length; i++) if (re.test(lines[i])) return i; return -1; };
      const steps = [['updatePhase', /_compScheduler\.updatePhase\(dt\)/], ['systems.update', /_systems\[i\]\.update\(dt\)/], ['lateUpdatePhase', /_compScheduler\.lateUpdatePhase\(dt\)/],
        ['AFTER_UPDATE', /emit\(DirectorEvent\.AFTER_UPDATE\)/], ['systems.postUpdate', /_systems\[i\]\.postUpdate\(dt\)/], ['BEFORE_DRAW', /emit\(DirectorEvent\.BEFORE_DRAW\)/], ['root.frameMove', /_root!\.frameMove\(dt\)/], ['AFTER_DRAW', /emit\(DirectorEvent\.AFTER_DRAW\)/]];
      let at = tickStart; const lines = [];
      for (const [n, re] of steps) { const i = find(d, at + 1, re); lines.push(`${n}@${i + 1}`); at = i < 0 ? 1e9 : i; }
      const fm = r.findIndex(l => /private _frameMoveProcess \(\): void/.test(l));
      const su = find(r, fm, /scenes\[i\]\.update\(stamp\)/), bc = find(r, fm, /Director\.EVENT_BEFORE_COMMIT/), rd = find(r, fm, /_pipeline\.render\(cameraList\)/);
      const am = fs.readFileSync(ps.join(ENGINE, 'cocos/animation/animation-manager.ts'), 'utf8');
      const animSys = /registerSystem\(AnimationManager\.ID, animationManager, SystemPriority\.HIGH\)/.test(am);
      rec(F, `3.8.8 源码：director.ts tick() 顺序 ${lines.join(' → ')}；root.ts _frameMoveProcess scenes[i].update@${su + 1} → BEFORE_COMMIT@${bc + 1} → render@${rd + 1}；AnimationManager 是 System（cine_camera 烘焙动画在 systems.update 写节点）。=> BEFORE_DRAW 是 scene.update（worldBounds / 剔除）之前、所有组件 / 动画 / 系统写入之后的最后一个公开钩子`,
        tickStart > 0 && at < 1e9 && fm > 0 && su > fm && bc > su && rd > bc && animSys, '');
    }
  }

  // ---------------------------------------------------------------- F1–F5 SkyFollowCamera
  {
    const { cc } = makeCC();
    const { SkyFollowCamera } = makeCC.loadScripts(ts, SCRIPTS, cc, ['SkyFollowCamera']).SkyFollowCamera;
    const D = cc.director; const { Node, Quat } = cc;
    const scene = new Node('scene'); D.scene = scene;
    const world = new Node('world'); scene.addChild(world); world.setPosition(10, 0, -5);
    const rig = new Node('cine_rig'); world.addChild(rig); const a = 0.5; rig.setRotation(new Quat(0, Math.sin(a / 2), 0, Math.cos(a / 2)));
    const camNode = new Node('Main Camera'); rig.addChild(camNode); camNode.addComponent(cc.Camera);
    const env = new Node('env'); scene.addChild(env); env.setPosition(3, 0, 7); env.setScale(new cc.Vec3(2, 2, 2));
    const sky = new Node('meadow_sky_dome'); env.addChild(sky); sky.setPosition(0, -20, 0);
    const skyY0 = sky.worldPosition.y;
    // 对照：lateUpdate 跟随（常见写法），注册在相机写入者之前
    const sky2 = new Node('sky_lateUpdate'); scene.addChild(sky2);
    D.comps.push({ lateUpdate () { const c = camNode.worldPosition; sky2.setWorldPosition(c.x, 0, c.z); } });
    const comp = sky.addComponent(SkyFollowCamera); comp.cameraNode = camNode; comp.onEnable();
    // cine_camera 风格路径：平滑推进 + 每 7 帧一次远距离硬切（±300 m）；写入点轮流落在 6 个阶段；偶数次改 rig（父节点）而不是相机本身
    const N = 180; const target = []; let p = [0, 2, 0];
    for (let f = 0; f < N; f++) { if (f % 7 === 6) p = [p[0] + (f % 2 ? 300 : -300), 2 + (f % 5), p[2] + (f % 3 ? -250 : 280)]; else p = [p[0] + 0.7, 2 + 0.01 * f, p[2] - 0.4]; target.push(p.slice()); }
    const PH = ['update', 'anim(systems.update)', 'lateUpdate', 'AFTER_UPDATE', 'postUpdate', 'microtask(帧间 Promise)'];
    let frame = -1; const phaseOf = (f) => f % 6;
    const write = (f) => { const t = target[f]; if (f % 2) camNode.setWorldPosition(t[0], t[1], t[2]); else { const cl = camNode.toWorld([0, 0, 0]); const rw = rig.toWorld([0, 0, 0]); rig.setWorldPosition(rw[0] + t[0] - cl[0], rw[1] + t[1] - cl[1], rw[2] + t[2] - cl[2]); } };
    D.comps.push({ update () { if (phaseOf(frame) === 0) write(frame); }, lateUpdate () { if (phaseOf(frame) === 2) write(frame); } });
    D.systems.push({ update () { if (phaseOf(frame) === 1) write(frame); }, postUpdate () { if (phaseOf(frame) === 4) write(frame); } });
    D.on(cc.Director.EVENT_AFTER_UPDATE, () => { if (phaseOf(frame) === 3) write(frame); }, null);
    const R = 400;   // 天空球半径（包围盒半边长）
    const log = [];
    D.onSceneUpdate = () => {
      const c = camNode.worldPosition, s = sky.worldPosition, s2 = sky2.worldPosition;
      const gpuOff = [c.x - s.x, c.z - s.z];                                  // sky-unlit: worldPos.xz += cc_cameraPos.xz - matWorld[3].xz
      log.push({ f: frame, ph: phaseOf(frame), c: [c.x, c.z], s: [s.x, s.z], sy: s.y, s2: [s2.x, s2.z], gpuOff, tgt: target[frame],
        inside: Math.abs(c.x - s.x) <= R && Math.abs(c.z - s.z) <= R, insideNoFollow: Math.abs(c.x - 3) <= R && Math.abs(c.z - 7) <= R });
    };
    for (frame = 0; frame < N; frame++) {
      if (phaseOf(frame) === 5) await Promise.resolve().then(() => write(frame));   // 0007 的 Promise .then：微任务，在两帧之间
      D.tick(1 / 60);
    }
    frame = -1;   // 路径写入者停手（后面的子测试复用同一个 director）
    const tol = 1e-6;
    const eqXZ = (u, v) => Math.abs(u[0] - v[0]) <= tol && Math.abs(u[1] - v[1]) <= tol;
    const camOk = log.every(l => eqXZ(l.c, [l.tgt[0], l.tgt[2]]));
    const lag0 = log.filter(l => !eqXZ(l.s, l.c));
    const maxJump = Math.max(...log.slice(1).map((l, i) => Math.hypot(l.c[0] - log[i].c[0], l.c[1] - log[i].c[1])));
    const yOk = log.every(l => Math.abs(l.sy - skyY0) <= tol);
    const perPhase = PH.map((n, k) => `${n}:${log.filter(l => l.ph === k && eqXZ(l.s, l.c)).length}/${log.filter(l => l.ph === k).length}`);
    rec(F, `零帧延迟：相机沿 cine_camera 式路径逐帧移动（${N} 帧，最大单帧跳 ${maxJump.toFixed(0)} m，父节点带旋转 / 天空在缩放 2× 的父节点下），写入点轮流落在 update / 动画系统 / lateUpdate / AFTER_UPDATE / postUpdate / 帧间微任务；每帧 scene.update（画面用的变换）时天空节点世界 XZ == 相机世界 XZ（容差 1e-6 m），Y 不动`,
      camOk && lag0.length === 0 && yOk && maxJump > 300, `${perPhase.join(' ')}；不一致帧=${lag0.length}`);
    const lagFrames = log.filter(l => !eqXZ(l.s2, l.c));
    const lagPhases = [...new Set(lagFrames.map(l => PH[l.ph]))];
    rec('harness-sanity', `反向对照 F1：同一路径用 lateUpdate 跟随（注册在相机写入者之前），${lagFrames.length}/${N} 帧落后一帧（阶段：${lagPhases.join('、')}）——证明上一项的路径和写入阶段能抓到“晚写”`,
      lagFrames.length > 0 && lagPhases.includes('lateUpdate') && lagPhases.includes('postUpdate') && lagPhases.includes('AFTER_UPDATE'), '');
    const gpuZero = log.every(l => Math.abs(l.gpuOff[0]) <= tol && Math.abs(l.gpuOff[1]) <= tol);
    // 顶点最终位置：CPU 跟随 + GPU 跟随（偏移 = 0）与“只 GPU 跟随”（节点不动）的结果一致，而不是相机位置的两倍
    const vtx = [123, 45, -67]; let maxDiff = 0, dbl = 0;
    for (const l of log) { const both = [l.s[0] + vtx[0] * 2 + l.gpuOff[0], l.s[1] + vtx[2] * 2 + l.gpuOff[1]]; const gpuOnly = [3 + vtx[0] * 2 + (l.c[0] - 3), 7 + vtx[2] * 2 + (l.c[1] - 7)];
      maxDiff = Math.max(maxDiff, Math.abs(both[0] - gpuOnly[0]), Math.abs(both[1] - gpuOnly[1])); const naive = [l.s[0] + vtx[0] * 2 + l.c[0], l.s[1] + vtx[2] * 2 + l.c[1]]; dbl = Math.max(dbl, Math.abs(naive[0] - gpuOnly[0])); }
    rec(F, `与 GPU 跟随（SKY_FOLLOW_CAMERA=1）不重复位移：每帧 shader 偏移 cc_cameraPos.xz − matWorld[3].xz = 0；顶点最终世界位置与“只 GPU 跟随”一致（最大差 ${maxDiff.toExponential(1)} m）`,
      gpuZero && maxDiff <= 1e-6, `对照：如果 shader 直接加 cc_cameraPos（不减节点位置）会偏 ${dbl.toFixed(0)} m`);
    const insideAll = log.every(l => l.inside), outsideNoFollow = log.filter(l => !l.insideNoFollow).length;
    rec(F, `CPU 剔除：每帧相机都在天空节点的世界包围盒（半边长 ${R} m）内 → 不会被视锥剔除；对照：节点不跟随时 ${outsideNoFollow}/${N} 帧相机在包围盒外（Oi 审查 #1 指出的风险）`, insideAll && outsideNoFollow > 0, '');

    // F4 BEFORE_DRAW 里更晚的写入者：检测 + syncAll 修正
    const before = comp.lateWrites; let usesSync = false, mism = 0, mism2 = 0;
    const lateWriter = () => { const c = camNode.worldPosition; camNode.setWorldPosition(c.x + 50, c.y, c.z - 50); if (usesSync) SkyFollowCamera.syncAll(); };
    D.on(cc.Director.EVENT_BEFORE_DRAW, lateWriter, null);
    const warn = console.warn; let warned = 0; console.warn = () => { warned++; };
    D.onSceneUpdate = () => { const c = camNode.worldPosition, s = sky.worldPosition; if (Math.abs(c.x - s.x) > tol || Math.abs(c.z - s.z) > tol) { if (usesSync) mism2++; else mism++; } };
    for (let i = 0; i < 10; i++) D.tick(1 / 60);
    const detected = comp.lateWrites - before; usesSync = true; const b2 = comp.lateWrites;
    for (let i = 0; i < 10; i++) D.tick(1 / 60);
    console.warn = warn; D.off(cc.Director.EVENT_BEFORE_DRAW, lateWriter, null);
    rec(F, `契约外的写入者（在 BEFORE_DRAW 里、注册晚于 SkyFollowCamera 写相机）：BEFORE_COMMIT 核对检测到 ${detected}/10 帧并只警告 1 次；写入者写完调用 SkyFollowCamera.syncAll() 后 0/10 帧不一致、不再计数`,
      mism === 10 && detected === 10 && warned === 1 && mism2 === 0 && comp.lateWrites === b2, `未修正不一致帧=${mism} 修正后=${mism2}`);

    // F5 自动找相机 / 停用注销
    const comp2 = new Node('sky2b'); scene.addChild(comp2); const s2c = comp2.addComponent(SkyFollowCamera); s2c.onEnable();
    const autoOk = Math.abs(comp2.worldPosition.x - camNode.worldPosition.x) < tol;
    comp.onDisable(); s2c.onDisable();
    const left = D.h.filter(x => x.tg === comp || x.tg === s2c).length;
    rec(F, `cameraNode 不填时自动用场景里 priority 最小的启用 Camera；onDisable 注销 BEFORE_DRAW / BEFORE_COMMIT 监听并移出 syncAll 列表（剩余 ${left}）`, autoOk && left === 0 && SkyFollowCamera.active.size === 0, '');
  }

  // ---------------------------------------------------------------- G 兜底选择（纯函数，真实 v0.8 数据）
  const haveData = fs.existsSync(INST) && fs.existsSync(ANCH);
  if (!haveData) { rec(Gf, '兜底选择（真实数据）', null, `找不到 ${INST} 或 ${ANCH}`); return; }
  const inst = JSON.parse(fs.readFileSync(INST, 'utf8')), anch = JSON.parse(fs.readFileSync(ANCH, 'utf8'));
  const pathA = Object.keys(anch).filter(k => /^walk_path_\d+$/.test(k)).sort().map(k => anch[k].game_m);
  const viewNames = ['player_spawn', 'region_interaction_point', 'windmill_door_point'];
  const isGrass = (g) => String(g.template).startsWith('grass_') || !!(g.attrs && g.attrs._ROOT_COLOR);
  const clumps = []; for (const g of inst.groups) if (isGrass(g)) for (let i = 0; i < g.count; i++) clumps.push({ x: g.t[i * 3], z: g.t[i * 3 + 2] });
  {
    const { cc } = makeCC();
    const GF = makeCC.loadScripts(ts, SCRIPTS, cc, ['GrassFallback']).GrassFallback;
    const path = pathA.map(p => ({ x: p[0], z: p[2] })), views = viewNames.map(n => ({ x: anch[n].game_m[0], z: anch[n].game_m[2] }));
    const A = GF.selectFallbackClumps(clumps, { path, views }), B = GF.selectFallbackClumps(clumps, { path, views });
    const same = JSON.stringify(A.keep) === JSON.stringify(B.keep);
    const dSeg = (p, a, b) => { const dx = b.x - a.x, dz = b.z - a.z, l2 = dx * dx + dz * dz; let t = l2 ? ((p.x - a.x) * dx + (p.z - a.z) * dz) / l2 : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(a.x + t * dx - p.x, a.z + t * dz - p.z); };
    const edge = clumps.map(p => Math.abs(Math.min(...path.slice(1).map((b, k) => dSeg(p, path[k], b))) - 1.0));
    const dv = clumps.map(p => Math.min(...views.map(v => Math.hypot(p.x - v.x, p.z - v.z))));
    const mean = (a) => a.reduce((s, x) => s + x, 0) / (a.length || 1);
    const keptI = A.keep.map((k, i) => k ? i : -1).filter(i => i >= 0), dropI = A.keep.map((k, i) => k ? -1 : i).filter(i => i >= 0);
    const thresholdOk = Math.max(...keptI.map(i => A.priority[i])) <= Math.min(...dropI.map(i => A.priority[i]));
    const nearPath = [...edge.keys()].sort((a, b) => edge[a] - edge[b]).slice(0, 50).every(i => A.keep[i]);
    const nearView = [...dv.keys()].sort((a, b) => dv[a] - dv[b]).slice(0, 30).every(i => A.keep[i]);
    rec(Gf, `30% 选择（真实 v0.8：${clumps.length} 丛草 + anchors 里 walk_path_00…${String(pathA.length - 1).padStart(2, '0')} 小路 + ${viewNames.join(' / ')} 视点）：保留 ${A.kept}（= round(${clumps.length}×0.3)），两次结果逐丛一致；保留集合的优先级全部 ≤ 丢弃集合；离路边缘最近的 50 丛、离视点最近的 30 丛全部保留`,
      A.kept === Math.round(clumps.length * 0.3) && A.keep.filter(Boolean).length === A.kept && same && thresholdOk && nearPath && nearView && A.rule === 'path+views',
      `离路边缘平均距离：保留 ${mean(keptI.map(i => edge[i])).toFixed(2)} m vs 全部 ${mean(edge).toFixed(2)} m；离视点平均：保留 ${mean(keptI.map(i => dv[i])).toFixed(2)} m vs 全部 ${mean(dv).toFixed(2)} m`);
    const S = GF.selectFallbackClumps(clumps, {}); const idx = S.keep.map((k, i) => k ? i : -1).filter(i => i >= 0); const gaps = idx.slice(1).map((v, i) => v - idx[i]);
    const M = GF.selectFallbackClumps(clumps, { path, views, mask: (x) => (x < -45 ? 1000 : 1) }); const far = clumps.map((p, i) => p.x < -45 ? i : -1).filter(i => i >= 0);
    const r0 = GF.selectFallbackClumps(clumps, { path, keepRatio: 0 }).kept, r1 = GF.selectFallbackClumps(clumps, { path, keepRatio: 1 }).kept;
    rec(Gf, `没有小路和视点数据时退回均匀抽稀：保留 ${S.kept}，相邻保留序号间隔 ${Math.min(...gaps)}–${Math.max(...gaps)}；路径遮罩钩子 mask(x,z)：给 x < −45 m 的 ${far.length} 丛权重 1000 后它们全部保留；keepRatio 0 / 1 → ${r0} / ${r1}`,
      S.rule === 'stride' && S.kept === 300 && Math.max(...gaps) <= 4 && far.length > 0 && far.every(i => M.keep[i]) && r0 === 0 && r1 === clumps.length, '');
    // 根色校验
    const v1 = GF.validateRootColors(null, 3), v2 = GF.validateRootColors([0.1, 0.2, 0.3, 0.4], 2), v3 = GF.validateRootColors([0.1, NaN, 0.3, -1, 0, 0, 0.2, 0.2, 9], 3), v4 = GF.validateRootColors([0.1, 0.2, 0.3], 1);
    const L = GF.PALETTE_MID_GREEN_LINEAR; const isMid = (c, i) => [0, 1, 2].every(k => Math.abs(c[i * 3 + k] - L[k]) < 1e-15);
    rec(H, `validateRootColors：缺失（null）→ 3/3 填中间绿；长度不够 → 第 2 个填；NaN / 负数 / 超范围 → 填；合法值原样保留；中间绿线性值 = #60AE32 平方（与 shader SRGBToLinear 一致），不会出现黑根 0`,
      v1.missing === 3 && [0, 1, 2].every(i => isMid(v1.colors, i)) && v2.missing === 1 && !isMid(v2.colors, 0) && isMid(v2.colors, 1) && v3.invalid === 3 && v4.missing === 0 && v4.invalid === 0 && v4.colors.join() === '0.1,0.2,0.3'
      && Math.abs(L[1] - (0xae / 255) ** 2) < 1e-15 && L.every(x => x > 0), '');
    // 关草触发条件
    const run = (seq, o) => { const m = new GF.FrameBudgetMonitor(o); let t = 0, hit = -1, hits = 0; for (const dt of seq) { t += dt; if (m.push(dt)) { hits++; if (hit < 0) hit = t; } } return { hit, hits }; };
    const rep = (dt, sec) => Array(Math.round(sec / dt)).fill(dt);
    const a1 = run(rep(1 / 60, 60)), a2 = run(rep(0.035, 60)), a3 = run(rep(0.05, 20)), a4 = run([...rep(0.05, 6), 1.2, ...rep(0.05, 20)]);
    const mixed = (r) => { const s = []; for (let i = 0; i < 2000; i++) s.push((i % 100) < r ? 0.05 : 0.02); return s; };
    const a5 = run(mixed(70)), a6 = run(mixed(90));
    rec(Gf, `关草触发（FrameBudgetMonitor 默认：预算 40 ms、窗口 5 s、超预算帧 ≥ 80%、进场 3 s 不计、单帧 > 0.5 s 清窗口）：60 fps / 35 ms 恒不触发；50 ms 恒定在 t=${a3.hit.toFixed(2)} s 触发且只触发 ${a3.hits} 次；中途 1.2 s 卡顿（切后台）清窗口 → t=${a4.hit.toFixed(2)} s 才触发；70% 超预算不触发，90% 触发`,
      a1.hit < 0 && a2.hit < 0 && Math.abs(a3.hit - 8.0) < 0.06 && a3.hits === 1 && a4.hit > 6 + 1.2 + 4.9 && a5.hit < 0 && a6.hit > 0, '');
  }

  // ---------------------------------------------------------------- G/H MeadowInstancer 集成（桩场景，真实实例 JSON + anchors）
  const buildScene = (opts) => {
    const env = makeCC(opts); const { cc } = env; const S = makeCC.loadScripts(ts, SCRIPTS, cc, ['GrassWindQuality', 'GrassFallback', 'MeadowInstancer']);
    const { Node, MeshRenderer, Material, Vec3 } = cc;
    const base = new Material(); base.passes[0].defines.WIND_QUALITY = 2; const flowerMat = new Material(); flowerMat.effectName = 'builtin-standard';
    const root = new Node('meadow_root');
    const mesh = (n) => ({ name: n, struct: { minPosition: new Vec3(-0.3, 0, -0.3), maxPosition: new Vec3(0.3, 0.6, 0.3), primitives: [], vertexBundles: [] }, readAttribute: () => null });
    const data = JSON.parse(JSON.stringify(inst)); if (opts.mutate) opts.mutate(data);
    for (const g of data.groups) { const n = new Node(g.node); root.addChild(n); if (opts.srcTRS && g.node === opts.srcTRS.node) { n.setPosition(new Vec3(...opts.srcTRS.p)); n.setRotation(new cc.Quat(...opts.srcTRS.q)); n.setScale(new Vec3(...opts.srcTRS.s)); }
      const r = n.addComponent(MeshRenderer); r.mesh = mesh(g.template); r.setSharedMaterial(isGrass(g) ? base : flowerMat, 0); }
    if (opts.anchors !== false) for (const k of Object.keys(anch)) if (/^walk_path_\d+$/.test(k) || viewNames.includes(k)) { const a = new Node(k); root.addChild(a); a.setPosition(new Vec3(...anch[k].game_m)); }
    const ground = new Node('ground'); root.addChild(ground); const gr = ground.addComponent(MeshRenderer); gr.mesh = mesh('ground'); gr.setSharedMaterial(new Material(), 0);
    const comp = new S.MeadowInstancer.MeadowInstancer(); comp.node = root; comp.instances = { json: data };
    Object.assign(comp, { castShadows: false, fallbackKeepRatio: 0.3, forceNoInstancing: false, viewAnchorNames: viewNames.slice(), extraViews: [], frameBudgetMs: 40, budgetWindowSec: 5, budgetOverRatio: 0.8, bakedGroundTexture: null, groundRenderer: gr, groundTextureProperty: 'mainTexture', releaseMaterialsOnDestroy: true }, opts.props || {});
    const all = (n) => [n, ...n.children.flatMap(all)];
    const spawned = () => all(root).filter(n => n.comps.length && /_\d+$/.test(n.name) && n.parent && /_expanded$/.test(n.parent.name));
    return { ...env, S, base, flowerMat, root, comp, gr, data, spawned, all };
  };
  const quiet = (f) => { const w = console.warn; const msgs = []; console.warn = (...a) => msgs.push(a.join(' ')); try { return [f(), msgs]; } finally { console.warn = w; } };
  {
    const T = buildScene({ instancing: false }); quiet(() => T.comp.start());
    const sp = T.spawned(); const grassN = sp.filter(n => n.name.startsWith('grass_')), flowerN = sp.filter(n => n.name.startsWith('flower_'));
    const ref = T.S.GrassFallback.selectFallbackClumps(clumps, { path: pathA.map(p => ({ x: p[0], z: p[2] })), views: viewNames.map(n => ({ x: anch[n].game_m[0], z: anch[n].game_m[2] })) });
    const refNames = []; let k = 0; for (const g of inst.groups) if (isGrass(g)) for (let i = 0; i < g.count; i++, k++) if (ref.keep[k]) refNames.push(`${g.template}_${i}`);
    const T2 = buildScene({ instancing: false }); quiet(() => T2.comp.start());
    const names = grassN.map(n => n.name).sort().join(), names2 = T2.spawned().filter(n => n.name.startsWith('grass_')).map(n => n.name).sort().join();
    const noAttr = sp.every(n => !n.getComponent(T.cc.MeshRenderer).model.inst.a_root_color);
    const rc = T.base.props.rootColor; const rcOk = rc && rc.r === 0x60 && rc.g === 0xae && rc.b === 0x32 && rc.a === 255;
    rec(Gf, `MeadowInstancer 无实例化（device.hasFeature(INSTANCED_ARRAYS) = false）：在场景里从 walk_path_* / 视点锚点节点取数据，草只展开 ${grassN.length}/${clumps.length} 丛（与纯函数选择逐丛一致、两次运行一致），花全部 ${flowerN.length} 丛照常；不设 a_root_color；草基础材质 rootColor = #60AE32（rule=${T.comp.report.rule}）`,
      grassN.length === 300 && names === refNames.sort().join() && names === names2 && flowerN.length === inst.groups.filter(g => !isGrass(g)).reduce((s, g) => s + g.count, 0) && noAttr && rcOk && T.comp.instancing === false, '');
    // 统一根色路径：effect 里无实例化分支 = SRGBToLinear(rootColor.rgb)，与缺失填充的线性值一致
    const eff = fs.readFileSync(ps.join(HERE, '../../runtime/effects/meadow-grass-wind.effect'), 'utf8');
    const branch = /#if USE_INSTANCING && USE_INSTANCE_ROOT_COLOR\s*\n\s*v_root = a_root_color\.rgb;\s*\n\s*#else\s*\n\s*v_root = SRGBToLinear\(rootColor\.rgb\);/.test(eff);
    const defM = /rootColor:\s*\{\s*value:\s*\[([^\]]+)\]/.exec(eff); const def = defM ? defM[1].split(',').map(Number) : [];
    const lin = [rc.r, rc.g, rc.b].map(x => (x / 255) ** 2); const L = T.S.GrassFallback.PALETTE_MID_GREEN_LINEAR;
    rec(Gf, `统一根色路径：effect 在 USE_INSTANCING 被引擎关掉（pass.ts _syncBatchingScheme）时走 v_root = SRGBToLinear(rootColor.rgb)；MeadowInstancer 设的 rootColor 经 SRGBToLinear 后 = 缺失 _ROOT_COLOR 填充值 = (${L.map(x => x.toFixed(4)).join(', ')})；effect 默认 rootColor = [${def.slice(0, 3)}] ≈ #60AE32（±0.5/255）`,
      branch && lin.every((x, i) => Math.abs(x - L[i]) < 1e-12) && def.slice(0, 3).every((x, i) => Math.abs(x * 255 - [0x60, 0xae, 0x32][i]) <= 0.5), '');
    // 关草：update 驱动
    const tex = { name: 'baked_grass_ground (art TBD)' }; T.comp.bakedGroundTexture = tex; let ev = null; T.root.on('meadow-grass-off', (v) => { ev = v; }, null);
    for (let i = 0; i < 600; i++) T.comp.update(1 / 60);
    const offEarly = T.comp.grassOff; let tOff = -1;
    for (let i = 0; i < 400 && tOff < 0; i++) { T.comp.update(0.05); if (T.comp.grassOff) tOff = 10 + i * 0.05; }
    const grassDisabled = grassN.every(n => n.getComponent(T.cc.MeshRenderer).enabled === false), flowersOn = flowerN.every(n => n.getComponent(T.cc.MeshRenderer).enabled !== false);
    const gTex = T.gr.instances[0] && T.gr.instances[0].props.mainTexture === tex;
    const T3 = buildScene({ instancing: true }); quiet(() => T3.comp.start()); for (let i = 0; i < 400; i++) T3.comp.update(0.05);
    rec(Gf, `减量后仍超预算才关草：10 s 60 fps 不关；之后每帧 50 ms，在 t≈${tOff.toFixed(2)} s 关草（setGrassOff）：300 丛草 renderer 全部禁用、花不受影响、地面材质 mainTexture 换成烘焙草色贴图槽里的贴图、节点发 'meadow-grass-off'(true)；有实例化的设备不装监视器、不关草`,
      !offEarly && tOff > 0 && grassDisabled && flowersOn && gTex && ev === true && T3.comp.instancing && !T3.comp.grassOff && T3.spawned().length === 1150, `有实例化时展开 ${T3.spawned().length}`);
    const T4 = buildScene({ instancing: false, anchors: false }); quiet(() => T4.comp.start());
    rec(Gf, `场景里找不到小路 / 视点锚点时退回均匀抽稀（rule=${T4.comp.report.rule}），仍保留 ${T4.comp.report.grassKept} 丛；forceNoInstancing 调试开关在有实例化的设备上也走兜底`,
      T4.comp.report.rule === 'stride' && T4.comp.report.grassKept === 300 && (() => { const T5 = buildScene({ instancing: true, props: { forceNoInstancing: true } }); quiet(() => T5.comp.start()); return T5.comp.instancing === false && T5.comp.report.grassKept === 300; })(), '');
  }
  {
    // H1 缺失 / 非法 _ROOT_COLOR
    const T = buildScene({ instancing: true, mutate: (d) => { delete d.groups.find(g => g.template === 'grass_clump_T3_mid_short').attrs._ROOT_COLOR; const g = d.groups.find(g => g.template === 'grass_clump_T1_mid_long'); g.attrs._ROOT_COLOR[0] = NaN; g.attrs._ROOT_COLOR[4] = -2; } });
    const [, msgs] = quiet(() => T.comp.start());
    const L = T.S.GrassFallback.PALETTE_MID_GREEN_LINEAR;
    const rs = T.spawned().filter(n => n.name.startsWith('grass_')).map(n => n.getComponent(T.cc.MeshRenderer));
    const zero = rs.filter(r => { const v = r.model.inst.a_root_color; return !v || (v[0] === 0 && v[1] === 0 && v[2] === 0); }).length;
    const filled = rs.filter(r => { const v = r.model.inst.a_root_color; return v && [0, 1, 2].every(k => Math.abs(v[k] - L[k]) < 1e-15); }).length;
    // T3 那一组 _ROOT_COLOR 被删掉了：isGrass 仍按模板名认出是草
    rec(H, `_ROOT_COLOR 校验：删掉一组（T3，41 丛）+ 另一组 2 个非法值 → MeadowInstancer 报告缺失 ${T.comp.report.rootColorMissing} / 非法 ${T.comp.report.rootColorInvalid}，打 ${msgs.filter(m => /_ROOT_COLOR/.test(m)).length} 条警告，这些实例 a_root_color = 中间绿（${filled} 个），黑根 0 个`,
      T.comp.report.rootColorMissing === 41 && T.comp.report.rootColorInvalid === 2 && zero === 0 && filled === 43 && msgs.filter(m => /_ROOT_COLOR/.test(m)).length === 2, '');
  }
  {
    // H2 模板节点非单位 TRS：展开节点世界位置 = 模板节点变换 × 实例 TRS
    const q = [0, Math.sin(Math.PI / 4), 0, Math.cos(Math.PI / 4)];
    const T = buildScene({ instancing: true, srcTRS: { node: 'meadow_grass_instances.0', p: [5, 1, -3], q, s: [2, 2, 2] } });
    quiet(() => T.comp.start());
    const g = inst.groups.find(x => x.node === 'meadow_grass_instances.0'); const src = T.root.children.find(n => n.name === g.node);
    let maxErr = 0; for (let i = 0; i < g.count; i++) { const n = T.all(T.root).find(x => x.name === `${g.template}_${i}` && x.comps.length); const w = n.toWorld([0, 0, 0]); const e = src.toWorld([g.t[i * 3], g.t[i * 3 + 1], g.t[i * 3 + 2]]); maxErr = Math.max(maxErr, ...w.map((v, k) => Math.abs(v - e[k]))); }
    const ws = T.all(T.root).find(x => x.name === `${g.template}_0` && x.comps.length).worldScale.x;
    rec(H, `模板节点非单位 TRS（平移 (5,1,−3)、绕 Y 90°、缩放 2）：${g.count} 个展开节点挂在复制了模板局部 TRS 的 *_expanded 容器下，世界位置 = 模板节点变换 × 实例 TRS（最大误差 ${maxErr.toExponential(1)} m），世界缩放含父级 2×（包围盒按世界缩放算）`,
      maxErr < 1e-9 && Math.abs(ws - 2 * g.s[0]) < 1e-12, '');
  }
  {
    // H3 晚到的展开（异步加载 / 自动画质组件先跑完）立即 apply 当前档；重新启用 / 缩放 → 下一个 BEFORE_DRAW 刷新
    const T = buildScene({ instancing: true }); const { gwq } = { gwq: T.S.GrassWindQuality };
    gwq.applyGrassWindQuality([], 1);   // 先切档（此时还没有草）
    quiet(() => T.comp.start());
    const rs = T.spawned().filter(n => n.name.startsWith('grass_')).map(n => n.getComponent(T.cc.MeshRenderer));
    const qOk = rs.every(r => r.sharedMaterials[0] !== T.base && gwq.getGrassWindQuality(r.sharedMaterials[0]) === 1) && rs.every(r => r.sharedMaterials[0] === rs[0].sharedMaterials[0]);
    const colorOk = rs.every(r => r.model.inst.a_root_color);
    const T0 = buildScene({ instancing: true }); quiet(() => T0.comp.start()); const untouched = T0.spawned().filter(n => n.name.startsWith('grass_')).every(n => n.getComponent(T0.cc.MeshRenderer).sharedMaterials[0] === T0.base);
    rec(H, `apply 时序：区域加载前已经切到“低”档 → 新展开的 ${rs.length} 丛草立即用“低”档共享材质（同一个，保住实例化）且根色已重设；没切过档时不改材质`, qOk && colorOk && untouched, '');
    // 重新启用 / 缩放
    for (const r of rs) r.model.inst = {};
    T.comp.onEnable(); const before = rs.filter(r => r.model.inst.a_root_color).length;
    T.cc.director.tick(1 / 60); const after = rs.filter(r => r.model.inst.a_root_color).length;
    for (const r of rs) r.model.inst = {};
    T.root.setScale(new T.cc.Vec3(1.5, 1.5, 1.5)); T.root.setScale(new T.cc.Vec3(1.5, 1.5, 1.5)); T.cc.director.tick(1 / 60);
    const afterScale = rs.filter(r => r.model.inst.a_root_color).length;
    const pending = T.cc.director.h.filter(x => x.tg === T.comp).length;
    rec(H, `重新启用 / 根节点缩放：合并到下一个 BEFORE_DRAW 刷新一次（启用后同步阶段 ${before}，BEFORE_DRAW 后 ${after}/${rs.length}；缩放两次只排 1 次，刷新后 ${afterScale}/${rs.length}），刷新后不残留 director 监听（${pending}）`,
      before === 0 && after === rs.length && afterScale === rs.length && pending === 0, '');
    // H4 卸载
    gwq.applyGrassWindQuality(rs, 0);   // 低 → 关：两个运行时副本（base 本身是高档 2）
    const fam = gwq.getGrassWindMaterialFamily(T.base).filter(m => m !== T.base);
    const templates = T.root.children.filter(n => /_instances\.\d+$/.test(n.name)).map(n => n.getComponent(T.cc.MeshRenderer));
    const tGrass = templates.filter(r => isGrass(T.data.groups.find(g => g.node === r.node.name)));
    gwq.applyGrassWindQuality(tGrass, 1);   // 模板节点也被切过档（自动画质组件扫到了它们）
    const spawnedBefore = T.spawned();
    T.comp.onDestroy();
    const deact = spawnedBefore.every(n => n.active === false && n.isValid === false);
    const destroyed = fam.length > 0 && fam.every(m => m.destroyed) && !T.base.destroyed && !T.flowerMat.destroyed;
    const restored = tGrass.every(r => r.sharedMaterials[0] === T.base);
    const lis = gwq.grassWindEvents.h.filter(x => x.tg === T.comp).length + T.cc.director.h.filter(x => x.tg === T.comp).length + T.root.h.filter(x => x.tg === T.comp).length;
    const famAfter = gwq.getGrassWindMaterialFamily(T.base).filter(m => m !== T.base).length;
    const fresh = gwq.getQualityMaterial(T.base, 1); const freshOk = !fresh.destroyed && fresh !== T.base && !fam.includes(fresh);
    rec(H, `区域卸载（onDestroy）：销毁 ${fam.length} 个各档运行时材质副本（原材质资源和花材质不动），模板节点换回原材质，grassWindEvents / director / 节点监听剩 ${lis}，缓存清空（剩 ${famAfter}）；再次进入区域时重新生成未销毁的副本`,
      destroyed && restored && lis === 0 && famAfter === 0 && freshOk && deact, `destroyed=${destroyed} restored=${restored} lis=${lis} famAfter=${famAfter} fresh=${freshOk}；展开节点先停用再 destroy（destroy 延迟到下一帧，停用让本帧不再用已销毁的副本）：${deact}`);
    // 对照：不释放时副本留着
    const T6 = buildScene({ instancing: true, props: { releaseMaterialsOnDestroy: false } }); quiet(() => T6.comp.start()); const g6 = T6.S.GrassWindQuality; g6.applyGrassWindQuality(T6.spawned().map(n => n.getComponent(T6.cc.MeshRenderer)), 1);
    const f6 = g6.getGrassWindMaterialFamily(T6.base).filter(m => m !== T6.base); T6.comp.onDestroy();
    rec('harness-sanity', `反向对照 H1：releaseMaterialsOnDestroy = false 时卸载后 ${f6.length} 个副本未销毁（证明上一项靠的是 v1.2 的释放）`, f6.length > 0 && f6.every(m => !m.destroyed), '');
  }
};
