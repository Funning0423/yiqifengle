'use strict';
// E4 v1.1/v1.2：MeadowInstancer（包围盒扩展 + a_root_color 重设）和 GrassWindQuality 包围盒工具的 Node 测试。
// 'cc' 用最小桩代替；桩里只模拟和本测试有关的引擎行为（3.8.8 源码出处见注释）：
//  - MeshRenderer.setSharedMaterial → subModel 重建实例属性块（全 0）     render-scene/scene/submodel.ts / model.ts _updateInstancedAttributes
//  - Model.createBoundingShape(min,max) + updateWorldBound()：本地 AABB 经节点 TRS 变成世界 AABB  render-scene/scene/model.ts
//  - Pass.getHandle(name) / getUniform(handle)：属性名 → 当前 uniform 值（含 effect 默认值）      render-scene/core/pass.ts
const fs = require('fs'), ps = require('path'), cp = require('child_process'), os = require('os');
const Module = require('module');

module.exports = async function run (ctx) {
  const { ts, tsc, ccd, rec, ref, GLB, INST, HERE, winds, U, OUT } = ctx;
  const G = 'e-meadow-instancer';
  const giTs = ps.join(HERE, '../../runtime/scripts/GrassWindQuality.ts'), miTs = ps.join(HERE, '../../runtime/scripts/MeadowInstancer.ts');

  // E0 类型检查（runtime/scripts 下 4 个文件一起，互相 import）
  {
    const dir = fs.mkdtempSync(ps.join(os.tmpdir(), 'e4-mi-')); const names = ['GrassWindQuality', 'GrassFallback', 'MeadowInstancer', 'SkyFollowCamera'];
    for (const n of names) fs.copyFileSync(ps.join(HERE, '../../runtime/scripts', n + '.ts'), ps.join(dir, n + '.ts'));
    fs.writeFileSync(ps.join(dir, 'tsconfig.json'), JSON.stringify({ compilerOptions: { target: 'ES2017', module: 'ES2015', moduleResolution: 'node', strict: true, experimentalDecorators: true, noEmit: true, lib: ['ES2017', 'DOM'], skipLibCheck: true, types: [] }, files: [ccd, ...names.map(n => ps.join(dir, n + '.ts'))] }));
    const r = cp.spawnSync('node', [tsc, '-p', ps.join(dir, 'tsconfig.json')], { encoding: 'utf8' });
    rec(G, 'runtime/scripts 全部 4 个 TS（GrassWindQuality / GrassFallback / MeadowInstancer / SkyFollowCamera，同一目录互相 import）用 Creator 3.8.8 自带 TypeScript + cc.d.ts 严格模式类型检查 0 错误', r.status === 0, (r.stdout + r.stderr).slice(0, 600));
    fs.rmSync(dir, { recursive: true, force: true });
  }
  if (!fs.existsSync(GLB) || !fs.existsSync(INST)) { rec(G, 'MeadowInstancer 逻辑测试', null, `找不到 ${GLB} 或 ${INST}`); return; }

  // ---- 读 GLB（COLOR_0 保留原始 uint16，模拟 Cocos 导入后 RGBA16UI + isNormalized 的顶点数据）
  const b = fs.readFileSync(GLB); const jl = b.readUInt32LE(12); const J = JSON.parse(b.slice(20, 20 + jl).toString()); const BIN = b.slice(20 + jl + 8);
  const CT = { 5121: [1, 'readUInt8'], 5123: [2, 'readUInt16LE'], 5126: [4, 'readFloatLE'] }; const NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
  const accRaw = (i) => { const a = J.accessors[i], bv = J.bufferViews[a.bufferView], [sz, fn] = CT[a.componentType], n = NC[a.type];
    const stride = bv.byteStride || sz * n, off = (bv.byteOffset || 0) + (a.byteOffset || 0); const out = [];
    for (let k = 0; k < a.count; k++) for (let c = 0; c < n; c++) out.push(BIN[fn](off + k * stride + c * sz)); return { a, out, n }; };
  const inst = JSON.parse(fs.readFileSync(INST, 'utf8'));

  // ---- cc 桩（v1.2 起与其他测试共用 cc-stub.js）
  const makeCC = require('./cc-stub');
  const { cc: ccMock, Model } = makeCC({ instancing: true });
  const { Node, MeshRenderer, Material, Vec3 } = ccMock;
  const load = () => { const r = makeCC.loadScripts(ts, ps.join(HERE, '../../runtime/scripts'), ccMock, ['GrassWindQuality', 'GrassFallback', 'MeadowInstancer']); return { gwq: r.GrassWindQuality, mi: r.MeadowInstancer }; };

  // ---- 网格桩：真实 v0.8 模板
  const meshes = {}; const meshVerts = {};
  for (const m of J.meshes) {
    const pr = m.primitives[0]; const pos = accRaw(pr.attributes.POSITION);
    const pa = J.accessors[pr.attributes.POSITION];
    const hasColor = 'COLOR_0' in pr.attributes; const col = hasColor ? accRaw(pr.attributes.COLOR_0) : null;
    const attrs = [{ name: 'a_position', format: 2, isNormalized: false }];
    if (col) attrs.push({ name: 'a_color', format: col.a.componentType === 5123 ? 1 : col.a.componentType === 5126 ? 2 : 3, isNormalized: !!col.a.normalized });
    const struct = { minPosition: new Vec3(...pa.min), maxPosition: new Vec3(...pa.max), primitives: [{ vertexBundelIndices: [0] }], vertexBundles: [{ attributes: attrs }] };
    const raw = col ? (col.a.componentType === 5123 ? Uint16Array : col.a.componentType === 5126 ? Float32Array : Uint8Array).from(col.out) : null;
    meshes[m.name] = { name: m.name, struct, readAttribute: (i, n) => (n === 'a_color' ? raw : null) };
    const div = col ? (col.a.componentType === 5123 ? 65535 : col.a.componentType === 5121 ? 255 : 1) : 1;
    meshVerts[m.name] = { pos: pos.out, col: col ? col.out.map(x => x / div) : null };
  }

  // ---- 场景：根节点下每组一个模板节点（共享材质，WIND_QUALITY = 2 = 最大位移）
  const { gwq, mi } = load();
  const base = new Material(); base.passes[0].defines.WIND_QUALITY = 2;
  const flowerMat = new Material(); flowerMat.effectName = 'builtin-standard';
  const root = new Node('meadow_root');
  const grassGroups = inst.groups.filter(g => meshes[g.template] && meshVerts[g.template].col);
  for (const g of inst.groups) {
    const n = new Node(g.node); root.addChild(n);
    const mesh = meshes[g.template] || { name: g.template, struct: { minPosition: new Vec3(-0.3, 0, -0.3), maxPosition: new Vec3(0.3, 0.5, 0.3), primitives: [], vertexBundles: [] }, readAttribute: () => null };
    const r = n.addComponent(MeshRenderer); r.mesh = mesh; r.setSharedMaterial(grassGroups.includes(g) ? base : flowerMat, 0);
  }
  const comp = new mi.MeadowInstancer(); comp.node = root; comp.instances = { json: inst }; comp.castShadows = false;
  comp.start();
  const all = (n) => [n, ...n.children.flatMap(all)];
  const spawned = all(root).filter(c => c.active && c.getComponent(MeshRenderer) && /_\d+$/.test(c.name));
  const grassR = []; for (const g of grassGroups) for (let i = 0; i < g.count; i++) { const n = all(root).find(c => c.name === `${g.template}_${i}` && c.comps.length); grassR.push({ g, i, n, r: n.getComponent(MeshRenderer) }); }
  const rootOf = (g, i) => [g.attrs._ROOT_COLOR[i * 3], g.attrs._ROOT_COLOR[i * 3 + 1], g.attrs._ROOT_COLOR[i * 3 + 2], 1];

  // E1 包围盒覆盖真实最大位移
  const L = Math.hypot(U.windDirSpeed.x, U.windDirSpeed.y); const dir = [U.windDirSpeed.x / L, U.windDirSpeed.y / L];
  const times = []; for (let t = 0; t <= 9; t += 0.15) times.push(t);
  const contain = (useMeshBounds) => {
    let out = 0, n = 0, maxD = 0, maxDrop = 0, worstMargin = Infinity;
    for (const { g, i, n: node, r } of grassR) {
      let wb = r.model.world;
      if (useMeshBounds) { const m = new Model(node); m.createBoundingShape(r.mesh.struct.minPosition, r.mesh.struct.maxPosition); m.updateWorldBound(); wb = m.world; }
      const V = meshVerts[g.template]; const o = ref.vec2(g.t[i * 3], g.t[i * 3 + 2]); const nv = V.pos.length / 3;
      for (let k = 0; k < nv; k++) {
        const c = { r: V.col[k * 4], g: V.col[k * 4 + 1], b: V.col[k * 4 + 2], a: V.col[k * 4 + 3] };
        const wp = node.toWorld([V.pos[k * 3], V.pos[k * 3 + 1], V.pos[k * 3 + 2]]);
        for (const t of times) {
          const { d, drop } = ref.displacement(winds[2], 2, U, o, c, t); maxD = Math.max(maxD, Math.abs(d)); maxDrop = Math.max(maxDrop, Math.abs(drop));
          const p = [wp[0] + dir[0] * d, wp[1] - drop, wp[2] + dir[1] * d]; n++;
          let inside = true; for (let a = 0; a < 3; a++) { const m = Math.min(p[a] - wb.min[a], wb.max[a] - p[a]); worstMargin = Math.min(worstMargin, m); if (m < -1e-6) inside = false; }
          if (!inside) out++;
        }
      }
    }
    return { out, n, maxD, maxDrop, worstMargin };
  };
  const E1 = contain(false), E1neg = contain(true);
  const pads = grassR.map(x => x.r.model.local.min.map((v, k) => (x.r.mesh.struct.minPosition[['x', 'y', 'z'][k]] - v)));
  const padMin = Math.min(...pads.map(p => Math.min(...p))), padMax = Math.max(...pads.map(p => Math.max(...p)));
  rec(G, `包围盒覆盖风位移：${grassR.length} 个草实例 × v0.8 真实顶点 × ${times.length} 个时刻（WIND_QUALITY 2，CPU 参考 = effect 里 windOffset 的机械翻译），位移后的顶点全部在扩展后的世界包围盒内`,
    E1.out === 0 && E1.n > 0 && E1.maxD > 0.69, `samples=${E1.n} outside=${E1.out} max|d|=${E1.maxD.toFixed(3)} m max|drop|=${E1.maxDrop.toFixed(3)} m 最小余量=${E1.worstMargin.toFixed(3)} m；本地 pad ${padMin.toFixed(3)}–${padMax.toFixed(3)} m（按模板 maxA，不是写死的 0.69）`);
  rec(G, '反向对照：不扩包围盒（网格原包围盒）时，同样的样本有顶点跑出包围盒（证明上一项有效，这就是屏幕边缘“突然出现”的原因）', E1neg.out > 0, `outside=${E1neg.out}/${E1neg.n}`);

  // E2 maxA 从网格读、按模板不同
  const stats = JSON.parse(fs.readFileSync(ps.join(OUT, 'meadow-COLOR_0-stats.json'), 'utf8'));
  const ampBad = stats.filter(s => Math.abs(gwq.meshMaxWindAmplitude(meshes[s.mesh]) - s.a.max) > 1e-6).map(s => `${s.mesh}: ${gwq.meshMaxWindAmplitude(meshes[s.mesh])} vs ${s.a.max}`);
  const noColor = gwq.meshMaxWindAmplitude({ struct: { primitives: [{ vertexBundelIndices: [0] }], vertexBundles: [{ attributes: [] }] }, readAttribute: () => null });
  const broken = gwq.meshMaxWindAmplitude({ get struct () { throw new Error('released'); } });
  rec(G, 'meshMaxWindAmplitude：从导入网格的 a_color（uint16 归一化原始值）读出每个模板的 max(COLOR_0.a)，与 GLB 统计一致；没有顶点色 / 数据不可读时返回 1（保守）', ampBad.length === 0 && noColor === 1 && broken === 1, ampBad.join('; ') || stats.map(s => `${s.mesh.replace('grass_clump_', '')}=${s.a.max.toFixed(3)}`).join(' '));

  // E3 切档 / 改强度 → 包围盒重算；根色重设
  const T0 = grassR[0];
  const pad = (x) => x.r.mesh.struct.minPosition.x - x.r.model.local.min[0];
  const p2 = pad(T0);
  const colorsOk = () => grassR.every(x => { const v = x.r.model.inst.a_root_color; const e = rootOf(x.g, x.i); return v && v.every((y, k) => Math.abs(y - e[k]) < 1e-12); });
  const initialColors = colorsOk();
  const changed = gwq.applyGrassWindQuality(grassR.map(x => x.r), 1);
  const sameMat = grassR.every(x => x.r.sharedMaterials[0] === grassR[0].r.sharedMaterials[0]) && grassR[0].r.sharedMaterials[0] !== base;
  const p1 = pad(T0); const colorsAfter1 = colorsOk();
  const exp1 = gwq.grassWindBoundsPad({ ...gwq.readGrassWindParams(T0.r.sharedMaterials[0]) }, gwq.meshMaxWindAmplitude(T0.r.mesh), Math.min(...T0.n.scl.map(Math.abs)));
  gwq.applyGrassWindQuality(grassR.map(x => x.r), 0);
  const p0 = pad(T0); const colorsAfter0 = colorsOk();
  gwq.applyGrassWindQuality(grassR.map(x => x.r), 2);
  gwq.setGrassWindParams(base, { windStrength: 2 });
  const pS = pad(T0); const variantStrength = gwq.readGrassWindParams(T0.r.sharedMaterials[0]).windStrength;
  gwq.setGrassWindParams(base, { windStrength: 1 });
  rec(G, `切档后包围盒按档重算：高 ${p2.toFixed(3)} m → 低 ${p1.toFixed(3)} m（= 解析值 ${exp1.toFixed(3)}，该实例最小缩放 ${Math.min(...T0.n.scl).toFixed(3)}）→ 关 ${p0} m（还原网格原包围盒）；setGrassWindParams(windStrength 1→2) 后 pad 翻倍 ${pS.toFixed(3)} m，且已同步到当前档的运行时材质`,
    p2 > p1 && Math.abs(p1 - exp1) < 1e-9 && p0 === 0 && Math.abs(pS - 2 * p2) < 1e-9 && variantStrength === 2 && changed === grassR.length && sameMat, `changed=${changed} sameMaterial=${sameMat} variantStrength=${variantStrength}`);
  rec(G, `a_root_color：生成时设好，切到低 / 关 / 高三次换材质（桩模拟引擎清空实例属性）后，${grassR.length} 个草实例的根色都被 MeadowInstancer 重设为 JSON 里的值`, initialColors && colorsAfter1 && colorsAfter0 && colorsOk(), `initial=${initialColors} afterLow=${colorsAfter1} afterOff=${colorsAfter0} afterHigh=${colorsOk()}`);
  // 反向对照：去掉监听后切档，根色丢失
  gwq.grassWindEvents.targetOff(comp);
  gwq.applyGrassWindQuality(grassR.map(x => x.r), 1);
  const lost = grassR.filter(x => !x.r.model.inst.a_root_color).length;
  rec(G, '反向对照：MeadowInstancer 不监听时切档，根色全部丢失（实例属性被清零）——证明上一项靠的是 v1.1 的重设逻辑', lost === grassR.length, `lost=${lost}/${grassR.length}`);
  gwq.grassWindEvents.on(gwq.GRASS_WIND_QUALITY_EVENT, comp.onWindChanged, comp);

  // E4 防错
  let threw = null; let ret;
  try {
    const nInactive = new Node('inactive'); nInactive.active = false; const rI = nInactive.addComponent(MeshRenderer); rI.mesh = meshes[grassGroups[0].template]; rI.sharedMaterials = [base];
    ret = gwq.applyGrassWindBounds(rI);
    grassR[1].r.isValid = false; grassR[1].r.setInstancedAttribute = () => { throw new Error('should be skipped'); };
    grassR[2].r.setInstancedAttribute = () => { throw new Error('boom'); };
    const warn = console.warn; console.warn = () => {}; try { comp.onWindChanged(); } finally { console.warn = warn; }
  } catch (e) { threw = e; }
  rec(G, '防错：节点未激活（model 未创建）时返回 -1 不抛错；已销毁的 renderer 跳过；单个 setInstancedAttribute 抛错不影响其余实例和包围盒', threw === null && ret === -1 && grassR[3].r.model.inst.a_root_color !== undefined, `threw=${threw && threw.message} ret=${ret}`);
  comp.onDestroy(); const left = gwq.grassWindEvents.h.filter(x => x.tg === comp).length;
  rec(G, 'onDestroy 注销全局事件监听（不泄漏）', left === 0, `listeners left=${left}`);
};
