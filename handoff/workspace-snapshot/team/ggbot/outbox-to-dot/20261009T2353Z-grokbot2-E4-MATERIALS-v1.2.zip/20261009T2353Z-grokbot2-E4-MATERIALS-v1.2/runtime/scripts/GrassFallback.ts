/**
 * GrassFallback.ts · E4 v1.2（grokbot2 / GGbot）· Cocos Creator 3.8.8 · 未在 Creator / 真机里运行过（not_run）
 *
 * 没有硬件实例化（WebGL1 且没有 ANGLE_instanced_arrays）时的草甸兜底。美术定的策略：
 *  1. 减量，不关：保留约 30% 草丛，优先保留靠近小路（walk_path）边缘和镜头默认 / 区域视点的；
 *  2. 根色没法逐丛传，统一用调色板草绿渐变行的中间色 #60AE32；
 *  3. 减量后帧时间仍然超预算（可测的触发条件见 FrameBudgetMonitor），才整片关草，换美术之后提供的“烘焙草色地面贴图”。
 * 引擎依据：pass.ts _syncBatchingScheme —— USE_INSTANCING 但 device 没有 Feature.INSTANCED_ARRAYS 时，引擎把 USE_INSTANCING 关掉，
 * 每丛一次 draw call，a_root_color 不存在，shader 用 rootColor 统一根色；webgl-device.ts 只在有 ANGLE_instanced_arrays 时置该 feature，
 * webgl2-device.ts 恒为 true。
 * 本文件全是纯函数 / 纯类（除 supportsInstancing），方便在 Node 里测。
 */
import { director, gfx } from 'cc';

export const FALLBACK_KEEP_RATIO = 0.3;
/** 调色板 meadow_palette_256 草绿渐变行（第 0–15 行，草模板 UV 都在 v≈8/256）中间 x = 128 的颜色，sRGB。 */
export const PALETTE_MID_GREEN_HEX = '#60AE32';
export const PALETTE_MID_GREEN_SRGB: readonly [number, number, number] = [0x60 / 255, 0xae / 255, 0x32 / 255];
/** 与 effect 的 SRGBToLinear（x²）一致的线性值，用于填补缺失的 _ROOT_COLOR。 */
export const PALETTE_MID_GREEN_LINEAR: readonly [number, number, number] = [
  PALETTE_MID_GREEN_SRGB[0] * PALETTE_MID_GREEN_SRGB[0], PALETTE_MID_GREEN_SRGB[1] * PALETTE_MID_GREEN_SRGB[1], PALETTE_MID_GREEN_SRGB[2] * PALETTE_MID_GREEN_SRGB[2]];

/** 当前设备是否支持硬件实例化。拿不到 device（编辑器预览早期等）时返回 true（不降级）。 */
export function supportsInstancing (): boolean {
  try {
    const dev = director.root && director.root.device;
    if (!dev) return true;
    return dev.hasFeature(gfx.Feature.INSTANCED_ARRAYS);
  } catch (e) { return true; }
}

// ---------------------------------------------------------------- _ROOT_COLOR 校验

export interface RootColorCheck { colors: number[]; missing: number; invalid: number; }

/**
 * 校验并补全一组实例的 _ROOT_COLOR（线性 RGB，每实例 3 个数）。缺失 / 长度不够 / 非有限数 / 超出 [0, 4] 的实例填 PALETTE_MID_GREEN_LINEAR。
 * 开 USE_INSTANCE_ROOT_COLOR 时，没设的实例属性是 0 → 黑根，所以生成实例前必须过一遍。
 */
export function validateRootColors (raw: ArrayLike<number> | null | undefined, count: number): RootColorCheck {
  const colors = new Array<number>(count * 3);
  let missing = 0, invalid = 0;
  for (let i = 0; i < count; i++) {
    let ok = !!raw && raw.length >= (i + 1) * 3;
    if (!ok) missing++;
    else {
      for (let k = 0; k < 3; k++) { const v = raw![i * 3 + k]; if (typeof v !== 'number' || !isFinite(v) || v < 0 || v > 4) ok = false; }
      if (!ok) invalid++;
    }
    for (let k = 0; k < 3; k++) colors[i * 3 + k] = ok ? raw![i * 3 + k] : PALETTE_MID_GREEN_LINEAR[k];
  }
  return { colors, missing, invalid };
}

// ---------------------------------------------------------------- 30% 选择

export interface XZ { x: number; z: number; }
export interface FallbackSelectOptions {
  keepRatio?: number;            // 默认 0.3
  path?: readonly XZ[];          // 小路折线（walk_path_00…22，按顺序）
  pathHalfWidth?: number;        // 小路半宽，默认 1.0 m；离路中心线 ≤ 半宽的算“路面上”，优先级按路边缘距离算
  views?: readonly XZ[];         // 镜头默认 / 区域视点（看向的位置）
  viewWeight?: number;           // 视点距离的折算系数，默认 1（=同等重要）
  mask?: (x: number, z: number) => number;   // 预留：路径遮罩 / 美术画的优先级图，返回 ≥ 0 的权重，越大越优先（默认 1）
}
export interface FallbackSelection { keep: boolean[]; kept: number; rule: 'path+views' | 'stride'; priority: number[]; }

function distToSegment (p: XZ, a: XZ, b: XZ): number {
  const dx = b.x - a.x, dz = b.z - a.z; const l2 = dx * dx + dz * dz;
  let t = l2 > 0 ? ((p.x - a.x) * dx + (p.z - a.z) * dz) / l2 : 0; t = Math.max(0, Math.min(1, t));
  const x = a.x + t * dx - p.x, z = a.z + t * dz - p.z; return Math.sqrt(x * x + z * z);
}

/**
 * 确定性选择：优先级距离 = min(离小路边缘的距离, 离最近视点的距离 × viewWeight) / mask 权重；从小到大取 round(N × keepRatio) 个，
 * 相同优先级按输入顺序。没有小路也没有视点时退回“均匀抽稀”（Bresenham 式按序号均匀保留）。同样输入永远同样输出。
 */
export function selectFallbackClumps (clumps: readonly XZ[], opts: FallbackSelectOptions = {}): FallbackSelection {
  const n = clumps.length;
  const ratio = Math.max(0, Math.min(1, opts.keepRatio ?? FALLBACK_KEEP_RATIO));
  const target = Math.round(n * ratio);
  const keep = new Array<boolean>(n).fill(false);
  const path = opts.path || [], views = opts.views || [];
  const priority = new Array<number>(n).fill(0);
  if (path.length === 0 && views.length === 0) {
    let kept = 0;
    for (let i = 0; i < n; i++) if (Math.floor((i + 1) * ratio) > Math.floor(i * ratio)) { keep[i] = true; kept++; }
    return { keep, kept, rule: 'stride', priority };
  }
  const hw = opts.pathHalfWidth ?? 1.0, vw = opts.viewWeight ?? 1.0;
  for (let i = 0; i < n; i++) {
    const p = clumps[i];
    let dPath = Infinity;
    if (path.length === 1) dPath = Math.hypot(p.x - path[0].x, p.z - path[0].z);
    for (let k = 0; k + 1 < path.length; k++) dPath = Math.min(dPath, distToSegment(p, path[k], path[k + 1]));
    const edge = Math.abs(dPath - hw);                     // 离路边缘（两侧都算）
    let dView = Infinity; for (const v of views) dView = Math.min(dView, Math.hypot(p.x - v.x, p.z - v.z));
    let d = Math.min(edge, dView * vw);
    if (opts.mask) { const w = opts.mask(p.x, p.z); d = d / Math.max(isFinite(w) ? w : 1, 1e-3); }
    priority[i] = d;
  }
  const order = Array.from({ length: n }, (_, i) => i).sort((a, b) => (priority[a] - priority[b]) || (a - b));
  for (let k = 0; k < target; k++) keep[order[k]] = true;
  return { keep, kept: target, rule: 'path+views', priority };
}

// ---------------------------------------------------------------- 关草触发条件

export interface FrameBudgetOptions {
  budgetMs?: number;     // 每帧预算，默认 40 ms（≈ 25 fps）
  windowSec?: number;    // 连续观察窗口，默认 5 s
  overRatio?: number;    // 窗口内超预算帧占比阈值，默认 0.8
  warmupSec?: number;    // 进场后不计的时间（shader 编译、加载卡顿），默认 3 s
  maxDtSec?: number;     // 单帧 dt 超过它视为切后台 / 断点，不计并清空窗口，默认 0.5 s
}

/**
 * “减量后帧率仍然撑不住”的可测触发条件：进场 warmupSec 后，连续 windowSec 秒的帧里，dt > budgetMs 的帧占比 ≥ overRatio。
 * 只触发一次（push 返回 true 的那一帧）。不做任何性能判断以外的事；关草由调用方（MeadowInstancer.setGrassOff）执行。
 */
export class FrameBudgetMonitor {
  readonly budgetMs: number; readonly windowSec: number; readonly overRatio: number; readonly warmupSec: number; readonly maxDtSec: number;
  private elapsed = 0; private win: { dt: number; over: boolean }[] = []; private winTime = 0; private overCount = 0;
  triggered = false;
  constructor (o: FrameBudgetOptions = {}) {
    this.budgetMs = o.budgetMs ?? 40; this.windowSec = o.windowSec ?? 5; this.overRatio = o.overRatio ?? 0.8;
    this.warmupSec = o.warmupSec ?? 3; this.maxDtSec = o.maxDtSec ?? 0.5;
  }
  reset (): void { this.win = []; this.winTime = 0; this.overCount = 0; }
  /** 每帧调用，dt 单位秒。返回 true = 本帧达到关草条件（只返回一次）。 */
  push (dt: number): boolean {
    if (this.triggered || !(dt > 0)) return false;
    if (dt > this.maxDtSec) { this.reset(); return false; }
    this.elapsed += dt;
    if (this.elapsed <= this.warmupSec) return false;
    const over = dt * 1000 > this.budgetMs;
    this.win.push({ dt, over }); this.winTime += dt; if (over) this.overCount++;
    while (this.win.length > 1 && this.winTime - this.win[0].dt >= this.windowSec) {
      const f = this.win.shift()!; this.winTime -= f.dt; if (f.over) this.overCount--;
    }
    if (this.winTime >= this.windowSec - 1e-9 && this.overCount / this.win.length >= this.overRatio) { this.triggered = true; return true; }
    return false;
  }
}
