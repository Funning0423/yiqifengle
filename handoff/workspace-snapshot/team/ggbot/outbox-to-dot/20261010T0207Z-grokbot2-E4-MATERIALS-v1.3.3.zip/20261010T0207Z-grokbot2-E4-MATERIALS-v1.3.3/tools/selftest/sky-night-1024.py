#!/usr/bin/env python3
"""E4 v1.3.3：不支持 ASTC 的设备用的 1024×512 夜空图（从美术 v0.1a 2048×1024 PNG 生成）+ 核对 + 对比图。只用 numpy / Pillow。
  make   <src2048.png> <out1024.png>                      生成（确定性：固定随机种子）
  check  <src2048.png> <shipped1024.png> <horizonV> [out.json]  重新生成并逐字节对比、量色带 / 抖动 / 星星 / 地平线 / 接缝，含对照
  review <src2048.png> <shipped1024.png> <outdir>         生成对比图（暗区一块、星星一块、地平线一块；原样 + 拉对比度）
  gradient <src2048.png>                                  量夜景图加载前用的两色渐变（天顶第 0 行、地平线第 878 行，线性光平均）
生成步骤：
 1) sRGB → 线性光，2×2 盒式平均（线性光里平均，亮星不会被 sRGB 平均压暗太多，渐变的亮度也不偏）→ 回 sRGB（浮点）；
 2) 量化前加轻抖动：均匀分布 ±0.5 级（RPDF，固定种子）。平均把原图 ±1 级的抖动磨平了，不加会出现整块单色 = 色带；
    RPDF 只会落到相邻两个整数级上，地平线以下的平坦区仍然在 ±1 级以内；
 3) 保星：在 2048 原图上找孤立亮点（3×3 局部最大，且比半径 4 的方环中位数亮 > 12 级），所在 2×2 块输出 = 块内逐通道最大值（max-aware），
    星星峰值不被平均掉。原图地平线以下没有星星（最低一颗在第 761 行）。"""
import sys, json, hashlib, os
import numpy as np
from PIL import Image
SRC_SHA = '1fd02ba7284fe9dec25e2a2ea3deb5e8a10ebf9c014ef058c793b8883f39acd0'
SEED = 20261009; STAR_T = 12.0
S2L = lambda c: np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
L2S = lambda c: np.where(c <= 0.0031308, c * 12.92, 1.055 * np.power(np.clip(c, 0, None), 1 / 2.4) - 0.055)
lum = lambda a: a[..., 0] * 0.2126 + a[..., 1] * 0.7152 + a[..., 2] * 0.0722
def load(p): return np.asarray(Image.open(p).convert('RGB')).astype(np.float64)
def sh(a, dy, dx): return np.roll(np.roll(a, dy, 0), dx, 1)
def stars(L, r, T=STAR_T):
    """孤立亮点：3×3 局部最大（u 环绕），且比半径 r 的方环中位数亮 > T 级。返回 行、列、突出量、亮度。"""
    ring = [sh(L, dy, dx) for dy in range(-r, r + 1) for dx in range(-r, r + 1) if max(abs(dy), abs(dx)) == r]
    p = L - np.median(np.stack(ring), 0)
    lm = np.ones(L.shape, bool)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dy or dx: lm &= L >= sh(L, dy, dx)
    m = lm & (p > T); m[:1] = False; m[-1:] = False
    ys, xs = np.nonzero(m); return ys, xs, p[ys, xs], L[ys, xs]
def down(a, linear=True, dither=True, starpass=True):
    H, W = a.shape[0] // 2, a.shape[1] // 2
    x = S2L(a / 255) if linear else a / 255
    x = x.reshape(H, 2, W, 2, 3).mean((1, 3))
    s = (L2S(x) if linear else x) * 255
    if dither: s = s + np.random.default_rng(SEED).uniform(-0.5, 0.5, s.shape)
    o = np.clip(np.floor(s + 0.5), 0, 255)
    if starpass:
        ys, xs, _, _ = stars(lum(a), 4)
        blk = a.reshape(H, 2, W, 2, 3).max((1, 3)); o[ys // 2, xs // 2] = blk[ys // 2, xs // 2]
    return o.astype(np.uint8)
def band(A, o, dark=None):
    """和 v1.3.2 同一判法，按同一块面积比较：1024 的 8×8 块 ↔ 2048 的 16×16 块，天空渐变区（2048 第 0–863 行 = 1024 第 0–431 行）。
    平滑块 = 原图块内亮度极差 ≤ 2 级（排除星星）；dark = 只看块均值亮度 < dark 的块（暗区，自测用 35 级）。"""
    B = lum(A[:864]).reshape(54, 16, A.shape[1] // 16, 16).transpose(0, 2, 1, 3).reshape(54, -1, 256)
    D = lum(o[:432].astype(float)).reshape(54, 8, o.shape[1] // 8, 8).transpose(0, 2, 1, 3).reshape(54, -1, 64)
    sm = (B.max(2) - B.min(2)) <= 2.0
    if dark is not None: sm &= B.mean(2) < dark
    uni = lambda b: float(((b[sm].max(1) - b[sm].min(1)) < 0.5).mean())
    e = np.abs(D[sm].mean(1) - B[sm].mean(1)); so = B[sm].std(1).mean(); sd = D[sm].std(1).mean()
    r = {'smooth_blocks': int(sm.sum()), 'uniform_block_fraction_orig': uni(B), 'uniform_block_fraction': uni(D), 'block_mean_err_max': float(e.max()),
         'block_mean_err_rms': float(np.sqrt((e ** 2).mean())), 'dither_retention': float(sd / so)}
    r['pass'] = r['uniform_block_fraction'] <= r['uniform_block_fraction_orig'] + 0.05 and r['block_mean_err_max'] <= 0.75 and r['dither_retention'] >= 0.85
    return r
def star_keep(A, o):
    """2048 的每颗星，在 1024 对应位置 ±1 纹素内有没有星（同一判法，方环半径按比例取 2）；匹配上的比峰值亮度和突出量。"""
    y2, x2, p2, l2 = stars(lum(A), 4); y1, x1, p1, l1 = stars(lum(o.astype(float)), 2)
    M = np.full(o.shape[:2], -1); M[y1, x1] = np.arange(len(y1)); got = []; pk = []; pr = []
    for y, x, p, l in zip(y2, x2, p2, l2):
        best = -1
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                yy, xx = y // 2 + dy, (x // 2 + dx) % o.shape[1]
                if 0 <= yy < o.shape[0] and M[yy, xx] >= 0 and (best < 0 or l1[M[yy, xx]] > l1[best]): best = M[yy, xx]
        got.append(best >= 0)
        if best >= 0: pk.append(l1[best] / l); pr.append(p1[best] / p)
    r = {'stars_2048': len(y2), 'stars_1024': len(y1), 'matched': int(sum(got)), 'count_retention': float(np.mean(got)),
         'peak_ratio_median': float(np.median(pk)) if pk else 0.0, 'peak_ratio_p10': float(np.percentile(pk, 10)) if pk else 0.0,
         'prominence_ratio_median': float(np.median(pr)) if pr else 0.0, 'lowest_star_row_2048': int(y2.max()) if len(y2) else None}
    r['pass'] = r['count_retention'] >= 0.95 and r['peak_ratio_median'] >= 0.95 and r['peak_ratio_p10'] >= 0.9
    return r
def seam(x, k):
    """u 环绕接缝：第 0 列和最后一列的平均差，和图内每一对相邻列的平均差比（均值 / 99 分位 / 接缝排第几）。"""
    d = np.abs(np.diff(np.concatenate([x, x[:, :1]], 1), axis=1)).mean(tuple(i for i in range(x.ndim) if i != 1)); inner = d[:-1]
    return {k: float(d[-1]), k + '_inner': float(inner.mean()), k + '_inner_p99': float(np.percentile(inner, 99)), k + '_rank': float((inner < d[-1]).mean())}
def horizon(A, o, hv):
    H = o.shape[0]; first = next(r for r in range(H) if (r + 0.5) / H > hv)
    L = lum(o.astype(float)); below = o[first:].astype(float)
    rowdev = float(np.abs(L[first:].mean(1) - L[first].mean()).max()); med = np.median(below, 0); pix = float(np.abs(below - med[None]).max())
    a878 = A[878:].reshape(-1, 3).mean(0); o_b = below.reshape(-1, 3).mean(0)
    r = {'horizonV_xH': hv * H, 'first_texel_row_below_horizonV': first, 'rows_below_rowmean_dev_max': rowdev, 'rows_below_pixel_dev_from_col_median_max': pix,
         'colour_below_1024': [round(float(v), 2) for v in o_b], 'colour_below_2048_rows_878_1023': [round(float(v), 2) for v in a878],
         'colour_below_diff_max': float(np.abs(o_b - a878).max()), 'row_prev_vs_first_lum': float(abs(L[first - 1].mean() - L[first].mean())),
         **seam(o.astype(float), 'seam_all'), **seam(below, 'seam_below')}
    r['pass'] = (first == 439 and rowdev <= 1 and pix <= 1 and r['colour_below_diff_max'] <= 1 and r['row_prev_vs_first_lum'] <= 1.0
                 and r['seam_all'] <= r['seam_all_inner_p99'] and r['seam_below'] <= r['seam_below_inner_p99'])
    return r
def mem(p):
    w, h = Image.open(p).size; px = w * h; mip = lambda b: int(round(b * 4 / 3))
    return {'png_file_bytes': os.path.getsize(p), 'rgba8_bytes': px * 4, 'rgba8_with_mips_bytes': mip(px * 4), 'rgb8_bytes': px * 3, 'rgb8_with_mips_bytes': mip(px * 3)}
def review(A, o, outdir):
    from PIL import ImageDraw
    os.makedirs(outdir, exist_ok=True); ctl = down(A, dither=False, starpass=False)
    L = lum(A); y2, x2, _, _ = stars(L, 4)
    # 暗区：256×128 窗口里最亮像素最暗的（没有星星 / 月亮 / 云边）；星区：星星最多的（都按 2048 坐标，16 对齐）
    cand = [(y, x) for y in range(0, 600, 32) for x in range(0, 2048 - 256 + 1, 64)]
    cnt = lambda y, x: int(((y2 >= y) & (y2 < y + 128) & (x2 >= x) & (x2 < x + 256)).sum())
    dark = min(cand, key=lambda c: (L[c[0]:c[0] + 128, c[1]:c[1] + 256].max(), L[c[0]:c[0] + 128, c[1]:c[1] + 256].mean()))   # 窗口里最亮的点也最暗 = 没有星星 / 月亮 / 云边
    star = max(cand, key=lambda c: cnt(*c)); hor = (878 - 64, 896)
    out = {}
    for name, (y, x) in [('dark', dark), ('stars', star), ('horizon', hor)]:
        crops = [('2048 original', A[y:y + 128, x:x + 256]), ('1024 shipped (x2 nearest)', o[y // 2:y // 2 + 64, x // 2:x // 2 + 128].repeat(2, 0).repeat(2, 1)),
                 ('control: 1024 box, no dither/star (x2)', ctl[y // 2:y // 2 + 64, x // 2:x // 2 + 128].repeat(2, 0).repeat(2, 1))]
        ref = A[y:y + 128, x:x + 256]
        for boost in (False, True):
            if boost and name == 'stars':
                lo, hi = np.percentile(lum(ref), 2), np.percentile(lum(ref), 60)   # 背景拉开，星星饱和
            elif boost:
                lo, hi = np.percentile(lum(ref), 0.5) - 1, np.percentile(lum(ref), 99.5) + 1
            S = 3; pw, ph = 256 * S, 128 * S
            img = Image.new('RGB', (pw * 3 + 40, ph + 46), (40, 40, 40)); d = ImageDraw.Draw(img)
            for i, (lab, c) in enumerate(crops):
                c = c.astype(float)
                if boost: c = np.clip((c - lo) / max(hi - lo, 1e-6) * 255, 0, 255)
                img.paste(Image.fromarray(c.astype(np.uint8)).resize((pw, ph), Image.NEAREST), (10 + i * (pw + 10), 36))
                d.text((10 + i * (pw + 10), 6), lab, fill=(255, 255, 255))
            tag = f'{name} region, 2048 rows {y}-{y + 127} cols {x}-{x + 255}' + (f', contrast x{255 / max(hi - lo, 1e-6):.0f} (lum {lo:.0f}-{hi:.0f} -> 0-255)' if boost else ', as-is') + ', all panels x3 nearest'
            d.text((10, 20), tag, fill=(255, 220, 120))
            fn = os.path.join(outdir, f'night1024-{name}-compare{"-contrast" if boost else ""}.png'); img.save(fn, optimize=True); out[os.path.basename(fn)] = {'rows': [y, y + 127], 'cols': [x, x + 255], 'stars_in_crop': cnt(y, x)}
    return out
if __name__ == '__main__':
    cmd, a = sys.argv[1], sys.argv[2:]
    A = load(a[0]); src_sha = hashlib.sha256(open(a[0], 'rb').read()).hexdigest()
    if cmd == 'make':
        Image.fromarray(down(A)).save(a[1], optimize=True); print(a[1], hashlib.sha256(open(a[1], 'rb').read()).hexdigest())
    elif cmd == 'check':
        o_ship = load(a[1]).astype(np.uint8); hv = float(a[2]); o = down(A); im = Image.open(a[1])
        R = {'source_sha256': src_sha, 'source_sha_ok': src_sha == SRC_SHA, 'shipped_sha256': hashlib.sha256(open(a[1], 'rb').read()).hexdigest(),
             'shipped_size': im.size, 'shipped_mode': im.mode, 'regenerated_equal': bool(np.array_equal(o, o_ship)), 'regenerated_max_diff': int(np.abs(o.astype(int) - o_ship).max()),
             'band_all': band(A, o_ship), 'band_dark': band(A, o_ship, dark=35), 'stars': star_keep(A, o_ship), 'horizon': horizon(A, o_ship, hv), 'memory': mem(a[1])}
        R['controls'] = {}
        for k, kw in [('box_linear_no_dither_no_star', dict(dither=False, starpass=False)), ('box_srgb_no_dither_no_star', dict(linear=False, dither=False, starpass=False)), ('dither_no_star', dict(starpass=False))]:
            c = down(A, **kw); R['controls'][k] = {'band_all': band(A, c), 'band_dark': band(A, c, dark=35), 'stars': star_keep(A, c)}
        s = json.dumps(R, indent=1); print(s)
        if len(a) > 3: open(a[3], 'w').write(s + '\n')
    elif cmd == 'gradient':
        # 夜景图加载前的两色渐变（v1.3.3 final）：天顶 = 第 0 行、地平线 = 第 878 行（2048 图，= 地平线以下平坦色的起始行），
        # 各行 2048 个像素先转线性光求平均、再转回 sRGB（0–255，保留小数）；同时给出直接对 sRGB 值求平均的结果作对照。
        def row(rs):
            px = A[rs].reshape(-1, 3); lin = L2S(S2L(px / 255).mean(0)) * 255
            return {'rows': [rs.start, rs.stop - 1], 'linear_mean_srgb': [round(float(v), 4) for v in lin], 'srgb_mean': [round(float(v), 4) for v in px.mean(0)],
                    'min': [int(v) for v in px.min(0)], 'max': [int(v) for v in px.max(0)], 'hex_rounded': '#' + ''.join(f'{int(round(v)):02X}' for v in lin)}
        print(json.dumps({'source_sha256': src_sha, 'source_sha_ok': src_sha == SRC_SHA, 'zenith_row0': row(slice(0, 1)), 'horizon_row878': row(slice(878, 879)), 'below_rows878_1023': row(slice(878, 1024))}, indent=1))
    elif cmd == 'review':
        print(json.dumps(review(A, load(a[1]).astype(np.uint8), a[2]), indent=1))
