'use strict';
// E4 v1.3.3 Node 测试：
//  m-night-select   夜空图按 ASTC 支持选择（SkyNightTexture.ts）：检测 yes / no / unknown、选择、加载 / 释放生命周期（复用 BakedGroundSwap）、
//                   和引擎 ImageAsset 挑 .astc 的判法一致；对照：v1.3.2 包（材质直接引用 2048 夜空）在不支持 ASTC 的设备上拿到的是 2048 图。
//  n-night-1024     1024×512 夜空图核对（sky-night-1024.py check）：重新生成逐字节一致、地平线第 439 行、以下平坦、接缝、色带 / 抖动、星星保留、对照、显存；对比图。
const fs = require('fs'), ps = require('path'), cp = require('child_process');
const makeCC = require('./cc-stub');
const ASTC_RGBA_4X4 = 89, SAMPLED_TEXTURE = 2;   // cc.d.ts：gfx.Format.ASTC_RGBA_4X4 = 89，gfx.FormatFeatureBit.SAMPLED_TEXTURE = 2（M9 核对）

module.exports = async function run (ctx) {
  const { ts, rec, HERE } = ctx; const ENGINE = ctx.ENGINE || '/opt/cocos/CocosCreator-3.8.8-win/resources/resources/3d/engine';
  const PKG = ps.join(HERE, '../..'), NEW = ps.join(PKG, 'runtime/scripts');
  const V132 = process.env.E4_V132_PKG || ps.join(HERE, 'controls/v1.3.2-package');
  const M = 'm-night-select', MC = 'm-night-control', N = 'n-night-1024';
  class FakeTex { constructor (n) { this.name = n; this.refCount = 0; } addRef () { this.refCount++; return this; } decRef () { this.refCount--; if (this.refCount < 0) throw Error('decRef < 0 ' + this.name); return this; } }
  // 最小 'cc'：SkyNightTexture + BakedGroundTexture 用到的部分
  const makeEnv = (rootDevice, am) => {
    const warns = [];
    const prop = (a, b) => (typeof b === 'string' ? undefined : () => {});
    class Component { constructor () { this.node = null; } }
    class MaterialInstance { constructor () { this.props = {}; } getProperty (k) { return this.props[k] === undefined ? null : this.props[k]; } setProperty (k, v) { this.props[k] = v; } }
    class MeshRenderer { constructor () { this.isValid = true; this.mi = new MaterialInstance(); this.miCalls = 0; } getMaterialInstance (i) { this.miCalls++; return i === 0 ? this.mi : null; } }
    const cc = { _decorator: { ccclass: () => (c) => c, property: prop }, Component, MeshRenderer, Texture2D: class Texture2D {}, assetManager: am, CCFloat: Number, Vec4: class Vec4 { constructor (x = 0, y = 0, z = 0, w = 0) { Object.assign(this, { x, y, z, w }); } },
      director: rootDevice === '__noroot__' ? {} : { root: { device: rootDevice } }, gfx: { Format: { ASTC_RGBA_4X4 }, FormatFeatureBit: { SAMPLED_TEXTURE } } };
    const S = makeCC.loadScripts(ts, NEW, cc, ['BakedGroundTexture', 'SkyNightTexture']);
    return { cc, S, warns };
  };
  const dev = (feat) => ({ getFormatFeatures: (f) => (f === ASTC_RGBA_4X4 ? feat : 0xff) });
  const withWarn = (fn) => { const ws = []; const o = console.warn; console.warn = (...a) => ws.push(a.map(String).join(' ')); try { return [fn(), ws]; } finally { console.warn = o; } };
  // 组件：注入可控加载器，返回请求表
  const mount = (env, device) => {
    const { S, cc } = env; const C = new S.SkyNightTexture.SkyNightTexture(); const r = new cc.MeshRenderer(); C.skyRenderer = r;
    Object.assign(C, { materialIndex: 0, textureProperty: 'nightTexture', bundleName: 'region_meadow', astcPath: S.SkyNightTexture.SKY_NIGHT_ASTC_PATH, noAstcPath: S.SkyNightTexture.SKY_NIGHT_NOASTC_PATH });
    const reqs = []; C.loader = (b, p, done) => reqs.push({ b, p, done }); if (device !== undefined) C.device = device;
    return { C, r, reqs };
  };
  const P2048 = 'textures/tex_meadow_sky_night_2048x1024/texture', P1024 = 'textures/tex_meadow_sky_night_1024x512/texture';
  let env;
  try { env = makeEnv(dev(SAMPLED_TEXTURE | 1)); } catch (e) { rec(M, 'SkyNightTexture.ts 载入', false, String(e && e.stack)); return; }
  const { S } = env; const SN = S.SkyNightTexture;

  // M1 检测
  {
    const cases = [['ASTC 可采样', dev(SAMPLED_TEXTURE | 1), 'yes'], ['ASTC 不可采样（features 只有别的位）', dev(1 | 4), 'no'], ['features = 0', dev(0), 'no'],
      ['设备 null', null, 'unknown'], ['没有 getFormatFeatures', {}, 'unknown'], ['getFormatFeatures 抛异常', { getFormatFeatures: () => { throw Error('lost context'); } }, 'unknown'],
      ['返回值不是数字', { getFormatFeatures: () => undefined }, 'unknown']];
    const got = cases.map(([n, d, want]) => [n, SN.detectAstcSupport(d).support, want]);
    // 不注入 → 用 director.root.device
    const eY = makeEnv(dev(SAMPLED_TEXTURE)).S.SkyNightTexture.detectAstcSupport(), eN = makeEnv(dev(0)).S.SkyNightTexture.detectAstcSupport(), eU = makeEnv('__noroot__').S.SkyNightTexture.detectAstcSupport();
    const ok = got.every(g => g[1] === g[2]) && eY.support === 'yes' && eN.support === 'no' && eU.support === 'unknown';
    rec(M, 'M1 ASTC 检测：getFormatFeatures(ASTC_RGBA_4X4) 含 SAMPLED_TEXTURE → yes，不含 → no；没有设备 / 没有方法 / 抛异常 / 返回值不对 → unknown；默认读 director.root.device', ok, JSON.stringify(got) + ` 默认设备 yes/no/无 root → ${eY.support}/${eN.support}/${eU.support}`);
  }
  // M2 选择
  {
    const y = SN.selectNightSkyPath('yes'), n = SN.selectNightSkyPath('no'), u = SN.selectNightSkyPath('unknown');
    rec(M, 'M2 选择：yes → 2048 ASTC 资源；no → 1024×512 未压缩资源；unknown → 也是 1024（按不支持处理）', y.path === P2048 && y.variant === 'astc2048' && n.path === P1024 && n.variant === 'raw1024' && u.path === P1024 && u.variant === 'raw1024', JSON.stringify({ y, n, u }));
  }
  // M3–M5 组件生命周期（yes / no / unknown）
  const life = (label, device, wantPath, wantWarn) => {
    const e = makeEnv(null); const { C, r, reqs } = mount(e, device); const orig = r.mi.getProperty('nightTexture');
    const [, ws] = withWarn(() => C.onLoad());
    const before = r.mi.getProperty('nightTexture'); const t = new FakeTex(wantPath);
    const one = reqs.length === 1 && reqs[0].p === wantPath && reqs[0].b === 'region_meadow';
    if (reqs[0]) reqs[0].done(null, t);
    const applied = r.mi.getProperty('nightTexture') === t && t.refCount === 1 && C.state.state === 'applied';
    C.onDestroy(); const released = r.mi.getProperty('nightTexture') === orig && t.refCount === 0 && C.state === null;
    const warnOk = wantWarn ? ws.length === 1 && /按不支持处理/.test(ws[0]) : ws.length === 0;
    rec(M, `${label}：只发 1 次加载（${wantPath.split('/')[1]}）；加载完成前 nightTexture 保持原值；完成后贴上、引用 1；onDestroy 换回原值、decRef 到 0${wantWarn ? '；warn 一次“按不支持处理”' : '；不 warn'}`,
      one && before === orig && applied && released && warnOk, `reqs=${JSON.stringify(reqs.map(q => q.p))} before=${before} applied=${applied} released=${released} ref=${t.refCount} warns=${JSON.stringify(ws)} variant=${C.selected && C.selected.variant} via=${C.detection && C.detection.via}`);
  };
  life('M3 支持 ASTC', dev(SAMPLED_TEXTURE), P2048, false);
  life('M4 不支持 ASTC', dev(0), P1024, false);
  life('M5 检测失败（getFormatFeatures 抛异常）', { getFormatFeatures: () => { throw Error('x'); } }, P1024, true);
  // M6 加载中卸载 / 失败 / 没有 renderer
  {
    const e = makeEnv(null); const a = mount(e, dev(0)); a.C.onLoad(); a.C.onDestroy(); const t = new FakeTex('late'); a.reqs[0].done(null, t);
    const lateOk = a.r.mi.getProperty('nightTexture') === null && t.refCount === 0;
    const b = mount(e, dev(0)); b.C.onLoad(); const [, ws] = withWarn(() => b.reqs[0].done(Error('404'), null));
    const failOk = b.r.mi.getProperty('nightTexture') === null && b.C.state.state === 'failed' && ws.length === 1 && /夜空贴图加载失败/.test(ws[0]); b.C.onDestroy();
    const c = new SN.SkyNightTexture(); const [, ws2] = withWarn(() => c.onLoad()); c.onDestroy();
    rec(M, 'M6 加载中区域卸载：迟到的回调不贴、addRef 后立即 decRef（引用 0）；加载失败：保持原值、state failed、warn 写“夜空贴图加载失败”；没指定 skyRenderer：warn、不加载、onDestroy 不出错',
      lateOk && failOk && ws2.length === 1, `late=${lateOk} fail=${failOk} warn=${JSON.stringify(ws)} noRenderer=${JSON.stringify(ws2)}`);
  }
  // M7 默认加载器（assetManager 桩）
  {
    const calls = []; const t = new FakeTex('am');
    const am = { getBundle: (n) => ({ load: (p, T, cb) => { calls.push([n, p, T && T.name]); cb(null, t); } }) };
    const e = makeEnv(dev(0), am); const C = new e.S.SkyNightTexture.SkyNightTexture(); C.skyRenderer = new e.cc.MeshRenderer(); C.onLoad();
    const ok1 = calls.length === 1 && calls[0][0] === 'region_meadow' && calls[0][1] === P1024 && calls[0][2] === 'Texture2D' && C.skyRenderer.mi.getProperty('nightTexture') === t && t.refCount === 1;
    C.onDestroy();
    rec(M, 'M7 默认加载器：assetManager.getBundle(region_meadow).load(1024 路径, Texture2D)，贴上后 onDestroy 引用回到 0', ok1 && t.refCount === 0, JSON.stringify(calls));
  }
  // M8 BakedGroundSwap 的 label 改动不影响地面：默认文字仍是“烘焙地面贴图”
  {
    const e = makeEnv(null); const B = e.S.BakedGroundTexture; const tgt = { v: 'orig', get () { return this.v; }, set (x) { this.v = x; }, valid: () => true };
    const s = new B.BakedGroundSwap(tgt, (b, p, d) => d(Error('x'), null), 'region_meadow', 'p'); const [, ws] = withWarn(() => s.setWanted(true));
    rec(M, 'M8 BakedGroundSwap 新增可选 label（只影响警告文字），地面不传时默认“烘焙地面贴图”', s.label === '烘焙地面贴图' && /烘焙地面贴图加载失败/.test(ws[0] || '') && tgt.v === 'orig', JSON.stringify(ws));
  }
  // M9 引擎一致性（静态）：ImageAsset._deserialize 跳过 .astc 的条件 = 本检测；cc.d.ts 枚举值
  {
    const ia = ps.join(ENGINE, 'cocos/asset/assets/image-asset.ts'), dts = ps.join(ENGINE, 'bin/.declarations/cc.d.ts'), mac = ps.join(ENGINE, 'cocos/core/platform/macro.ts'), st = ps.join(ENGINE, 'cocos/asset/assets/simple-texture.ts');
    if (![ia, dts, mac, st].every(fs.existsSync)) rec(M, 'M9 引擎源码核对', null, '找不到 Creator 3.8.8 引擎源码');
    else {
      const s = fs.readFileSync(ia, 'utf8'), d = fs.readFileSync(dts, 'utf8'), m = fs.readFileSync(mac, 'utf8'), t = fs.readFileSync(st, 'utf8');
      const c1 = s.includes("tmpExt === '.astc' && (!device || !(device.getFormatFeatures(Format.ASTC_RGBA_4X4) & FormatFeatureBit.SAMPLED_TEXTURE))");
      const c2 = /ASTC_RGBA_4X4 = 89,/.test(d) && /SAMPLED_TEXTURE = 2,/.test(d);
      const c3 = /private _format: PixelFormat = PixelFormat\.RGBA8888;/.test(s);   // png / jpg 没有 @格式 → 按 RGBA8888 上传
      const c4 = /if \(NATIVE \|\| MINIGAME \|\| RUNTIME_BASED\) \{\s*this\.CLEANUP_IMAGE_CACHE = true;/.test(m) && /if \(macro\.CLEANUP_IMAGE_CACHE\)/.test(t);
      const src = fs.readFileSync(ps.join(NEW, 'SkyNightTexture.ts'), 'utf8'); const c5 = src.includes('getFormatFeatures(gfx.Format.ASTC_RGBA_4X4)') && src.includes('gfx.FormatFeatureBit.SAMPLED_TEXTURE');
      rec(M, 'M9 和引擎一致（Creator 3.8.8 源码）：ImageAsset._deserialize 只在 getFormatFeatures(ASTC_RGBA_4X4) & SAMPLED_TEXTURE 时选 .astc，没设备也跳过 = 本组件的判法；枚举值 89 / 2；PNG 无 @格式 → RGBA8888 上传；小游戏 CLEANUP_IMAGE_CACHE = true（上传后释放 CPU 侧图像）',
        c1 && c2 && c3 && c4 && c5, JSON.stringify({ engineAstcSkip: c1, enums: c2, pngRGBA8888: c3, cleanupMinigame: c4, ours: c5 }));
    }
  }
  // M10 .meta / 预设
  {
    const TM = ps.join(PKG, 'runtime/textures-meta'); let ok = false, det = '';
    try {
      const m = JSON.parse(fs.readFileSync(ps.join(TM, 'tex_meadow_sky_night_1024x512.png.meta'), 'utf8')); const u = m.subMetas['6c48a'].userData;
      const others = fs.readdirSync(TM).filter(f => f.endsWith('.meta') && !f.includes('1024x512')).map(f => JSON.parse(fs.readFileSync(ps.join(TM, f), 'utf8')).uuid);
      const same = (f) => fs.existsSync(ps.join(V132, 'runtime/textures-meta', f)) && fs.readFileSync(ps.join(TM, f), 'utf8') === fs.readFileSync(ps.join(V132, 'runtime/textures-meta', f), 'utf8');
      const unchanged = ['tex_meadow_sky_night_2048x1024.png.meta', 'tex_meadow_sky_2048x1024.jpg.meta', 'tex_meadow_ground_grassoff_1024.jpg.meta', 'texture-compress-presets.e4.json'].map(f => [f, same(f)]);
      ok = m.files[0] === '.png' && m.userData.compressSettings.useCompressTexture === false && u.wrapModeS === 'repeat' && u.wrapModeT === 'clamp-to-edge' && u.mipfilter === 'none' && u.minfilter === 'linear' && u.magfilter === 'linear'
        && m.userData.hasAlpha === false && m.subMetas['6c48a'].name === 'texture' && !others.includes(m.uuid) && unchanged.every(x => x[1]);
      det = JSON.stringify({ compress: m.userData.compressSettings, wrap: [u.wrapModeS, u.wrapModeT], mip: u.mipfilter, uuidUnique: !others.includes(m.uuid), unchangedVsV132: unchanged });
    } catch (e) { det = String(e); }
    rec(M, 'M10 1024 夜空 .meta：.png、不压缩（useCompressTexture false，没有 ETC2）、wrap S repeat / T clamp、mipmap 关、linear、无 alpha、uuid 不重复；2048 夜空 / 白天 / 地面 .meta 和预设文件与 v1.3.2 逐字节相同', ok, det);
  }
  // MC 对照：v1.3.2 包 —— 没有 SkyNightTexture，材质直接引用 2048 夜空；引擎按 _deserialize 选格式（预设 astc_4x4 + png）
  {
    if (!fs.existsSync(ps.join(V132, 'runtime/textures-meta/texture-compress-presets.e4.json'))) rec(MC, 'v1.3.2 对照', null, `找不到 v1.3.2 包（${V132}）`);
    else {
      // 引擎选择逻辑（image-asset.ts _deserialize 的 .astc / .png 分支，M9 已核对源码）
      const pick = (exts, astcOk) => { for (const e of ['.astc', '.png']) if (exts.includes(e) && (e !== '.astc' || astcOk)) return e; return null; };   // SUPPORT_TEXTURE_FORMATS 里 .astc 排在 .png 前
      const nightFor = (pkg, astcOk) => {
        const hasSel = fs.existsSync(ps.join(pkg, 'runtime/scripts/SkyNightTexture.ts'));
        if (hasSel) { const e = makeEnv(null); const S2 = makeCC.loadScripts(ts, ps.join(pkg, 'runtime/scripts'), e.cc, ['BakedGroundTexture', 'SkyNightTexture']).SkyNightTexture; const p = S2.selectNightSkyPath(S2.detectAstcSupport(dev(astcOk ? SAMPLED_TEXTURE : 0)).support).path; return p.includes('1024x512') ? { asset: '1024x512', ext: '.png', bytes: 1024 * 512 * 4 } : { asset: '2048x1024', ext: '.astc', bytes: 2048 * 1024 }; }
        const pr = JSON.parse(fs.readFileSync(ps.join(pkg, 'runtime/textures-meta/texture-compress-presets.e4.json'), 'utf8'));
        const up = (pr.textureCompressConfig || pr).userPreset; const night = up['e4-meadow-sky-night'];
        const fmts = Object.keys((night.options || night).miniGame || {}); const exts = fmts.map(f => (f.startsWith('astc') ? '.astc' : f === 'png' ? '.png' : '.' + f));
        const ext = pick(exts, astcOk); return { asset: '2048x1024', ext, bytes: ext === '.astc' ? 2048 * 1024 : 2048 * 1024 * 4, fmts };
      };
      const oldNo = nightFor(V132, false), oldYes = nightFor(V132, true), newNo = nightFor(PKG, false), newYes = nightFor(PKG, true);
      rec(MC, '对照：v1.3.2 在不支持 ASTC 的设备上拿到 2048×1024 夜空（PNG 兜底，RGBA8 8 MiB）→ 不满足 v1.3.3 要求；v1.3.3 同一设备拿 1024×512（2 MiB）', oldNo.asset === '2048x1024' && oldNo.ext === '.png' && newNo.asset === '1024x512',
        JSON.stringify({ v132_noAstc: oldNo, v133_noAstc: newNo }));
      rec(MC, '对照：支持 ASTC 的设备上 v1.3.2 和 v1.3.3 都用 2048 ASTC 4×4（2 MiB），行为不变', oldYes.ext === '.astc' && newYes.asset === '2048x1024' && newYes.ext === '.astc', JSON.stringify({ v132: oldYes, v133: newYes }));
    }
  }
  // N 1024 夜空图
  {
    const A = process.env.E4_ART_OUTBOX || '/workspace/wechat-game/team/art/outbox-to-dot'; const SRC = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png');
    const SHIP = ps.join(PKG, 'runtime/textures/tex_meadow_sky_night_1024x512.png'); const OUTJ = ps.join(HERE, 'out/sky-night-1024-check.json');
    const eff = fs.readFileSync(ps.join(PKG, 'runtime/effects/sky-unlit.effect'), 'utf8'); const hv = parseFloat((eff.match(/horizonV:\s*\{\s*value:\s*([0-9.]+)/) || [])[1]);
    if (!fs.existsSync(SRC) || !fs.existsSync(SHIP)) rec(N, '1024 夜空图', null, '找不到 v0.1a 夜空源图或 1024 成品');
    else {
      // 本机内存紧时 python 偶尔被系统杀掉（没有输出也没有报错）：这种情况重跑一次，结果只看第二次
      const runCheck = () => cp.spawnSync('python3', [ps.join(HERE, 'sky-night-1024.py'), 'check', SRC, SHIP, String(hv), OUTJ], { encoding: 'utf8', maxBuffer: 1 << 26 });
      let r = runCheck(); if (r.status !== 0 && !(r.stderr || '').trim()) r = runCheck(); let R = null; try { R = JSON.parse(r.stdout); } catch (e) { /* */ }
      if (!R) rec(N, 'sky-night-1024.py check', false, `status ${r.status} signal ${r.signal} ` + (r.stderr || '').slice(-600));
      else {
        const f = (x, d = 3) => Number(x).toFixed(d), b = (x) => `单色块 ${f(x.uniform_block_fraction * 100, 1)}%（原图 ${f(x.uniform_block_fraction_orig * 100, 1)}%）、块均值误差 max ${f(x.block_mean_err_max, 2)}、抖动保留 ${f(x.dither_retention, 3)}`;
        const H = R.horizon, St = R.stars, Mm = R.memory, C = R.controls;
        rec(N, `N1 源图 v0.1a SHA ${R.source_sha256.slice(0, 8)}…；成品 ${R.shipped_size.join('×')} ${R.shipped_mode} PNG（SHA ${R.shipped_sha256.slice(0, 8)}…）；用 sky-night-1024.py 重新生成逐字节一致`, R.source_sha_ok && R.shipped_size[0] === 1024 && R.shipped_size[1] === 512 && R.shipped_mode === 'RGB' && R.regenerated_equal, `max diff ${R.regenerated_max_diff}`);
        rec(N, `N2 地平线：horizonV ${hv} × 512 = ${f(H.horizonV_xH, 2)}，第一个纹素中心过 horizonV 的行 = ${H.first_texel_row_below_horizonV}（要求 439）；第 439–511 行行均偏差 ${f(H.rows_below_rowmean_dev_max)}、逐像素对列中位数 ${H.rows_below_pixel_dev_from_col_median_max}（≤ 1 级）；颜色 (${H.colour_below_1024.join(',')}) 对 2048 第 878–1023 行差 ${f(H.colour_below_diff_max)}；第 438 / 439 行亮度差 ${f(H.row_prev_vs_first_lum)}`,
          H.first_texel_row_below_horizonV === 439 && H.rows_below_rowmean_dev_max <= 1 && H.rows_below_pixel_dev_from_col_median_max <= 1 && H.colour_below_diff_max <= 1 && H.row_prev_vs_first_lum <= 1, '');
        rec(N, `N3 u 环绕接缝：全图 ${f(H.seam_all, 2)}（相邻列平均 ${f(H.seam_all_inner, 2)}，99 分位 ${f(H.seam_all_inner_p99, 2)}，排第 ${f(H.seam_all_rank * 100, 0)}%）；地平线以下 ${f(H.seam_below, 2)}（${f(H.seam_below_inner, 2)} / ${f(H.seam_below_inner_p99, 2)}）`, H.seam_all <= H.seam_all_inner_p99 && H.seam_below <= H.seam_below_inner_p99, '全图接缝略高于平均是边缘列上的几颗星（第 179–191 行），排位在相邻列分布之内');
        rec(N, `N4 色带 / 抖动（和 v1.3.2 同一判法，1024 的 8×8 块对 2048 的 16×16 块）：全天空 ${b(R.band_all)}；暗区（块亮度 < 35）${b(R.band_dark)}`, R.band_all.pass && R.band_dark.pass, `平滑块 ${R.band_all.smooth_blocks} / 暗区 ${R.band_dark.smooth_blocks}`);
        rec(N, `N5 星星保留：2048 找到 ${St.stars_2048} 颗，1024 对应位置 ±1 纹素内找到 ${St.matched}（${f(St.count_retention * 100, 1)}%）；峰值亮度比 中位数 ${f(St.peak_ratio_median, 2)} / 10 分位 ${f(St.peak_ratio_p10, 2)}；突出量比中位数 ${f(St.prominence_ratio_median, 2)}（要求 ≥ 95% / ≥ 0.95 / ≥ 0.9）`, St.pass, `1024 里检出 ${St.stars_1024} 颗（相邻的星合成一颗）；最低一颗在 2048 第 ${St.lowest_star_row_2048} 行，地平线以下没有星`);
        const c1 = C.box_linear_no_dither_no_star, c2 = C.box_srgb_no_dither_no_star, c3 = C.dither_no_star;
        rec(N, `N6 对照必须失败：线性光盒式平均不加抖动 → 色带（${b(c1.band_all)}）；sRGB 盒式平均 → 色带（${b(c2.band_all)}）；只加抖动不保星 → 星星峰值比中位数 ${f(c3.stars.peak_ratio_median, 2)}、保留 ${f(c3.stars.count_retention * 100, 1)}%`, !c1.band_all.pass && !c2.band_all.pass && c3.band_all.pass && !c3.stars.pass && !c1.stars.pass, '');
        rec(N, `N7 显存（1024×512，无 mip）：Creator 不压缩时按 RGBA8888 上传 = ${Mm.rgba8_bytes} B（${f(Mm.rgba8_bytes / 1048576, 2)} MiB）；带 mip ${f(Mm.rgba8_with_mips_bytes / 1048576, 2)} MiB；若按 RGB8 算 ${f(Mm.rgb8_bytes / 1048576, 2)} / ${f(Mm.rgb8_with_mips_bytes / 1048576, 2)} MiB；包体 PNG ${Mm.png_file_bytes} B`, Mm.rgba8_bytes === 2097152, '');
        const RV = ps.join(PKG, 'docs/review'); const want = ['dark', 'stars', 'horizon'].flatMap(n => [`night1024-${n}-compare.png`, `night1024-${n}-compare-contrast.png`]);
        const have = want.filter(w => fs.existsSync(ps.join(RV, w)));
        rec(N, 'N8 对比图 docs/review/：暗区 / 星区 / 地平线各一组（2048 原图 | 1024 成品 ×2 最近邻 | 对照盒式平均），原样 + 拉对比度，共 6 张', have.length === 6, have.join(', '));
      }
    }
  }
};
