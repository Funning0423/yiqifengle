// 0007 v1.2 self-test: syntax (parseDiagnostics) + typecheck (cc stubbed) + pure-math/data/state-machine checks.
const ts=require(process.env.TS||'/tmp/ggts/node_modules/typescript'),fs=require('fs'),path=require('path');
const SRC=process.argv[2];const out={syntax:{},typecheck:null,tests:[]};let fail=0;
const ok=(name,cond,detail)=>{out.tests.push({name,pass:!!cond,detail});if(!cond)fail++;};
const files=['CameraPose.ts','RegionCameraData.ts','FirstsliceRoutes.ts','WorldFlowCore.ts','WorldFlowComponent.ts'];
for(const f of files){const sf=ts.createSourceFile(f,fs.readFileSync(path.join(SRC,f),'utf8'),ts.ScriptTarget.ES2020,true,ts.ScriptKind.TS);out.syntax[f]=sf.parseDiagnostics.length;if(sf.parseDiagnostics.length)fail++;}
// typecheck with a minimal 'cc' stub (decorators etc. as any)
{const stub=path.join(__dirname,'cc-stub.d.ts');fs.writeFileSync(stub,"declare module 'cc' { export const _decorator:any; export class Component{node:any;addComponent(c:any):any;} export class Prefab{} export function instantiate(p:any):any; export class Camera{node:any;fov:number;} export class Vec3{constructor(...a:any[]);x:number;y:number;z:number;} export class MeshRenderer{node:any;enabled:boolean;} export class Node{[k:string]:any} export const game:any; export class Game{static EVENT_HIDE:string;static EVENT_SHOW:string;} export class SkeletalAnimation{[k:string]:any} export class AnimationClip{[k:string]:any;static WrapMode:any} export class AnimationState{[k:string]:any} export const assetManager:any; export function isValid(o:any,s?:boolean):boolean; }\ndeclare module '../region/RegionAmbientAnimation' { export class RegionAmbientAnimation{clipUuids:string[];} }\n");
 const prog=ts.createProgram([...files.map(f=>path.join(SRC,f)),stub],{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS,strict:true,noEmit:true,experimentalDecorators:true,skipLibCheck:true,lib:['lib.es2020.d.ts','lib.dom.d.ts'],baseUrl:SRC});
 const d=ts.getPreEmitDiagnostics(prog).filter(x=>!x.file||files.includes(path.basename(x.file.fileName)));
 out.typecheck=d.map(x=>(x.file?path.basename(x.file.fileName)+':'+(x.file.getLineAndCharacterOfPosition(x.start).line+1)+' ':'')+ts.flattenDiagnosticMessageText(x.messageText,' '));if(d.length)fail++;}
// transpile pure modules
const tmp=path.join(__dirname,'js');fs.mkdirSync(tmp,{recursive:true});
for(const f of ['CameraPose.ts','RegionCameraData.ts','FirstsliceRoutes.ts','WorldFlowCore.ts','FirstsliceFacts.ts','CharacterReference.ts'])fs.writeFileSync(path.join(tmp,f.replace('.ts','.js')),ts.transpileModule(fs.readFileSync(path.join(SRC,f),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText);
const C=require(path.join(tmp,'CameraPose.js')),D=require(path.join(tmp,'RegionCameraData.js')),R=require(path.join(tmp,'FirstsliceRoutes.js')),W=require(path.join(tmp,'WorldFlowCore.js'));
const {FIRSTSLICE}=require(path.join(tmp,'FirstsliceFacts.js')),{CHARACTER_REFERENCE}=require(path.join(tmp,'CharacterReference.js'));
const near=(a,b,e=1e-6)=>a.every((v,i)=>Math.abs(v-b[i])<e);
// 1. lookAt equivalence: camera -Z points at target, +Y up-ish, no roll
for(const [n,v] of Object.entries({...D.REGION_CAMERA.island.variants,...Object.fromEntries(Object.entries(D.REGION_CAMERA.home.variants).map(([k,v])=>['home:'+k,v]))})){if(!v)continue;
 const q=C.rotationFromLookAt(v.position,v.target),f=C.rotate(q,[0,0,-1]),d=[v.target[0]-v.position[0],v.target[1]-v.position[1],v.target[2]-v.position[2]],l=Math.hypot(...d);
 ok('lookAt-forward '+n,near(f,d.map(x=>x/l),1e-9));ok('lookAt-noroll '+n,Math.abs(C.rotate(q,[1,0,0])[1])<1e-9&&C.rotate(q,[0,1,0])[1]>0);ok('valid '+n,C.validateCameraPose(C.fromLookAt(v))===null);}
// 2. blend/slerp endpoints + easing
{const a=C.fromLookAt(D.REGION_CAMERA.island.variants['legacy-capsule']),b=C.fromLookAt(D.REGION_CAMERA.island.variants['temporary-6m']);
 const m0=C.blendPose(a,b,0,'easeInOutCubic'),m1=C.blendPose(a,b,1,'easeInOutCubic'),mh=C.blendPose(a,b,.5,'easeInOutCubic');
 ok('blend endpoints',near(m0.position,a.position)&&near(m1.position,b.position)&&near(m1.rotation,b.rotation,1e-9));ok('blend unit quat',Math.abs(Math.hypot(...mh.rotation)-1)<1e-9);}
// 3. frame checks
const ch=D.REGION_CAMERA.islandCharacter,box=C.characterBox(ch.root,ch.heightM,ch.halfWidthM);const frames={};
for(const [n,fov] of [['legacy-capsule',45],['legacy-capsule',55],['temporary-6m',45],['temporary-6m',55]])for(const a of [.46,.75]){const p=C.fromLookAt({...D.REGION_CAMERA.island.variants[n],fovVerticalDeg:fov});const r=C.frameCheck(p,a,box);frames[`${n}@fov${fov}@${a}`]={x:[+r.minX.toFixed(3),+r.maxX.toFixed(3)],y:[+r.minY.toFixed(3),+r.maxY.toFixed(3)],pass:r.pass};}
out.frames=frames;ok('temporary-6m bbox in frame 0.46',frames['temporary-6m@fov45@0.46'].pass);ok('temporary-6m bbox in frame 0.75',frames['temporary-6m@fov45@0.75'].pass);ok('legacy fails (reproduces OI-FRAME-002 class)',!frames['legacy-capsule@fov45@0.46'].pass);
ok('6m distance',Math.abs(Math.hypot(...[-5.796-(-2.114),3.323-0.9,9.352-5.281]))-6<0.01);
// 4. routes read data; exit_path_17
const cfg=R.createFirstsliceRoutes(FIRSTSLICE,CHARACTER_REFERENCE);
ok('cameraIsland = temporary-6m data',near(cfg.cameraIsland.position,[-5.796,3.323,9.352])&&cfg.cameraIsland.fovVerticalDeg===45);
ok('cameraHome = oi-interim-standing data',near(cfg.cameraHome.position,[-1.1,1.5,-2.4])&&near(cfg.cameraHome.target,[.1,.86,-4.35])&&cfg.cameraHome.fovVerticalDeg===55);
ok('island root = exit_path_17 = data root',near(cfg.toIsland[cfg.toIsland.length-1],ch.root,1e-3),cfg.toIsland[cfg.toIsland.length-1]);
// 5. data-only switch
{const save=D.REGION_CAMERA.islandPoseSource;const warn=console.warn;let warned=0;console.warn=()=>warned++;
 D.REGION_CAMERA.islandPoseSource='yunjing-final';let e=D.islandPoseEntry();ok('yunjing-final null -> fallback temporary-6m + warn',e===D.REGION_CAMERA.island.variants['temporary-6m']&&warned===1);
 D.REGION_CAMERA.island.variants['yunjing-final']={position:[-8,6,12],target:[-2.1,.9,5.3],fovVerticalDeg:45,characterYawDeg:20,source:'test'};
 const c2=R.createFirstsliceRoutes(FIRSTSLICE,CHARACTER_REFERENCE);ok('yunjing-final data used w/o code change',near(c2.cameraIsland.position,[-8,6,12])&&Math.abs(c2.islandYawRad-20*Math.PI/180)<1e-12);
 D.REGION_CAMERA.island.variants['yunjing-final']=null;D.REGION_CAMERA.islandPoseSource=save;console.warn=warn;}
// 6. six entries on the real WorldFlow state machine with fake lease/character/level
(async()=>{
 const cams=[];const resets=[];let pendingLevel=null;
 const lease={setLayers(){},setDoor(){},setCamera(p){cams.push(p);},animateDoor:async()=>{},animateCamera:async(path)=>{cams.push(path[path.length-1]);},cancelTransient(){},assertStaticWorld(){},dispose(){}};
 const std=CHARACTER_REFERENCE;
 const character={calibrated:true,coordinates:{units:'m',up:'+Y',forward:'+Z',rootMotion:'controller-only',standingRoot:cfg.seat.standingControllerRoot,seatedRoot:cfg.seat.seatedControllerRoot,seatYawRad:cfg.seat.yawRad,clearanceRadiusM:.15},
  advance(){},perform:(a,t)=>a.kind==='walk'&&slowWalk?new Promise(()=>{}):Promise.resolve(),cancelAndReset(p){resets.push(p);},setVisible(){},dispose(){}};
 let slowWalk=false;
 const levelLease={requestExit:()=>({ok:true}),hide(){},showPaused(){},resume:()=>({ok:true}),dispose(){}};
 const flow=new W.WorldFlow({config:cfg,mode:'fixed',character,levels:{enter:async()=>levelLease},loadWorld:async()=>lease});
 const last=()=>cams[cams.length-1],lastReset=()=>resets[resets.length-1];
 const isIsland=()=>last()===cfg.cameraIsland&&lastReset().kind==='standing'&&near(lastReset().controllerRoot,ch.root,1e-3)&&lastReset().yawRad===0;
 const isHome=()=>last()===cfg.cameraHome&&lastReset().kind==='seated';
 const rows=[];
 await flow.load();rows.push(['cold-start',flow.snapshot().state,isHome()]);
 await flow.leaveHome();rows.push(['leave-complete',flow.snapshot().state,isIsland()]);
 await flow.enterLevel('s1');flow.exitLevel();rows.push(['result-return',flow.snapshot().state,isIsland()]);
 flow.hide();flow.show();flow.resume();rows.push(['pause-resume(island)',flow.snapshot().state,isIsland()]);
 await flow.enterLevel('s1');flow.hide();flow.show();flow.resume();flow.exitLevel();rows.push(['pause-resume(level)->result-return',flow.snapshot().state,isIsland()]);
 slowWalk=true;const p=flow.returnHome();await new Promise(r=>setTimeout(r,5));flow.cancelTransition();await p;rows.push(['cancel(returnHome)->island',flow.snapshot().state,isIsland()]);
 slowWalk=false;await flow.returnHome();slowWalk=true;const p2=flow.leaveHome();await new Promise(r=>setTimeout(r,5));flow.cancelTransition();await p2;rows.push(['cancel(leaveHome)->home',flow.snapshot().state,isHome()]);
 out.sixEntries=rows;for(const r of rows)ok('entry '+r[0],r[2],r[1]);
 out.skip='not_run (no skip path before 0006 merges)';
 out.fail=fail;console.log(JSON.stringify(out,null,1));process.exit(fail?1:0);
})();
