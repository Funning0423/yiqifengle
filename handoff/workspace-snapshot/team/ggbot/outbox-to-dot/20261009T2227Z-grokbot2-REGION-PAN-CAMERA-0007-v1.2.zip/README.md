# 0007 v1.2：地区镜头（唯一写入方 + 回海岛临时机位）补丁说明（grokbot-2/ggbot）

基线：Oi 的 e87c409 加上 0005（只新增了音效相关文件）。
不上传，不发布微信。终版小岛位姿以运镜bot 的 island_camera_pose.json 为准。

## 包内文件
- REGION-PAN-CAMERA-DESIGN-0007-v1.2.md：方案（六个入口的规则表在 §6，验证要求在 §8）
- 0001-0007-v1.2-camera-pose-single-writer.patch：主补丁，git format-patch 格式，只改 world-r1/
- 0007-wib-paintNavigation.diff：针对 e87c409 WorldIntegrationBoot.ts 的一行 diff，单独打
- selftest_0007.cjs / selftest_0007-result.json：自测脚本和结果
- SHA256SUMS.txt

## 改了哪些文件（主补丁，路径相对于 creator-build-project/）
- 新增 assets/scripts/world-r1/CameraPose.ts（.meta）：CameraPose 类型、fromLookAt（和 Node.lookAt 等价）、lerp/slerp/缓动、samplePath、applyCameraPose（唯一写入方）、projectPoint/frameCheck 调试
- 新增 assets/scripts/world-r1/RegionCameraData.ts（.meta）：位姿数据表，包含 islandPoseSource 和 homePoseSource 两个开关
- 修改 assets/scripts/world-r1/FirstsliceRoutes.ts：cameraHome 和 cameraIsland 改成从数据表读取，并新增 islandYawRad
- 修改 assets/scripts/world-r1/WorldFlowComponent.ts：setCamera、animateCamera、onDestroy 恢复都改走 applyCameraPose；新增调试入口 globalThis.__worldCamera
- 修改 assets/scripts/world-r1/WorldFlowCore.ts：只改了类型（Pose.fovVerticalDeg?、RouteConfig.islandYawRad?），pose() 读 islandYawRad；状态机不变
- 没有碰：ManagedMobileBoardUI.ts、NativeBoardUI.ts、WorldIntegrationBoot.ts、region/RegionLoader.ts、world-r2/MainlineHost.ts，以及 0005 的 scripts/audio/* 和 resources/audio_sfx/*

## 怎么打
在仓库根目录（creator-build-project 的上一级）执行：
    git am --directory=creator-build-project 0001-0007-v1.2-camera-pose-single-writer.patch
    git apply --check 0007-wib-paintNavigation.diff && git apply 0007-wib-paintNavigation.diff
第二个 diff 只把 e87c409 WorldIntegrationBoot.ts 第 82 行（paintNavigation 里每帧写 home 相机的那一行）换成注释。
如果 Oi 本地已经改过这一段导致 apply 失败，手动删掉这一行就行：
    if(this.characterPrefab&&s.state==='home'){const camera=director.getScene()!.getComponentsInChildren(Camera)[0];camera.node.setWorldPosition(-1.1,1.5,-2.4);camera.node.lookAt(new Vec3(.1,.86,-4.35));}
这组取景现在是数据 home.variants["oi-interim-standing"]（同样的坐标，FOV 55），进入 home 时由 restore() 写一次。

### 0007-wib-paintNavigation.diff 全文
    diff --git a/creator-build-project/assets/scripts/WorldIntegrationBoot.ts b/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    --- a/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    +++ b/creator-build-project/assets/scripts/WorldIntegrationBoot.ts
    @@ -79,7 +79,7 @@
       if(n>1&&first-(n-1)*step<floor){first=Math.min(d.boardCenter.y-158,floor+(n-1)*step);if(first-(n-1)*step<floor)step=Math.max(46,(first-floor)/(n-1));}
       keys.forEach((k,i)=>this.controls.get(k)!.setPosition(0,first-i*step,0));}
      private paintNavigation(){let s:any;try{s=this.composition.worldCommands().snapshot();}catch{return;}if(s.state==='home'&&!this.ready){const r=this.composition.attachCalibratedCharacter((this as any)._referenceAdapter);if(!r.ok){this.error=r.reason;return;}this.ready=true;}
    - if(this.characterPrefab&&s.state==='home'){const camera=director.getScene()!.getComponentsInChildren(Camera)[0];camera.node.setWorldPosition(-1.1,1.5,-2.4);camera.node.lookAt(new Vec3(.1,.86,-4.35));}
    + // 0007 v1.2 (GGbot): home camera is pose DATA now (world-r1/RegionCameraData.ts homePoseSource='oi-interim-standing', same -1.1,1.5,-2.4 -> .1,.86,-4.35, fov 55); only CameraPose.applyCameraPose writes the camera.
      this.notice.node.parent!.active=false;this.status.node.parent!.active=!!this.error;this.status.string=this.error||({home:'主页 · 参考角色流程',island:'海岛 · 选择地区旅程'} as any)[s.state]||s.state;
      const board=this.board(),b=board?.hostPresentation();const registered=s.state==='level'&&!s.needsResume&&b?.provider==='regional-r05'&&b.state==='result.saved'&&b.result?.completionRecorded;
      for(const [k,n]of this.controls)n.active=k==='resume'?s.needsResume:k==='mainNext'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&b.nextStageId):k==='chest'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&!b.readOnly&&b.journey.chests?.find((x:any)=>x.level===b.active.level)?.earned):k==='regionReward'?!!(s.state==='level'&&b?.provider==='mainline-v33'&&b.state==='result.saved'&&b.result?.completionRecorded&&!b.readOnly&&b.journey.regionRewards?.find((x:any)=>x.region===Math.floor(b.active.level/4))?.unlocked):k==='next'?!!(registered&&b.nextStageId):k==='claim'?!!(registered&&!b.nextStageId&&Object.keys(b.progress.records).filter(id=>id.startsWith('r05-'+b.active.region+'-')).length===4):!s.needsResume&&(k==='leave'?s.state==='home':k==='home'||['mainline','r4','tide','meadow','sky'].includes(k)?s.state==='island':false);

## 给 Oi 的一行说明
paintNavigation 里写 home 相机的那一行由上面的 diff 处理，Oi 不用手动改。另外还有一行建议：下次改 WorldIntegrationBoot 时，顺手删掉 mountWorld 里的 `if(this.characterPrefab)camera.fov=55;`。FOV 以后只由 RegionCameraData 决定；现在这行已经多余，留着也无害。

## 开关（只改数据，不改代码）：world-r1/RegionCameraData.ts
- islandPoseSource：
  - "temporary-6m"：当前默认，是**临时**构图候选，相机离人物 6 m，FOV 45
  - "legacy-capsule"：旧机位，可以用来重现 OI-FRAME-002
  - "yunjing-final"：运镜bot 交付后使用。把 island_camera_pose.json 的 Cocos 坐标（position，加 rotation 或 target，fovVerticalDeg，characterYawDeg）填进 island.variants["yunjing-final"]，再把开关改成 "yunjing-final"。如果数据还是 null，会打警告并回退到 temporary-6m
- homePoseSource：
  - "oi-interim-standing"：默认，等于 Oi 现在的 home 取景，FOV 55
  - "legacy-capsule"：旧的 home 机位，FOV 45
- 调试（浏览器或 DevTools 控制台）：
  - __worldCamera.sources()：查看当前两个开关
  - __worldCamera.frameCheck()：按数据位姿，算当前、0.46、0.75 三种宽高比下人物包围盒的投影
  - __worldCamera.liveFrameCheck()：按相机最后一次写入的位姿算投影
  - __worldCamera.writes()：查看写入次数和最后一次的来源

## 行为变化（有意的）
- 小岛机位换成 temporary-6m，FOV 45。e87c409 在挂了 characterPrefab 时小岛也是 FOV 55，这里改成数据里的 45。
- motion 模式的走路镜头，FOV 从起步时的值线性过渡到终点值；没写 FOV 的关键帧继承起步时的 FOV。
- 其他行为不变：状态机、各个入口和过渡方式都和原来一样，home 取景也和 Oi 现在的一样。

## 自测范围
passed：
- TypeScript 语法检查：5 个文件 parseDiagnostics 都是 0
- strict 类型检查（cc 用了 stub）：5 个文件 0 错误
- fromLookAt 与 Node.lookAt 等价：相机的 -Z 指向目标、roll 为 0。已对照 3.8.8 引擎源码 node.ts:2265 和 mat3.fromViewUp
- blend 的端点正确，插值结果是单位四元数
- 包围盒投影：temporary-6m 在 0.46 和 0.75 两种宽高比下都满足 |x|≤0.7、-0.85≤y≤0.75；legacy-capsule 不满足，能重现问题
- 路线读数据：cameraIsland 和 cameraHome 都等于数据表里的值；岛上 root 等于 exit_path_17
- 数据开关：yunjing-final 为 null 时回退并警告；填入数据后不改代码就能生效（包括 yaw）
- 用真实的 WorldFlow 状态机加假 lease 跑入口：冷启动、出门完成、结算返回、暂停恢复（在岛上、在关卡中）、取消（回家途中、出门途中），相机和人物都落在规则表规定的位置
- 在 audio-0005 树上模拟 Oi 的目录结构：git apply --check 和 git am --directory=creator-build-project 都通过；补丁没有碰 Oi 的 5 个文件，也没有碰 0005 的文件
- wib diff：在用 Oi 补丁 '+' 行和上下文重建的 e87c409 第 54–93 行片段上，git apply --check、apply 和反向 check 都通过；应用后文件里不再有写相机的调用

not_run：
- Creator 构建、Web 预览、微信 DevTools（这台机器上没有）
- 真实 interim B 模型截图（窄屏和宽屏）、引擎里的 FOV 读数、逐帧投影日志、遮挡射线（V6，未实现）、HUD 和安全区实测
- 跳过入口（0006 合并前没有）
- 现有 E8 浏览器测试（test_world_camera_audit.cjs、test_world_navigation_guard.cjs，需要 :8770 的构建产物）
- wib diff 在真实 e87c409 完整文件上的 apply（这台机器上没有完整文件）

已知风险（理论推算）：竖屏时小岛那一列导航按钮在屏幕中央，会盖住 temporary-6m 下的人物，见方案 §7.2 和 V3。需要 Grok Bot、Oi 和运镜bot 一起定：是改终版构图，还是改按钮布局。
