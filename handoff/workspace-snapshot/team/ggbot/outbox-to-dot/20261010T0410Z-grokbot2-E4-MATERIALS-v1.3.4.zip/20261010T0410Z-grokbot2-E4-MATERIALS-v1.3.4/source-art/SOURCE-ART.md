# 原始贴图（v1.3.4 起随包，供独立核对；**不导入工程**）

三张都是美术交付的原文件，逐字节复制，没有改动。游戏工程里用的是美术那边的同一文件（按第一节放到 `region_meadow` 包），这里的副本只用来核对。

| 文件 | 用途 / 工程里的名字 | 尺寸 | 字节 | SHA256（完整） | 来源 |
|---|---|---|---|---|---|
| `20261010T0133Z-grokbot2-MEADOW-SKY-DAY-v0.1a.jpg` | 白天天空 → `tex_meadow_sky_2048x1024.jpg` | 2048×1024 RGB JPEG | 57,542 | `153979281ac0b9a96d360245f59ad3b02438b1a39082afbca5cefc647959a4b8` | `team/art/outbox-to-dot/` 散件；与 `20261010T0133Z-grokbot2-MEADOW-SKY-DAY-v0.1a.zip`（SHA256 `2d8e5bb32aa9db7b6f4b9424c2bb1e16b5acd73b2aedb14d6c2524c1c95e15a5`）内 `day-v0.1a/meadow_sky_2048x1024.jpg` 逐字节相同 |
| `20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png` | 夜空 2048（ASTC 4×4）→ `tex_meadow_sky_night_2048x1024.png`；也是 1024×512 夜空和加载前渐变两色的源图 | 2048×1024 RGB PNG | 446,676 | `1fd02ba7284fe9dec25e2a2ea3deb5e8a10ebf9c014ef058c793b8883f39acd0` | 同上目录散件；与 `20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.zip`（SHA256 `7beaec9738ccb0fefd4e2a4f7f2a959809f2d545aae11ce9cb724fa3b47434be`）内 `night-v0.1a/meadow_sky_night_2048x1024.png` 逐字节相同 |
| `tex_meadow_ground_grassoff_1024.jpg` | 烘焙草色地面（关草时按需加载）→ 同名 | 1024×1024 RGB JPEG | 317,636 | `bb369d4d1512637e7e2863f521fb6e58f5a1c5f3e9d2252ac3aa99c77e19d530` | 同上目录散件；与 `20261010T0122Z-grokbot2-MEADOW-v0.8.1-BAKE-GROUNDTEX-CAMPOSE.zip`（SHA256 `0bbe1d68a1040bff0f6e04c26047f9c2c997c4bbd0ba70e5579685310c6d76bd`）内 `v0.8.1-bake/textures/tex_meadow_ground_grassoff_1024.jpg` 逐字节相同，并列在 `20261010T0122Z-grokbot2-SHA256SUMS-MEADOW-v0.8.1-BAKE.txt` |

没有随包、只给 ID 的（工程不用，只是美术源文件）：同一个 BAKE zip 里的 `v0.8.1-bake/textures/source/tex_meadow_ground_grassoff_2048_paint_master.png`（SHA256 `98b847f4f71200f3ecd54d7cc518906639cce3a2c8ce6609e21a4cc64eba91c4`）和 `…/tex_meadow_ground_grassoff_1024_lossless.png`（`f0bbfa3fb082774e5c7bce0dde420b09a98f1802aba2f7a17a9634e9088b2bbf`）；夜空 zip 里的 JPG 变体 `night-v0.1a/meadow_sky_night_2048x1024.jpg`（游戏不用，会出色带）。

用这里的夜空原图可以独立重做 1024×512 夜空和渐变取色：
`python3 tools/selftest/sky-night-1024.py check source-art/20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png runtime/textures/tex_meadow_sky_night_1024x512.png 0.857`
`python3 tools/selftest/sky-night-1024.py gradient source-art/20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png`
