'use strict';
// E4 v1.3.3 final：夜景图加载前不黑（两色渐变垫底 + 0.3 s 交叉淡入）。
//  o-night-gradient  渐变色和美术 v0.1a 夜景图实测一致；加载前第一帧不黑；淡入单调、约 0.3 s；已加载 / 淡入中卸载 / 加载失败重试 / 淡入中切昼夜；白天输出不变。
//  o-night-control   0157Z 版 v1.3.3（controls/v1.3.3-0157Z-runtime）加载前夜空是黑的。
// shader 模型：从 sky-unlit.effect 里把默认路径夜晚分支（#elif SKY_SOURCE != 1 … #if SKY_SOURCE == 2）逐行机械翻译成 JS 执行；
//   合成行 `vec3 c = mix(day * …, night * …, nb);` / `c *= skyParams.y;` 逐字核对后手写。SRGBToLinear 按 c 组同样取 x²（Cocos legacy 近似）。
const fs = require('fs'), ps = require('path'), cp = require('child_process');
const makeCC = require('./cc-stub');
const ASTC_RGBA_4X4 = 89, SAMPLED_TEXTURE = 2;

module.exports = async function run (ctx) {
  const { ts, rec, HERE } = ctx;
  const PKG = ps.join(HERE, '../..'), NEW = ps.join(PKG, 'runtime/scripts'), NEWFX = ps.join(PKG, 'runtime/effects/sky-unlit.effect');
  const OLD = ps.join(HERE, 'controls/v1.3.3-0157Z-runtime'); const O = 'o-night-gradient', OC = 'o-night-control';
  class FakeTex { constructor (n, rgb) { this.name = n; this.rgb = rgb; this.refCount = 0; } addRef () { this.refCount++; return this; } decRef () { this.refCount--; if (this.refCount < 0) throw Error('decRef < 0'); return this; } }
  class Vec4 { constructor (x = 0, y = 0, z = 0, w = 0) { this.x = x; this.y = y; this.z = z; this.w = w; } }
  const makeEnv = (dir) => {
    const prop = (a, b) => (typeof b === 'string' ? undefined : () => {});
    class MaterialInstance { constructor () { this.props = {}; this.sets = []; this.effectName = "sky-unlit"; } getProperty (k) { return this.props[k] === undefined ? null : this.props[k]; } setProperty (k, v) { this.props[k] = v; this.sets.push([k, v]); } }
    class MeshRenderer { constructor () { this.isValid = true; this.mi = new MaterialInstance(); } getMaterialInstance (i) { return i === 0 ? this.mi : null; } }
    const cc = { _decorator: { ccclass: () => (c) => c, property: prop }, CCFloat: Number, Component: class { }, MeshRenderer, Texture2D: class {}, Vec4, assetManager: undefined,
      director: { root: { device: null } }, gfx: { Format: { ASTC_RGBA_4X4 }, FormatFeatureBit: { SAMPLED_TEXTURE } } };
    return { cc, S: makeCC.loadScripts(ts, dir, cc, ['BakedGroundTexture', 'SkyNightTexture']).SkyNightTexture };
  };
  const dev = (astc) => ({ getFormatFeatures: (f) => (f === ASTC_RGBA_4X4 ? (astc ? SAMPLED_TEXTURE : 0) : 0) });
  const quiet = (fn) => { const o = console.warn; const ws = []; console.warn = (...a) => ws.push(a.join(' ')); try { return fn(); } finally { console.warn = o; } };
  const mount = (S, cc, astc, opts = {}) => {
    const C = new S.SkyNightTexture(); const r = new cc.MeshRenderer(); C.skyRenderer = r; C.device = dev(astc);
    Object.assign(C, { materialIndex: 0, textureProperty: 'nightTexture', bundleName: 'region_meadow', astcPath: S.SKY_NIGHT_ASTC_PATH, noAstcPath: S.SKY_NIGHT_NOASTC_PATH });
    for (const k of ['fadeSeconds', 'setGradientColors', 'gradientZenith', 'gradientHorizon', 'retryDelaySeconds', 'maxRetries']) if (k in C && C[k] === undefined) C[k] = S.SkyNightTexture.prototype[k];
    const reqs = []; C.loader = opts.loader || ((b, p, done) => reqs.push({ b, p, done }));
    if (opts.nb !== undefined) r.mi.setProperty('nightBlend', opts.nb);
    return { C, r, reqs };
  };

  // ---- shader 模型 ----
  const V3 = (a) => Array.isArray(a) ? a : [a, a, a];
  const vm = (f) => (...xs) => { if (xs.every(x => typeof x === 'number')) return f(...xs); const n = xs.map(V3); return [0, 1, 2].map(i => f(...n.map(x => x[i]))); };
  const mix = vm((a, b, t) => a * (1 - t) + b * t), clamp = vm((x, a, b) => Math.min(Math.max(x, a), b)), max = vm((a, b) => Math.max(a, b)), S2L = vm((x) => x * x);
  const model = (fxPath) => {
    const src = fs.readFileSync(fxPath, 'utf8'); const fsSrc = src.slice(src.indexOf('CCProgram sky-fs'));
    const i0 = fsSrc.indexOf('#elif SKY_SOURCE != 1'), i1 = fsSrc.indexOf('#if SKY_SOURCE == 2', i0);
    const lines = fsSrc.slice(i0 + 21, i1).split('\n').map(l => l.replace(/\/\/.*$/, '').trim()).filter(Boolean);
    const js = lines.map(l => l.replace(/^(float|vec3)\s+/, 'let ').replace(/texture\(nightTexture,\s*v_uv\)\.rgb/g, 'NT').replace(/\.rgb/g, '').replace(/skyParams\.z/g, 'SP[2]').replace(/horizonParams\.y/g, 'HP[1]').replace(/\bv_v\b/g, 'V')).join('\n');
    const branch = new Function('mix', 'clamp', 'max', 'SRGBToLinear', 'nightZenith', 'nightHorizon', 'SP', 'HP', 'V', 'NT', `let night;\n${js}\nreturn night;`);
    const okC = fsSrc.includes('vec3 c = mix(day * SRGBToLinear(dayTint.rgb), night * SRGBToLinear(nightTint.rgb), nb);') && fsSrc.includes('c *= skyParams.y;') && fsSrc.includes('float nb = skyParams.x;');
    const fx = (U, dayRGB, texRGB, v) => {
      const night = branch(mix, clamp, max, S2L, U.nightZenith, U.nightHorizon, [U.nb, U.intensity, U.mix], [0, U.horizonV], v, texRGB);   // NT = 采样到的 sRGB 值，分支里自己做 SRGBToLinear
      const day = S2L(dayRGB); const c = mix(mix(day, day, 0).map((d, i) => d * S2L(U.dayTint)[i]), night.map((n, i) => n * S2L(U.nightTint)[i]), U.nb);
      return c.map(x => x * U.intensity);
    };
    return { fx, js, okC, lines };
  };
  const NEWM = model(NEWFX), OLDM = fs.existsSync(ps.join(OLD, 'effects/sky-unlit.effect')) ? model(ps.join(OLD, 'effects/sky-unlit.effect')) : null;
  const uni = (mi, extra = {}) => { const g = (k, d) => { const v = mi.getProperty(k); return v === null ? d : v; }; const c = (x) => (x && x.x !== undefined ? [x.x, x.y, x.z] : x);
    return Object.assign({ nightZenith: c(g('nightZenith', [0.0627, 0.0784, 0.1882])), nightHorizon: c(g('nightHorizon', [0.4392, 0.5255, 0.6941])), nb: g('nightBlend', 0), mix: g('nightTexMix', 0), intensity: 1, horizonV: 0.857, dayTint: [1, 1, 1], nightTint: [1, 1, 1] }, extra); };
  const texOf = (mi) => { const t = mi.getProperty('nightTexture'); return t && t.rgb ? t.rgb : [0, 0, 0]; };   // 没贴图 = 默认 black
  const DAY = [0.38, 0.71, 0.82], TEX = [0.30, 0.36, 0.55]; const toS = (lin) => lin.map(x => Math.sqrt(Math.max(0, x)) * 255);
  const px = (M, r, v, extra) => M.fx(uni(r.mi, extra), DAY, texOf(r.mi), v);
  const f2 = (a) => '(' + a.map(x => x.toFixed(2)).join(', ') + ')';

  const { S, cc } = makeEnv(NEW);
  // O1 颜色和图一致
  {
    const A = process.env.E4_ART_OUTBOX || '/workspace/wechat-game/team/art/outbox-to-dot'; let SRC = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png'); if (!fs.existsSync(SRC)) SRC = ps.join(PKG, 'source-art/20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png');   // v1.3.4：包里带原图
    if (!fs.existsSync(SRC)) rec(O, 'O1 渐变色对图', null, '找不到 v0.1a 夜景图');
    else {
      const r = cp.spawnSync('python3', [ps.join(HERE, 'sky-night-1024.py'), 'gradient', SRC], { encoding: 'utf8' }); let G = null; try { G = JSON.parse(r.stdout); } catch (e) { /* */ }
      if (G) fs.writeFileSync(ps.join(HERE, 'out/night-gradient-colours.json'), JSON.stringify(G, null, 1));
      const z = G && G.zenith_row0.linear_mean_srgb, h = G && G.horizon_row878.linear_mean_srgb;
      const close = (a, b) => a.every((x, i) => Math.abs(x - b[i]) <= 0.0005);
      const C = new S.SkyNightTexture(); const ok = G && G.source_sha_ok && close(S.NIGHT_GRADIENT_ZENITH, z) && close(S.NIGHT_GRADIENT_HORIZON, h) && close(C.gradientZenith, z) && close(C.gradientHorizon, h)
        && Math.abs(h[0] - G.below_rows878_1023.linear_mean_srgb[0]) < 0.5;
      rec(O, `O1 渐变色 = 美术 v0.1a 夜景图实测（sky-night-1024.py gradient，每行 2048 像素线性光平均→sRGB）：天顶第 0 行 ${G ? f2(z) : '?'}（${G && G.zenith_row0.hex_rounded}），地平线第 878 行 ${G ? f2(h) : '?'}（${G && G.horizon_row878.hex_rounded}）；脚本常量和组件默认值一致（±0.0005）；第 878 行 = 地平线以下平坦区（878–1023 平均 ${G ? f2(G.below_rows878_1023.linear_mean_srgb) : '?'}）`, !!ok, G ? `sRGB 直接平均：天顶 ${f2(G.zenith_row0.srgb_mean)} / 地平线 ${f2(G.horizon_row878.srgb_mean)}` : (r.stderr || '').slice(-300));
    }
  }
  // O2 effect 静态
  {
    const src = fs.readFileSync(NEWFX, 'utf8');
    const okProp = /nightTexMix:\s*\{ value: 0\.0, target: skyParams\.z/.test(src) && /vec4 skyParams;/.test(src);
    const okLines = NEWM.lines.join('|') === ['float gt = clamp(v_v / max(horizonParams.y, 0.0001), 0.0, 1.0);', 'vec3 grad = mix(SRGBToLinear(nightZenith.rgb), SRGBToLinear(nightHorizon.rgb), gt);', 'night = mix(grad, SRGBToLinear(texture(nightTexture, v_uv).rgb), skyParams.z);'].join('|');
    const old = OLDM ? fs.readFileSync(ps.join(OLD, 'effects/sky-unlit.effect'), 'utf8') : '';
    const tint = (s) => (s.match(/#if SKY_NIGHT_TINT_ONLY\n([\s\S]*?)#elif/) || [])[1];
    const ubo = (s) => (s.match(/uniform SkyFS \{([\s\S]*?)\};/) || [])[1].split('\n').map(l => l.replace(/\/\/.*$/, '').trim()).filter(Boolean).join(' ');
    const same = OLDM && tint(src) === tint(old) && ubo(src) === ubo(old);
    rec(O, 'O2 sky-unlit.effect：新属性 nightTexMix → skyParams.z（原来的保留位，默认 0 = 渐变），UBO 布局与 0157Z 版逐字相同（还是 128 B）；默认路径夜晚分支 = 渐变 + mix(渐变, 夜景图, nightTexMix) 三行；SKY_NIGHT_TINT_ONLY 分支逐字不变；合成行不变', okProp && okLines && same && NEWM.okC, NEWM.lines.join(' / '));
  }
  // O3 加载前第一帧不黑（ASTC / 非 ASTC）+ O4 对照
  const firstFrame = (M, Smod, ccm, astc) => { const m = mount(Smod, ccm, astc, { nb: 1 }); quiet(() => m.C.onLoad()); const vs = [0, 0.3, 0.6, 0.857, 0.95, 1].map(v => toS(px(M, m.r, v))); return { m, vs }; };
  {
    const res = [true, false].map(astc => firstFrame(NEWM, S, cc, astc));
    const zS = S.NIGHT_GRADIENT_ZENITH, hS = S.NIGHT_GRADIENT_HORIZON;
    const ok = res.every(({ m, vs }) => m.reqs.length === 1 && m.r.mi.getProperty('nightTexture') === null && m.C.texMix === 0
      && vs.every(c => Math.max(...c) > 10) && vs[0].every((x, i) => Math.abs(x - zS[i]) < 0.6) && [3, 4, 5].every(k => vs[k].every((x, i) => Math.abs(x - hS[i]) < 0.6)) && vs[1][2] > vs[0][2] && vs[2][2] > vs[1][2]);
    rec(O, `O3 夜里进场、贴图还没到（nightBlend 1，nightTexture 空 = black）：第一帧夜空是渐变不是黑色。v = 0 → ${f2(res[1].vs[0])}，v = 0.6 → ${f2(res[1].vs[2])}，v = 0.857 / 0.95 / 1 → ${f2(res[1].vs[3])}（地平线以下平坦）；ASTC / 非 ASTC 一样`, ok, `sRGB 0–255（shader 模型，SRGBToLinear = x²）`);
    if (!OLDM) rec(OC, '0157Z 对照', null, '找不到 controls/v1.3.3-0157Z-runtime');
    else {
      const o = makeEnv(ps.join(OLD, 'scripts')); const r0 = firstFrame(OLDM, o.S, o.cc, false);
      const black = r0.vs.every(c => c.every(x => x === 0));
      rec(OC, `对照：0157Z 版 v1.3.3 同样情况第一帧夜空全黑 ${f2(r0.vs[0])}（v = 0…1 都是 0）→ 本次修的就是这个`, black && r0.m.reqs.length === 1, r0.vs.map(f2).join(' '));
    }
  }
  // O5 淡入：单调、约 0.3 s、没有硬切（ASTC / 非 ASTC，60 / 30 fps，掉帧）
  const fadeRun = (astc, dt, opts = {}) => {
    const m = mount(S, cc, astc, { nb: 1 }); quiet(() => m.C.onLoad()); m.C.update(dt); const t = new FakeTex('night', TEX); m.reqs[0].done(null, t);
    const mixes = [m.C.texMix]; const cols = [toS(px(NEWM, m.r, 0.3))]; let time = 0, tDone = null;
    for (let i = 0; i < 120 && tDone === null; i++) { if (opts.at && opts.at[i] !== undefined) m.r.mi.setProperty('nightBlend', opts.at[i]); const d = opts.hitch && i === 3 ? 1.0 : dt; m.C.update(d); time += d; mixes.push(m.C.texMix); cols.push(toS(px(NEWM, m.r, 0.3, { nb: 1 }))); if (m.C.texMix >= 1) tDone = time; }
    return { m, t, mixes, cols, tDone };
  };
  {
    const runs = [[true, 1 / 60], [false, 1 / 60], [true, 1 / 30], [false, 1 / 30]].map(([a, dt]) => ({ a, dt, ...fadeRun(a, dt) }));
    const mono = (xs) => xs.every((x, i) => i === 0 || x >= xs[i - 1] - 1e-12);
    const ok = runs.every(r => r.mixes[0] === 0 && mono(r.mixes) && r.tDone !== null && r.tDone >= 0.29 && r.tDone <= 0.34 && Math.max(...r.mixes.slice(1).map((x, i) => x - r.mixes[i])) <= r.dt / 0.3 + 1e-9
      && [0, 1, 2].every(ch => { const sg = Math.sign(r.cols[r.cols.length - 1][ch] - r.cols[0][ch]) || 1; return mono(r.cols.map(c => sg * c[ch])); }) && r.m.C.switchMode === 'fade' && r.t.refCount === 1);
    const h = fadeRun(false, 1 / 60, { hitch: true });
    rec(O, `O5 淡入：贴图到了以后 nightTexMix 0 → 1 线性单调，用时 ${runs.map(r => r.tDone.toFixed(3) + ' s').join(' / ')}（ASTC 60 fps / 非 ASTC 60 fps / ASTC 30 fps / 非 ASTC 30 fps，要求 0.29–0.34 s），每帧最多前进 dt / 0.3，像素颜色单调过渡（没有硬切）；一帧卡 1 s 时直接到 1、不超过 1`,
      ok && h.mixes.every(x => x <= 1) && h.tDone !== null, `60 fps 前几帧 mix = ${runs[0].mixes.slice(0, 5).map(x => x.toFixed(3)).join(', ')}；掉帧 ${h.mixes.slice(0, 6).map(x => x.toFixed(3)).join(', ')}`);
  }
  // O6 已经加载好 / 白天到的
  {
    const tA = new FakeTex('cached', TEX); const a = mount(S, cc, true, { nb: 1, loader: (b, p, done) => done(null, tA) }); quiet(() => a.C.onLoad());
    const aOk = a.C.texMix === 1 && a.C.switchMode === 'sync' && !a.C.fading && a.r.mi.getProperty('nightTexture') === tA; a.C.update(1 / 60); const aOk2 = a.C.texMix === 1;
    const b = mount(S, cc, false, { nb: 0 }); quiet(() => b.C.onLoad()); const tB = new FakeTex('day', TEX); b.reqs[0].done(null, tB); b.C.update(1 / 60);
    const bOk = b.C.texMix === 1 && b.C.switchMode === 'day' && !b.C.fading; b.r.mi.setProperty('nightBlend', 1); b.C.update(1 / 60); const bOk2 = b.C.texMix === 1 && !b.C.fading;
    const col = toS(px(NEWM, b.r, 0.3)), want = toS(S2L(TEX));
    rec(O, 'O6 已加载的情况（我的选择：直接切，不淡入）：onLoad 里同步加载好 → 第一帧 nightTexMix = 1（switchMode sync）；白天加载完（nightBlend 0，渐变看不见）→ 直接设 1（switchMode day），之后进入夜晚不再淡入，直接是夜景图',
      aOk && aOk2 && bOk && bOk2 && col.every((x, i) => Math.abs(x - want[i]) < 1e-9), `夜里像素 ${f2(col)} = 夜景图 ${f2(want)}`);
  }
  // O7 淡入中卸载
  {
    const m = mount(S, cc, true, { nb: 1 }); quiet(() => m.C.onLoad()); const t = new FakeTex('n', TEX); m.reqs[0].done(null, t);
    for (let i = 0; i < 8; i++) m.C.update(1 / 60); const mid = m.C.texMix; m.C.onDestroy();
    const after = toS(px(NEWM, m.r, 0)); m.C.update(1 / 60);
    const ok = mid > 0 && mid < 1 && m.r.mi.getProperty('nightTexture') === null && t.refCount === 0 && m.C.texMix === 0 && !m.C.fading && after.every((x, i) => Math.abs(x - S.NIGHT_GRADIENT_ZENITH[i]) < 0.6) && m.C.texMix === 0;
    rec(O, `O7 淡入中卸载（nightTexMix ${mid.toFixed(3)} 时 onDestroy）：nightTexture 换回原值、引用回 0、nightTexMix 回 0（天空还在的话是渐变 ${f2(after)}，不黑），之后 update 不再动`, ok, '');
  }
  // O8 加载失败：保持渐变 + 重试
  {
    const m = mount(S, cc, false, { nb: 1 }); quiet(() => m.C.onLoad()); quiet(() => m.reqs[0].done(Error('404'), null));
    const g0 = toS(px(NEWM, m.r, 0)); let t = 0; while (m.reqs.length < 2 && t < 5) { m.C.update(0.1); t += 0.1; }
    const retryAt = t; const tx = new FakeTex('retry', TEX); m.reqs[1].done(null, tx); for (let i = 0; i < 30; i++) m.C.update(1 / 60);
    const okRetry = m.reqs.length === 2 && m.reqs[1].p === m.reqs[0].p && retryAt >= 1.99 && retryAt <= 2.11 && m.C.texMix === 1 && m.C.switchMode === 'fade' && tx.refCount === 1 && g0.every((x, i) => Math.abs(x - S.NIGHT_GRADIENT_ZENITH[i]) < 0.6);
    const n = mount(S, cc, false, { nb: 1 }); quiet(() => { n.C.onLoad(); for (let k = 0; k < 10; k++) { const q = n.reqs[n.reqs.length - 1]; if (!q.used) { q.used = true; q.done(Error('x'), null); } for (let i = 0; i < 25; i++) n.C.update(0.1); } });
    const okMax = n.reqs.length === 4 && n.C.retries === 3 && n.C.texMix === 0 && n.C.state.state === 'failed';
    rec(O, `O8 加载失败：保持渐变（v = 0 → ${f2(g0)}）；${retryAt.toFixed(1)} s 后用 BakedGroundSwap 原有的 setWanted(false → true) 重试同一路径，成功后照常 0.3 s 淡入；一直失败时最多重试 3 次（共 4 次请求），之后一直是渐变`, okRetry && okMax, `请求数 ${m.reqs.length} / ${n.reqs.length}`);
  }
  // O9 淡入中切昼夜 + 白天不变
  {
    const base = fadeRun(true, 1 / 60), sw = fadeRun(true, 1 / 60, { at: { 3: 0, 6: 1, 9: 0.5 } });
    const same = base.mixes.length === sw.mixes.length && base.mixes.every((x, i) => x === sw.mixes[i]);
    // 白天：随机输入下新 / 旧 shader 模型逐位相同（nb = 0）
    let dayEq = !!OLDM, n = 0; let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; OLDM && i < 2000; i++) {
      const U = { nightZenith: [rnd(), rnd(), rnd()], nightHorizon: [rnd(), rnd(), rnd()], nb: 0, mix: rnd(), intensity: 0.5 + rnd(), horizonV: 0.857, dayTint: [rnd(), rnd(), rnd()], nightTint: [rnd(), rnd(), rnd()] };
      const d = [rnd(), rnd(), rnd()], tx = [rnd(), rnd(), rnd()], v = rnd();
      const a = NEWM.fx(U, d, tx, v), b = OLDM.fx(U, d, tx, v); if (!a.every((x, k) => x === b[k])) dayEq = false; n++;
    }
    // 淡入中 nightBlend = 0 的帧：输出 = 白天
    const m = mount(S, cc, true, { nb: 1 }); quiet(() => m.C.onLoad()); m.reqs[0].done(null, new FakeTex('n', TEX)); m.C.update(1 / 60); m.C.update(1 / 60);
    m.r.mi.setProperty('nightBlend', 0); const dayPx = toS(m.C && NEWM.fx(uni(m.r.mi), DAY, TEX, 0.3)); const dayRef = toS(OLDM ? OLDM.fx(uni(m.r.mi), DAY, TEX, 0.3) : [0, 0, 0]);
    rec(O, `O9 淡入中切昼夜（第 3 帧切白天、第 6 帧切夜、第 9 帧 0.5）：nightTexMix 序列和不切时逐帧相同（淡入不重启、不中断）；白天（nightBlend 0）新旧 shader 模型 ${n} 组随机输入逐位相同，淡入中白天帧的像素 = 白天 ${f2(dayPx)}`, same && dayEq && dayPx.every((x, i) => x === dayRef[i]), '');
  }
};
