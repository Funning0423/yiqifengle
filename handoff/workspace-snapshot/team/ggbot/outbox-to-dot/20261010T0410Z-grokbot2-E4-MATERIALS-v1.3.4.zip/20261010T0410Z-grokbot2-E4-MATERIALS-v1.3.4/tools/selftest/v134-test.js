'use strict';
// E4 v1.3.4 Node 测试（Oi v1.3.3 复审 team/oi/e4v133rev/INTEGRATION-MEMO.txt）：
//  p-swap-errors   E4-132-01：BakedGroundSwap 加载成功后 valid / get / set 抛异常或目标无效 → 只释放一次、state = failed；换回时 valid 抛异常也 decRef；
//                  SkyNightTexture 复用时同样。
//  p-sky-config    E4-133-01：没有材质 / 没有贴图槽 / effect 不对 = 失败，不记 applied、nightTexMix 保持 0（渐变）、不自动重试；retry() 改好后能恢复；正常材质照常。
//  p-control       同样的用例跑在 v1.3.3 final 原文件（controls/v1.3.3-final-runtime）上必须失败。
//  p-docs          README 旧段改成 nightTexture 留空、写明预先绑定会让 2048 和 1024 都加载；source-art 三张原图完整 SHA。
const fs = require('fs'), ps = require('path');
const makeCC = require('./cc-stub');
const ASTC_RGBA_4X4 = 89, SAMPLED_TEXTURE = 2;

module.exports = async function run (ctx) {
  const { ts, rec, HERE } = ctx;
  const PKG = ps.join(HERE, '../..'), NEW = ps.join(PKG, 'runtime/scripts'), OLD = ps.join(HERE, 'controls/v1.3.3-final-runtime/scripts');
  const PE = 'p-swap-errors', PC = 'p-sky-config', PX = 'p-control', PD = 'p-docs';
  class Tex { constructor (n) { this.name = n; this.refs = 0; } addRef () { this.refs++; return this; } decRef () { this.refs--; return this; } }
  const quiet = (fn) => { const o = console.warn; const ws = []; console.warn = (...a) => ws.push(a.map(String).join(' ')); try { return [fn(), ws]; } finally { console.warn = o; } };
  class Vec4 { constructor (x = 0, y = 0, z = 0, w = 0) { Object.assign(this, { x, y, z, w }); } }
  // 材质实例：opts.handles = { name: handle }（模拟 Pass.getHandle：没有 = 0）；effectName
  class Mat { constructor (o = {}) { this.props = {}; this.isValid = true; this.effectName = o.effectName === undefined ? 'sky-unlit' : o.effectName; const hs = o.handles; this.passes = hs ? [{ getHandle: (n) => hs[n] || 0 }] : []; } getProperty (k) { return this.props[k] === undefined ? null : this.props[k]; } setProperty (k, v) { this.props[k] = v; } }
  const load = (dir) => {
    const prop = (a, b) => (typeof b === 'string' ? undefined : () => {});
    class MeshRenderer { constructor () { this.isValid = true; this.mat = new Mat(); } getMaterialInstance (i) { return i === 0 ? this.mat : null; } }
    const cc = { _decorator: { ccclass: () => (c) => c, property: prop }, CCFloat: Number, Component: class {}, MeshRenderer, Texture2D: class {}, Vec4, assetManager: undefined,
      director: { root: { device: null } }, gfx: { Format: { ASTC_RGBA_4X4 }, FormatFeatureBit: { SAMPLED_TEXTURE } } };
    const S = makeCC.loadScripts(ts, dir, cc, ['BakedGroundTexture', 'SkyNightTexture']); return { cc, B: S.BakedGroundTexture, K: S.SkyNightTexture };
  };
  // ---- BakedGroundSwap 用例 ----
  const swapCase = (B, kind) => {
    const orig = new Tex('orig'); let slot = orig; const tgt = { valid: () => true, get: () => slot, set: (t) => { slot = t; } };
    let setCalls = 0;
    if (kind === 'get') tgt.get = () => { throw Error('get'); };
    if (kind === 'valid') tgt.valid = () => { throw Error('valid'); };
    if (kind === 'set') tgt.set = (t) => { setCalls++; if (setCalls === 1) { slot = t; throw Error('set after partial write'); } slot = t; };
    if (kind === 'invalid') tgt.valid = () => false;
    const pend = []; const b = new B.BakedGroundSwap(tgt, (bu, p, d) => pend.push(d), 'region_meadow', 'p'); b.setWanted(true);
    const t = new Tex('baked'); let threw = false; const [, ws] = quiet(() => { try { pend[0](null, t); } catch (e) { threw = true; } });
    const r = { threw, refs: t.refs, state: b.state, slotIsOrig: slot === orig, failed: b.stats.failed, stale: b.stats.stale, warns: ws.length };
    quiet(() => { try { b.dispose(); } catch (e) { r.disposeThrew = true; } }); r.refsAfterDispose = t.refs; return r;
  };
  const restoreCase = (B) => {   // 已贴上后，换回时 valid 抛异常
    const orig = new Tex('orig'); let slot = orig; let boom = false; const tgt = { valid: () => { if (boom) throw Error('valid at restore'); return true; }, get: () => slot, set: (t) => { slot = t; } };
    const pend = []; const b = new B.BakedGroundSwap(tgt, (bu, p, d) => pend.push(d), 'region_meadow', 'p'); b.setWanted(true); const t = new Tex('baked'); pend[0](null, t);
    const applied = b.state === 'applied' && t.refs === 1; boom = true; let threw = false; quiet(() => { try { b.setWanted(false); } catch (e) { threw = true; } });
    return { applied, threw, refs: t.refs, state: b.state };
  };
  const N = load(NEW), O = fs.existsSync(OLD) ? load(OLD) : null;
  {
    const res = Object.fromEntries(['get', 'valid', 'set', 'invalid'].map(k => [k, swapCase(N.B, k)]));
    const ok = ['get', 'valid', 'set'].every(k => !res[k].threw && res[k].refs === 0 && res[k].state === 'failed' && res[k].failed === 1 && res[k].warns === 1 && res[k].refsAfterDispose === 0)
      && res.set.slotIsOrig && res.invalid.refs === 0 && res.invalid.state === 'failed' && res.invalid.stale === 1 && res.invalid.failed === 0;
    rec(PE, 'E4-132-01 BakedGroundSwap：贴图到了以后 target.get / target.valid / target.set 抛异常 → 不抛回加载器、引用回 0（只 decRef 一次）、state failed、failed +1、warn 一次；set 写了一半再抛 → 尽量换回原贴图；目标无效 → 同 v1.3.1（stale +1、failed、引用 0）', ok, JSON.stringify(res));
    const rr = restoreCase(N.B);
    rec(PE, 'E4-132-01 换回原贴图时 target.valid 抛异常：不抛出、照样 decRef（引用 0）、state idle', rr.applied && !rr.threw && rr.refs === 0 && rr.state === 'idle', JSON.stringify(rr));
  }
  // ---- SkyNightTexture ----
  const sky = (L, opts = {}) => {
    const C = new L.K.SkyNightTexture(); const r = new L.cc.MeshRenderer(); C.skyRenderer = r; C.device = { getFormatFeatures: () => 0 };
    for (const k of Object.keys(C)) if (C[k] === undefined && L.K.SkyNightTexture.prototype[k] !== undefined) C[k] = L.K.SkyNightTexture.prototype[k];
    Object.assign(C, { materialIndex: 0, textureProperty: 'nightTexture', bundleName: 'region_meadow', astcPath: L.K.SKY_NIGHT_ASTC_PATH, noAstcPath: L.K.SKY_NIGHT_NOASTC_PATH, fadeSeconds: 0.3, retryDelaySeconds: 2, maxRetries: 3, setGradientColors: true, gradientZenith: L.K.NIGHT_GRADIENT_ZENITH.slice(), gradientHorizon: L.K.NIGHT_GRADIENT_HORIZON.slice() });
    if (C.expectedEffect === undefined && 'expectedEffect' in L.K.SkyNightTexture.prototype) C.expectedEffect = 'sky-unlit';
    if (opts.mat !== undefined) r.mat = opts.mat; r.mat && r.mat.setProperty && r.mat.setProperty('nightBlend', 1);
    if (opts.matFn) r.getMaterialInstance = opts.matFn;
    const reqs = []; C.loader = (b, p, d) => reqs.push(d); return { C, r, reqs };
  };
  const run = (L, opts, after) => { const s = sky(L, opts); const t = new Tex('night'); const [, ws] = quiet(() => { s.C.onLoad(); if (after) after(s); let threw = false; try { s.reqs[0](null, t); } catch (e) { threw = true; s.threw = true; } s.st0 = s.C.state && s.C.state.state; s.refs0 = t.refs; let mx = 0; for (let i = 0; i < 120; i++) { s.C.update(0.1); mx = Math.max(mx, s.C.texMix); } s.maxMix = mx; });
    return { s, t, ws, st: s.C.state && s.C.state.state, mix: s.C.texMix, reqs: s.reqs.length, threw: !!s.threw }; };
  {
    // 材质 getter 抛异常（Oi v133 focused 同款）
    const g = run(N, {}, (s) => { const m = s.r.mat; const og = m.getProperty.bind(m); m.getProperty = (k) => { if (k === 'nightTexture') throw Error('getter'); return og(k); }; });
    quiet(() => g.s.C.onDestroy());
    rec(PE, 'E4-132-01 SkyNightTexture 复用 BakedGroundSwap：贴图到了时读 nightTexture 抛异常 → 不抛出、引用立刻回 0、state failed、nightTexMix 一直是 0（渐变）；这类运行时失败照旧 2 s 后重试（不是接入错误）', !g.threw && g.s.refs0 === 0 && g.s.st0 === 'failed' && g.s.maxMix === 0 && g.t.refs === 0 && g.reqs >= 2, JSON.stringify({ threw: g.threw, refsAtFail: g.s.refs0, stateAtFail: g.s.st0, maxMix: g.s.maxMix, requests: g.reqs, refsAfterDestroy: g.t.refs }));
  }
  {
    const cases = [
      ['没有材质（getMaterialInstance 返回 null）', { matFn: () => null }],
      ['materialIndex 越界', { matFn: (i) => (i === 0 ? null : null) }],
      ['getMaterialInstance 抛异常', { matFn: () => { throw Error('boom'); } }],
      ['材质已销毁', { mat: Object.assign(new Mat(), { isValid: false }) }],
      ['有 sky 的其他 handle 但没有 nightTexture 槽', { mat: new Mat({ handles: { nightBlend: 0x1001, nightTexMix: 0x1002 } }) }],
      ['effect 不对（builtin-unlit，没有任何 sky handle）', { mat: new Mat({ handles: { mainTexture: 0x2001 }, effectName: 'builtin-unlit' }) }],
    ];
    const out = cases.map(([n, o]) => { const r = run(N, o); quiet(() => r.s.C.onDestroy()); return [n, r.st, r.mix, r.t.refs, r.reqs, r.s.C.configError ? 'configError' : '', r.ws.filter(w => /接入有误/.test(w)).length]; });
    const ok = out.every(([, st, mix, refs, reqs, ce, nw]) => st === 'failed' && mix === 0 && refs === 0 && reqs === 1 && ce === 'configError' && nw === 1);
    rec(PC, 'E4-133-01 接入错误 = 失败：没有材质 / 槽越界 / getMaterialInstance 抛异常 / 材质已销毁 / 没有 nightTexture 槽 / effect 不对 → state failed（不是 applied）、nightTexMix 保持 0、贴图引用 0、12 s 内不自动重试（只 1 次请求）、warn 一次“接入有误”', ok, JSON.stringify(out));
    // 正常：真实 handle（有 nightTexture）和只靠 effect 名的都要能贴上并淡入
    const good = [['handle 有 nightTexture', { mat: new Mat({ handles: { nightTexture: 0x3001, nightBlend: 0x1001 } }) }], ['没有 handle 信息、effect = sky-unlit', { mat: new Mat() }]].map(([n, o]) => { const r = run(N, o); const v = [n, r.st, r.mix, r.t.refs, r.s.C.switchMode]; quiet(() => r.s.C.onDestroy()); return v.concat(r.t.refs); });
    rec(PC, '正常材质不受影响：有 nightTexture handle 的、或拿不到 handle 但 effect 是 sky-unlit 的 → applied、0.3 s 淡入到 1、引用 1，onDestroy 后 0', good.every(g => g[1] === 'applied' && g[2] === 1 && g[3] === 1 && g[4] === 'fade' && g[5] === 0), JSON.stringify(good));
    // retry()：接入改好后
    const fix = run(N, { mat: new Mat({ handles: { nightBlend: 0x1001 } }) }); const okBefore = fix.st === 'failed' && fix.mix === 0;
    fix.s.r.mat = new Mat({ handles: { nightTexture: 0x3001, nightBlend: 0x1001 } }); fix.s.r.mat.setProperty('nightBlend', 1);
    quiet(() => { fix.s.C.retry(); const t2 = new Tex('n2'); fix.s.reqs[1](null, t2); for (let i = 0; i < 10; i++) fix.s.C.update(0.05); fix.t2 = t2; });
    const okAfter = fix.s.C.state.state === 'applied' && fix.s.C.texMix === 1 && fix.t2.refs === 1 && fix.s.C.configError === '';
    quiet(() => fix.s.C.onDestroy());
    rec(PC, '接入改好后调 retry()：清掉 configError、重新加载、贴上并淡入；onDestroy 后引用 0', okBefore && okAfter && fix.t2.refs === 0, JSON.stringify({ okBefore, okAfter, refs: fix.t2.refs }));
  }
  // ---- 对照：v1.3.3 final 原文件 ----
  if (!O) rec(PX, 'v1.3.3 final 对照', null, '找不到 controls/v1.3.3-final-runtime');
  else {
    const g = swapCase(O.B, 'get');
    rec(PX, '对照：v1.3.3 final 的 BakedGroundSwap 在 target.get 抛异常时把异常抛回加载器、留下 1 个引用（= Oi E4-132-01 复现）', g.threw && g.refs === 1, JSON.stringify(g));
    const m = run(O, { matFn: () => null });
    rec(PX, '对照：v1.3.3 final 的 SkyNightTexture 没有材质时记 applied、nightTexMix 淡到 1（= Oi E4-133-01 复现）', m.st === 'applied' && m.mix === 1, JSON.stringify({ state: m.st, mix: m.mix }));
  }
  // ---- 文档 / 原图 ----
  {
    const R = fs.readFileSync(ps.join(PKG, 'README.md'), 'utf8');
    const bad = /`mat_meadow_sky`：`mainTexture` = 白天图，`nightTexture` = 夜空图/.test(R) || /`mainTexture` 白天图、`nightTexture` 夜景图/.test(R);
    const both = /预先绑定[^\n]*2048[^\n]*1024[^\n]*都会加载|预先绑定[^\n]*1024[^\n]*2048[^\n]*都会加载/.test(R);
    rec(PD, 'README：不再有“nightTexture = 夜空图 / 夜景图”的旧接入写法；写明 nightTexture 留空，预先绑定会让 2048 和 1024 都加载', !bad && both, `旧写法残留=${bad} 说明=${both}`);
    const want = { '20261010T0133Z-grokbot2-MEADOW-SKY-DAY-v0.1a.jpg': '153979281ac0b9a96d360245f59ad3b02438b1a39082afbca5cefc647959a4b8', '20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png': '1fd02ba7284fe9dec25e2a2ea3deb5e8a10ebf9c014ef058c793b8883f39acd0', 'tex_meadow_ground_grassoff_1024.jpg': 'bb369d4d1512637e7e2863f521fb6e58f5a1c5f3e9d2252ac3aa99c77e19d530' };
    const crypto = require('crypto'); const SA = ps.join(PKG, 'source-art'); const doc = fs.existsSync(ps.join(SA, 'SOURCE-ART.md')) ? fs.readFileSync(ps.join(SA, 'SOURCE-ART.md'), 'utf8') : '';
    const res = Object.entries(want).map(([f, h]) => { const p = ps.join(SA, f); const got = fs.existsSync(p) ? crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex') : null; return [f, got === h, doc.includes(h)]; });
    rec(PD, 'source-art/：2048 白天、2048 夜空、烘焙地面三张原图随包，SHA256 与美术交付一致，SOURCE-ART.md 写了完整 SHA 和来源 zip', res.every(r => r[1] && r[2]), JSON.stringify(res));
  }
};
