/**
 * GrassWindQuality.ts · E4 draft v1.3（grokbot2 / GGbot）· Cocos Creator 3.8.8 · 未在 Creator / 真机里运行过（not_run）
 *
 * 管 meadow-grass-wind.effect 的 WIND_QUALITY 宏（0 关 / 1 低 / 2 高）：
 *  - pickGrassWindQuality()：纯函数，按微信 benchmarkLevel / modelLevel 选档（可单测）。
 *  - queryDeviceBenchmark()：读 wx.getDeviceBenchmarkInfo（基础库 ≥ 3.4.5，异步），失败再退到
 *    wx.getDeviceInfo().benchmarkLevel、wx.getSystemInfoSync().benchmarkLevel；没有 wx（Web / 编辑器预览）= 未知。
 *  - applyGrassWindQuality()：给一组 MeshRenderer 换成“同一个”带新宏的共享材质 → GPU 实例化合批不被打断。
 *  - setGrassWindQualityOnInstance()：只对 MaterialInstance 用 recompileShaders（会脱离共享材质，单独一次 draw call）。
 *  - v1.1：setGrassWindParams()（改风参数，同步到各档运行时材质）、grassWindEvents（全局事件）、
 *    包围盒工具 grassWindBoundsPad() / meshMaxWindAmplitude() / applyGrassWindBounds()，MeadowInstancer 用它们防止草尖在屏幕边缘“突然出现”。
 *  - v1.2：getAppliedGrassWindQuality()（异步加载 / 新增草后补一次切档）；releaseGrassWindQualityMaterials()（区域卸载时销毁各档运行时材质副本）。
 *
 * 为什么不直接改共享材质的宏：3.8.8 的 Material.recompileShaders 只对 MaterialInstance 生效（共享 Material 上只打警告 16370），
 * Material.initialize 在已有 pass 时也会拒绝（警告 12005）。所以每档复制一份运行时 Material（Material.copy + defines 覆盖），按档缓存。
 *
 * 注意：
 *  1. 换材质后引擎会重建每个 subModel 的实例属性块（全 0），自定义实例属性（a_root_color）要重新 setInstancedAttribute，
 *     见 ApplyOptions.onReapplied 和 'grass-wind-quality-applied' 事件（v1.1 起 applyGrassWindQuality 每次都在全局 grassWindEvents 上发，
 *     GrassWindQualityAuto 另外在 target 节点上发）。
 *  2. 切档会触发新 shader 变体编译，微信上可能卡一帧，建议只在进场 / 设置界面切。
 */
import { _decorator, Component, EventTarget, gfx, Material, Mesh, MeshRenderer, Node, renderer, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

export enum GrassWindQuality { OFF = 0, LOW = 1, HIGH = 2 }

/** effect 资源名以此结尾的材质才会被处理（用户 effect 的 name 可能带目录前缀）。 */
export const GRASS_WIND_EFFECT_SUFFIX = 'meadow-grass-wind';
export const GRASS_WIND_QUALITY_EVENT = 'grass-wind-quality-applied';
/** v1.1：风参数（强度等）经 setGrassWindParams 改过后发出，参数 (baseMaterial)。 */
export const GRASS_WIND_PARAMS_EVENT = 'grass-wind-params-changed';
/** v1.1：全局事件通道。MeadowInstancer 在这里监听，不需要和 GrassWindQualityAuto 挂在同一个节点上。 */
export const grassWindEvents = new EventTarget();

export interface DeviceBenchmark {
  benchmarkLevel: number;      // -1 未知；>= 1 性能值（越高越好，移动端目前 < 50）；旧接口里 0 / -2 表示“无法运行”
  modelLevel: number;          // 0 未知；1 高；2 中；3 低（仅 getDeviceBenchmarkInfo 有；会随时间变化，只作参考）
  platform: string;            // 'ios' | 'android' | 'devtools' | 'windows' | 'mac' | 'web' ...
  source: 'getDeviceBenchmarkInfo' | 'getDeviceInfo' | 'getSystemInfoSync' | 'none';
}

/**
 * 分档阈值（微信《设备档位下的用户分布》2026-03-04 版：Android 高档 >= 30、中档 23–29；iOS 高档 >= 36、中档 30–35）。
 * 风动是顶点运算，草甸实例化后约 6.8 万顶点，低档机也只是几个 sin，所以只有“明确无法运行”才关。
 */
export const GRASS_WIND_THRESHOLDS = { androidHigh: 30, iosHigh: 36 };

export function pickGrassWindQuality (b: Partial<DeviceBenchmark> | null | undefined): GrassWindQuality {
  const level = b && typeof b.benchmarkLevel === 'number' && isFinite(b.benchmarkLevel) ? b.benchmarkLevel : -1;
  const platform = (b && b.platform ? String(b.platform) : '').toLowerCase();
  if (level === 0 || level === -2) return GrassWindQuality.OFF;           // 旧接口：设备无法运行小游戏
  if (level < 1) {                                                        // -1 / 未知 / 没有 wx → 低
    if (b && b.modelLevel === 1) return GrassWindQuality.HIGH;            // 档位已知是高档机时才升
    return GrassWindQuality.LOW;
  }
  const high = platform === 'ios' ? GRASS_WIND_THRESHOLDS.iosHigh : GRASS_WIND_THRESHOLDS.androidHigh;
  return level >= high ? GrassWindQuality.HIGH : GrassWindQuality.LOW;
}

declare const wx: any;

function wxApi (): any { return typeof wx !== 'undefined' && wx ? wx : null; }

function syncPlatform (w: any): string {
  try { if (typeof w.getDeviceInfo === 'function') return String(w.getDeviceInfo().platform || ''); } catch (e) { /* ignore */ }
  try { if (typeof w.getSystemInfoSync === 'function') return String(w.getSystemInfoSync().platform || ''); } catch (e) { /* ignore */ }
  return '';
}

function syncBenchmark (w: any): DeviceBenchmark {
  const platform = syncPlatform(w);
  try {
    if (typeof w.getDeviceInfo === 'function') {
      const lv = w.getDeviceInfo().benchmarkLevel;
      if (typeof lv === 'number') return { benchmarkLevel: lv, modelLevel: 0, platform, source: 'getDeviceInfo' };
    }
  } catch (e) { /* ignore */ }
  try {
    if (typeof w.getSystemInfoSync === 'function') {
      const lv = w.getSystemInfoSync().benchmarkLevel;
      if (typeof lv === 'number') return { benchmarkLevel: lv, modelLevel: 0, platform, source: 'getSystemInfoSync' };
    }
  } catch (e) { /* ignore */ }
  return { benchmarkLevel: -1, modelLevel: 0, platform, source: 'none' };
}

/** 读设备档位；永不 reject。timeoutMs 内 getDeviceBenchmarkInfo 没回调就退到同步接口。 */
export function queryDeviceBenchmark (timeoutMs = 800): Promise<DeviceBenchmark> {
  const w = wxApi();
  if (!w) return Promise.resolve({ benchmarkLevel: -1, modelLevel: 0, platform: 'web', source: 'none' });
  if (typeof w.getDeviceBenchmarkInfo !== 'function') return Promise.resolve(syncBenchmark(w));
  return new Promise<DeviceBenchmark>((resolve) => {
    let done = false;
    const finish = (b: DeviceBenchmark): void => { if (!done) { done = true; resolve(b); } };
    const timer = setTimeout(() => finish(syncBenchmark(w)), timeoutMs);
    try {
      w.getDeviceBenchmarkInfo({
        success: (res: any) => {
          clearTimeout(timer);
          const lv = typeof res?.benchmarkLevel === 'number' ? res.benchmarkLevel : -1;
          const ml = typeof res?.modelLevel === 'number' ? res.modelLevel : 0;
          finish({ benchmarkLevel: lv, modelLevel: ml, platform: syncPlatform(w), source: 'getDeviceBenchmarkInfo' });
        },
        fail: () => { clearTimeout(timer); finish(syncBenchmark(w)); },
      });
    } catch (e) { clearTimeout(timer); finish(syncBenchmark(w)); }
  });
}

export async function autoPickGrassWindQuality (): Promise<GrassWindQuality> {
  return pickGrassWindQuality(await queryDeviceBenchmark());
}

export function isGrassWindMaterial (m: Material | null | undefined): m is Material {
  return !!m && !!m.effectAsset && String(m.effectName || '').endsWith(GRASS_WIND_EFFECT_SUFFIX);
}

/** 当前材质第 0 个 pass 上的 WIND_QUALITY（没设过 = 0）。 */
export function getGrassWindQuality (m: Material): GrassWindQuality {
  const p = m.passes && m.passes[0];
  const v = p ? (p.defines as renderer.MacroRecord).WIND_QUALITY : 0;
  return (typeof v === 'number' ? v : Number(v) || 0) as GrassWindQuality;
}

const qualityCache = new Map<Material, Material[]>();   // v1.2：Map（可遍历，卸载时能找到并销毁）
const originalOf = new WeakMap<Material, Material>();
let appliedQuality: GrassWindQuality | null = null;

/** 最近一次 applyGrassWindQuality 用的档位（没切过 = null）。异步加载 / 新增草之后用它补一次 apply。 */
export function getAppliedGrassWindQuality (): GrassWindQuality | null { return appliedQuality; }

/** 取 base 材质在某档下的运行时共享材质（同一 base + 同一档始终返回同一个对象，保证实例化合批）。 */
export function getQualityMaterial (base: Material, q: GrassWindQuality): Material {
  const root = originalOf.get(base) || base;
  let list = qualityCache.get(root);
  if (!list) { list = []; qualityCache.set(root, list); }
  if (getGrassWindQuality(root) === q) return root;
  let m = list[q];
  if (!m) {
    m = new Material();
    m.copy(root, { defines: { WIND_QUALITY: q } });   // 复制属性 / 状态 / 其他宏，只覆盖 WIND_QUALITY
    m.name = `${root.name || 'grass'}#WIND_QUALITY=${q}`;
    originalOf.set(m, root);
    list[q] = m;
  }
  return m;
}

export interface ApplyOptions {
  /** 每个被换了材质的 renderer 回调一次，用来重新 setInstancedAttribute('a_root_color', ...)。 */
  onReapplied?: (r: MeshRenderer) => void;
}

/** 给一组 MeshRenderer 切档。返回实际换掉的材质槽数量。 */
export function applyGrassWindQuality (renderers: readonly MeshRenderer[], q: GrassWindQuality, opts: ApplyOptions = {}): number {
  let changed = 0;
  for (const r of renderers) {
    if (!r || !r.isValid) continue;
    let touched = false;
    const mats = r.sharedMaterials;
    for (let i = 0; i < mats.length; i++) {
      const m = mats[i];
      if (!isGrassWindMaterial(m)) continue;
      const target = getQualityMaterial(m, q);
      if (target !== m) { r.setSharedMaterial(target, i); changed++; touched = true; }
    }
    if (touched && opts.onReapplied) opts.onReapplied(r);
  }
  appliedQuality = q;
  grassWindEvents.emit(GRASS_WIND_QUALITY_EVENT, q, renderers);
  return changed;
}

/**
 * v1.2：区域卸载时调用。先把 restore 里还在用副本的 renderer 换回原材质，再 destroy() 各档运行时副本并清缓存。
 * base 不传 = 释放全部。原材质（资源）本身不动。返回销毁的副本数。
 */
export function releaseGrassWindQualityMaterials (base?: Material | null, restore: readonly MeshRenderer[] = []): number {
  const roots = base ? [originalOf.get(base) || base] : Array.from(qualityCache.keys());
  let n = 0;
  for (const root of roots) {
    const list = qualityCache.get(root);
    if (!list) continue;
    for (const r of restore) {
      if (!r || !r.isValid) continue;
      const mats = r.sharedMaterials;
      for (let i = 0; i < mats.length; i++) if (mats[i] && list.indexOf(mats[i]!) >= 0) { try { r.setSharedMaterial(root, i); } catch (e) { /* 节点正在销毁 */ } }
    }
    for (const m of list) {
      if (!m || m === root) continue;
      originalOf.delete(m);
      try { m.destroy(); n++; } catch (e) { console.warn('releaseGrassWindQualityMaterials: destroy failed', e); }
    }
    qualityCache.delete(root);
  }
  return n;
}

const materialUsers = new Map<Material, number>();   // v1.3：按原材质计数的使用者（多个区域共享同一草材质时）

/** v1.3：登记一个使用者（MeadowInstancer.start 调用）。返回登记后的使用者数。 */
export function retainGrassWindMaterial (m: Material): number {
  const root = originalOf.get(m) || m;
  const n = (materialUsers.get(root) || 0) + 1; materialUsers.set(root, n); return n;
}

/**
 * v1.3：注销一个使用者；**最后一个**使用者注销且 destroyWhenLast = true 时才 releaseGrassWindQualityMaterials（销毁各档副本）。
 * 返回销毁的副本数（还有别的使用者时为 0，不动副本）。没登记过的材质按“最后一个”处理。
 */
export function releaseGrassWindMaterialRef (m: Material, restore: readonly MeshRenderer[] = [], destroyWhenLast = true): number {
  const root = originalOf.get(m) || m;
  const n = (materialUsers.get(root) || 1) - 1;
  if (n > 0) { materialUsers.set(root, n); return 0; }
  materialUsers.delete(root);
  return destroyWhenLast ? releaseGrassWindQualityMaterials(root, restore) : 0;
}

/** v1.3：当前登记的使用者数（测试 / 调试用）。 */
export function grassWindMaterialUsers (m: Material): number { return materialUsers.get(originalOf.get(m) || m) || 0; }

/** base 材质 + 它已经生成的各档运行时材质（改参数时要一起改，否则切档后参数会退回旧值）。 */
export function getGrassWindMaterialFamily (m: Material): Material[] {
  const root = originalOf.get(m) || m;
  const out = [root];
  const list = qualityCache.get(root);
  if (list) for (const x of list) if (x && out.indexOf(x) < 0) out.push(x);
  return out;
}

/**
 * v1.1：改风参数（windStrength、amplitudeScale 等 effect 属性名），同步到所有档位的运行时材质，然后发 GRASS_WIND_PARAMS_EVENT，
 * MeadowInstancer 收到后重算包围盒。直接 setProperty 也能改画面，但包围盒不会跟着变。
 */
export function setGrassWindParams (m: Material, props: Record<string, Parameters<Material['setProperty']>[1]>): void {
  const family = getGrassWindMaterialFamily(m);
  for (const x of family) for (const k of Object.keys(props)) {
    try { x.setProperty(k, props[k]); } catch (e) { console.warn('setGrassWindParams: setProperty failed', k, e); }
  }
  grassWindEvents.emit(GRASS_WIND_PARAMS_EVENT, family[0]);
}

// ---------------------------------------------------------------- v1.1 包围盒（防止草尖被视锥剔除时“突然出现”）

export interface GrassWindBoundsParams {
  quality: number; windStrength: number; amplitudeScale: number;
  waveWeight: number; swayWeight: number; gustStrength: number; bendDrop: number;
}

/** effect 里的默认值；读不到 uniform 时用。 */
export const GRASS_WIND_DEFAULTS: GrassWindBoundsParams = {
  quality: 0, windStrength: 1.0, amplitudeScale: 1.5, waveWeight: 0.36, swayWeight: 0.26, gustStrength: 0.15, bendDrop: 0.3,
};

/** 从材质第 0 个 pass 读当前实际上传的风参数（含 effect 默认值，不只是 setProperty 过的）。 */
export function readGrassWindParams (m: Material): GrassWindBoundsParams {
  const out: GrassWindBoundsParams = { ...GRASS_WIND_DEFAULTS, quality: getGrassWindQuality(m) };
  const p = m.passes && m.passes[0];
  if (!p) return out;
  const keys: (keyof GrassWindBoundsParams)[] = ['windStrength', 'amplitudeScale', 'waveWeight', 'swayWeight', 'gustStrength', 'bendDrop'];
  for (const k of keys) {
    try {
      const h = p.getHandle(k);
      if (h) { const v = p.getUniform(h, 0 as number); if (typeof v === 'number' && isFinite(v)) out[k] = v; }
    } catch (e) { /* 保持默认值 */ }
  }
  return out;
}

/**
 * 风位移的上界（米，世界空间）。和 shader 一致：
 *   |d| ≤ |windStrength·amplitudeScale|·maxA·(|waveWeight| + [q2] |swayWeight| + |gustStrength|)，r ≤ 1
 *   水平位移 |d| 沿风向，竖直 |bendDrop·d·r| ≤ |bendDrop|·|d|  → 位移向量长度 ≤ |d|max·√(1+bendDrop²)
 * quality 0 → 0。返回 { horizontal, vertical, length }。
 */
export function grassWindMaxDisplacement (p: GrassWindBoundsParams, maxA: number): { horizontal: number; vertical: number; length: number } {
  if (!(p.quality > 0)) return { horizontal: 0, vertical: 0, length: 0 };
  const wsum = Math.abs(p.waveWeight) + (p.quality > 1 ? Math.abs(p.swayWeight) + Math.abs(p.gustStrength) : 0);
  const h = Math.abs(p.windStrength * p.amplitudeScale) * Math.max(0, maxA) * wsum;
  const v = Math.abs(p.bendDrop) * h;
  return { horizontal: h, vertical: v, length: Math.sqrt(h * h + v * v) };
}

/**
 * 模型本地包围盒每个方向要扩多少（本地单位）。世界空间位移长度 L 换到本地最多 L / 最小缩放；
 * WIND_SPACE 1（本地 +X）时位移本身就是本地单位，所以取 max(L, L / minScale)，两种空间都覆盖。另加 margin（默认 2%）。
 */
export function grassWindBoundsPad (p: GrassWindBoundsParams, maxA: number, minWorldScale: number, margin = 0.02): number {
  const L = grassWindMaxDisplacement(p, maxA).length;
  if (L <= 0) return 0;
  const s = Math.abs(minWorldScale);
  const k = s > 1e-6 ? Math.max(1, 1 / s) : 1;
  return L * k * (1 + margin);
}

const maxAmpCache = new WeakMap<Mesh, number>();

/** 网格 COLOR_0.a（a_color.w）的最大值，按网格缓存。读不到（没有顶点色 / 数据已释放 / 非归一化整数格式）就返回 1（a 的上限，保守）。 */
export function meshMaxWindAmplitude (mesh: Mesh | null | undefined): number {
  if (!mesh) return 1;
  const hit = maxAmpCache.get(mesh);
  if (hit !== undefined) return hit;
  let best = -1;
  try {
    const st = mesh.struct;
    for (let i = 0; i < st.primitives.length; i++) {
      let attr: gfx.Attribute | null = null;
      for (const bi of st.primitives[i].vertexBundelIndices) {
        const b = st.vertexBundles[bi];
        for (const a of b.attributes) if (a.name === gfx.AttributeName.ATTR_COLOR) attr = a;
      }
      if (!attr) continue;
      const info = gfx.FormatInfos[attr.format];
      const data = mesh.readAttribute(i, gfx.AttributeName.ATTR_COLOR);
      if (!info || !data || info.count < 4) { best = Math.max(best, 1); continue; }   // RGB 顶点色：glTF 规定 a = 1
      let scale = 1;
      if (info.type === gfx.FormatType.FLOAT || info.type === gfx.FormatType.UFLOAT) scale = 1;
      else if (attr.isNormalized || info.type === gfx.FormatType.UNORM || info.type === gfx.FormatType.SNORM) {
        const bits = (info.size / info.count) * 8;
        const signed = info.type === gfx.FormatType.SNORM || info.type === gfx.FormatType.INT;
        scale = 1 / (Math.pow(2, signed ? bits - 1 : bits) - 1);
      } else { best = Math.max(best, 1); continue; }                                // 非归一化整数：不知道含义，保守
      for (let k = 3; k < data.length; k += info.count) best = Math.max(best, data[k] * scale);
    }
  } catch (e) { best = -1; }
  const v = best >= 0 && isFinite(best) ? best : 1;
  maxAmpCache.set(mesh, v);
  return v;
}

function minAbsWorldScale (n: Node): number {
  const s = n.worldScale;
  return Math.min(Math.abs(s.x), Math.abs(s.y), Math.abs(s.z));
}

const tmpMin = new Vec3();
const tmpMax = new Vec3();

/**
 * 按当前风参数扩大 renderer 的模型包围盒（不是草材质 / quality 0 → 还原成网格原始包围盒）。
 * 返回本地 pad；model 还没创建（节点未激活）时返回 -1，等下次事件再算。
 * 注意：MeshRenderer 重新启用 / 换 mesh 时引擎会把包围盒重置为网格原值，需要再调一次。
 */
export function applyGrassWindBounds (r: MeshRenderer): number {
  try {
    const model = r && r.model; const mesh = r && r.mesh;
    if (!model || !mesh) return -1;
    const st = mesh.struct;
    if (!st || !st.minPosition || !st.maxPosition) return -1;
    let pad = 0;
    for (const m of r.sharedMaterials) {
      if (!isGrassWindMaterial(m)) continue;
      pad = Math.max(pad, grassWindBoundsPad(readGrassWindParams(m), meshMaxWindAmplitude(mesh), minAbsWorldScale(r.node)));
    }
    tmpMin.set(st.minPosition.x - pad, st.minPosition.y - pad, st.minPosition.z - pad);
    tmpMax.set(st.maxPosition.x + pad, st.maxPosition.y + pad, st.maxPosition.z + pad);
    model.createBoundingShape(tmpMin, tmpMax);
    model.updateWorldBound();
    return pad;
  } catch (e) {
    console.warn('applyGrassWindBounds failed', e);
    return -1;
  }
}

/** 只用于已经是 MaterialInstance 的材质（例如单独调试一丛草）。共享材质返回 false，不做任何事。 */
export function setGrassWindQualityOnInstance (m: Material, q: GrassWindQuality): boolean {
  if (!(m instanceof renderer.MaterialInstance)) return false;
  m.recompileShaders({ WIND_QUALITY: q });
  return true;
}

/**
 * 场景组件：start 时自动选档（或用 overrideQuality），对 target 下所有用 meadow-grass-wind 的 MeshRenderer 生效，
 * 然后在 target 节点上发 'grass-wind-quality-applied'(quality, renderers)（全局 grassWindEvents 上也会发），
 * MeadowInstancer 收到后重设 a_root_color 并重算包围盒。
 */
@ccclass('GrassWindQualityAuto')
export class GrassWindQualityAuto extends Component {
  @property(Node) target: Node | null = null;
  /** -1 = 自动；0 / 1 / 2 = 强制。 */
  @property overrideQuality = -1;

  static current: GrassWindQuality | null = null;
  static lastBenchmark: DeviceBenchmark | null = null;

  async start (): Promise<void> {
    let q: GrassWindQuality;
    if (this.overrideQuality >= 0 && this.overrideQuality <= 2) {
      q = this.overrideQuality as GrassWindQuality;
    } else {
      const b = await queryDeviceBenchmark();
      GrassWindQualityAuto.lastBenchmark = b;
      q = pickGrassWindQuality(b);
    }
    if (!this.isValid) return;
    this.apply(q);
  }

  apply (q: GrassWindQuality): number {
    const root = this.target || this.node;
    const rs = root.getComponentsInChildren(MeshRenderer);
    const n = applyGrassWindQuality(rs, q);
    GrassWindQualityAuto.current = q;
    root.emit(GRASS_WIND_QUALITY_EVENT, q, rs);
    return n;
  }
}
