import {_decorator,Component,director,MeshRenderer,gfx} from 'cc';
import {BakedGroundSwap,defaultGroundTextureLoader,GroundTextureLoader} from './BakedGroundTexture';
const {ccclass,property}=_decorator;
/**
 * SkyNightTexture.ts · E4 v1.3.3（grokbot2 / GGbot）· Cocos Creator 3.8.8 · 未在 Creator / 真机里运行过（not_run）
 *
 * 草甸夜空图按设备选一张加载（Grok Bot 定）：
 *  - 支持 ASTC → 2048×1024 夜空（v0.1a PNG 源，预设 e4-meadow-sky-night = ASTC 4×4 thorough，约 2.0 MiB）；
 *  - 不支持 ASTC（含检测失败）→ 单独的 1024×512 夜空（由 v0.1a 线性光降采样 + 轻抖动 + 保星生成，**不压缩**，RGBA8 约 2.0 MiB）。
 *    不用 ETC2（实测出色带）。Creator 的兜底格式只能和原图同尺寸，所以 1024 是另一个资源。
 * 检测方法和引擎自己挑 .astc 的判法一模一样（cocos/asset/assets/image-asset.ts _deserialize）：
 *   device.getFormatFeatures(gfx.Format.ASTC_RGBA_4X4) & gfx.FormatFeatureBit.SAMPLED_TEXTURE。
 *   引擎用 deviceManager.gfxDevice（@internal）；这里用公开的 director.root.device，两者是同一个设备对象（GrassFallback 查实例化也用它）。
 *   拿不到设备 / 调用抛异常 = 'unknown'，**按不支持处理**并 console.warn 一次（引擎在没有设备时也会跳过 .astc）。
 * 前提：mat_meadow_sky 的 nightTexture **留空**（材质直接引用会跟材质一起加载 2048 那张，不支持 ASTC 的设备就会加载 2048 PNG 兜底 = 8 MiB）。
 * 加载 / 释放沿用 BakedGroundSwap（v1.3.1 的按需加载生命周期）：onLoad 开始加载，加载完成前 nightTexture 保持原值（留空 = 黑色）；
 *   成功 → addRef 后贴到天空材质实例；onDestroy（区域卸载）→ 换回原值、decRef（引用归零由 assetManager 释放）；过期回调不贴、不泄漏。
 */
export type AstcSupport='yes'|'no'|'unknown';
export interface AstcDetection{support:AstcSupport;via:string;}
export const SKY_NIGHT_BUNDLE='region_meadow';
export const SKY_NIGHT_ASTC_PATH='textures/tex_meadow_sky_night_2048x1024/texture';
export const SKY_NIGHT_NOASTC_PATH='textures/tex_meadow_sky_night_1024x512/texture';

/** 查 ASTC 4×4 是否可采样。device 参数只给测试用；不传就用 director.root.device。 */
export function detectAstcSupport(device?:any):AstcDetection{
  try{
    const dev:any=device!==undefined?device:(director as any)?.root?.device;
    if(!dev||typeof dev.getFormatFeatures!=='function')return {support:'unknown',via:'没有 gfx 设备或没有 getFormatFeatures'};
    const f=dev.getFormatFeatures(gfx.Format.ASTC_RGBA_4X4);
    if(typeof f!=='number')return {support:'unknown',via:'getFormatFeatures 返回值不是数字'};
    return (f&gfx.FormatFeatureBit.SAMPLED_TEXTURE)?{support:'yes',via:'getFormatFeatures(ASTC_RGBA_4X4) 含 SAMPLED_TEXTURE'}:{support:'no',via:'getFormatFeatures(ASTC_RGBA_4X4) 不含 SAMPLED_TEXTURE'};
  }catch(e){return {support:'unknown',via:'检测抛异常：'+String(e)};}
}
/** 选择：只有明确支持 ASTC 才用 2048；no / unknown 都用 1024。 */
export function selectNightSkyPath(support:AstcSupport,astcPath=SKY_NIGHT_ASTC_PATH,noAstcPath=SKY_NIGHT_NOASTC_PATH):{variant:'astc2048'|'raw1024';path:string}{
  return support==='yes'?{variant:'astc2048',path:astcPath}:{variant:'raw1024',path:noAstcPath};
}

@ccclass('SkyNightTexture')
export class SkyNightTexture extends Component{
  @property(MeshRenderer) skyRenderer:MeshRenderer|null=null;
  @property materialIndex=0;
  @property textureProperty='nightTexture';
  @property bundleName=SKY_NIGHT_BUNDLE;
  @property astcPath=SKY_NIGHT_ASTC_PATH;
  @property noAstcPath=SKY_NIGHT_NOASTC_PATH;
  /** 测试 / 特殊加载方式用；默认 = BakedGroundTexture 的 assetManager 加载器。 */
  loader:GroundTextureLoader|null=null;
  /** 测试用：注入设备；undefined = director.root.device。 */
  device:any=undefined;
  detection:AstcDetection|null=null;
  selected:{variant:'astc2048'|'raw1024';path:string}|null=null;
  private swap:BakedGroundSwap|null=null;
  get state(){const s=this.swap;return s?{state:s.state,applied:s.applied,stats:s.stats}:null;}
  onLoad(){
    if(!this.skyRenderer){console.warn('SkyNightTexture: 没有指定 skyRenderer，不加载夜空图');return;}
    this.detection=detectAstcSupport(this.device);
    if(this.detection.support==='unknown')console.warn(`SkyNightTexture: ASTC 支持检测失败（${this.detection.via}），按不支持处理，加载 1024×512 未压缩夜空`);
    this.selected=selectNightSkyPath(this.detection.support,this.astcPath,this.noAstcPath);
    const self=this;
    const mi=()=>{const r:any=self.skyRenderer;return r?r.getMaterialInstance(self.materialIndex):null;};
    const target={
      valid:()=>!!self.skyRenderer&&self.skyRenderer.isValid,
      get:()=>{const m:any=mi();return m&&typeof m.getProperty==='function'?m.getProperty(self.textureProperty):null;},
      set:(tex:any)=>{const m:any=mi();if(m)m.setProperty(self.textureProperty,tex);},
    };
    this.swap=new BakedGroundSwap(target,this.loader||defaultGroundTextureLoader,this.bundleName,this.selected.path,'夜空贴图');
    this.swap.setWanted(true);
  }
  onDestroy(){if(this.swap){this.swap.dispose();this.swap=null;}}
}
