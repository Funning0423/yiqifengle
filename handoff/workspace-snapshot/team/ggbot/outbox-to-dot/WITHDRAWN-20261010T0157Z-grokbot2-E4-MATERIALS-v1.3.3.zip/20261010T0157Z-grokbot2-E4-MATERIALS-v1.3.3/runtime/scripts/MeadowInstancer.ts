import {_decorator,Component,Color,director,Director,JsonAsset,Material,Node,MeshRenderer,Quat,Vec3,Vec4} from 'cc';
import {applyGrassWindBounds,applyGrassWindQuality,getAppliedGrassWindQuality,grassWindEvents,GRASS_WIND_PARAMS_EVENT,GRASS_WIND_QUALITY_EVENT,isGrassWindMaterial,releaseGrassWindMaterialRef,releaseGrassWindQualityMaterials,retainGrassWindMaterial,setGrassWindParams} from './GrassWindQuality';
import {BAKED_GROUND_DEFAULT_BUNDLE,BAKED_GROUND_DEFAULT_PATH,BakedGroundSwap,defaultGroundTextureLoader,GroundTextureLoader} from './BakedGroundTexture';
import {FALLBACK_KEEP_RATIO,FLOWER_FALLBACK_KEEP_RATIO,FrameBudgetMonitor,PALETTE_MID_GREEN_SRGB,selectFallbackClumps,supportsInstancing,validateRootColors,XZ} from './GrassFallback';
const {ccclass,property}=_decorator;
/**
 * 原型（未在 Cocos 中编译/运行，not_run）：Cocos 3.8 导入器不读 EXT_mesh_gpu_instancing，
 * 导入后每个 `meadow_*_instances.N` 节点只会显示 1 个模板。本组件按 extract_gpu_instances.py 导出的 JSON
 * 把每组展开成 N 个 MeshRenderer 节点，共享同一 mesh + 同一材质；材质开启 USE_INSTANCING 后，
 * 引擎按“mesh+材质”自动合成 1 次实例化 draw call（每组 1 次）。
 * 草的 `_ROOT_COLOR` 通过实例属性 a_root_color 传给风 shader（需要自定义 effect 声明该属性）。
 * 挂在草甸模型根节点上，instances 绑定 region_meadow bundle 里的 meadow_instances JSON。
 * E4 v1.1：① 按风参数扩大每个实例的模型包围盒（风会把草尖推出网格原包围盒，屏幕边缘会“突然出现”）；
 * ② GrassWindQuality 切档换材质后引擎会清空实例属性，收到 'grass-wind-quality-applied' 后重设 a_root_color；
 * 两者在切档 / setGrassWindParams 改参数时都会重算。需要 GrassWindQuality.ts、GrassFallback.ts 放在同一目录。
 * E4 v1.2：③ _ROOT_COLOR 逐实例校验，缺失 / 非法填调色板中间绿；④ 展开节点挂在复制模板局部 TRS 的容器下；
 * ⑤ 展开后补 apply 当前画质档；⑥ 无硬件实例化兜底（草 30%、统一根色 #60AE32、超预算关草）；⑦ 卸载释放。
 * E4 v1.3（Oi v1.2 复审）：
 * ⑧ 兜底时花簇也减量：保留 round(N × 0.5)，与草同一套优先级规则（E4-12-01）；
 * ⑨ forceNoInstancing 真正切到非实例化材质分支：复制一份 USE_INSTANCING = false 的材质给展开节点用（E4-12-02）；
 * ⑩ 包围盒刷新改为每个 BEFORE_DRAW 检测本节点**最终 worldScale**（含所有祖先），变了才刷新（E4-12-03）；
 * ⑪ 多个区域共享同一草材质时按使用者计数，最后一个卸载才销毁各档副本。
 * E4 v1.3.1：
 * ⑫ 烘焙草色地面贴图改为“关草时才加载”（BakedGroundTexture.ts）：场景里不再直接引用贴图，只存 bundle + 路径；
 *    关草 → 加载（加载完之前地面保持原贴图）→ 换上；恢复草 / 区域卸载 → 换回原贴图并 decRef；加载失败保持原样；快速开关丢弃过期回调。
 * ⑬ 关草的原因：'budget'（无实例化兜底超预算，粘滞）、'manual'（setGrassOff 默认）；任一原因在 = 关草。
 *    'quality'（WIND_QUALITY 切到 OFF）只在 grassOffWhenWindQualityOff = true 时才算；v1.3.2 起默认 false：OFF 只停摆动，草照样显示。
 */
@ccclass('MeadowInstancer')
export class MeadowInstancer extends Component {
  @property(JsonAsset) instances:JsonAsset|null=null;
  /** 草和花都不投影（README 建议），省掉阴影 pass。 */
  @property castShadows=false;
  /** 无实例化兜底：草保留比例（美术定 0.3），保留数 = round(N × 比例)。 */
  @property fallbackKeepRatio=FALLBACK_KEEP_RATIO;
  /** 无实例化兜底：花簇保留比例（美术定 0.5），保留数 = round(N × 比例)。 */
  @property flowerKeepRatio=FLOWER_FALLBACK_KEEP_RATIO;
  /** 调试 / 验收：当作不支持实例化。展开节点改用 USE_INSTANCING = false 的材质副本（真正走 uniform 根色分支）。 */
  @property forceNoInstancing=false;
  /** 视点锚点名（草甸 GLB 里的节点）。镜头默认 / 区域视点定稿后加到 extraViews。 */
  @property([String]) viewAnchorNames:string[]=['player_spawn','region_interaction_point','windmill_door_point'];
  /** 额外视点（镜头位置或看向点的节点）。 */
  @property([Node]) extraViews:Node[]=[];
  /** 关草触发：每帧预算（ms）、窗口（s）、超预算帧占比。只在无实例化兜底模式下计。 */
  @property frameBudgetMs=40;
  @property budgetWindowSec=5;
  @property budgetOverRatio=0.8;
  /** v1.3.1：关草后给地面换的烘焙草色地面贴图，**只存位置不直接引用**（关草时才加载）。路径留空 = 只关草不换地面。 */
  @property bakedGroundBundle=BAKED_GROUND_DEFAULT_BUNDLE;
  @property bakedGroundTexturePath=BAKED_GROUND_DEFAULT_PATH;
  @property(MeshRenderer) groundRenderer:MeshRenderer|null=null;
  @property groundTextureProperty='mainTexture';
  /**
   * v1.3.2（Grok Bot 定）：默认 false = WIND_QUALITY OFF 只是草不摆动、照样显示；关全部草 + 换烘焙地面只走低端兜底的帧预算（budget）。
   * 设 true = v1.3.1 行为（OFF 也关草，切回 LOW / HIGH 恢复），仅留作调试 / 将来改主意用。
   */
  @property grassOffWhenWindQualityOff=false;
  /** 卸载时释放各档运行时材质副本（按使用者计数：共享同一草材质的最后一个 MeadowInstancer 卸载时才真正销毁）。 */
  @property releaseMaterialsOnDestroy=true;

  instancing=true;
  grassOff=false;
  /** 测试 / 自定义加载用；不设就用 assetManager（defaultGroundTextureLoader）。 */
  groundTextureLoader:GroundTextureLoader|null=null;
  readonly grassOffReasons=new Set<string>();
  private groundSwap:BakedGroundSwap|null=null;
  readonly report={rootColorMissing:0,rootColorInvalid:0,grassTotal:0,grassKept:0,flowerTotal:0,flowerKept:0,rule:'all' as string,forcedVariants:0};
  private spawned:Node[]=[];
  private wind:{r:MeshRenderer,c:number[]|null,grass:boolean}[]=[];
  private templates:MeshRenderer[]=[];
  private assetMaterials:Material[]=[];             // 模板节点原来的材质（资源，登记了使用者）
  private spawnMaterials:Material[]=[];             // 展开节点实际用的材质（= 资源，或强制非实例化时的副本）
  private forcedVariants=new Map<Material,Material>();
  private monitor:FrameBudgetMonitor|null=null;
  private boundsDirty=false;
  private lastScale:number[]|null=null;
  private listening=false;

  start(){
    const data:any=this.instances?.json;if(!data)throw Error('MeadowInstancer: bind instances JSON');
    this.instancing=!this.forceNoInstancing&&supportsInstancing();
    const q=new Quat(),p=new Vec3(),s=new Vec3(),c=new Vec4(),w=new Vec3();
    // 无实例化：草、花分别做一次确定性选择（同一套小路 / 视点优先级），保留数 = round(N × 比例)
    let keepMask:Map<string,boolean[]>|null=null;
    if(!this.instancing){
      keepMask=new Map();const path=this.pathPoints(),views=this.viewPoints();
      for(const grassPass of [true,false]){
        const clumps:XZ[]=[];const owners:{grp:any,i:number}[]=[];
        for(const grp of data.groups){
          if(this.isGrassGroup(grp)!==grassPass)continue;const src=this.find(this.node,grp.node);if(!src)continue;
          for(let i=0;i<grp.count;i++){this.localToWorld(src,grp,i,w);clumps.push({x:w.x,z:w.z});owners.push({grp,i});}
        }
        const sel=selectFallbackClumps(clumps,{keepRatio:grassPass?this.fallbackKeepRatio:this.flowerKeepRatio,path,views});
        owners.forEach((o,k)=>{let m=keepMask!.get(o.grp.node);if(!m){m=new Array(o.grp.count).fill(false);keepMask!.set(o.grp.node,m);}m[o.i]=sel.keep[k];});
        if(grassPass){this.report.grassTotal=clumps.length;this.report.grassKept=sel.kept;this.report.rule=sel.rule;}
        else{this.report.flowerTotal=clumps.length;this.report.flowerKept=sel.kept;}
      }
      console.warn(`MeadowInstancer: ${this.forceNoInstancing?'forceNoInstancing':'设备不支持实例化'}，草 ${this.report.grassKept}/${this.report.grassTotal}、花 ${this.report.flowerKept}/${this.report.flowerTotal}（${this.report.rule}），根色统一 #60AE32`);
      this.monitor=new FrameBudgetMonitor({budgetMs:this.frameBudgetMs,windowSec:this.budgetWindowSec,overRatio:this.budgetOverRatio});
    }
    for(const grp of data.groups){
      const src=this.find(this.node,grp.node);if(!src){console.warn('MeadowInstancer: missing node',grp.node);continue;}
      const mr=src.getComponent(MeshRenderer);if(!mr||!mr.mesh)continue;
      const grass=this.isGrassGroup(grp);
      const asset=mr.sharedMaterial!;
      if(asset&&this.assetMaterials.indexOf(asset)<0){this.assetMaterials.push(asset);if(isGrassWindMaterial(asset))retainGrassWindMaterial(asset);}
      const mat=asset&&this.forceNoInstancing?this.nonInstancedVariant(asset):asset;
      if(mat&&this.spawnMaterials.indexOf(mat)<0)this.spawnMaterials.push(mat);
      this.templates.push(mr);
      // 实例 TRS 相对模板节点：容器复制模板节点的局部 TRS，展开节点挂在容器下
      const holder=new Node(src.name+'_expanded');holder.layer=src.layer;src.parent!.addChild(holder);
      holder.setPosition(src.position);holder.setRotation(src.rotation);holder.setScale(src.scale);
      let roots:number[]|null=null;
      if(grass){
        const chk=validateRootColors(grp.attrs?._ROOT_COLOR,grp.count);roots=chk.colors;
        this.report.rootColorMissing+=chk.missing;this.report.rootColorInvalid+=chk.invalid;
        if(chk.missing||chk.invalid)console.warn(`MeadowInstancer: ${grp.node} _ROOT_COLOR 缺失 ${chk.missing} / 非法 ${chk.invalid}，已填调色板中间绿`);
      }
      const keep=keepMask?keepMask.get(grp.node):null;
      for(let i=0;i<grp.count;i++){
        if(keepMask&&!(keep&&keep[i]))continue;
        const n=new Node(grp.template+'_'+i);n.layer=src.layer;holder.addChild(n);
        p.set(grp.t[i*3],grp.t[i*3+1],grp.t[i*3+2]);n.setPosition(p);
        if(grp.r){q.set(grp.r[i*4],grp.r[i*4+1],grp.r[i*4+2],grp.r[i*4+3]);n.setRotation(q);}
        if(grp.s){s.set(grp.s[i*3],grp.s[i*3+1],grp.s[i*3+2]);n.setScale(s);}
        const r=n.addComponent(MeshRenderer);r.mesh=mr.mesh;r.setSharedMaterial(mat,0);
        r.shadowCastingMode=this.castShadows?MeshRenderer.ShadowCastingMode.ON:MeshRenderer.ShadowCastingMode.OFF; // 原型里的 renderer.scene.ShadowCastingMode 在 3.8.8 不存在（tsc 报错）
        let rc:number[]|null=null;
        if(roots&&this.instancing){c.set(roots[i*3],roots[i*3+1],roots[i*3+2],1);rc=[c.x,c.y,c.z,c.w];r.setInstancedAttribute('a_root_color',rc);}
        applyGrassWindBounds(r);
        this.wind.push({r,c:rc,grass});
        this.spawned.push(n);
      }
      this.spawned.push(holder);
      src.active=false; // 原始单个模板节点隐藏
    }
    if(!this.instancing){
      // 真实无实例化：引擎关掉 USE_INSTANCING（pass.ts _syncBatchingScheme）；强制模式：展开节点用的就是 USE_INSTANCING = false 的副本。
      // 两种情况 shader 都走 v_root = SRGBToLinear(rootColor)：把展开节点实际用的草材质 rootColor 设成调色板中间绿
      const g=PALETTE_MID_GREEN_SRGB;const col=new Color(Math.round(g[0]*255),Math.round(g[1]*255),Math.round(g[2]*255),255);
      for(const m of this.spawnMaterials)if(isGrassWindMaterial(m))setGrassWindParams(m,{rootColor:col});
    }
    grassWindEvents.on(GRASS_WIND_QUALITY_EVENT,this.onWindChanged,this);
    grassWindEvents.on(GRASS_WIND_QUALITY_EVENT,this.onQualityApplied,this);
    grassWindEvents.on(GRASS_WIND_PARAMS_EVENT,this.onWindChanged,this);
    // 包围盒刷新：每个 BEFORE_DRAW 比较本节点最终 worldScale（含祖先链），变了 / 重新启用 / 手动 markBoundsDirty 才刷新一次
    this.lastScale=this.readWorldScale();this.boundsDirty=false;
    if(!this.listening){director.on(Director.EVENT_BEFORE_DRAW,this.onBeforeDraw,this);this.listening=true;}
    // 已经切过档（自动画质组件先跑完 / 本区域异步加载）：对新展开的节点立即 apply 当前档（会触发 onWindChanged）
    const cur=getAppliedGrassWindQuality();
    if(cur!==null)applyGrassWindQuality(this.wind.map(x=>x.r),cur);
  }
  update(dt:number){
    if(this.monitor&&!this.grassOffReasons.has('budget')&&this.monitor.push(dt))this.setGrassOff(true,'budget');
  }
  /**
   * 关草（或恢复）。reason：'manual'（默认）/ 'budget' / 'quality'；reason = 'all' 且 off = false 时清掉所有原因。
   * 任一原因在 = 关草：禁用所有草的 renderer，开始按需加载烘焙地面贴图（加载完才换；见 BakedGroundTexture.ts）；
   * 全部原因清掉 = 恢复草，地面换回原贴图并释放烘焙贴图。状态变化时在本节点发 'meadow-grass-off'(off)。
   */
  setGrassOff(off:boolean,reason:string='manual'){
    if(off)this.grassOffReasons.add(reason);else if(reason==='all')this.grassOffReasons.clear();else this.grassOffReasons.delete(reason);
    const eff=this.grassOffReasons.size>0;
    const changed=eff!==this.grassOff;this.grassOff=eff;
    for(const w of this.wind)if(w.grass&&w.r.isValid)w.r.enabled=!eff;
    const swap=this.ensureGroundSwap();if(swap)swap.setWanted(eff);
    if(changed)this.node.emit('meadow-grass-off',eff);
  }
  /** 当前烘焙地面贴图状态（测试 / 调试面板用）。 */
  get groundTextureState(){const g=this.groundSwap;return g?{state:g.state,applied:g.applied,stats:g.stats}:null;}
  private onQualityApplied(q:number){
    if(!this.grassOffWhenWindQualityOff)return;
    this.setGrassOff(q===0,'quality');
  }
  private ensureGroundSwap():BakedGroundSwap|null{
    if(this.groundSwap)return this.groundSwap;
    if(!this.bakedGroundTexturePath||!this.groundRenderer)return null;
    const self=this;
    const target={
      valid:()=>!!self.groundRenderer&&self.groundRenderer.isValid,
      get:()=>{const mi:any=self.groundRenderer!.getMaterialInstance(0);return mi&&typeof mi.getProperty==='function'?mi.getProperty(self.groundTextureProperty):null;},
      set:(tex:any)=>{const mi:any=self.groundRenderer!.getMaterialInstance(0);if(mi)mi.setProperty(self.groundTextureProperty,tex);},
    };
    this.groundSwap=new BakedGroundSwap(target,this.groundTextureLoader||defaultGroundTextureLoader,this.bakedGroundBundle,this.bakedGroundTexturePath);
    return this.groundSwap;
  }
  /** 切档 / 改风参数 / 缩放变化 / 重新启用后：重设每实例根色（换材质会清空实例属性），按新参数重算包围盒。单个失败不影响其他。 */
  onWindChanged(){
    for(const w of this.wind){
      if(!w.r.isValid)continue;
      try{if(w.c)w.r.setInstancedAttribute('a_root_color',w.c);}catch(e){console.warn('MeadowInstancer: a_root_color',e);}
      applyGrassWindBounds(w.r);
    }
  }
  /** 外部改了展开节点的 mesh / 缩放等本组件看不到的东西时调用：下一个 BEFORE_DRAW 刷新一次。 */
  markBoundsDirty(){this.boundsDirty=true;}
  onEnable(){this.boundsDirty=true;}
  private readWorldScale():number[]{const s=this.node.worldScale;return [s.x,s.y,s.z];}
  private onBeforeDraw(){
    if(!this.isValid||this.wind.length===0)return;
    const s=this.readWorldScale(),l=this.lastScale;
    if(!l||Math.abs(s[0]-l[0])>1e-6||Math.abs(s[1]-l[1])>1e-6||Math.abs(s[2]-l[2])>1e-6){this.lastScale=s;this.boundsDirty=true;}
    if(this.boundsDirty){this.boundsDirty=false;this.onWindChanged();}
  }
  /** 强制非实例化：资源材质的副本，只把 USE_INSTANCING 关掉（其余宏 / 属性照抄），本组件拥有并在卸载时销毁。 */
  private nonInstancedVariant(base:Material):Material{
    let v=this.forcedVariants.get(base);
    if(!v){v=new Material();v.copy(base,{defines:{USE_INSTANCING:false}});v.name=`${base.name||'mat'}#NO_INSTANCING`;this.forcedVariants.set(base,v);this.report.forcedVariants++;}
    return v;
  }
  private isGrassGroup(grp:any):boolean{return String(grp.template||'').startsWith('grass_')||!!grp.attrs?._ROOT_COLOR;}
  private localToWorld(src:Node,grp:any,i:number,out:Vec3){
    out.set(grp.t[i*3],grp.t[i*3+1],grp.t[i*3+2]);
    // 实例相对模板节点：world = src.worldMatrix × t
    Vec3.transformMat4(out,out,src.worldMatrix);
  }
  private pathPoints():XZ[]{
    const pts:{k:number,x:number,z:number}[]=[];
    const walk=(n:Node)=>{const m=/^walk_path_(\d+)$/.exec(n.name);if(m){const w=n.worldPosition;pts.push({k:+m[1],x:w.x,z:w.z});}for(const c of n.children)walk(c);};
    walk(this.node);pts.sort((a,b)=>a.k-b.k);return pts.map(p=>({x:p.x,z:p.z}));
  }
  private viewPoints():XZ[]{
    const out:XZ[]=[];
    for(const name of this.viewAnchorNames){const n=this.find(this.node,name);if(n){const w=n.worldPosition;out.push({x:w.x,z:w.z});}}
    for(const n of this.extraViews)if(n&&n.isValid){const w=n.worldPosition;out.push({x:w.x,z:w.z});}
    return out;
  }
  private find(n:Node,name:string):Node|null{if(n.name===name)return n;for(const c of n.children){const f=this.find(c,name);if(f)return f;}return null;}
  onDestroy(){
    grassWindEvents.targetOff(this);director.targetOff(this);this.listening=false;
    // v1.3.1：区域卸载 → 地面换回原贴图、释放烘焙贴图、作废进行中的加载回调
    if(this.groundSwap){this.groundSwap.dispose();this.groundSwap=null;}
    // 先停用（立即把模型移出场景）再 destroy：destroy 是延迟到下一帧 _deferredDestroy 的（core/data/object.ts 173–187），
    // 不停用的话本帧还会用下面刚销毁的材质副本去画
    for(const n of this.spawned)if(n.isValid){n.active=false;n.destroy();}
    // 强制非实例化的副本归本组件所有：先销毁它们的各档副本，再销毁它们自己
    this.forcedVariants.forEach((v)=>{releaseGrassWindQualityMaterials(v);try{v.destroy();}catch(e){console.warn('MeadowInstancer: destroy variant',e);}});
    this.forcedVariants.clear();
    // 资源材质的各档副本：按使用者计数，最后一个使用者才销毁（多区域共享同一草材质时不误删别人的）
    for(const m of this.assetMaterials)if(isGrassWindMaterial(m))releaseGrassWindMaterialRef(m,this.templates,this.releaseMaterialsOnDestroy);
    this.spawned=[];this.wind=[];this.templates=[];this.assetMaterials=[];this.spawnMaterials=[];
  }
}
