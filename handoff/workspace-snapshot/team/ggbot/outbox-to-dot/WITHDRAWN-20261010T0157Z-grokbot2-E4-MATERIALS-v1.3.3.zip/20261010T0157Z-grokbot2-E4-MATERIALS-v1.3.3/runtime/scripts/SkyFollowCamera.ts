/**
 * SkyFollowCamera.ts · E4 v1.3（grokbot2 / GGbot）· Cocos Creator 3.8.8 · 未在 Creator / 真机里运行过（not_run）
 *
 * 让天空球节点的世界 X/Z 每帧等于相机的世界 X/Z（Y、UV、美术资源不动），这样 CPU 侧的包围盒跟着相机走，天空不会被视锥剔除整片剔掉
 * （Oi 审查 #1：sky-unlit 的 SKY_FOLLOW_CAMERA 只在 GPU 上移位置，节点 worldBounds 还在原处）。
 *
 * 为什么挂在 director EVENT_BEFORE_DRAW，而不是 lateUpdate（依据 3.8.8 源码 cocos/game/director.ts tick()）：
 *   BEGIN_FRAME → 输入 → BEFORE_UPDATE → startPhase → 组件 update → 各 System.update（AnimationManager：cine_camera 烘焙动画在这里写节点）
 *   → 组件 lateUpdate → AFTER_UPDATE → 延迟销毁 → 各 System.postUpdate（物理同步等）→ **BEFORE_DRAW** → UI 脏渲染器 → root.frameMove(dt)
 *   root.frameMove → _frameMoveProcess：scenes[i].update(stamp)（模型 updateTransform → worldBounds、相机矩阵）→ BEFORE_COMMIT
 *   → BEFORE_RENDER → pipeline.render（视锥剔除用 worldBounds）。
 *   用 lateUpdate 不可靠：同在 lateUpdate 的相机写入者和本组件谁先谁后取决于 executionOrder；之后还有 AFTER_UPDATE 监听、System.postUpdate 可能写相机。
 *   BEFORE_DRAW 是 scene.update 之前最后一个公开钩子，所有组件 / 动画 / 系统的写入都已完成。
 *   0007 v1.3（sim13 7bd6342）的相机写入者 applyCameraPose 由 WorldFlowComponent.update（组件 update 阶段）和 Promise 回调
 *   （微任务，在两帧之间）调用；运镜 cine_camera 烘焙动画走 AnimationManager.update。都早于 BEFORE_DRAW。
 * 仍可能更晚的写入：别的 BEFORE_DRAW 监听（注册在本组件之后）。对策：写完后调用 SkyFollowCamera.syncAll()；
 *   本组件在 EVENT_BEFORE_COMMIT（scene.update 之后）核对相机 XZ 是否在同步之后又变了，变了就计数并警告一次（lateWrites）。
 *
 * 接入合同（v1.3）：凡是在 BEFORE_DRAW 监听里写相机（或相机祖先）的代码，写完必须在同一个监听里调用 SkyFollowCamera.syncAll()，
 *   也就是在 root.frameMove → scene.update 之前。verify 只计数 + 警告，**不修正**：到 BEFORE_COMMIT 时 scene.update 已经算完包围盒，
 *   那一帧天空可能已被 CPU 剔除，被剔除的模型 shader 根本不跑，GPU 偏移救不回来。
 * 与 GPU 跟随的关系：sky-unlit SKY_FOLLOW_CAMERA = 1 时 shader 做 worldPos.xz += cc_cameraPos.xz − matWorld[3].xz。
 *   本组件把节点放到相机 XZ 后，这个偏移 = 0，不会重复位移。GPU 偏移只在模型没被剔除时起作用，不是剔除兜底。
 * 多相机限制：只跟随一个相机。第二个相机若离被跟随相机很远，可能看不到天空（被它自己的视锥剔除）；
 *   需要时给第二个相机单独一个天空节点（各自挂 SkyFollowCamera，用 layer / visibility 分开），本组件不处理。
 */
import { _decorator, Camera, Component, director, Director, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('SkyFollowCamera')
export class SkyFollowCamera extends Component {
  /** 要跟随的相机节点。不填 = 场景里第一个启用的 Camera（按 priority 最小）。 */
  @property(Node) cameraNode: Node | null = null;
  /** 只跟 XZ（默认）。天空球 Y 保持美术位置。 */
  @property followY = false;
  /** 在 BEFORE_COMMIT 核对有没有更晚的相机写入（调试用，开销是一次读坐标）。 */
  @property verifyLateWrites = true;

  static readonly active = new Set<SkyFollowCamera>();
  /** 在 BEFORE_DRAW 里写相机的代码，写完调用它。 */
  static syncAll (): void { SkyFollowCamera.active.forEach((s) => s.sync()); }

  lateWrites = 0;
  private lastX = NaN; private lastZ = NaN; private warned = false;

  onEnable (): void {
    director.on(Director.EVENT_BEFORE_DRAW, this.sync, this);
    if (this.verifyLateWrites) director.on(Director.EVENT_BEFORE_COMMIT, this.verify, this);
    SkyFollowCamera.active.add(this);
    this.sync();
  }

  onDisable (): void {
    director.off(Director.EVENT_BEFORE_DRAW, this.sync, this);
    director.off(Director.EVENT_BEFORE_COMMIT, this.verify, this);
    SkyFollowCamera.active.delete(this);
  }

  private resolveCamera (): Node | null {
    if (this.cameraNode && this.cameraNode.isValid) return this.cameraNode;
    const scene = director.getScene();
    if (!scene) return null;
    let best: Camera | null = null;
    for (const c of scene.getComponentsInChildren(Camera)) if (c.enabledInHierarchy && (!best || c.priority < best.priority)) best = c;
    return best ? best.node : null;
  }

  /** 把天空节点世界 X/Z（和可选 Y）设成相机的。读 worldPosition 会先刷新脏的世界变换。 */
  sync (): void {
    try {
      const cam = this.resolveCamera();
      if (!cam || !this.node.isValid) return;
      const c = cam.worldPosition, p = this.node.worldPosition;
      this.lastX = c.x; this.lastZ = c.z;
      const y = this.followY ? c.y : p.y;
      if (p.x !== c.x || p.z !== c.z || p.y !== y) this.node.setWorldPosition(c.x, y, c.z);
    } catch (e) { console.warn('SkyFollowCamera.sync failed', e); }
  }

  private verify (): void {
    const cam = this.resolveCamera();
    if (!cam) return;
    const c = cam.worldPosition;
    if (Math.abs(c.x - this.lastX) > 1e-4 || Math.abs(c.z - this.lastZ) > 1e-4) {
      this.lateWrites++;
      if (!this.warned) { this.warned = true; console.warn('SkyFollowCamera: 相机在 BEFORE_DRAW 同步之后又被写了（本帧天空包围盒可能落后），写入方请在写完后调用 SkyFollowCamera.syncAll()'); }
    }
  }
}
