'use strict';
// E4 v1.3.1 / v1.3.2 Node 测试（v1.3.2：I7 改为“OFF 默认不关草”、新增 I10 帧预算端到端、I7 另对照 v1.3.1 原文件）：
//  i-ground-ondemand  烘焙草色地面贴图按需加载（BakedGroundTexture.ts + MeadowInstancer）：I1–I7 在 v1.3.1 上必须通过；
//  i-ground-control   同一组 I1–I7 跑在 v1.3 原代码（controls/v1.3-runtime-scripts，v1.3 包里的原文件）上必须失败 = 证明测试能抓到旧行为；
//  j-art-v081         美术 v0.8.1 贴图核对（ground-tex-check.py：尺寸 / UV 公式 / 朝向）；
//  k-meadow-pose      草甸位姿过 0007 真实 CameraPose.ts（meadow-pose-test.mjs）。
const fs = require('fs'), ps = require('path'), cp = require('child_process');
const makeCC = require('./cc-stub');

module.exports = async function run (ctx) {
  const { ts, rec, INST, HERE } = ctx;
  const NEW = ps.join(HERE, '../../runtime/scripts'), OLD = ps.join(HERE, 'controls/v1.3-runtime-scripts');
  const G = 'i-ground-ondemand', GC = 'i-ground-control';
  if (!fs.existsSync(INST)) { rec(G, '按需加载测试', null, `找不到 ${INST}`); return; }
  const inst = JSON.parse(fs.readFileSync(INST, 'utf8'));
  const isGrass = (g) => String(g.template || '').startsWith('grass_') || !!(g.attrs && g.attrs._ROOT_COLOR);
  const groups = [inst.groups.find(isGrass), inst.groups.find(g => !isGrass(g))];

  class FakeTex { constructor (n) { this.name = n; this.refCount = 0; this.addRefs = 0; this.decRefs = 0; } addRef () { this.refCount++; this.addRefs++; return this; } decRef () { this.refCount--; this.decRefs++; if (this.refCount < 0) throw Error('decRef below 0: ' + this.name); return this; } }
  // 可控加载器：记下请求，测试决定何时 / 以什么结果回调
  const makeLoader = () => { const reqs = []; const f = (bundle, path, done) => reqs.push({ bundle, path, done }); f.reqs = reqs; return f; };

  // impl = 'new'（v1.3.1，按需加载）| 'old'（v1.3：场景直接引用 bakedGroundTexture，setGrassOff 立即换）
  const build = (dir, impl, opts = {}) => {
    const env = makeCC({ instancing: opts.instancing !== false }); const { cc } = env; const S = makeCC.loadScripts(ts, dir, cc, ['GrassWindQuality', 'GrassFallback', 'MeadowInstancer']);
    const { Node, MeshRenderer, Material, Vec3 } = cc;
    const base = new Material(); Object.assign(base.passes[0].defines, { WIND_QUALITY: 2, USE_INSTANCING: true, USE_INSTANCE_ROOT_COLOR: true });
    const flowerMat = new Material(); flowerMat.effectName = 'builtin-standard';
    const root = new Node('meadow_root');
    const mesh = (n) => ({ name: n, struct: { minPosition: new Vec3(-0.3, 0, -0.3), maxPosition: new Vec3(0.3, 0.6, 0.3), primitives: [], vertexBundles: [] }, readAttribute: () => null });
    const data = { groups: JSON.parse(JSON.stringify(groups)) };
    for (const g of data.groups) { const n = new Node(g.node); root.addChild(n); const r = n.addComponent(MeshRenderer); r.mesh = mesh(g.template); r.setSharedMaterial(isGrass(g) ? base : flowerMat, 0); }
    const origTex = new FakeTex('meadow_ground_v0_8_1024'); const gm = new Material(); gm.effectName = 'builtin-standard'; gm.props.mainTexture = origTex;
    const ground = new Node('meadow_terrain'); root.addChild(ground); const gr = ground.addComponent(MeshRenderer); gr.mesh = mesh('ground'); gr.setSharedMaterial(gm, 0);
    const comp = new S.MeadowInstancer.MeadowInstancer(); comp.node = root; comp.instances = { json: data };
    Object.assign(comp, { castShadows: false, fallbackKeepRatio: 0.3, flowerKeepRatio: 0.5, forceNoInstancing: false, viewAnchorNames: [], extraViews: [], frameBudgetMs: 40, budgetWindowSec: 5, budgetOverRatio: 0.8,
      groundRenderer: gr, groundTextureProperty: 'mainTexture', releaseMaterialsOnDestroy: true }, opts.props || {});
    const loader = makeLoader(); const texs = [];
    const nextTex = () => { const t = new FakeTex('tex_meadow_ground_grassoff_1024#' + texs.length); texs.push(t); return t; };
    if (impl === 'new') { comp.groundTextureLoader = opts.loader || loader; }
    else { comp.bakedGroundTexture = nextTex(); }        // v1.3：唯一能拿到贴图的方式 = 场景里直接拖引用（随场景加载）
    const warns = []; const w = console.warn; console.warn = (...a) => warns.push(a.map(String).join(' '));
    try { comp.start(); } finally { console.warn = w; }
    const groundTex = () => (gr.instances && gr.instances[0] ? gr.instances[0].props.mainTexture : gm.props.mainTexture);
    const flowerRs = () => root.children.filter(n => /_expanded$/.test(n.name)).flatMap(h => h.children).filter(n => !n.name.startsWith('grass_')).map(n => n.getComponent(MeshRenderer));
    const grassRs = () => root.children.filter(n => /_expanded$/.test(n.name)).flatMap(h => h.children).filter(n => n.name.startsWith('grass_')).map(n => n.getComponent(MeshRenderer));
    const call = (f) => { const w2 = console.warn; console.warn = (...a) => warns.push(a.map(String).join(' ')); try { return f(); } finally { console.warn = w2; } };
    return { cc, S, comp, gr, root, origTex, flowerRs, loader, texs, nextTex, groundTex, grassRs, warns, call, impl };
  };
  const resolve = (T, i, tex) => T.call(() => T.loader.reqs[i].done(null, tex));
  const fail = (T, i) => T.call(() => T.loader.reqs[i].done(new Error('404 tex_meadow_ground_grassoff_1024'), null));
  const allZero = (T) => T.texs.every(t => t.refCount === 0);

  // 每个用例返回 {ok, why}；why 列出没满足的条件（旧代码失败时说明抓到的是哪一条）
  const check = (conds) => { const bad = Object.entries(conds).filter(([, v]) => !v).map(([k]) => k); return { ok: bad.length === 0, why: bad.length ? '未满足：' + bad.join('；') : '全部满足' }; };
  const cases = [
    ['I1 场景不直接引用烘焙贴图、进场（草开着）不加载：组件上没有贴图引用，加载器 0 次，贴图引用计数 0；源码里没有 @property(Texture2D)', (dir, impl) => {
      const T = build(dir, impl); const src = fs.readFileSync(ps.join(dir, 'MeadowInstancer.ts'), 'utf8');
      return check({ '组件属性里没有贴图对象': !Object.values(T.comp).some(v => v instanceof FakeTex), '进场加载 0 次': T.loader.reqs.length === 0, '源码无 @property(Texture2D)': !/@property\(\s*Texture2D\s*\)/.test(src), '地面是原贴图': T.groundTex() === T.origTex });
    }],
    ['I2 关草才加载，加载完成前地面保持原贴图；完成后换上并 addRef（引用 1），bundle / 路径 = region_meadow / textures/tex_meadow_ground_grassoff_1024/texture', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); const n = T.loader.reqs.length; const before = T.groundTex(); const grassOff = T.grassRs().every(r => r.enabled === false);
      let after = null, tex = null; if (n === 1) { tex = T.nextTex(); resolve(T, 0, tex); after = T.groundTex(); }
      const r0 = T.loader.reqs[0] || {};
      return check({ '关草后发起 1 次加载': n === 1, '加载中地面仍是原贴图': before === T.origTex, '草 renderer 已全部禁用': grassOff, '加载完成后地面 = 烘焙贴图': !!tex && after === tex, '引用计数 1': !!tex && tex.refCount === 1, '默认 bundle/路径': r0.bundle === 'region_meadow' && r0.path === 'textures/tex_meadow_ground_grassoff_1024/texture', 'state=applied': T.comp.groundTextureState && T.comp.groundTextureState.state === 'applied' });
    }],
    ['I3 恢复草：地面换回原贴图，烘焙贴图 decRef 到 0（交还 assetManager 释放）', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); if (T.loader.reqs.length) resolve(T, 0, T.nextTex());
      T.call(() => T.comp.setGrassOff(false));
      return check({ '地面 = 原贴图': T.groundTex() === T.origTex, '所有烘焙贴图引用 0': allZero(T), '有过 decRef': T.texs.some(t => t.decRefs > 0), '草 renderer 恢复': T.grassRs().every(r => r.enabled !== false) });
    }],
    ['I4 加载失败：地面保持原贴图、console.warn、state=failed、无引用；草仍关着；再次关草会重试并成功', (dir, impl) => {
      const T = build(dir, impl); T.call(() => T.comp.setGrassOff(true)); const n1 = T.loader.reqs.length; if (n1) fail(T, 0);
      const st = T.comp.groundTextureState; const kept = T.groundTex() === T.origTex; const warned = T.warns.some(m => /加载失败/.test(m)); const stillOff = T.grassRs().every(r => r.enabled === false);
      T.call(() => { T.comp.setGrassOff(false); T.comp.setGrassOff(true); }); const n2 = T.loader.reqs.length; let tex = null; if (n2 === 2) { tex = T.nextTex(); resolve(T, 1, tex); }
      return check({ '发起了加载': n1 === 1, '失败后地面 = 原贴图': kept, 'warn': warned, 'state=failed': !!st && st.state === 'failed' && st.stats.failed === 1, '草仍关': stillOff, '重试发起第 2 次加载': n2 === 2, '重试成功换上': !!tex && T.groundTex() === tex && tex.refCount === 1 });
    }],
    ['I5 快速开关（关/开/关/开/关，回调乱序 3→1→2 到达）：只有最后一次请求的贴图贴上（引用 1），过期的 2 张 addRef 后立刻 decRef（引用 0）；再开草全部归 0；关→开后回调才到：地面不变、引用 0', (dir, impl) => {
      const T = build(dir, impl); T.call(() => { T.comp.setGrassOff(true); T.comp.setGrassOff(false); T.comp.setGrassOff(true); T.comp.setGrassOff(false); T.comp.setGrassOff(true); });
      const n = T.loader.reqs.length; let t1, t2, t3; let midOk = false, finalOk = false;
      if (n === 3) { t1 = T.nextTex(); t2 = T.nextTex(); t3 = T.nextTex(); const beforeAny = T.groundTex() === T.origTex; resolve(T, 2, t3); resolve(T, 0, t1); resolve(T, 1, t2);
        midOk = beforeAny && T.groundTex() === t3 && t3.refCount === 1 && t1.refCount === 0 && t2.refCount === 0 && T.comp.groundTextureState.stats.stale === 2; }
      T.call(() => T.comp.setGrassOff(false)); const back = T.groundTex() === T.origTex && allZero(T);
      T.call(() => { T.comp.setGrassOff(true); T.comp.setGrassOff(false); }); const m = T.loader.reqs.length; if (m === n + 1) { const t4 = T.nextTex(); resolve(T, m - 1, t4); finalOk = T.groundTex() === T.origTex && t4.refCount === 0; }
      return check({ '3 次关草 = 3 次加载': n === 3, '乱序回调后只贴最后一次请求的贴图、过期的引用 0': midOk, '开草后原贴图且全部引用 0': back, '开草后才到的回调被丢弃': finalOk });
    }],
    ['I6 区域卸载（onDestroy）：加载中卸载 → 之后的回调不写地面、贴图引用 0；已换上时卸载 → 地面换回原贴图、引用 0', (dir, impl) => {
      const A = build(dir, impl); A.call(() => A.comp.setGrassOff(true)); const nA = A.loader.reqs.length; A.call(() => A.comp.onDestroy()); let aOk = false;
      if (nA === 1) { const t = A.nextTex(); resolve(A, 0, t); aOk = A.groundTex() === A.origTex && t.refCount === 0; }
      const B = build(dir, impl); B.call(() => B.comp.setGrassOff(true)); if (B.loader.reqs.length) resolve(B, 0, B.nextTex()); const applied = B.groundTex() !== B.origTex; B.call(() => B.comp.onDestroy());
      return check({ '加载中卸载：发起过加载': nA === 1, '加载中卸载：回调不写地面、引用 0': aOk, '已换上后卸载：换回原贴图': applied && B.groundTex() === B.origTex, '已换上后卸载：引用 0': allZero(B) && B.texs.some(t => t.decRefs > 0) });
    }],
    ['I7（v1.3.2）WIND_QUALITY OFF 默认只停摆动：草 renderer 全部仍显示、grassOff=false、不加载烘焙地面、地面原贴图；切 LOW / HIGH / OFF 来回同样；grassOffWhenWindQualityOff 默认 false。设 true 时仍是 v1.3.1 行为（OFF 关草 + 加载，切回 LOW 恢复并释放）', (dir, impl) => {
      const T = build(dir, impl); const rs = T.grassRs(); const Q = T.S.GrassWindQuality;
      T.call(() => { Q.applyGrassWindQuality(rs, 0); }); const offVisible = rs.length > 0 && rs.every(r => r.enabled !== false) && !T.comp.grassOff && T.loader.reqs.length === 0 && T.groundTex() === T.origTex;
      T.call(() => { Q.applyGrassWindQuality(rs, 2); Q.applyGrassWindQuality(rs, 1); Q.applyGrassWindQuality(rs, 0); }); const cycle = rs.every(r => r.enabled !== false) && T.loader.reqs.length === 0 && !T.comp.grassOff;
      const O = build(dir, impl, { props: { grassOffWhenWindQualityOff: true } }); const ors = O.grassRs(); O.call(() => O.S.GrassWindQuality.applyGrassWindQuality(ors, 0)); const optIn = ors.every(r => r.enabled === false) && O.loader.reqs.length === 1;
      if (O.loader.reqs.length) resolve(O, 0, O.nextTex()); O.call(() => O.S.GrassWindQuality.applyGrassWindQuality(ors, 1)); const optBack = ors.every(r => r.enabled !== false) && O.groundTex() === O.origTex && allZero(O);
      return check({ '默认值 grassOffWhenWindQualityOff = false': T.comp.grassOffWhenWindQualityOff === false, 'OFF：草仍显示、不加载、地面原贴图': offVisible, 'HIGH/LOW/OFF 来回：草一直显示、0 次加载': cycle, '设 true：OFF 关草 + 加载': optIn, '设 true：LOW 恢复、原贴图、引用 0': optBack });
    }],
    ['I10（v1.3.2）低端兜底帧预算是唯一的自动关草路径（无实例化设备，FrameBudgetMonitor 40 ms / 5 s / 80%）：前 10 s 60 fps（中途切 OFF 也不关）不关草、不加载；之后每帧 50 ms，在 13.5–15.5 s 触发：保留下来的草 renderer 全部禁用、花不受影响、发 meadow-grass-off(true) 一次、发起 1 次加载、加载完成前地面原贴图、完成后换成烘焙贴图（引用 1）；之后切 HIGH / OFF、继续慢帧都不恢复也不再加载；手动 setGrassOff(false) 不解除 budget；有实例化的设备同样帧序列不装监视器、不关草、不加载', (dir, impl) => {
      const T = build(dir, impl, { instancing: false }); const rs = T.grassRs(), fs2 = T.flowerRs(); const Q = T.S.GrassWindQuality; const evs = []; T.root.on('meadow-grass-off', (v) => evs.push(v), null);
      let t = 0; for (let i = 0; i < 600; i++) { T.call(() => T.comp.update(1 / 60)); t += 1 / 60; if (i === 300) T.call(() => Q.applyGrassWindQuality(rs, 0)); }
      const calm = !T.comp.grassOff && rs.every(r => r.enabled !== false) && T.loader.reqs.length === 0;
      T.call(() => Q.applyGrassWindQuality(rs, 1));
      let tOff = -1; for (let i = 0; i < 200 && tOff < 0; i++) { T.call(() => T.comp.update(0.05)); t += 0.05; if (T.comp.grassOff) tOff = t; }
      const hidden = rs.length > 0 && rs.every(r => r.enabled === false), flowersOn = fs2.length > 0 && fs2.every(r => r.enabled !== false);
      const loading = T.loader.reqs.length === 1 && T.groundTex() === T.origTex; let tex = null; if (T.loader.reqs.length === 1) { tex = T.nextTex(); resolve(T, 0, tex); }
      const swapped = !!tex && T.groundTex() === tex && tex.refCount === 1;
      T.call(() => { Q.applyGrassWindQuality(rs, 2); Q.applyGrassWindQuality(rs, 0); Q.applyGrassWindQuality(rs, 1); for (let i = 0; i < 200; i++) T.comp.update(0.05); T.comp.setGrassOff(false); });
      const sticky = T.comp.grassOff && rs.every(r => r.enabled === false) && T.groundTex() === tex && T.loader.reqs.length === 1;
      const H = build(dir, impl, { instancing: true }); H.call(() => { for (let i = 0; i < 600; i++) H.comp.update(1 / 60); for (let i = 0; i < 400; i++) H.comp.update(0.05); });
      const hw = H.comp.instancing && !H.comp.grassOff && H.loader.reqs.length === 0 && H.grassRs().every(r => r.enabled !== false);
      return check({ '无实例化兜底生效（instancing=false，草已减量）': T.comp.instancing === false && rs.length > 0 && rs.length < T.comp.report.grassTotal, '前 10 s 60 fps（含切 OFF）不关草不加载': calm, [`13.5–15.5 s 触发（实际 ${tOff.toFixed(2)} s）`]: tOff >= 13.5 && tOff <= 15.5, '草全部禁用': hidden, '花不受影响': flowersOn, '事件 meadow-grass-off(true) 恰好 1 次': evs.length === 1 && evs[0] === true,
        '1 次加载且完成前地面原贴图': loading, '完成后地面 = 烘焙贴图、引用 1': swapped, '切档 / 继续慢帧 / 手动 setGrassOff(false) 都不恢复、不再加载': sticky, '有实例化设备不关草不加载': hw });
    }],
  ];
  const runCase = (dir, impl, f) => { try { return f(dir, impl); } catch (e) { return { ok: false, why: '异常：' + String(e && e.message || e) }; } };
  for (const [name, f] of cases) {
    const n = runCase(NEW, 'new', f); rec(G, name, n.ok, n.why);
    const o = runCase(OLD, 'old', f); rec(GC, `对照（v1.3 原代码必须失败）：${name.split(' ')[0]}`, !o.ok, `v1.3 结果：${o.ok ? '通过（对照无效！）' : '失败'} — ${o.why}`);
  }
  // v1.3.2 对照：I7（OFF 默认不关草）跑在 v1.3.1 原文件上必须失败（v1.3.1 默认 OFF 也关草）
  {
    const OLD131 = ps.join(HERE, 'controls/v1.3.1-runtime-scripts'); const [name, f] = cases.find(c => c[0].startsWith('I7'));
    const o = runCase(OLD131, 'new', f); rec(GC, '对照（v1.3.1 原代码必须失败）：I7（v1.3.2）', !o.ok, `v1.3.1 结果：${o.ok ? '通过（对照无效！）' : '失败'} — ${o.why}`);
  }
  // I8 同步回调（贴图已在缓存）+ 回调被调两次 + 加载器抛异常
  {
    const T = build(NEW, 'new', { loader: (b, p, done) => { const t = new FakeTex('cached'); T8.push(t); done(null, t); done(null, t); } }); var T8 = [];
    T.call(() => T.comp.setGrassOff(true)); const ok1 = T8.length === 1 && T.groundTex() === T8[0] && T8[0].refCount === 1; T.call(() => T.comp.setGrassOff(false)); const ok2 = T.groundTex() === T.origTex && T8[0].refCount === 0;
    const X = build(NEW, 'new', { loader: () => { throw Error('boom'); } }); X.call(() => X.comp.setGrassOff(true)); const ok3 = X.groundTex() === X.origTex && X.comp.groundTextureState.state === 'failed';
    const Y = build(NEW, 'new', { props: { bakedGroundTexturePath: '' } }); Y.call(() => Y.comp.setGrassOff(true)); const ok4 = Y.loader.reqs.length === 0 && Y.grassRs().every(r => r.enabled === false) && Y.groundTex() === Y.origTex;
    rec(G, 'I8 同步回调（贴图已在缓存）立即换上、重复回调只算一次；加载器抛异常 = 加载失败（地面不变）；路径留空 = 只关草不加载', ok1 && ok2 && ok3 && ok4, `sync=${ok1}/${ok2} throw=${ok3} empty=${ok4}`);
  }
  // I9 默认加载器（assetManager）：bundle 已加载 → bundle.load(path, Texture2D)；未加载 → loadBundle 再 load；bundle 加载失败 / 没有 assetManager → 失败回调
  {
    const calls = []; const mkBundle = (name) => ({ name, load (p, type, cb) { calls.push([name, p, type && type.name]); cb(null, { p }); } });
    const am = { bundles: { region_meadow: mkBundle('region_meadow') }, getBundle (n) { return this.bundles[n] || null; }, loadBundle (n, cb) { calls.push(['loadBundle', n]); if (n === 'missing') cb(new Error('no bundle')); else { this.bundles[n] = mkBundle(n); cb(null, this.bundles[n]); } } };
    const env = makeCC({ instancing: true, assetManager: am }); const B = makeCC.loadScripts(ts, NEW, env.cc, ['BakedGroundTexture']).BakedGroundTexture;
    const out = []; const cb = (e, t) => out.push([e ? String(e.message) : null, t]);
    B.defaultGroundTextureLoader('region_meadow', 'textures/tex_meadow_ground_grassoff_1024/texture', cb); B.defaultGroundTextureLoader('other', 'x/texture', cb); B.defaultGroundTextureLoader('missing', 'x/texture', cb);
    const env2 = makeCC({ instancing: true }); const B2 = makeCC.loadScripts(ts, NEW, env2.cc, ['BakedGroundTexture']).BakedGroundTexture; B2.defaultGroundTextureLoader('region_meadow', 'p', cb);
    const ok = out.length === 4 && out[0][0] === null && out[0][1].p === 'textures/tex_meadow_ground_grassoff_1024/texture' && calls[0][2] === 'Texture2D' && calls.some(c => c[0] === 'loadBundle' && c[1] === 'other') && out[1][0] === null && out[2][0] === 'no bundle' && out[3][0] === 'assetManager unavailable';
    rec(G, 'I9 默认加载器：已加载的 bundle 直接 bundle.load(path, Texture2D)；未加载先 loadBundle；bundle 失败 / 没有 assetManager → 失败回调（不抛）', ok, JSON.stringify(calls));
  }

  // ---------------------------------------------------------------- J 美术 v0.8.1 贴图核对
  {
    const ART = ctx.ART081 || process.env.E4_ART081 || '/workspace/e4/art081/v0.8.1-bake';
    const V08 = ctx.V08 || process.env.E4_V08 || '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8';
    const args = [ps.join(HERE, 'ground-tex-check.py'), ps.join(ART, 'textures/tex_meadow_ground_grassoff_1024.jpg'), ps.join(V08, 'textures/meadow_ground_v0_8_1024.jpg'), ps.join(V08, 'meadow_greybox_v0_8.glb'), ps.join(V08, 'data/anchors_v0_8.json'), ps.join(HERE, 'out/ground-tex-check.json')];
    if (!args.slice(1, 5).every(fs.existsSync)) rec('j-art-v081', '烘焙贴图核对', null, '找不到美术 v0.8.1 / v0.8 文件：' + args.slice(1, 5).filter(p => !fs.existsSync(p)).join(', '));
    else {
      const r = cp.spawnSync('python3', args, { encoding: 'utf8' }); let R = null; try { R = JSON.parse(r.stdout); } catch (e) { /* */ }
      if (!R) rec('j-art-v081', '烘焙贴图核对', false, (r.stderr || '').slice(0, 400));
      else {
        rec('j-art-v081', `尺寸：${R.baked.size.join('×')} ${R.baked.mode} ${R.baked.format}（v0.8 地面 ${R.v08_ground.size.join('×')}），sha256 ${R.baked.sha256.slice(0, 8)}…`, R.baked.size[0] === 1024 && R.baked.size[1] === 1024 && R.baked.mode === 'RGB' && R.baked.sha256 === 'bb369d4d1512637e7e2863f521fb6e58f5a1c5f3e9d2252ac3aa99c77e19d530', '');
        rec('j-art-v081', `UV：v0.8 GLB meadow_terrain（${R.uv.vertices} 顶点，材质 ${R.uv.material} 用 TEXCOORD_${R.uv.baseColor_texCoord} 采 ${R.uv.baseColor_image}）满足 u=(x+80)/160、v=(z+80)/160，最大误差 ${R.uv.max_abs_err_u.toExponential(1)} / ${R.uv.max_abs_err_v_topdown.toExponential(1)}（若按上下翻转则误差 ${R.uv.max_abs_err_v_if_flipped}）`, R.uv.max_abs_err_u < 1e-4 && R.uv.max_abs_err_v_topdown < 1e-4 && R.uv.baseColor_texCoord === 0, '');
        const o = R.orientation;
        rec('j-art-v081', `朝向（不翻转）：${o.walk_path_points} 个 walk_path 锚点按该公式取像素，原样 ${o.dirt_hits_as_is} 个落在土路色上（上下翻 ${o.dirt_hits_if_v_flipped}、左右翻 ${o.dirt_hits_if_u_mirrored}）；与 v0.8 地面图逐像素几乎相同的比例原样 ${(o.near_equal_v08_fraction_as_is * 100).toFixed(2)}%（上下翻 ${(o.near_equal_v08_fraction_v_flipped * 100).toFixed(3)}%、左右翻 ${(o.near_equal_v08_fraction_u_mirrored * 100).toFixed(3)}%）`, R.ok, '');
      }
    }
  }
  // J4 .meta / 压缩预设（静态检查；Creator 里是否生效 not_run）
  {
    const M = ps.join(HERE, '../../runtime/textures-meta'); let ok = false, why = '';
    try {
      const meta = JSON.parse(fs.readFileSync(ps.join(M, 'tex_meadow_ground_grassoff_1024.jpg.meta'), 'utf8')); const sub = meta.subMetas['6c48a']; const u = sub.userData;
      const pre = JSON.parse(fs.readFileSync(ps.join(M, 'texture-compress-presets.e4.json'), 'utf8')).textureCompressConfig;
      const p = pre.userPreset[meta.userData.compressSettings.presetId];
      let astc = 0, sz = 1024; for (;;) { const b = Math.ceil(sz / 6); astc += b * b * 16; if (sz === 1) break; sz >>= 1; }
      ok = meta.importer === 'image' && meta.userData.type === 'texture' && meta.userData.hasAlpha === false && sub.name === 'texture' && u.wrapModeS === 'clamp-to-edge' && u.wrapModeT === 'clamp-to-edge' && u.mipfilter === 'linear' && u.minfilter === 'linear'
        && meta.userData.compressSettings.useCompressTexture === true && !!p && !!p.options.miniGame.astc_6x6 && pre.genMipmaps === true && astc === 626288;
      why = `presetId=${meta.userData.compressSettings.presetId} miniGame=${Object.keys(p.options.miniGame)} ASTC6x6+mips=${astc} B (${(astc / 1048576).toFixed(2)} MiB)`;
    } catch (e) { why = String(e); }
    rec('j-art-v081', '.meta：image→texture 子资源 name=texture（按需加载路径 textures/tex_meadow_ground_grassoff_1024/texture）、wrap S/T = clamp-to-edge、mipfilter linear（mipmap 开，三线性）、hasAlpha false、compressSettings 指向预设 e4-meadow-ground-astc6x6（miniGame astc_6x6 → etc2_rgb → jpg，genMipmaps）；ASTC 6×6 含 mip = 626,288 B ≈ 0.60 MiB', ok, why);
  }
  // ---------------------------------------------------------------- L 天空图 v0.1a（v1.3.2）
  {
    const L = 'l-sky-v01a'; const A = process.env.E4_ART_OUTBOX || '/workspace/wechat-game/team/art/outbox-to-dot';
    const DAY = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-DAY-v0.1a.jpg'), NIGHT = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.png');
    const ZD = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-DAY-v0.1a.zip'), ZN = ps.join(A, '20261010T0133Z-grokbot2-MEADOW-SKY-NIGHT-v0.1a.zip');
    const RT = process.env.E4_SKY_ROUNDTRIP || '/workspace/e4/astc';
    if (![DAY, NIGHT, ZD, ZN].every(fs.existsSync)) rec(L, '天空图 v0.1a', null, '找不到美术 v0.1a 文件');
    else {
      // 1 交付核对：zip 与 .sha256、zip 内 SHA256SUMS、散件与 zip 内同名文件逐字节相同；night zip 里的 JPG 变体解出来备用
      const py = `import zipfile,hashlib,sys,json,os,tempfile
out={}
for z,loose,inner in [(sys.argv[1],sys.argv[3],'day-v0.1a/meadow_sky_2048x1024.jpg'),(sys.argv[2],sys.argv[4],'night-v0.1a/meadow_sky_night_2048x1024.png')]:
  zs=hashlib.sha256(open(z,'rb').read()).hexdigest(); side=open(z+'.sha256').read().split()[0]
  Z=zipfile.ZipFile(z); pre=inner.split('/')[0]; sums=Z.read(pre+'/SHA256SUMS').decode().split('\\n'); bad=[]; n=0
  for l in sums:
    l=l.strip()
    if not l: continue
    h,f=l.split(None,1); f=f.lstrip('*').lstrip('./'); n+=1
    if hashlib.sha256(Z.read(pre+'/'+f)).hexdigest()!=h: bad.append(f)
  out[os.path.basename(z)]={'zip_sha_ok':zs==side,'zip_sha':zs,'inner_n':n,'inner_bad':bad,'loose_eq_zipped':Z.read(inner)==open(loose,'rb').read()}
d=tempfile.mkdtemp(); open(os.path.join(d,'night.jpg'),'wb').write(zipfile.ZipFile(sys.argv[2]).read('night-v0.1a/meadow_sky_night_2048x1024.jpg')); out['night_jpg']=os.path.join(d,'night.jpg')
print(json.dumps(out))`;
      const z = cp.spawnSync('python3', ['-c', py, ZD, ZN, DAY, NIGHT], { encoding: 'utf8' }); let Zr = null; try { Zr = JSON.parse(z.stdout); } catch (e) { /* */ }
      const zv = Zr && Object.entries(Zr).filter(([k]) => k.endsWith('.zip')).map(([, v]) => v);
      rec(L, '交付核对：两个 zip 的 SHA256 与 .sha256 一致；zip 内 SHA256SUMS 全部 OK；散件 DAY .jpg / NIGHT .png 与 zip 内同名文件逐字节相同', !!zv && zv.length === 2 && zv.every(v => v.zip_sha_ok && v.inner_bad.length === 0 && v.inner_n > 0 && v.loose_eq_zipped), JSON.stringify(Zr || z.stderr).slice(0, 400));
      const eff = fs.readFileSync(ps.join(HERE, '../../runtime/effects/sky-unlit.effect'), 'utf8'); const hvM = /horizonV:\s*\{\s*value:\s*([0-9.]+)/.exec(eff); const hv = hvM ? Number(hvM[1]) : NaN;
      const args = [ps.join(HERE, 'sky-v01a-check.py'), DAY, NIGHT, Zr ? Zr.night_jpg : '', String(hv)]; const haveRT = fs.existsSync(ps.join(RT, 'night_4x4_thorough.png'));
      if (haveRT) args.push('--astc', RT); args.push(ps.join(HERE, 'out/sky-v01a-check.json'));
      const r = cp.spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 1 << 26 }); let R = null; try { R = JSON.parse(r.stdout); } catch (e) { /* */ }
      if (!R) rec(L, 'sky-v01a-check.py', false, (r.stderr || '').slice(0, 400));
      else {
        const d = R.day, n = R.night;
        rec(L, `SHA / 格式：白天 ${d.sha256.slice(0, 8)}…${d.sha256.slice(-4)} ${d.size.join('×')} ${d.mode} ${d.format}；夜空 ${n.sha256.slice(0, 8)}…${n.sha256.slice(-4)} ${n.size.join('×')} ${n.mode} ${n.format}（游戏用 PNG）`,
          d.sha_ok && n.sha_ok && d.size[0] === 2048 && d.size[1] === 1024 && n.size[0] === 2048 && n.size[1] === 1024 && d.mode === 'RGB' && n.mode === 'RGB' && d.format === 'JPEG' && n.format === 'PNG', '');
        rec(L, `地平线以下第 878–1023 行平坦：白天 行均偏差 ${d.rows_878_1023_rowmean_dev_max.toFixed(3)} / 逐像素对列中位数 ${d.rows_878_1023_pixel_dev_from_col_median_max}；夜空 ${n.rows_878_1023_rowmean_dev_max.toFixed(3)} / ${n.rows_878_1023_pixel_dev_from_col_median_max}（抖动 ±1）；都 ≤ 1 级。地平线色 白天 (${d.horizon_colour_srgb_col0}) 夜空 (${n.horizon_colour_srgb_col0})`,
          [d, n].every(x => x.rows_878_1023_rowmean_dev_max <= 1 && x.rows_878_1023_pixel_dev_from_col_median_max <= 1), '');
        rec(L, `第 878 行与 sky-unlit.effect 的 horizonV = ${hv} 对齐：${hv} × 1024 = ${R.horizonV_x1024.toFixed(2)}，第一个纹素中心 (r+0.5)/1024 > horizonV 的行 = ${R.first_texel_row_below_horizonV}；第 877 行（地平线所在纹素，过渡带末尾）与第 878 行亮度差 白天 ${d.row_877_vs_878_lum.toFixed(2)} / 夜空 ${n.row_877_vs_878_lum.toFixed(2)}（无台阶）；第 866 行以上仍是渐变（行均跨度 ${d.above_866_rowmean_span.toFixed(0)} / ${n.above_866_rowmean_span.toFixed(0)}）`,
          R.first_texel_row_below_horizonV === 878 && R.horizonV_x1024 > 877 && R.horizonV_x1024 < 878 && d.row_877_vs_878_lum <= 1 && n.row_877_vs_878_lum <= 1 && d.above_866_rowmean_span > 20 && n.above_866_rowmean_span > 20, '');
        rec(L, `地平线以下 u 环绕无接缝：白天 ${d.seam_below_wrap.toFixed(2)}（相邻列 ${d.seam_below_inner.toFixed(2)}），夜空 ${n.seam_below_wrap.toFixed(2)}（相邻列 ${n.seam_below_inner.toFixed(2)}）`, d.seam_below_wrap <= d.seam_below_inner + 0.5 && n.seam_below_wrap <= n.seam_below_inner + 0.5, '');
        // 色带判据：平滑块变成完全一色的比例 ≤ 原图 + 0.05、8×8 块均值误差 ≤ 0.75 级、（有抖动时）抖动保留 ≥ 0.85
        const ok = (v, dithered) => v.uniform_block_fraction <= v.uniform_block_fraction_orig + 0.05 && v.block8_mean_err_max <= 0.75 && (!dithered || v.dither_retention >= 0.85);
        const fmt = (v) => `一色块 ${(v.uniform_block_fraction * 100).toFixed(1)}%（原图 ${(v.uniform_block_fraction_orig * 100).toFixed(1)}%）、块均值误差 max ${v.block8_mean_err_max.toFixed(2)}、抖动保留 ${v.dither_retention.toFixed(2)}`;
        const jv = n.jpg_variant_vs_png;
        rec(L, `对照：美术的夜空 JPG q90 变体会抹掉抖动 → 判为色带（${fmt(jv)}）。所以游戏用 PNG`, !ok(jv, true), '');
        if (!haveRT) rec(L, '压缩往返色带检查（Creator 自带 astcenc / PVRTexTool）', null, `没有往返结果目录 ${RT}（用 sky-compress-roundtrip.sh 生成，需要 wine + Creator 3.8.8）`);
        else {
          const A2 = R.astc_roundtrip; const g = (k) => A2[k];
          rec(L, `夜空选用 ASTC 4×4 thorough：不加色带（${fmt(g('night_4x4_thorough.png'))}）。参考：省显存的 6×6 thorough ${ok(g('night_6x6_thorough.png'), true) ? '也通过' : '未通过（擦边）'}（${fmt(g('night_6x6_thorough.png'))}），所以不选`, ok(g('night_4x4_thorough.png'), true), '');
          rec(L, `对照：夜空 ETC2 RGB（etcfast）判为色带（${fmt(g('night_etc2_etcfast.png'))}）；ASTC 6×6 medium 块均值误差 ${g('night_6x6_medium.png').block8_mean_err_max.toFixed(2)} 超限 → 预设不用 ETC2、ASTC 用 thorough`, !ok(g('night_etc2_etcfast.png'), true) && !ok(g('night_6x6_medium.png'), true), '');
          rec(L, `白天选用 ASTC 6×6 thorough：不加色带（${fmt(g('day_6x6_thorough.png'))}）；对照 ETC2 RGB 判为色带（${fmt(g('day_etc2_etcfast.png'))}）→ 白天兜底用 JPG`, ok(g('day_6x6_thorough.png'), false) && !ok(g('day_etc2_etcfast.png'), false), '');
        }
      }
      // .meta / 预设
      const M = ps.join(HERE, '../../runtime/textures-meta'); let mok = false, why = '';
      try {
        const pre = JSON.parse(fs.readFileSync(ps.join(M, 'texture-compress-presets.e4.json'), 'utf8')).textureCompressConfig.userPreset;
        const chk = (f, ext, preset, must, mustNot) => { const m = JSON.parse(fs.readFileSync(ps.join(M, f), 'utf8')); const u = m.subMetas['6c48a'].userData; const p = pre[m.userData.compressSettings.presetId];
          const plats = ['miniGame', 'android', 'ios']; return m.files.includes(ext) && m.userData.compressSettings.presetId === preset && !!p && u.wrapModeS === 'repeat' && u.wrapModeT === 'clamp-to-edge' && u.mipfilter === 'none' && u.minfilter === 'linear' && m.userData.hasAlpha === false
            && plats.every(pl => must.every(k => p.options[pl][k] && (k.startsWith('astc') ? p.options[pl][k].quality === 'thorough' : true)) && Object.keys(p.options[pl]).every(k => !mustNot.some(x => k.startsWith(x)))); };
        const okD = chk('tex_meadow_sky_2048x1024.jpg.meta', '.jpg', 'e4-meadow-sky-day', ['astc_6x6', 'jpg'], ['etc', 'pvrtc']);
        const okN = chk('tex_meadow_sky_night_2048x1024.png.meta', '.png', 'e4-meadow-sky-night', ['astc_4x4', 'png'], ['etc', 'pvrtc', 'jpg', 'webp']);
        mok = okD && okN; why = `day=${okD} night=${okN}`;
      } catch (e) { why = String(e); }
      rec(L, '.meta：白天 .jpg / 夜空 .png，wrap S repeat / T clamp-to-edge、mipmap 关、linear、无 alpha；预设白天 astc_6x6 thorough → jpg，夜空 astc_4x4 thorough → png（预设里没有 ETC / PVRTC，夜空也没有 JPG / WebP，避免把色带加回来）', mok, why);
    }
  }
  // ---------------------------------------------------------------- K 草甸位姿 → 0007 CameraPose.ts
  {
    // 0007 的 CameraPose.ts 只读引用（0007 v1.3 树）；RegionCameraData.ts 用本包 tools/patches/0007-meadow-pose/ 里打过补丁的副本
    const CP = process.env.E4_0007_CAMERAPOSE || '/workspace/t0007/sim13/creator-build-project/assets/scripts/world-r1/CameraPose.ts';
    const RCD = ps.join(HERE, '../patches/0007-meadow-pose/RegionCameraData.ts.patched');
    let W = ctx.W0007 || process.env.E4_0007_WORLD_R1 || '';
    if (!W && fs.existsSync(CP) && fs.existsSync(RCD)) { W = fs.mkdtempSync(ps.join(require('os').tmpdir(), 'e4-0007-')); fs.copyFileSync(CP, ps.join(W, 'CameraPose.ts')); fs.copyFileSync(RCD, ps.join(W, 'RegionCameraData.ts')); }
    if (!W) W = ps.dirname(CP);
    const POSE = ctx.POSE || process.env.E4_MEADOW_POSE || '/workspace/wechat-game/team/art/outbox-to-dot/20261010T0127Z-grokbot2-meadow_camera_pose-v0.8.1a.json';
    const ANCH = ctx.ANCH || '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/data/anchors_v0_8.json';
    const CHK = ctx.CHK || process.env.E4_POSE_CHECK || '/workspace/wechat-game/team/cinematic/work/meadow-pose-check';
    const need = [ps.join(W, 'CameraPose.ts'), ps.join(W, 'RegionCameraData.ts'), POSE, ANCH, ps.join(CHK, 'SHA256SUMS')];
    if (!need.every(fs.existsSync)) rec('k-meadow-pose', '草甸位姿', null, '找不到：' + need.filter(p => !fs.existsSync(p)).join(', '));
    else {
      const r = cp.spawnSync('node', [ps.join(HERE, 'meadow-pose-test.mjs'), W, POSE, ANCH, CHK, ps.join(HERE, 'out/meadow-pose-test.json')], { encoding: 'utf8' });
      let R = null; try { R = JSON.parse(r.stdout.slice(r.stdout.indexOf('{'))); } catch (e) { /* */ }
      if (!R) rec('k-meadow-pose', '草甸位姿', false, (r.stderr || r.stdout || '').slice(0, 400));
      else for (const x of R.results) rec('k-meadow-pose', x.name, x.pass, JSON.stringify(x.detail || '').slice(0, 300));
    }
  }
};
