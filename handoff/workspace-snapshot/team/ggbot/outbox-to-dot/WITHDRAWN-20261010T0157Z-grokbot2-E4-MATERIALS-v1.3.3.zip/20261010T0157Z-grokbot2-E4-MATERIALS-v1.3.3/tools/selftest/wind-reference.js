// CPU 参考实现：直接把 meadow-grass-wind.effect 里的 GLSL 函数 windOffset() 机械翻译成 JS 执行（不是手抄），
// 另附一份按美术 README（meadow_v0_8/README.md「草：风」）独立手写的公式，用来比对默认参数下两者一致。
'use strict';
const fs = require('fs');

function extractWindOffsetGLSL (effectText) {
  const start = effectText.indexOf('float windOffset (');
  if (start < 0) throw new Error('windOffset() not found in effect');
  let i = effectText.indexOf('{', start), depth = 0, end = -1;
  for (; i < effectText.length; i++) {
    if (effectText[i] === '{') depth++;
    else if (effectText[i] === '}') { depth--; if (depth === 0) { end = i + 1; break; } }
  }
  return effectText.slice(start, end);
}

// 只支持 windOffset 用到的 GLSL 子集；遇到不认识的类型 / 函数就抛错，防止“翻译错了还通过”。
function transpile (glsl) {
  const lines = glsl.split('\n').map(l => l.replace(/\/\/.*$/, ''));
  const out = [];
  for (let raw of lines) {
    let l = raw.trim();
    if (!l) continue;
    if (/^float windOffset \(vec2 p, vec2 dir, vec4 c, float t\) \{$/.test(l)) { out.push('return function windOffset (p, dir, c, t) {'); continue; }
    let m;
    if ((m = l.match(/^#if (.+)$/))) { out.push(`if (${m[1]}) {`); continue; }
    if (l === '#else') { out.push('} else {'); continue; }
    if (l === '#endif') { out.push('}'); continue; }
    if (l.startsWith('#')) throw new Error('unsupported directive: ' + l);
    l = l.replace(/^(float|vec2) (\w+) =/, 'let $2 =');
    if (/\b(vec3|vec4|mat\d|int|bool)\b/.test(l)) throw new Error('unsupported type in: ' + l);
    l = l.replace(/\bsin\(/g, 'Math.sin(').replace(/\bmax\(/g, 'Math.max(');
    const fnNames = (l.match(/\b([A-Za-z_]\w*)\(/g) || []).map(s => s.slice(0, -1));
    for (const f of fnNames) if (!['Math.sin', 'Math.max', 'sin', 'max', 'dot', 'vec2', 'function', 'windOffset', 'if'].includes(f) && !l.includes('Math.' + f)) throw new Error('unsupported call ' + f + ' in: ' + l);
    out.push(l);
  }

  const body = out.join('\n');
  // eslint-disable-next-line no-new-func
  const factory = new Function('WIND_QUALITY', 'windShape', 'windDirSpeed', 'gustParams', 'dot', 'vec2', body);
  return { body, factory };
}

const dot = (a, b) => a.x * b.x + a.y * b.y;
const vec2 = (x, y) => ({ x, y });

function makeShaderWind (effectPath, quality, u) {
  const { factory, body } = transpile(extractWindOffsetGLSL(fs.readFileSync(effectPath, 'utf8')));
  const fn = factory(quality, u.windShape, u.windDirSpeed, u.gustParams, dot, vec2);
  return { fn, body };
}

// 与 effect 的 vert() 一致的外层：方向归一化，WIND_QUALITY 0 时不调用 windOffset。
function displacement (wind, quality, u, phaseP, color, t) {
  if (quality === 0) return { d: 0, drop: 0 };
  const L = Math.max(Math.hypot(u.windDirSpeed.x, u.windDirSpeed.y), 0.0001);
  const dir = vec2(u.windDirSpeed.x / L, u.windDirSpeed.y / L);
  const d = wind(phaseP, dir, color, t);
  return { d, drop: u.gustParams.w * d * color.r };
}

// 美术原公式（README）：A = a*1.5; ph = 2π(dot(origin.xz, W)/26 + g); ω = 2π/4; d = A r² (0.36 sin(ph - ωt) - 0.26 sin(ωt))
function artFormula (origin, color, t) {
  const W = { x: 0.944, y: -0.330 };
  const A = color.a * 1.5, r = color.r;
  const ph = 2 * Math.PI * ((origin.x * W.x + origin.y * W.y) / 26.0 + color.g);
  const w = 2 * Math.PI / 4.0;
  return A * r * r * (0.36 * Math.sin(ph - w * t) - 0.26 * Math.sin(w * t));
}

const DEFAULTS = () => ({
  windDirSpeed: { x: 0.94398, y: -0.32999, z: 6.5, w: 26.0 },   // 与 effect 默认值一致（run-selftest 里有一致性检查）
  windShape: { x: 1.0, y: 1.5, z: 0.36, w: 0.26 },
  gustParams: { x: 0.15, y: 0.12, z: 40.0, w: 0.3 },
});

module.exports = { extractWindOffsetGLSL, transpile, makeShaderWind, displacement, artFormula, DEFAULTS, dot, vec2 };
