#!/usr/bin/env bash
# E4 v1.3.2：用 Creator 3.8.8 自带的压缩工具（wine 运行）把天空图压缩再解压，供 sky-v01a-check.py --astc 比较色带。
# 用法：bash sky-compress-roundtrip.sh <day.jpg> <night.png> <输出目录> [Creator resources 目录]
# 工具：resources/tools/astc-encoder/astcenc.exe（v5.2.0，-tl = LDR）、resources/tools/PVRTexTool_win32/PVRTexToolCLI.exe（ETC2_RGB etcfast）
set -euo pipefail
DAY=$1; NIGHT=$2; OUT=$3; RES=${4:-/opt/cocos/CocosCreator-3.8.8-win/resources}
A=$RES/tools/astc-encoder/astcenc.exe; P=$RES/tools/PVRTexTool_win32/PVRTexToolCLI.exe
mkdir -p "$OUT"; python3 -c "from PIL import Image;import sys;Image.open(sys.argv[1]).convert('RGB').save(sys.argv[2])" "$DAY" "$OUT/day.png"; cp "$NIGHT" "$OUT/night.png"
cd "$OUT"
for b in 4x4 5x5 6x6; do for q in medium thorough; do wine "$A" -tl night.png night_${b}_${q}.png $b -$q -silent >/dev/null 2>&1; done; done
for b in 4x4 6x6; do wine "$A" -tl day.png day_${b}_thorough.png $b -thorough -silent >/dev/null 2>&1; done
wine "$A" -tl day.png day_6x6_medium.png 6x6 -medium -silent >/dev/null 2>&1
for t in night day; do wine "$P" -i $t.png -o ${t}_etc2_etcfast.pvr -f ETC2_RGB,UBN,sRGB -q etcfast -d ${t}_etc2_etcfast.png >/dev/null 2>&1; rm -f ${t}_etc2_etcfast.pvr; done
ls -1 "$OUT"
