// Bundle engine/editor/exports/offline-mappings.ts (Cocos 3.8.8) into a standalone CJS module for shdc-lib.js.
// Only enums/helpers are needed; heavy engine modules are stubbed (rendering/define enums copied verbatim from 3.8.8).
import * as esbuild from 'esbuild';
import fs from 'fs'; import path from 'path';
const [,, E, outFile] = process.argv;
const H = path.dirname(new URL(import.meta.url).pathname) + '/';
// internal:constants → every flag false (NET_MODE 0)
const names = new Set();
const walk = d => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name);
  if (f.isDirectory()) walk(p); else if (p.endsWith('.ts')) { const s = fs.readFileSync(p, 'utf8');
    for (const m of s.matchAll(/import\s*\{([^}]*)\}\s*from\s*'internal:constants'/g)) m[1].split(',').map(x => x.trim()).filter(Boolean).forEach(x => names.add(x)); } } };
walk(path.join(E, 'cocos'));
fs.writeFileSync(H + 'constants.ts', [...names].sort().map(n => `export const ${n} = ${n === 'NET_MODE' ? 0 : false};`).join('\n') + '\n');
fs.writeFileSync(H + 'core-stub.ts', `export { murmurhash2_32_gc } from '${E}/cocos/core/algorithm/murmurhash2_gc';\n`);
fs.writeFileSync(H + 'gfx-stub.ts', `export * from '${E}/cocos/gfx/base/define';\nexport { Sampler } from '${E}/cocos/gfx/base/states/sampler';\n`);
await esbuild.build({ entryPoints: [E + '/editor/exports/offline-mappings.ts'], bundle: true, platform: 'node', format: 'cjs', outfile: outFile, logLevel: 'error',
  plugins: [{ name: 'cc', setup (b) {
    b.onResolve({ filter: /^internal:constants$/ }, () => ({ path: H + 'constants.ts' }));
    b.onResolve({ filter: /^pal\// }, () => ({ path: H + 'pal-stub.ts' }));
    b.onResolve({ filter: /cocos\/rendering\/define$/ }, () => ({ path: H + 'rendering-define.ts' }));
    b.onResolve({ filter: /^\.\.\/\.\.\/cocos\/core$/ }, () => ({ path: H + 'core-stub.ts' }));
    b.onResolve({ filter: /^\.\.\/\.\.\/cocos\/gfx$/ }, () => ({ path: H + 'gfx-stub.ts' }));
    b.onResolve({ filter: /core\/data\/gc-object$/ }, () => ({ path: H + 'gc-object.ts' }));
  } }] });
console.log('offline-mappings bundled ->', outFile);
