#!/usr/bin/env bash
# 从本机 Cocos Creator 3.8.8 安装里取出官方 effect 编译器（shdc-lib.js），组装成可在 Node 下独立运行的版本。
# 不在交付包里分发 Creator 的代码；每台机器自己从安装目录生成。
# 用法: CREATOR=/path/to/CocosCreator-3.8.8/resources bash setup.sh [outDir]
set -euo pipefail
CREATOR="${CREATOR:-/opt/cocos/CocosCreator-3.8.8-win/resources}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$HERE/../.cc-effect-compiler}"   # 默认 tools/selftest/.cc-effect-compiler（run-selftest.js 的默认位置）
E="$CREATOR/resources/3d/engine"
grep -q '"version": "3.8.8"' "$E/package.json" || { echo "engine at $E is not 3.8.8"; exit 2; }
mkdir -p "$OUT" && TMP="$(mktemp -d)"
npx --yes @electron/asar@3 extract "$CREATOR/app.asar" "$TMP/asar" >/dev/null
SRC="$TMP/asar/modules/engine-extensions/extensions/engine-extends/static/effect-compiler"
cp "$SRC"/{index.js,shdc-lib.js,utils.js} "$OUT/"
mkdir -p "$OUT/node_modules"; for m in glsl-parser glsl-tokenizer js-yaml; do cp -r "$TMP/asar/node_modules/$m" "$OUT/node_modules/"; done
[ -d "$HERE/node_modules/esbuild" ] || npm i --prefix "$HERE" --no-save --no-audit --no-fund esbuild@0.23.1 >/dev/null 2>&1
node "$HERE/build-offline-mappings.mjs" "$E" "$OUT/offline-mappings.js"
cp "$HERE/compile.js" "$OUT/compile.js"
sha256sum "$OUT"/{index.js,shdc-lib.js,utils.js,offline-mappings.js} > "$OUT/PROVENANCE.sha256"
echo "$CREATOR" > "$OUT/PROVENANCE.creator-path"
rm -rf "$TMP"; echo "cc-effect-compiler ready at $OUT"
