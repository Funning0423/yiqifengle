export * from '/opt/cocos/CocosCreator-3.8.8-win/resources/resources/3d/engine/cocos/gfx/base/define';
export { Sampler } from '/opt/cocos/CocosCreator-3.8.8-win/resources/resources/3d/engine/cocos/gfx/base/states/sampler';
