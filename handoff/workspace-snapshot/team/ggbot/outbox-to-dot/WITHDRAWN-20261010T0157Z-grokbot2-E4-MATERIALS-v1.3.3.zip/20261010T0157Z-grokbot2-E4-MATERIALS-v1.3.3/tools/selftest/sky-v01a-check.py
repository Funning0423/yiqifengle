#!/usr/bin/env python3
"""E4 v1.3.2：美术天空图 v0.1a 核对。
用法：python3 sky-v01a-check.py <day.jpg> <night.png> <night 美术 jpg 变体> <horizonV> [--astc <astc 回读目录>] [out.json]
1) SHA / 尺寸 / 模式；2) 地平线以下第 878–1023 行平坦（行均亮度对第 878 行 ≤ 1 级；逐像素对本列中位数 ≤ 1 级）；
3) 第 878 行与 horizonV 对齐：878 是第一个纹素中心 (r+0.5)/1024 > horizonV 的行；第 866 行以上不是平坦区（确实是天空渐变）；
4) 地平线以下 u 环绕接缝；5) 色带（banding）：给定压缩回读图与原图比较 8×8 块均值误差（色带 = 块均值出现台阶）和抖动保留率（高频能量比）。"""
import sys, json, hashlib, os
import numpy as np
from PIL import Image
args = sys.argv[1:]; astc_dir = None
if '--astc' in args: i = args.index('--astc'); astc_dir = args[i + 1]; del args[i:i + 2]
day_p, night_p, night_jpg_p, hv = args[0], args[1], args[2], float(args[3]); out_p = args[4] if len(args) > 4 else None
SHA = {'day': '153979281ac0b9a96d360245f59ad3b02438b1a39082afbca5cefc647959a4b8', 'night': '1fd02ba7284fe9dec25e2a2ea3deb5e8a10ebf9c014ef058c793b8883f39acd0'}
lum = lambda a: a[..., 0] * 0.2126 + a[..., 1] * 0.7152 + a[..., 2] * 0.0722
def load(p): im = Image.open(p); return im, np.asarray(im.convert('RGB')).astype(np.float64)
R = {'horizonV': hv}
first = next(r for r in range(1024) if (r + 0.5) / 1024 > hv)
R['first_texel_row_below_horizonV'] = first; R['horizonV_x1024'] = hv * 1024
def flat(a, name):
    H = a.shape[0]; L = lum(a); below = a[878:]
    rowdev = np.abs(L[878:].mean(1) - L[878].mean()).max()
    med = np.median(below, axis=0)
    pix = np.abs(below - med[None]).max()
    seam = float(np.abs(below[:, 0] - below[:, -1]).mean()); inner = float(np.abs(below[:, 1:] - below[:, :-1]).mean())
    above = float(np.abs(L[:866].mean(1)[1:] - L[:866].mean(1)[:-1]).max()); span = float(L[:866].mean(1).max() - L[:866].mean(1).min())
    return {'rows_878_1023_rowmean_dev_max': float(rowdev), 'rows_878_1023_pixel_dev_from_col_median_max': float(pix), 'seam_below_wrap': seam, 'seam_below_inner': inner,
            'above_866_rowmean_span': span, 'horizon_colour_srgb_col0': [round(float(x), 1) for x in med[0]],
            'row_877_vs_878_lum': float(abs(L[877].mean() - L[878].mean())), 'row_869_vs_878_lum': float(abs(L[869].mean() - L[878].mean()))}
def band(orig, dec):
    """只看天空渐变区（第 0–863 行）里“平滑块”：原图 8×8 块内亮度极差 ≤ 2 级（排除星星 / 月亮 / 云边）。
    色带的两个症状：① 抖动被抹掉 → 块变成完全一色（uniform_block_fraction 上升，dither_retention 下降）；② 块均值出现台阶（block8_mean_err）。"""
    h, w = 864, orig.shape[1] // 8 * 8
    blk = lambda a: lum(a[:h, :w]).reshape(h // 8, 8, w // 8, 8).transpose(0, 2, 1, 3).reshape(h // 8, w // 8, 64)
    bo, bd = blk(orig), blk(dec)
    smooth = (bo.max(2) - bo.min(2)) <= 2.0
    so = bo[smooth].std(1).mean(); sd = bd[smooth].std(1).mean()
    e = np.abs(bd[smooth].mean(1) - bo[smooth].mean(1))
    uni = lambda b: float(((b[smooth].max(1) - b[smooth].min(1)) < 0.5).mean())
    return {'smooth_blocks': int(smooth.sum()), 'dither_retention': float(sd / so) if so > 0 else None, 'uniform_block_fraction_orig': uni(bo), 'uniform_block_fraction': uni(bd),
            'block8_mean_err_max': float(e.max()), 'block8_mean_err_rms': float(np.sqrt((e ** 2).mean())), 'psnr_db_full': float(10 * np.log10(255 ** 2 / max(1e-12, ((dec - orig) ** 2).mean())))}
for name, p in [('day', day_p), ('night', night_p)]:
    im, a = load(p); sha = hashlib.sha256(open(p, 'rb').read()).hexdigest()
    R[name] = {'sha256': sha, 'sha_ok': sha == SHA[name], 'size': im.size, 'mode': im.mode, 'format': im.format, **flat(a, name)}
_, N = load(night_p); _, NJ = load(night_jpg_p)
R['night']['jpg_variant_vs_png'] = band(N, NJ)
if astc_dir:
    R['astc_roundtrip'] = {}
    _, D = load(day_p)
    for f in sorted(os.listdir(astc_dir)):
        if f.startswith('night_') and f.endswith('.png'): R['astc_roundtrip'][f] = band(N, load(os.path.join(astc_dir, f))[1])
        if f.startswith('day_') and f.endswith('.png'): R['astc_roundtrip'][f] = band(D, load(os.path.join(astc_dir, f))[1])
s = json.dumps(R, indent=1); print(s)
if out_p: open(out_p, 'w').write(s + '\n')
