#!/usr/bin/env python3
"""E4 v1.3.1：烘焙草地贴图核对（尺寸 / UV 公式 / 朝向）。用法：python3 ground-tex-check.py <baked.jpg> <v0.8 ground.jpg> <greybox.glb> <anchors.json> [out.json]"""
import sys, json, struct, hashlib
import numpy as np
from PIL import Image
baked_p, old_p, glb_p, anch_p = sys.argv[1:5]; out_p = sys.argv[5] if len(sys.argv) > 5 else None
R = {}
img = Image.open(baked_p); R['baked'] = {'sha256': hashlib.sha256(open(baked_p, 'rb').read()).hexdigest(), 'size': img.size, 'mode': img.mode, 'format': img.format}
old = Image.open(old_p); R['v08_ground'] = {'size': old.size, 'mode': old.mode}
A = np.asarray(img.convert('RGB')).astype(np.float64); O = np.asarray(old.convert('RGB')).astype(np.float64)
# GLB 地形 UV
b = open(glb_p, 'rb').read(); jl = struct.unpack('<I', b[12:16])[0]; J = json.loads(b[20:20 + jl]); BIN = b[20 + jl + 8:]
def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]; n = {'VEC2': 2, 'VEC3': 3}[a['type']]
    assert a['componentType'] == 5126
    st = bv.get('byteStride', 4 * n); off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    return np.array([struct.unpack_from('<%df' % n, BIN, off + k * st) for k in range(a['count'])])
mesh = next(m for m in J['meshes'] if m['name'] == 'meadow_terrain'); pr = mesh['primitives'][0]
P = acc(pr['attributes']['POSITION']); UV = acc(pr['attributes']['TEXCOORD_0'])
mat = J['materials'][pr['material']]; bct = mat['pbrMetallicRoughness']['baseColorTexture']
# glTF 坐标 = Cocos 坐标（+Y 上）。美术公式：u = (x+80)/160，v_blender = (y_b+80)/160，y_b = -z；glTF/Cocos 存的 v = 1 - v_blender = (z+80)/160
eu = (P[:, 0] + 80) / 160; ev = (P[:, 2] + 80) / 160
R['uv'] = {'mesh': 'meadow_terrain', 'vertices': len(P), 'material': mat['name'], 'baseColor_texCoord': bct.get('texCoord', 0),
           'baseColor_image': J['images'][J['textures'][bct['index']]['source']].get('name'),
           'max_abs_err_u': float(np.abs(UV[:, 0] - eu).max()), 'max_abs_err_v_topdown': float(np.abs(UV[:, 1] - ev).max()),
           'max_abs_err_v_if_flipped': float(np.abs(UV[:, 1] - (1 - ev)).max()),
           'x_range': [float(P[:, 0].min()), float(P[:, 0].max())], 'z_range': [float(P[:, 2].min()), float(P[:, 2].max())]}
# 朝向：图片第 row 行 = v（Creator 不翻 v，上传不翻 Y：见 E4 v1.1 UV 核对）。按 (x,z) → (col,row) 取样
def px(x, z, flip=False, mirror=False):
    u = (x + 80) / 160; v = (z + 80) / 160
    if flip: v = 1 - v
    if mirror: u = 1 - u
    return min(1023, max(0, int(u * 1024))), min(1023, max(0, int(v * 1024)))
anch = json.load(open(anch_p))
path = sorted((k, v['game_m']) for k, v in anch.items() if k.startswith('walk_path_'))
def dirt(c): return c[0] > 0.95 * c[1]
def path_dirt(**kw):
    n = 0
    for _, p in path:
        cx, cy = px(p[0], p[2], **kw); c = A[cy, cx]; n += dirt(c)
    return n
R['orientation'] = {'walk_path_points': len(path), 'dirt_hits_as_is': int(path_dirt()), 'dirt_hits_if_v_flipped': int(path_dirt(flip=True)), 'dirt_hits_if_u_mirrored': int(path_dirt(mirror=True))}
# 全图和 v0.8 原图的相关性：原样 vs 上下翻 vs 左右翻（河 / 河岸区域保留原图，小路两张图都画在同一位置）
def corr(a, b): a = a.mean(2).ravel(); b = b.mean(2).ravel(); a = a - a.mean(); b = b - b.mean(); return float((a * b).sum() / np.sqrt((a * a).sum() * (b * b).sum()))
R['orientation']['corr_with_v08_as_is'] = corr(A, O); R['orientation']['corr_with_v08_v_flipped'] = corr(A, O[::-1]); R['orientation']['corr_with_v08_u_mirrored'] = corr(A, O[:, ::-1])
eq = lambda B: float((np.abs(A - B).mean(2) < 3).mean())   # 河 / 河岸范围美术保留了 v0.8 原图：几乎相同的像素只在朝向正确时大量出现
R['orientation']['near_equal_v08_fraction_as_is'] = eq(O); R['orientation']['near_equal_v08_fraction_v_flipped'] = eq(O[::-1]); R['orientation']['near_equal_v08_fraction_u_mirrored'] = eq(O[:, ::-1])
ok = (R['baked']['size'] == (1024, 1024) and R['baked']['mode'] == 'RGB' and R['v08_ground']['size'] == (1024, 1024)
      and R['uv']['max_abs_err_u'] < 1e-4 and R['uv']['max_abs_err_v_topdown'] < 1e-4 and R['uv']['baseColor_texCoord'] == 0
      and R['orientation']['dirt_hits_as_is'] == len(path) and R['orientation']['dirt_hits_if_v_flipped'] < len(path) // 2
      and R['orientation']['corr_with_v08_as_is'] > max(R['orientation']['corr_with_v08_v_flipped'], R['orientation']['corr_with_v08_u_mirrored'])
      and R['orientation']['near_equal_v08_fraction_as_is'] > 3 * max(R['orientation']['near_equal_v08_fraction_v_flipped'], R['orientation']['near_equal_v08_fraction_u_mirrored']))
R['ok'] = bool(ok)
s = json.dumps(R, indent=1); print(s)
if out_p: open(out_p, 'w').write(s + '\n')
