export const systemInfo:any = { on(){}, off(){}, isNative:false, platform:0, os:'linux', hasFeature(){return false;} };
export const screenAdapter:any = { on(){}, off(){} };
