export enum RenderPassStage { DEFAULT = 100, UI = 200 }
export enum RenderPriority { MIN = 0, MAX = 0xff, DEFAULT = 0x80 }
export enum SetIndex { GLOBAL, MATERIAL, LOCAL, COUNT }
