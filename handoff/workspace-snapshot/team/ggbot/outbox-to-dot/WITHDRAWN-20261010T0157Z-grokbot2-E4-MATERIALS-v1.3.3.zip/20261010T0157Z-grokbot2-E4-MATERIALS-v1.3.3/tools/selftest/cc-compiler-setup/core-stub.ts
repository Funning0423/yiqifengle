export { murmurhash2_32_gc } from '/opt/cocos/CocosCreator-3.8.8-win/resources/resources/3d/engine/cocos/core/algorithm/murmurhash2_gc';
