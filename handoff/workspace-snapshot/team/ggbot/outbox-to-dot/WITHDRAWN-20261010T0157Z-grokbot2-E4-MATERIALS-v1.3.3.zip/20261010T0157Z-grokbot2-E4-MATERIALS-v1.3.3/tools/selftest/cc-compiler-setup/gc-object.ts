export class GCObject { constructor(){} }
