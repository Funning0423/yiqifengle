#!/usr/bin/env python3
"""E4 v1.1：夜景天空贴图检查（需要 Pillow + numpy）。输出 JSON。
用法: python3 sky-texture-check.py <night.png> [expected_sha256]"""
import sys, json, hashlib
from PIL import Image
import numpy as np
p = sys.argv[1]; exp = sys.argv[2] if len(sys.argv) > 2 else None
raw = open(p, 'rb').read(); sha = hashlib.sha256(raw).hexdigest()
im = Image.open(p); a = np.asarray(im.convert('RGB')).astype(float); H, W, _ = a.shape
rm = a.mean(axis=2).mean(axis=1)
peak = 800 + int(np.argmax(rm[800:960]))                       # 地平线辉光带（最亮的一行）
seam = float(np.abs(a[:, 0] - a[:, -1]).mean()); adj = float(np.abs(a[:, 1:] - a[:, :-1]).mean())
print(json.dumps({'sha256': sha, 'sha_ok': (exp is None or sha == exp), 'size': [W, H], 'mode': im.mode,
  'horizon_expected_row': 90 / 105 * H, 'glow_peak_row': peak, 'seam_mean_abs': seam, 'adjacent_col_mean_abs': adj,
  'row_mean_top_mid_bottom': [float(rm[0]), float(rm[H // 2]), float(rm[-1])]}))
