// E4 v1.3.1 step 3: meadow stop pose through 0007's real CameraPose.ts / RegionCameraData.ts (type-stripped, plain Node).
// usage: node meadow-pose-test.mjs <0007 world-r1 dir> <meadow_camera_pose v0.8.1a json (art)> <anchors_v0_8.json> <运镜bot meadow-pose-check dir> [out.json]
import { readFileSync, writeFileSync, mkdtempSync, existsSync } from 'node:fs'; import { stripTypeScriptTypes } from 'node:module'; import { join } from 'node:path'; import { tmpdir } from 'node:os'; import { pathToFileURL } from 'node:url'; import { createHash } from 'node:crypto';
const [dir, poseJson, anchorsJson, checkDir, out] = process.argv.slice(2); const tmp = mkdtempSync(join(tmpdir(), 'meadowpose-'));
for (const f of ['CameraPose', 'RegionCameraData']) writeFileSync(join(tmp, f + '.mjs'), stripTypeScriptTypes(readFileSync(join(dir, f + '.ts'), 'utf8')).replace(/from '\.\/CameraPose'/g, "from './CameraPose.mjs'"));
const C = await import(pathToFileURL(join(tmp, 'CameraPose.mjs'))); const D = await import(pathToFileURL(join(tmp, 'RegionCameraData.mjs')));
const res = []; const rec = (name, pass, detail) => res.push({ name, pass: !!pass, detail });
const FINAL = { position: [-4, 24, 62], target: [0.3151, 3.4577, -0.6059], fovVerticalDeg: 45 };
const eq = (a, b, e = 1e-9) => a.length === b.length && a.every((v, i) => Math.abs(v - b[i]) < e);
const stop = D.REGION_CAMERA.stops.find(s => s.id === 'meadow'); const e = stop?.pose;
rec('meadow stop has an authored pose object', e && typeof e === 'object', { keys: e && Object.keys(e) });
rec('pose = final (-4,24,62) / (0.3151,3.4577,-0.6059) / fov 45', eq(e.position, FINAL.position) && eq(e.target, FINAL.target) && e.fovVerticalDeg === 45, { data: [e.position, e.target, e.fovVerticalDeg] });
// 运镜bot check: SHA256SUMS all OK, and its alt check input pose = the data
const sums = readFileSync(join(checkDir, 'SHA256SUMS'), 'utf8').trim().split('\n'); const bad = [];
for (const l of sums) { const [h, f] = l.trim().split(/\s+/); const p = join(checkDir, f); if (!existsSync(p) || createHash('sha256').update(readFileSync(p)).digest('hex') !== h) bad.push(f); }
const sumsSha = createHash('sha256').update(readFileSync(join(checkDir, 'SHA256SUMS'))).digest('hex');
rec(`运镜bot meadow-pose-check SHA256SUMS: ${sums.length - bad.length}/${sums.length} OK`, bad.length === 0, { entries: sums.length, bad, sha256_of_SHA256SUMS: sumsSha });
const alt = JSON.parse(readFileSync(join(checkDir, 'check_alt_x-4.json'), 'utf8'));
rec('data = 运镜bot check_alt_x-4.json input pose', eq(alt.input.pose.position, e.position) && eq(alt.input.pose.target, e.target) && alt.input.pose.fovVerticalDeg === e.fovVerticalDeg, alt.input.pose);
const artBuf = readFileSync(poseJson); const art = JSON.parse(artBuf.toString('utf8')); const artSha = createHash('sha256').update(artBuf).digest('hex');
rec(`pose source = Grok Bot meadow_camera_pose v0.8.1a, sha256 ${artSha.slice(0, 8)}…${artSha.slice(-4)} (expected 12525f15…b3ef)`, artSha === '12525f15cc76715b2190de837156dafdbc3c2ded79fa72c34e64933337c6b3ef' && /v0\.8\.1a/.test(art.metadata?.revision || ''), { sha256: artSha, revision: art.metadata?.revision });
rec('data = v0.8.1a pose exactly (position/target/fov)', eq(art.pose.position, e.position) && eq(art.pose.target, e.target) && art.pose.fovVerticalDeg === e.fovVerticalDeg && Object.keys(art.pose).length === 3, art.pose);
rec('same AuthoredPose form as yunjing-final: no rotation authored, source string present', !('rotation' in e) && typeof e.source === 'string');
rec('status final, source cites v0.8.1a + sha and 运镜bot meadow-pose-check', e.status === 'final' && /meadow-pose-check/.test(e.source) && /v0\.8\.1a/.test(e.source) && /12525f15/.test(e.source), { status: e.status, source: e.source });
let ok = true; try { C.assertAuthoredPose(e, 'meadow'); } catch (x) { ok = String(x); } rec('assertAuthoredPose (0007 v1.3 contract) accepts it', ok === true, { err: ok });
const world = off => ({ position: e.position.map((v, i) => v + off[i]), target: e.target.map((v, i) => v + off[i]), fovVerticalDeg: e.fovVerticalDeg });
rec('rootOffset explicit [0,0,0] (meadow root placement not found)', eq(e.rootOffset, [0, 0, 0]), { rootOffset: e.rootOffset });
for (const off of [e.rootOffset, [120, 0, 0], [0, -5, 300], [-37.5, 2, -64]]) {
  const p = C.fromLookAt(world(off)); const v = C.validateCameraPose(p); const r = C.rotate(p.rotation, [1, 0, 0]); const f = C.rotate(p.rotation, [0, 0, -1]);
  const cam = { node: { pos: null, setWorldPosition (x, y, z) { this.pos = [x, y, z]; }, setWorldRotation () {} }, fov: 0 };
  const applied = C.applyCameraPose(cam, p, 'e4-v1.3.1-meadow-test');
  rec(`offset ${JSON.stringify(off)}: validateCameraPose null, applyCameraPose writes, |roll| < 0.001`, v === null && applied && Math.abs(r[1]) < 1e-3 && eq(cam.node.pos, world(off).position) && cam.fov === 45,
    { bad: v, applied, rightY: r[1], pitchDeg: Math.asin(f[1]) * 180 / Math.PI, yawDeg: Math.atan2(f[0], -f[2]) * 180 / Math.PI });
}
const p0 = C.fromLookAt(world([0, 0, 0])); const f0 = C.rotate(p0.rotation, [0, 0, -1]);
rec('derived forward = 运镜bot forward_cocos (1e-5)', eq(f0, alt.c1_format.forward_cocos, 1e-5), { derived: f0, check: alt.c1_format.forward_cocos });
// Re-derive 运镜bot's character margin with 0007's own characterBox/projectPoint (girl at player_spawn, 1.73 m incl. hat, 0.6 m wide)
const anchors = JSON.parse(readFileSync(anchorsJson, 'utf8')); const spawn = anchors.player_spawn.game_m;
for (const a of ['0.46', '0.75']) {
  const ch = alt.per_aspect[a].characters['girl_at_player_spawn_1.73m_hat']; const box = C.characterBox(spawn, 1.73, 0.3); const fc = C.frameCheck(p0, Number(a), box);
  rec(`aspect ${a}: 0007 frameCheck pass; character y_min ${fc.minY.toFixed(3)} (运镜bot ${ch['bbox_ndc[xmin,xmax,ymin,ymax]'][2]}), margin to -0.5 = ${(fc.minY + 0.5).toFixed(3)} (运镜bot ${ch['margin_to_-0.5']})`,
    fc.pass && Math.abs(fc.minY - ch['bbox_ndc[xmin,xmax,ymin,ymax]'][2]) <= 0.002 && fc.minY >= -0.5 && Math.abs(fc.minX - ch['bbox_ndc[xmin,xmax,ymin,ymax]'][0]) <= 0.002, fc);
}
const rolled = { ...p0, rotation: C.normalizeQuat([p0.rotation[0], p0.rotation[1], p0.rotation[2] + 0.05, p0.rotation[3]]) };
rec('control: rolled pose is rejected (roll-not-zero)', C.validateCameraPose(rolled) === 'roll-not-zero', { got: C.validateCameraPose(rolled) });
let thrown = false; try { C.assertAuthoredPose({ position: e.position, fovVerticalDeg: 45 }, 'x'); } catch { thrown = true; } rec('control: pose without target is rejected', thrown);
thrown = false; try { C.assertAuthoredPose({ ...e, rotation: [0, 0, 0, 1] }, 'x'); } catch { thrown = true; } rec('control: authored rotation is rejected', thrown);
rec('other stops untouched (tide=island, sky=null), island/home pose sources unchanged', D.REGION_CAMERA.stops[0].pose === 'island' && D.REGION_CAMERA.stops[2].pose === null && D.REGION_CAMERA.islandPoseSource === 'temporary-6m' && D.REGION_CAMERA.homePoseSource === 'oi-interim-standing');
const summary = { passed: res.filter(r => r.pass).length, failed: res.filter(r => !r.pass).length, results: res };
const s = JSON.stringify(summary, null, 1); console.log(s); if (out) writeFileSync(out, s + '\n'); process.exit(summary.failed ? 1 : 0);
