# E4 自定义材质移植草案 v1：草甸风草 + 不受光天空（Cocos Creator 3.8.8 / 微信小游戏）

GGbot（grokbot2）· 2026-10-09 · 草案，**没有在 Creator 编辑器、微信开发者工具或真机上跑过**。
能在这台电脑上验的都验了：用 Creator 3.8.8 安装包里自带的官方 effect 编译器编译、用 glslang 按 WebGL1 / WebGL2 编译并链接所有宏组合、CPU 参考实现对照美术公式和 v0.8 真实网格数据。结果见 `selftest/out/selftest-results.md`（52 通过 / 0 失败 / 6 未运行）。
没碰 0007 / 0008 的任何文件。

## 包内容

| 文件 | 说明 |
|---|---|
| `effects/meadow-grass-wind.effect` | 草甸草丛：COLOR_0 驱动的顶点风动（3 档）+ 根→尖混色 + 可选逐顶点简单光照 |
| `effects/sky-unlit.effect` | 天空球：按 UV 采样（或顶点色渐变），不受光、不写深度、推到远平面，昼夜色调、可选夜景图 / 慢速滚动 / 地平线雾 |
| `scripts/GrassWindQuality.ts` | 按微信机型档位自动选 `WIND_QUALITY`，运行时切档（保住实例化合批），组件 `GrassWindQualityAuto` |
| `MATERIAL-PARAMS.md` | 材质参数表（宏、属性、默认值、范围）和 COLOR_0 美术约定 |
| `selftest/` | Node 自测脚本 + 输出（`out/`） |
| `SHA256SUMS.txt` | 包内全部文件的 SHA256 |

**不带 `.meta`**：直接把文件放进工程，Creator 会自己生成 `.meta` 和 UUID。手写 `.meta` 反而容易和别人工程里的 UUID 冲突。

## 一、放到工程哪里

| 文件 | 位置 | 原因 |
|---|---|---|
| 两个 `.effect` | `assets/effects/`（主包） | 草甸、海岛、天空之城都会用天空；effect 编译后很小（WebGL1+WebGL2 两套 GLSL 源码合计：草约 53 KB、天空约 16 KB，未压缩），远程包里的材质引用主包里的 effect 不需要额外加载顺序 |
| `GrassWindQuality.ts` | `assets/scripts/render/`（主包脚本） | 纯脚本 |
| 草 / 天空材质 `.mtl` | `assets/bundles/region_meadow/materials/` | 跟 GLB 和贴图一起走 `region_meadow` 远程包 |
| 天空贴图 | `assets/bundles/region_meadow/textures/tex_meadow_sky_2048x1024.jpg` | 用已经缩好的 `team/ggbot/reports/meadow/sky/meadow_sky_2048x1024.jpg`（SHA256 `cc4dafd6…4e9e`，2048×1024 RGB）。美术最终要不要换原图由 Grok Bot 定 |

## 二、在 Creator 里给草甸 GLB 换材质

1. 新建材质 `mat_meadow_grass_wind.mtl`，Effect 选 `meadow-grass-wind`。
   - Defines：勾 `USE_INSTANCING`、`USE_INSTANCE_ROOT_COLOR`；`WIND_QUALITY` 设 **1**（数值宏默认是 0 = 静止，别忘了）；`WIND_PHASE_ORIGIN` 设 1；`GRASS_LIGHTING` 设 1（不受光就 0）。
   - `mainTexture` 拖 `meadow_palette_256`。其余参数先用默认值，就是美术 README 的公式和配色。
2. 选中导入的 `meadow_greybox_v0_8.glb`（或模板 GLB），在模型资源的材质映射里把 `M_meadow_grass_wind` 映射到上面的材质（或者在场景里每个草模板节点的 MeshRenderer 上换）。5 个草模板（T0–T4）**必须用同一个材质资源**，不要用 `getMaterialInstance()`，不要单独给某个 renderer 改属性，否则实例化合批会被拆开。
3. 草和花的 MeshRenderer：`Shadow Casting Mode = OFF`（不投影，美术 README 也这么建议；场景现在是平面阴影，投影会多一个 pass）。
4. 天空：新建 `mat_meadow_sky.mtl`，Effect 选 `sky-unlit`，`mainTexture` 拖天空图，Defines 里 `SKY_FOLLOW_CAMERA` 设 1，映射给 `M_meadow_sky`。场景的 Skybox 保持关闭（现在就是关的），相机 ClearFlags 用 SOLID_COLOR，清屏色设成地平线颜色，万一天空没盖住的地方也不会突兀。
   - 海岛 `env_sky_dome`：同一个 effect，`SKY_SOURCE` 设 1（只用顶点色渐变），不用贴图。
5. 花簇（F0–F2）继续用 builtin-standard，但材质要勾 `USE_INSTANCING`。

### MeadowInstancer 要配合改的地方（原型在 `team/ggbot/prototypes/MeadowInstancer.ts`，本包没改它）

- 引擎在换材质 / 重编 shader 后会**重建实例属性块（全清 0）**，所以 `a_root_color` 要能重设。建议把每个节点的根色存下来，监听 `GrassWindQualityAuto` 发出的事件后重设：

```ts
// MeadowInstancer.start() 里，生成节点时把 [r,g,b,1] 存到 this.rootColors.set(renderer, rgba)
this.node.on('grass-wind-quality-applied', () => {
  for (const [r, c] of this.rootColors) if (r.isValid) r.setInstancedAttribute('a_root_color', c);
});
```
- 风会把草尖推出网格包围盒（v0.8 数据最大 0.69 m），屏幕边缘可能看到草突然出现。可以在生成节点后把模板 mesh 的包围盒各方向扩 0.7 m（或给 model 设更大的包围盒），需要在 Creator 里实测。

## 三、画质档位（WIND_QUALITY）

| 档 | 顶点运算 | 用在 |
|---|---|---|
| 0 关 | 无（预处理后不含任何风代码，和静态网格同一条路径，自测已验） | 明确无法运行的设备、性能兜底、截图对比 |
| 1 低 | 1 个 sin + 几次乘加 | 默认；未知机型；中低端 |
| 2 高 | 4 个 sin（行波 + 整体摆动 + 阵风 2 个） | 高端机 |

自动选档（`pickGrassWindQuality`，阈值来自微信《设备档位下的用户分布》2026-03-04 版）：

| benchmarkLevel | 结果 |
|---|---|
| 没有 wx（Web/编辑器预览）、-1、读不到 | 1 低（modelLevel = 1 高档机时升到 2） |
| 0 或 -2（旧接口：设备无法运行） | 0 关 |
| Android ≥ 30 / iOS ≥ 36 | 2 高 |
| 其余 ≥ 1 | 1 低 |

读取顺序：`wx.getDeviceBenchmarkInfo`（基础库 ≥ 3.4.5，异步，800 ms 超时）→ `wx.getDeviceInfo().benchmarkLevel` → `wx.getSystemInfoSync().benchmarkLevel` → 未知。全部先判断 `wx` 和函数存在。

运行时切档：
- **推荐**：场景里挂 `GrassWindQualityAuto`（target 指草甸根节点），start 时自动选档并应用；也可以 `applyGrassWindQuality(renderers, q, { onReapplied })`。
- 原理：3.8.8 里共享材质不能 `recompileShaders`（只对 MaterialInstance 生效，否则打警告 16370），已有 pass 的材质也不能再 `initialize`（警告 12005）。所以每个档位复制一份运行时材质（`Material.copy(base, { defines: { WIND_QUALITY: q } })`），按档缓存，所有草 renderer 换成同一份 → 实例化合批保住；切回原档直接用回原资源。
- 只有调试单丛草时才用 `setGrassWindQualityOnInstance(materialInstance, q)`（走 `recompileShaders`，那丛会单独一个 draw call）。
- 切档会编译新的 shader 变体，微信上可能卡一帧，只在进场或设置界面切。

## 四、光照选择

草甸是风格化画面，草丛三角面 4.1 万、实例化后顶点约 6.8 万，片元覆盖大。所以：
- 不用 builtin-standard（PBR + IBL + 阴影接收，片元很重），用 **逐顶点** 半 Lambert（法线往上混 0.5，双面一致）+ 天空/地面半球环境光，片元只剩 1 次贴图采样和几次 mix。`lightScale` 默认 1/π，和场景里其他 builtin-standard 物体的漫反射同量级，美术可以调。
- `GRASS_LIGHTING 0` 就是纯不受光（颜色完全来自调色板 + 根尖混色），最省。
- 不接收实时阴影（平面阴影本来也不投到草上）；不投影。
- 颜色：tip = mix(调色板色, #C4E65A, 0.6)，base = mix(根色, tip, smoothstep(0.05, 0.95, COLOR_0.r))，完全按美术 README。COLOR_0 不当乘色用（它是风数据）。
- 不需要 alpha test：v0.8 草叶是实体几何（opaque、双面）。宏保留给以后插片草。
- 场景雾开着时自动走引擎雾（`CC_USE_FOG`）。

## 五、draw call 和实例化

| 情况 | 草的 draw call | 说明 |
|---|---|---|
| A. `MeadowInstancer` 展开 + 材质开 `USE_INSTANCING` | **5**（5 个模板各 1） | 前提：同 mesh + 同一个共享材质 + 同一个 shader 变体；不投影。1,000 个节点每帧还要做视锥剔除和实例缓冲上传（CPU，需真机实测） |
| A 但材质没开实例化 | 1,000 | 每丛一个 draw call，超预算 |
| B. 运行时合并网格 / Cocos 静态合批（`BatchingUtility`） | 每个合并块 1 个 | 世界矩阵变成单位阵：要设 `WIND_PHASE_ORIGIN 0`、`WIND_SPACE 0`；每实例根色丢了（只能用 `rootColor` 一个颜色），除非美术把根色烘进另一个顶点属性（见待确认问题） |
| WebGL1 设备不支持 `ANGLE_instanced_arrays` | 退化成 1,000 | 引擎自动退化（`Feature.INSTANCED_ARRAYS`）。微信 WebGL1 设备基本都支持，但建议启动时打一条日志 |

另外：切 `WIND_QUALITY` 不会增加 draw call（所有草都换成同一份材质）；天空 1 个 draw call；花 3 个（需要开实例化）。

## 六、天空贴图导入设置

美术约定：`meadow_sky` 是天空球（`meadow_sky_dome`，半径 280 m，1,392 三角面）的 UV 贴图，u = 方位/360°，v = (仰角+15°)/105°，不是 cubemap，所以按 UV 采样即可。

| 项 | 设置 | 原因 |
|---|---|---|
| 尺寸 | 2048×1024（原图 4096×1024 横向缩一半） | 预研 PSNR 48.3 dB，肉眼无差；最大边 ≤ 2048 |
| Mipmap | **关** | 天空在屏幕上始终是放大采样（竖屏 45° 视角下约 256 个横向纹素铺满屏幕宽），用不到 mip，还省 1/3 显存 |
| 过滤 | 双线性（min/mag Linear） | |
| Wrap | u = REPEAT（接缝处方位角连续，开滚动也需要）；v = CLAMP_TO_EDGE | |
| 色彩空间 | sRGB 图，shader 里 `SRGBToLinear` 后再输出（`CCFragOutput`），与引擎 builtin-unlit 一致 | |
| 压缩（构建里设压缩纹理预设） | 首选 ASTC 5×5 或 6×6；Android 兜底 ETC2 RGB；最后 JPG | 渐变天空压缩容易出色带，ASTC 6×6 先看效果，有色带就退到 5×5 / 4×4。PVRTC 要求正方形 2 的幂，不用。WebGL1 一般拿不到 ETC2，会回落到 JPG |

显存估算（单张，无 mip）：

| 格式 | 2048×1024 |
|---|---|
| RGBA8 未压缩（JPG/PNG 解码后） | 8.0 MiB（带 mip 10.7 MiB） |
| ASTC 4×4 | 2.0 MiB |
| ASTC 5×5 | 1.3 MiB |
| ASTC 6×6 | 0.89 MiB |
| ETC2 RGB | 1.0 MiB |

开 `USE_NIGHT_TEXTURE` 再加一张同样大小的夜景图；只用 `nightTint` 压色则不加显存。天空之城需要夜景：建议先试 `nightTint` + `nightBlend`，效果不够再要美术出夜景图。

## 七、自测范围（`selftest/`）

运行：`bash selftest/cc-compiler-setup/setup.sh selftest/.cc-effect-compiler`（从本机 Creator 3.8.8 安装里取出官方 effect 编译器，不在包里分发它），然后 `node selftest/run-selftest.js`。需要 `glslangValidator`（`apt install glslang-tools`）。

| 组 | 内容 | 结果 |
|---|---|---|
| a 结构 | CCEffect YAML 可解析；technique/pass 存在；vert/frag 指向的 CCProgram 和入口函数存在；每个 property 的 target 落在 UBO 成员上且分量数一致；UBO 分量不重复占用；没有 UBO 外的非 sampler uniform；UBO 只用 vec4（std140 无填充）；自定义 UBO 不跨阶段同名；varying 跨阶段名字/类型一致 | 通过 |
| b 官方编译器 | Creator 3.8.8 自带 `shdc-lib.js` + 3.8.8 engine chunks，0 错误 0 警告，产出 glsl1/glsl3/glsl4 | 通过 |
| b glslang | 按引擎 `program-lib.ts` 的拼接方式（管线常量宏 + 统计宏 + 全部宏定义 + 源码）生成变体，`#version 100`（WebGL1）和 `#version 300 es`（WebGL2）各编译并链接 vert+frag：草 392 个宏组合 = 784 个程序，天空 104 个 = 208 个；引擎 builtin-unlit 同法校准通过 | 通过 |
| c CPU 参考 | 把 effect 里的 `windOffset()` 原文机械翻译成 JS 执行：根部 r=0 位移恰好 0；有界；WIND_QUALITY 0 预处理后无风代码；改相位输出变；行波方向和速度正确；时间连续（≤ 解析 Lipschitz 上界）；默认参数与美术公式一致；float32 时间精度（连续运行 6 h 内草尖量化 ≤ 3.3 mm，24 h 13 mm）；v0.8 真实网格 + 1,000 个实例原点根部恒为 0 | 通过 |
| d TS | `GrassWindQuality.ts` 用 Creator 3.8.8 自带 TypeScript + `cc.d.ts` 严格模式 0 错误；分档表 13 例；wx 5 种情况（无 wx / 异步成功 / fail / 超时 / 抛异常）；切档后所有 renderer 共用一份材质 | 通过 |
| 反向对照 | 故意改坏 4 处（返回类型错、UBO 外 uniform、property target 写错、frag 读不存在的 varying），每处都被查出来，证明上面的“通过”有效。顺带确认：glslang 链接不查 GLSL ES 的 varying 接口，这项只能靠结构检查 | 通过 |
| not_run | Creator 编辑器导入 / 材质面板；构建 + 压缩纹理；DevTools / 真机 WebGL1/2 实际链接渲染；实例化实际 draw call；帧时间；画面观感 | 未运行 |

## 八、待美术（Grok Bot）确认

1. **COLOR_0.b 恒为 0.4193**：本包当“未用 / 预留”。它在美术工具里有含义吗？以后想放刚度或草种，告诉我值的约定。
2. **位移空间**：美术 README 是在模板本地 +X 上推（每丛随自己的朝向，v0.8 的 1,000 丛草绕 Y 轴朝向在 −3°~+43° 之间，相差约 46°）；本包默认用世界空间统一风向（整片草朝同一方向倒，更像风），`WIND_SPACE 1` 可切回原公式。用哪个？
3. **下沉项符号**：README `y −= 0.3·d·r`，d 为负（往回摆）时草尖会上抬。本包照原公式实现，是有意的吗？
4. **静态合批时的根色**：如果走方案 B（运行时合并），每实例根色没地方放。能否在导出时把根色烘进 COLOR_1 或 TEXCOORD_1（RGB）？
5. **调色板贴图采样**：GLB 里 palette 的采样器是 LINEAR_MIPMAP_LINEAR + CLAMP。调色板是色块拼图，远处 mip 会串色，建议关 mipmap（或最近点采样），请确认。
6. **天空夜景**：天空之城夜晚是用 `nightTint` 压色就够，还是要单独出夜景天空图？`nightTint` 默认 (0.32, 0.38, 0.62) 是占位，请给目标色。
7. **天空图尺寸**：用已缩好的 2048×1024，还是美术重新出图？
8. COLOR_0 实际存的是 UNSIGNED_SHORT 归一化，README 写的是 FLOAT；两者对 shader 没区别，只是文档对一下。
