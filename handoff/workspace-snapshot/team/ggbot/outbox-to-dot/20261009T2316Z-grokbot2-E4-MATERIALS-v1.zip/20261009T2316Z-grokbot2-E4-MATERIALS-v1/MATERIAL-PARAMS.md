# E4 材质参数表 v1（meadow-grass-wind / sky-unlit）

GGbot（grokbot2）· 2026-10-09 · 对应 Cocos Creator 3.8.8。默认值和范围都写在 `.effect` 里；这里是给美术和接入的人看的说明。
颜色属性全部按 **sRGB 拾色**（面板里看到的就是实际颜色），shader 里再转线性。没有用引擎的 `linear: true`：3.8.8 里 effect 自带的默认值不会经过 sRGB→线性转换（`Pass.resetUniform` 直接上传），只有材质里保存过的值才转，默认颜色会偏亮。

## 一、COLOR_0 约定（美术侧契约，草模板必须满足）

`meadow-grass-wind` 把 COLOR_0（Cocos 里叫 `a_color`）当 **风数据**，不是乘色。

| 通道 | 含义 | 取值 | v0.8 实测（5 个草模板，`meadow_grass_clump_templates_v0_8.glb`） |
|---|---|---|---|
| r | 弯曲权重：根 0 → 尖 1。位移按 r² 放大，根部固定 | 0–1；根部顶点必须正好 0 | 每个模板只有 4 个值：0 / 0.4 / 0.75 / 1.0（每片叶 4 圈）；r = 0 的顶点都在 y = −0.05 m（埋进地面 5 cm） |
| g | 相位偏移 / 2π（同一丛里不同叶子错开） | 0–1 | 0.000–0.999，每模板 8–9 个不同值 |
| b | **未使用，预留**（以后可放：刚度 / 草种 / 季节色） | 任意 | 恒为 0.4193（美术 README 写 0.419） |
| a | 振幅 / `amplitudeScale`（默认 1.5 m） | 0–1 | T0 0.504–0.737；T1 0.456–0.639；T2 0.435–0.568；T3 0.300–0.449；T4 0.239–0.390 |

- 存储格式：v0.8 实际是 **UNSIGNED_SHORT 归一化**（不是美术 README 写的 FLOAT），Cocos 导入后同样是 0–1 的 vec4，不影响 shader。
- 花簇模板（F0/F1/F2）没有 COLOR_0，用 `M_meadow_palette`（builtin-standard），不挂风材质。
- 每实例根色 `_ROOT_COLOR`（线性 RGB）：Cocos 导入器不读 `EXT_mesh_gpu_instancing`，由 `MeadowInstancer` 用 `setInstancedAttribute('a_root_color', [r, g, b, 1])` 传，材质要勾 `USE_INSTANCING` + `USE_INSTANCE_ROOT_COLOR`。1,000 个实例的线性均值 (0.109, 0.387, 0.031)，转 sRGB = #5DA731，这就是 `rootColor` 的默认兜底值。

## 二、meadow-grass-wind.effect

### 宏（材质面板 Defines）

| 宏 | 取值 | 默认 | 说明 |
|---|---|---|---|
| `USE_INSTANCING` | 开/关 | 关 | **草必须开**。同 mesh + 同一个共享材质的 MeshRenderer 合成一次实例化 draw call |
| `USE_INSTANCE_ROOT_COLOR` | 开/关 | 关 | 开：根色用每实例 `a_root_color`（只在 `USE_INSTANCING` 下生效）；关：用 `rootColor` |
| `WIND_QUALITY` | 0 / 1 / 2 | **0** | 0 关（静态，不做任何顶点运算）；1 低（单个行波正弦）；2 高（美术原公式两项 + 阵风）。引擎里数值宏默认取范围第一个值，所以**材质里要手动设 1 或 2**，或者用 `GrassWindQualityAuto` 运行时设 |
| `WIND_SPACE` | 0 / 1 | 0 | 0 世界空间：所有草沿 `windDir` 一起倒；1 模板本地 +X（美术 README 原公式，随每丛的旋转/缩放走） |
| `WIND_PHASE_ORIGIN` | 0 / 1 | 0 | 1 用实例原点算空间相位（整丛同相，**实例化 / 逐节点时设 1**）；0 用顶点世界坐标（静态合批 / 运行时合并网格时用，整丛内最多差 0.19 rad） |
| `GRASS_LIGHTING` | 0 / 1 | 0 | 0 不受光（颜色 = 根→尖混色 × mainColor）；1 逐顶点半 Lambert + 天空/地面环境光 |
| `USE_ALPHA_TEST` | 开/关 | 关 | v0.8 草是实体几何（opaque），不需要；以后换插片草时再开 |
| `CC_USE_FOG` 等 | 引擎管 | — | 场景雾开了会自动生效 |

推荐组合（草甸草丛）：`USE_INSTANCING=1, USE_INSTANCE_ROOT_COLOR=1, WIND_QUALITY=1（由脚本按机型改）, WIND_SPACE=0, WIND_PHASE_ORIGIN=1, GRASS_LIGHTING=1`。

### 属性

| 属性 | 默认 | 范围 | 写入 | 说明 |
|---|---|---|---|---|
| mainTexture | white | — | sampler | 调色板 `meadow_palette_256`（sRGB），按 TEXCOORD_0 采样 |
| tilingOffset | (1,1,0,0) | — | GrassWindVS.tilingOffset | UV 缩放/偏移 |
| mainColor | (1,1,1,1) | 颜色 | GrassWindFS.mainColor | 整体乘色；a 乘到透明度（只对 alpha test 有意义） |
| tipColor | (0.769,0.902,0.353) = #C4E65A | 颜色 | GrassWindFS.tipColor | 草尖调色（美术 README） |
| tipMix | 0.6 | 0–1 | colorParams.y | tip = mix(调色板色, tipColor, tipMix) |
| rootBlendStart | 0.05 | −1–1 | colorParams.z | 根→尖混合：smoothstep(start, end, COLOR_0.r) |
| rootBlendEnd | 0.95 | −1–2 | colorParams.w | start/end 都设成负数 = 不要根色，全用 tip |
| alphaThreshold | 0.5 | 0–1 | colorParams.x | 仅 `USE_ALPHA_TEST` |
| rootColor | (0.364,0.655,0.194) = #5DA731 | 颜色 | GrassWindVS.rootColor | 根色兜底（未开每实例根色时） |
| windDir | (0.944, −0.330) | 任意非零 | windDirSpeed.xy | 世界 XZ 风向（x, z），shader 内归一化；默认 = 美术主风向 W |
| windSpeed | 6.5 m/s | 0–30 | windDirSpeed.z | 风浪推进速度；周期 = 波长 / 速度 = 4 s |
| windWavelength | 26 m | 1–200 | windDirSpeed.w | 风浪波长（美术 26 m） |
| windStrength | 1.0 | 0–3 | windShape.x | 总倍率；0 = 不动（但顶点运算仍在，想省就设 WIND_QUALITY 0） |
| amplitudeScale | 1.5 m | 0–3 | windShape.y | COLOR_0.a 的米制换算（美术 1.5 m） |
| waveWeight | 0.36 | 0–1 | windShape.z | 行波项权重（美术 0.36） |
| swayWeight | 0.26 | 0–1 | windShape.w | 整体摆动项（美术 0.26），仅 WIND_QUALITY 2 |
| gustStrength | 0.15 | 0–1 | gustParams.x | 阵风权重，仅 WIND_QUALITY 2；**设 0 = 与美术公式逐项一致** |
| gustFreq | 0.12 Hz | 0–2 | gustParams.y | 阵风频率 |
| gustWavelength | 40 m | 1–200 | gustParams.z | 阵风团大小 |
| bendDrop | 0.3 | 0–1 | gustParams.w | y −= bendDrop × d × r（美术 0.3） |
| normalUpBlend | 0.5 | 0–1 | lightParams.x | 法线往 +Y 混，草丛受光更柔、双面一致（GRASS_LIGHTING） |
| wrapLighting | 0.5 | 0–1 | lightParams.y | 0 Lambert，1 半 Lambert |
| lightScale | 0.318（1/π） | 0–4 | lightParams.z | 主光倍率，默认与 builtin-standard 漫反射同量级 |
| ambientScale | 1.0 | 0–4 | lightParams.w | 环境光倍率 |

### 位移公式（shader 原文的意思）

```
A   = windStrength * amplitudeScale * COLOR_0.a                       // 米
k   = 2π / windWavelength ;  ωt = k * windSpeed * t                    // t = cc_time.x（秒）
ph  = k * dot(P, dir) + 2π * COLOR_0.g                                 // P = 实例原点 XZ（WIND_PHASE_ORIGIN 1）或顶点世界 XZ
w   = waveWeight * sin(ph − ωt)                                        // WIND_QUALITY ≥ 1
w  −= swayWeight * sin(ωt)                                             // WIND_QUALITY 2
w  += gustStrength * max(0, sin(gk·dot(P,dir) − 2π·gustFreq·t)) * (0.5 + 0.5·sin(0.588·gk·dot(P,perp) + 0.37·2π·gustFreq·t))   // WIND_QUALITY 2，gk = 2π/gustWavelength
d   = A * r² * w                                                       // r = COLOR_0.r，根部 r = 0 时 d = 0
世界空间：worldPos.xz += dir * d ; worldPos.y −= bendDrop * d * r
```

- |d| ≤ A·r²·(waveWeight + swayWeight + gustStrength)；默认权重和 0.77，所以草尖位移不超过 `windStrength × amplitudeScale × a`。
- 用 v0.8 实际数据算：草尖水平位移最大 0.69 m，下沉最大 0.21 m（自测 C8）。
- 默认参数、`gustStrength = 0`、`WIND_QUALITY 2`、`WIND_SPACE 1` 时和美术 README 公式一致（自测 C6：把 W 归一化后误差 < 1e−9 m；README 的 W = (0.944, −0.330) 长度 1.00002，原样用差 0.2 mm）。

## 三、sky-unlit.effect

### 宏

| 宏 | 取值 | 默认 | 说明 |
|---|---|---|---|
| `SKY_SOURCE` | 0 / 1 / 2 | 0 | 0 贴图（草甸 `meadow_sky`）；1 只用顶点色（海岛 `env_sky_dome` 的渐变）；2 贴图 × 顶点色 |
| `SKY_FOLLOW_CAMERA` | 0 / 1 | 0 | 1 = 天空球中心跟随相机 XZ（美术约定，**建议设 1**） |
| `USE_NIGHT_TEXTURE` | 开/关 | 关 | 开：再采一张夜景图，按 nightBlend 混；关：只用 nightTint 压色（省一张贴图显存） |
| `USE_UV_SCROLL` | 开/关 | 关 | u 方向慢速滚动（贴图 u 要 REPEAT） |
| `USE_HORIZON_FOG` | 开/关 | 关 | 地平线附近混到场景雾颜色 `cc_fogColor`（不走引擎雾，天空在 280 m 外，用引擎雾会整片变成雾色） |

### 属性

| 属性 | 默认 | 范围 | 写入 | 说明 |
|---|---|---|---|---|
| mainTexture | grey | — | sampler | 白天天空图（sRGB），按 TEXCOORD_0 采样 |
| nightTexture | black | — | sampler | 夜景天空图（仅 USE_NIGHT_TEXTURE） |
| tilingOffset | (1,1,0,0) | — | SkyVS.tilingOffset | |
| dayTint | (1,1,1,1) | 颜色 | SkyFS.dayTint | 白天乘色 |
| nightTint | (0.32,0.38,0.62,1) | 颜色 | SkyFS.nightTint | 夜晚乘色（占位值，等美术定） |
| nightBlend | 0 | 0–1 | skyParams.x | 0 白天 → 1 夜晚；昼夜过渡时用脚本插值 |
| intensity | 1.0 | 0–4 | skyParams.y | 整体亮度 |
| scrollSpeed | 0.002 | ±0.05 | skyVSParams.x | 每秒滚动多少 u（0.002 ≈ 8 分钟一圈）；仅 USE_UV_SCROLL |
| horizonFog | 0 | 0–1 | horizonParams.x | 地平线雾强度；仅 USE_HORIZON_FOG |
| horizonV | 0.143 | 0–1 | horizonParams.y | 地平线所在 v。草甸约定 v = (仰角+15°)/105°，仰角 0° → 0.143 |
| horizonWidth | 0.12 | 0.001–1 | horizonParams.z | 雾从地平线往上淡出的 v 宽度 |

渲染状态（effect 里写死）：`priority: max - 10`、`depthTest: true`、`depthWrite: false`、`cullMode: none`、顶点 z 推到远平面（`0.99999·w`，与引擎内置 skybox 相同）。
