/**
 * GrassWindQuality.ts · E4 draft v1（grokbot2 / GGbot）· Cocos Creator 3.8.8 · 未在 Creator / 真机里运行过（not_run）
 *
 * 管 meadow-grass-wind.effect 的 WIND_QUALITY 宏（0 关 / 1 低 / 2 高）：
 *  - pickGrassWindQuality()：纯函数，按微信 benchmarkLevel / modelLevel 选档（可单测）。
 *  - queryDeviceBenchmark()：读 wx.getDeviceBenchmarkInfo（基础库 ≥ 3.4.5，异步），失败再退到
 *    wx.getDeviceInfo().benchmarkLevel、wx.getSystemInfoSync().benchmarkLevel；没有 wx（Web / 编辑器预览）= 未知。
 *  - applyGrassWindQuality()：给一组 MeshRenderer 换成“同一个”带新宏的共享材质 → GPU 实例化合批不被打断。
 *  - setGrassWindQualityOnInstance()：只对 MaterialInstance 用 recompileShaders（会脱离共享材质，单独一次 draw call）。
 *
 * 为什么不直接改共享材质的宏：3.8.8 的 Material.recompileShaders 只对 MaterialInstance 生效（共享 Material 上只打警告 16370），
 * Material.initialize 在已有 pass 时也会拒绝（警告 12005）。所以每档复制一份运行时 Material（Material.copy + defines 覆盖），按档缓存。
 *
 * 注意：
 *  1. 换材质后引擎会重建每个 subModel 的实例属性块（全 0），自定义实例属性（a_root_color）要重新 setInstancedAttribute，
 *     见 ApplyOptions.onReapplied 和 GrassWindQualityAuto 发出的 'grass-wind-quality-applied' 事件。
 *  2. 切档会触发新 shader 变体编译，微信上可能卡一帧，建议只在进场 / 设置界面切。
 */
import { _decorator, Component, Material, MeshRenderer, Node, renderer } from 'cc';
const { ccclass, property } = _decorator;

export enum GrassWindQuality { OFF = 0, LOW = 1, HIGH = 2 }

/** effect 资源名以此结尾的材质才会被处理（用户 effect 的 name 可能带目录前缀）。 */
export const GRASS_WIND_EFFECT_SUFFIX = 'meadow-grass-wind';
export const GRASS_WIND_QUALITY_EVENT = 'grass-wind-quality-applied';

export interface DeviceBenchmark {
  benchmarkLevel: number;      // -1 未知；>= 1 性能值（越高越好，移动端目前 < 50）；旧接口里 0 / -2 表示“无法运行”
  modelLevel: number;          // 0 未知；1 高；2 中；3 低（仅 getDeviceBenchmarkInfo 有；会随时间变化，只作参考）
  platform: string;            // 'ios' | 'android' | 'devtools' | 'windows' | 'mac' | 'web' ...
  source: 'getDeviceBenchmarkInfo' | 'getDeviceInfo' | 'getSystemInfoSync' | 'none';
}

/**
 * 分档阈值（微信《设备档位下的用户分布》2026-03-04 版：Android 高档 >= 30、中档 23–29；iOS 高档 >= 36、中档 30–35）。
 * 风动是顶点运算，草甸实例约 8.8 万顶点，低档机也只是几个 sin，所以只有“明确无法运行”才关。
 */
export const GRASS_WIND_THRESHOLDS = { androidHigh: 30, iosHigh: 36 };

export function pickGrassWindQuality (b: Partial<DeviceBenchmark> | null | undefined): GrassWindQuality {
  const level = b && typeof b.benchmarkLevel === 'number' && isFinite(b.benchmarkLevel) ? b.benchmarkLevel : -1;
  const platform = (b && b.platform ? String(b.platform) : '').toLowerCase();
  if (level === 0 || level === -2) return GrassWindQuality.OFF;           // 旧接口：设备无法运行小游戏
  if (level < 1) {                                                        // -1 / 未知 / 没有 wx → 低
    if (b && b.modelLevel === 1) return GrassWindQuality.HIGH;            // 档位已知是高档机时才升
    return GrassWindQuality.LOW;
  }
  const high = platform === 'ios' ? GRASS_WIND_THRESHOLDS.iosHigh : GRASS_WIND_THRESHOLDS.androidHigh;
  return level >= high ? GrassWindQuality.HIGH : GrassWindQuality.LOW;
}

declare const wx: any;

function wxApi (): any { return typeof wx !== 'undefined' && wx ? wx : null; }

function syncPlatform (w: any): string {
  try { if (typeof w.getDeviceInfo === 'function') return String(w.getDeviceInfo().platform || ''); } catch (e) { /* ignore */ }
  try { if (typeof w.getSystemInfoSync === 'function') return String(w.getSystemInfoSync().platform || ''); } catch (e) { /* ignore */ }
  return '';
}

function syncBenchmark (w: any): DeviceBenchmark {
  const platform = syncPlatform(w);
  try {
    if (typeof w.getDeviceInfo === 'function') {
      const lv = w.getDeviceInfo().benchmarkLevel;
      if (typeof lv === 'number') return { benchmarkLevel: lv, modelLevel: 0, platform, source: 'getDeviceInfo' };
    }
  } catch (e) { /* ignore */ }
  try {
    if (typeof w.getSystemInfoSync === 'function') {
      const lv = w.getSystemInfoSync().benchmarkLevel;
      if (typeof lv === 'number') return { benchmarkLevel: lv, modelLevel: 0, platform, source: 'getSystemInfoSync' };
    }
  } catch (e) { /* ignore */ }
  return { benchmarkLevel: -1, modelLevel: 0, platform, source: 'none' };
}

/** 读设备档位；永不 reject。timeoutMs 内 getDeviceBenchmarkInfo 没回调就退到同步接口。 */
export function queryDeviceBenchmark (timeoutMs = 800): Promise<DeviceBenchmark> {
  const w = wxApi();
  if (!w) return Promise.resolve({ benchmarkLevel: -1, modelLevel: 0, platform: 'web', source: 'none' });
  if (typeof w.getDeviceBenchmarkInfo !== 'function') return Promise.resolve(syncBenchmark(w));
  return new Promise<DeviceBenchmark>((resolve) => {
    let done = false;
    const finish = (b: DeviceBenchmark): void => { if (!done) { done = true; resolve(b); } };
    const timer = setTimeout(() => finish(syncBenchmark(w)), timeoutMs);
    try {
      w.getDeviceBenchmarkInfo({
        success: (res: any) => {
          clearTimeout(timer);
          const lv = typeof res?.benchmarkLevel === 'number' ? res.benchmarkLevel : -1;
          const ml = typeof res?.modelLevel === 'number' ? res.modelLevel : 0;
          finish({ benchmarkLevel: lv, modelLevel: ml, platform: syncPlatform(w), source: 'getDeviceBenchmarkInfo' });
        },
        fail: () => { clearTimeout(timer); finish(syncBenchmark(w)); },
      });
    } catch (e) { clearTimeout(timer); finish(syncBenchmark(w)); }
  });
}

export async function autoPickGrassWindQuality (): Promise<GrassWindQuality> {
  return pickGrassWindQuality(await queryDeviceBenchmark());
}

export function isGrassWindMaterial (m: Material | null | undefined): m is Material {
  return !!m && !!m.effectAsset && String(m.effectName || '').endsWith(GRASS_WIND_EFFECT_SUFFIX);
}

/** 当前材质第 0 个 pass 上的 WIND_QUALITY（没设过 = 0）。 */
export function getGrassWindQuality (m: Material): GrassWindQuality {
  const p = m.passes && m.passes[0];
  const v = p ? (p.defines as renderer.MacroRecord).WIND_QUALITY : 0;
  return (typeof v === 'number' ? v : Number(v) || 0) as GrassWindQuality;
}

const qualityCache = new WeakMap<Material, Material[]>();
const originalOf = new WeakMap<Material, Material>();

/** 取 base 材质在某档下的运行时共享材质（同一 base + 同一档始终返回同一个对象，保证实例化合批）。 */
export function getQualityMaterial (base: Material, q: GrassWindQuality): Material {
  const root = originalOf.get(base) || base;
  let list = qualityCache.get(root);
  if (!list) { list = []; qualityCache.set(root, list); }
  if (getGrassWindQuality(root) === q) return root;
  let m = list[q];
  if (!m) {
    m = new Material();
    m.copy(root, { defines: { WIND_QUALITY: q } });   // 复制属性 / 状态 / 其他宏，只覆盖 WIND_QUALITY
    m.name = `${root.name || 'grass'}#WIND_QUALITY=${q}`;
    originalOf.set(m, root);
    list[q] = m;
  }
  return m;
}

export interface ApplyOptions {
  /** 每个被换了材质的 renderer 回调一次，用来重新 setInstancedAttribute('a_root_color', ...)。 */
  onReapplied?: (r: MeshRenderer) => void;
}

/** 给一组 MeshRenderer 切档。返回实际换掉的材质槽数量。 */
export function applyGrassWindQuality (renderers: readonly MeshRenderer[], q: GrassWindQuality, opts: ApplyOptions = {}): number {
  let changed = 0;
  for (const r of renderers) {
    if (!r || !r.isValid) continue;
    let touched = false;
    const mats = r.sharedMaterials;
    for (let i = 0; i < mats.length; i++) {
      const m = mats[i];
      if (!isGrassWindMaterial(m)) continue;
      const target = getQualityMaterial(m, q);
      if (target !== m) { r.setSharedMaterial(target, i); changed++; touched = true; }
    }
    if (touched && opts.onReapplied) opts.onReapplied(r);
  }
  return changed;
}

/** 只用于已经是 MaterialInstance 的材质（例如单独调试一丛草）。共享材质返回 false，不做任何事。 */
export function setGrassWindQualityOnInstance (m: Material, q: GrassWindQuality): boolean {
  if (!(m instanceof renderer.MaterialInstance)) return false;
  m.recompileShaders({ WIND_QUALITY: q });
  return true;
}

/**
 * 场景组件：start 时自动选档（或用 overrideQuality），对 target 下所有用 meadow-grass-wind 的 MeshRenderer 生效，
 * 然后在 target 节点上发 'grass-wind-quality-applied'(quality, renderers)，MeadowInstancer 收到后重设 a_root_color。
 */
@ccclass('GrassWindQualityAuto')
export class GrassWindQualityAuto extends Component {
  @property(Node) target: Node | null = null;
  /** -1 = 自动；0 / 1 / 2 = 强制。 */
  @property overrideQuality = -1;

  static current: GrassWindQuality | null = null;
  static lastBenchmark: DeviceBenchmark | null = null;

  async start (): Promise<void> {
    let q: GrassWindQuality;
    if (this.overrideQuality >= 0 && this.overrideQuality <= 2) {
      q = this.overrideQuality as GrassWindQuality;
    } else {
      const b = await queryDeviceBenchmark();
      GrassWindQualityAuto.lastBenchmark = b;
      q = pickGrassWindQuality(b);
    }
    if (!this.isValid) return;
    this.apply(q);
  }

  apply (q: GrassWindQuality): number {
    const root = this.target || this.node;
    const rs = root.getComponentsInChildren(MeshRenderer);
    const n = applyGrassWindQuality(rs, q);
    GrassWindQualityAuto.current = q;
    root.emit(GRASS_WIND_QUALITY_EVENT, q, rs);
    return n;
  }
}
