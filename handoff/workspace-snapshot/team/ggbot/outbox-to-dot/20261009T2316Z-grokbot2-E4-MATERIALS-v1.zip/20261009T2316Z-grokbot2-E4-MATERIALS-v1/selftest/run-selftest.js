#!/usr/bin/env node
// E4 材质自测（Node）。不需要 Creator 运行；需要：
//  - 本机 Cocos Creator 3.8.8 安装（用它自带的 effect 编译器 shdc-lib.js 和 engine chunks；先跑 cc-compiler-setup/setup.sh）
//  - glslangValidator（apt: glslang-tools）
// 用法: node run-selftest.js [--engine <engineRoot>] [--compiler <dir>] [--glb <templates.glb>] [--instances <json>] [--out <dir>]
'use strict';
const fs = require('fs'), ps = require('path'), cp = require('child_process'), os = require('os');
const ref = require('./wind-reference');

const args = process.argv.slice(2); const arg = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const HERE = __dirname;
const ENGINE = arg('--engine', '/opt/cocos/CocosCreator-3.8.8-win/resources/resources/3d/engine');
const COMPILER = arg('--compiler', ps.join(HERE, '.cc-effect-compiler'));
const GLB = arg('--glb', '/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/meadow_grass_clump_templates_v0_8.glb');
const INST = arg('--instances', '/workspace/wechat-game/team/ggbot/reports/meadow/meadow_instances_v0_8.json');
const OUT = arg('--out', ps.join(HERE, 'out'));
const EFFECTS = [ps.join(HERE, '../effects/meadow-grass-wind.effect'), ps.join(HERE, '../effects/sky-unlit.effect')];
fs.mkdirSync(OUT, { recursive: true });

const results = []; // {id, group, status: passed|failed|not_run, detail}
const rec = (group, id, ok, detail) => { results.push({ group, id, status: ok === null ? 'not_run' : ok ? 'passed' : 'failed', detail }); };

// ---------------------------------------------------------------- (a) 结构检查
const yaml = require(ps.join(COMPILER, 'node_modules/js-yaml'));
function splitEffect (text) {
  const eff = text.match(/CCEffect\s*%\{([\s\S]*?)\}%/);
  const progs = {}; const re = /CCProgram\s+([\w-]+)\s*%\{([\s\S]*?)\}%/g; let m;
  while ((m = re.exec(text))) progs[m[1]] = m[2];
  return { yamlText: eff ? eff[1] : null, progs };
}
function stripComments (s) { return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, ''); }
function parseUBOs (src) {
  const s = stripComments(src); const ubos = {}; const re = /uniform\s+(\w+)\s*\{([^}]*)\}\s*;/g; let m;
  while ((m = re.exec(s))) {
    ubos[m[1]] = m[2].split(';').map(x => x.trim()).filter(Boolean).map(decl => {
      const t = decl.replace(/\b(highp|mediump|lowp)\b/g, '').trim().split(/\s+/); return { type: t[0], name: t[1] };
    });
  }
  return ubos;
}
function looseUniforms (src) {
  const s = stripComments(src).replace(/uniform\s+\w+\s*\{[^}]*\}\s*;/g, '');
  const out = []; const re = /\buniform\s+(?:highp\s+|mediump\s+|lowp\s+)?(\w+)\s+(\w+)/g; let m;
  while ((m = re.exec(s))) if (!/^sampler/.test(m[1])) out.push(m[1] + ' ' + m[2]);
  return out;
}
function varyings (src, kw) {
  const out = {}; const re = new RegExp(`^\\s*${kw}\\s+(?:highp\\s+|mediump\\s+|lowp\\s+)?(\\w+)\\s+(\\w+)\\s*;`, 'gm'); let m;
  const s = stripComments(src); while ((m = re.exec(s))) if (!/^a_/.test(m[2])) out[m[2]] = m[1];
  return out;
}
function varyingIssues (vsSrc, fsSrc) {
  const o = varyings(vsSrc, 'out'), i = varyings(fsSrc, 'in'); const issues = [];
  for (const [n, t] of Object.entries(i)) { if (!(n in o)) issues.push(`frag 读 ${n} 但 vert 没有输出`); else if (o[n] !== t) issues.push(`${n}: vert ${o[n]} / frag ${t}`); }
  return { issues, vs: o, fs: i };
}
const STD140_SIZE = { vec4: 16, mat4: 64, ivec4: 16 };
const compKeys = { x: 0, y: 1, z: 2, w: 3 };

const compile = require(ps.join(COMPILER, 'compile.js')).make(ENGINE);
const compiled = {};
for (const file of EFFECTS) {
  const name = ps.basename(file, '.effect'); const text = fs.readFileSync(file, 'utf8');
  const { yamlText, progs } = splitEffect(text);
  rec('a-structure', `${name}: CCEffect 头存在且 YAML 可解析`, !!yamlText, '');
  let doc = null; try { doc = yaml.load(yamlText); } catch (e) { rec('a-structure', `${name}: YAML 解析`, false, String(e)); continue; }
  const techs = doc && doc.techniques;
  rec('a-structure', `${name}: techniques/passes 存在`, Array.isArray(techs) && techs.length > 0 && techs.every(t => Array.isArray(t.passes) && t.passes.length > 0), JSON.stringify((techs || []).map(t => t.name)));
  for (const t of techs || []) for (const [pi, p] of t.passes.entries()) {
    for (const stage of ['vert', 'frag']) {
      const [prog, entry] = String(p[stage] || '').split(':');
      const ok = !!progs[prog] && new RegExp(`\\bvec4\\s+${entry}\\s*\\(`).test(progs[prog]);
      rec('a-structure', `${name}: ${t.name}.pass${pi}.${stage} = ${p[stage]} 指向存在的 CCProgram 和入口函数`, ok, '');
    }
    const vsU = parseUBOs(progs[String(p.vert).split(':')[0]] || ''), fsU = parseUBOs(progs[String(p.frag).split(':')[0]] || '');
    const shared = Object.keys(vsU).filter(k => k in fsU);
    rec('a-structure', `${name}: 自定义 UBO 不跨阶段同名（各阶段布局独立）`, shared.length === 0, shared.join(','));
    const all = { ...vsU, ...fsU };
    const badTypes = []; let bytes = 0;
    for (const [b, mem] of Object.entries(all)) for (const x of mem) { if (!(x.type in STD140_SIZE)) badTypes.push(`${b}.${x.name}:${x.type}`); else bytes += STD140_SIZE[x.type]; }
    rec('a-structure', `${name}: UBO 成员只用 vec4/mat4（std140 无填充，WebGL1 展开为 uniform 也无对齐问题）`, badTypes.length === 0, `blocks=${Object.keys(all).join(',')} bytes=${bytes} bad=${badTypes.join(',')}`);
    const loose = [...looseUniforms(progs[String(p.vert).split(':')[0]]), ...looseUniforms(progs[String(p.frag).split(':')[0]])];
    rec('a-structure', `${name}: 没有 UBO 之外的非 sampler uniform`, loose.length === 0, loose.join(','));
    const vi = varyingIssues(progs[String(p.vert).split(':')[0]] || '', progs[String(p.frag).split(':')[0]] || '');
    rec('a-structure', `${name}: 自定义 varying 跨阶段名字/类型一致（glslang -l 不查这一项，所以单独查）`, vi.issues.length === 0, vi.issues.join('; ') || Object.entries(vi.fs).map(([n, t]) => t + ' ' + n).join(', '));
    const members = {}; for (const [b, mem] of Object.entries(all)) for (const x of mem) members[x.name] = x.type;
    const samplers = (stripComments(Object.values(progs).join('\n')).match(/uniform\s+sampler\w+\s+(\w+)/g) || []).map(s => s.split(/\s+/).pop());
    const propIssues = [];
    for (const [pn, pv] of Object.entries(p.properties || {})) {
      const target = pv.target || pn; const [base, sw] = target.split('.');
      if (samplers.includes(base)) continue;
      if (!(base in members)) { propIssues.push(`${pn}->${target}: 无此 UBO 成员`); continue; }
      const n = sw ? sw.length : (members[base] === 'vec4' ? 4 : 16);
      if (sw && ![...sw].every(c => c in compKeys)) propIssues.push(`${pn}: 非法分量 ${sw}`);
      const v = Array.isArray(pv.value) ? pv.value.length : 1;
      if (sw && v !== n) propIssues.push(`${pn}: 默认值 ${v} 个分量但目标 ${target} 有 ${n} 个`);
      if (!sw && members[base] === 'vec4' && v !== 4) propIssues.push(`${pn}: 默认值应为 4 分量`);
    }
    rec('a-structure', `${name}: 每个 property 的 target 都落在 UBO 成员/sampler 上，分量数一致`, propIssues.length === 0, propIssues.join('; ') || `${Object.keys(p.properties || {}).length} props`);
    // 同一 UBO 分量不被两个 property 重复占用
    const used = {}; const dup = [];
    for (const [pn, pv] of Object.entries(p.properties || {})) { const t = pv.target || pn; const [b, sw] = t.split('.'); for (const c of (sw || 'xyzw')) { const k = b + '.' + c; if (used[k]) dup.push(`${k}: ${used[k]} & ${pn}`); used[k] = pn; } }
    rec('a-structure', `${name}: UBO 分量没有被两个 property 重复占用`, dup.length === 0, dup.join('; '));
  }
  // (a2) 官方编译器
  const r = compile(file);
  compiled[name] = r.effect;
  rec('b-cocos-shdc', `${name}: Cocos 3.8.8 官方 effect 编译器（shdc-lib）0 错误 0 警告`, r.errors.length === 0 && r.warnings.length === 0, [...r.errors, ...r.warnings].join(' | ').slice(0, 800));
  if (r.effect) {
    fs.writeFileSync(ps.join(OUT, `${name}.compiled.json`), JSON.stringify(r.effect, null, 1));
    for (const s of r.effect.shaders) {
      const defs = s.defines.map(d => d.name);
      for (const t of r.effect.techniques) for (const p of t.passes) for (const [pn, pv] of Object.entries(p.properties || {})) {
        const par = pv.editor && pv.editor.parent; if (par && !defs.includes(par)) rec('a-structure', `${name}: ${pn}.editor.parent=${par} 是 shader 里存在的宏`, false, '');
      }
      rec('b-cocos-shdc', `${name}: 生成 glsl1(WebGL1)/glsl3(WebGL2)/glsl4 三套源码`, !!(s.glsl1 && s.glsl3 && s.glsl4), s.name);
      rec('b-cocos-shdc', `${name}: uniform 向量统计`, true, JSON.stringify(s.builtins.statistics));
    }
  }
}

// ---------------------------------------------------------------- (b) glslang 变体编译
const GLSLANG = (() => { try { return cp.execFileSync('which', ['glslangValidator']).toString().trim(); } catch (e) { return null; } })();
const glslangVersion = GLSLANG ? cp.execFileSync(GLSLANG, ['--version']).toString().split('\n')[0] : null;
function pipelineConstants (profile) {
  const webgl1 = profile === 'glsl1';
  return [
    `#define CC_DEVICE_SUPPORT_FLOAT_TEXTURE ${webgl1 ? 0 : 1}`,
    '#define CC_ENABLE_CLUSTERED_LIGHT_CULLING 0',
    `#define CC_DEVICE_MAX_VERTEX_UNIFORM_VECTORS ${webgl1 ? 128 : 256}`,
    `#define CC_DEVICE_MAX_FRAGMENT_UNIFORM_VECTORS ${webgl1 ? 64 : 224}`,
    '#define CC_DEVICE_CAN_BENEFIT_FROM_INPUT_ATTACHMENT 0',
    '#define CC_PLATFORM_ANDROID_AND_WEBGL 0',
    '#define CC_ENABLE_WEBGL_HIGHP_STRUCT_VALUES 0',
    '#define CC_JOINT_UNIFORM_CAPACITY 30',
  ].join('\n') + '\n';
}
function macroValue (d, v) {
  if (d.type === 'boolean') return v ? '1' : '0';
  if (d.type === 'number') return String(v === undefined ? d.range[0] : v);
  if (d.type === 'string') return v === undefined ? d.options[0] : v;
  return '0';
}
function buildSource (shader, stage, profile, defs) {
  const tmpl = shader[profile];
  const statistics = Object.entries(shader.builtins.statistics).map(([k, v]) => `#define ${k} ${v}`).join('\n') + '\n';
  const macros = shader.defines.map(d => `#define ${d.name} ${macroValue(d, defs[d.name])}`).join('\n') + '\n';
  const prefix = pipelineConstants(profile) + statistics + macros;   // 与 program-lib.ts getGFXShader 相同的拼接顺序
  const header = profile === 'glsl1' ? '#version 100\n' : '#version 300 es\n'; // webgl2-commands.ts 也是在最前面加 #version 300 es
  return header + prefix + tmpl[stage];
}
function cartesian (axes) { return Object.entries(axes).reduce((acc, [k, vals]) => acc.flatMap(a => vals.map(v => ({ ...a, [k]: v }))), [{}]); }
const tmpDir = fs.mkdtempSync(ps.join(os.tmpdir(), 'e4-glsl-'));
function glslang (src, stage, extra = []) {
  const f = ps.join(tmpDir, `s${Math.random().toString(36).slice(2)}.${stage}`); fs.writeFileSync(f, src);
  const r = cp.spawnSync(GLSLANG, [...extra, f], { encoding: 'utf8' }); fs.unlinkSync(f);
  return { ok: r.status === 0, out: (r.stdout || '') + (r.stderr || '') };
}
// vert + frag 一起编译并链接（-l）。注意：glslang 对 GLSL ES 不做跨阶段 varying 接口匹配（反向对照 N4 证实），varying 由结构检查负责
function glslangLink (shader, profile, defs) {
  const id = Math.random().toString(36).slice(2); const fv = ps.join(tmpDir, `${id}.vert`), ff = ps.join(tmpDir, `${id}.frag`);
  fs.writeFileSync(fv, buildSource(shader, 'vert', profile, defs)); fs.writeFileSync(ff, buildSource(shader, 'frag', profile, defs));
  const r = cp.spawnSync(GLSLANG, ['-l', fv, ff], { encoding: 'utf8' }); fs.unlinkSync(fv); fs.unlinkSync(ff);
  return { ok: r.status === 0, out: (r.stdout || '') + (r.stderr || '') };
}
const MATRIX = {
  'meadow-grass-wind': {
    WIND_QUALITY: [0, 1, 2], WIND_SPACE: [0, 1], WIND_PHASE_ORIGIN: [0, 1], GRASS_LIGHTING: [0, 1],
    USE_INSTANCING: [false, true], USE_INSTANCE_ROOT_COLOR: [false, true], USE_ALPHA_TEST: [false, true], CC_USE_FOG: [0, 1],
  },
  'sky-unlit': { SKY_SOURCE: [0, 1, 2], SKY_FOLLOW_CAMERA: [0, 1], USE_UV_SCROLL: [false, true], USE_HORIZON_FOG: [false, true], USE_NIGHT_TEXTURE: [false, true], USE_INSTANCING: [false, true] },
};
const EXTRA = [ { CC_USE_HDR: true }, { CC_USE_HDR: true, CC_TONE_MAPPING_TYPE: 1, HDR_TONE_MAPPING_ACES: true }, { CC_USE_FOG: 2 }, { CC_USE_FOG: 3 }, { CC_USE_FOG: 4 }, { CC_USE_ACCURATE_FOG: true, CC_USE_FOG: 1 }, { CC_USE_RGBE_OUTPUT: true }, { CC_USE_FLOAT_OUTPUT: true } ];
const glslLog = [];
if (!GLSLANG) {
  rec('b-glslang', 'glslangValidator 可用', null, '未安装 glslangValidator（apt install glslang-tools）');
} else {
  // 校准：引擎自带 builtin-unlit 在同一套拼接下必须通过，否则说明拼接方式不对、本组结果无效。
  const unlit = compile(ps.join(ENGINE, 'editor/assets/effects/builtin-unlit.effect')).effect;
  let calFail = [];
  const s0 = unlit.shaders[0];
  for (const v of cartesian({ USE_INSTANCING: [false, true], USE_TEXTURE: [false, true], USE_VERTEX_COLOR: [false, true], CC_USE_FOG: [0, 1] }))
    for (const profile of ['glsl1', 'glsl3']) {
      const r = glslangLink(s0, profile, v); if (!r.ok) calFail.push(`${profile}/${JSON.stringify(v)}: ${r.out.slice(0, 300)}`);
    }
  rec('b-glslang', `校准：引擎 builtin-unlit 16 个变体 × WebGL1/WebGL2 用同一拼接方式编译 + 链接（vert+frag）通过（${glslangVersion}）`, calFail.length === 0, calFail.slice(0, 3).join(' | '));
  for (const [name, axes] of Object.entries(MATRIX)) {
    const eff = compiled[name]; if (!eff) { rec('b-glslang', `${name}: 变体编译`, false, '官方编译器没有产出'); continue; }
    const sh = eff.shaders[0];
    const variants = cartesian(axes).concat(EXTRA.map(e => ({ ...e })));
    let n = 0; const fails = [];
    for (const v of variants) for (const profile of ['glsl1', 'glsl3']) {
      const r = glslangLink(sh, profile, v); n++;
      if (!r.ok) fails.push(`${profile}/${JSON.stringify(v)}: ${r.out.replace(/\s+/g, ' ').slice(0, 400)}`);
    }
    glslLog.push({ effect: name, variants: variants.length, linkedPrograms: n, failures: fails });
    rec('b-glslang', `${name}: ${variants.length} 个宏组合 × GLSL ES 1.00(WebGL1) / 3.00 es(WebGL2) = ${n} 个程序（vert+frag 编译并链接）全部通过`, fails.length === 0, fails.slice(0, 3).join(' | '));
  }
  // WIND_QUALITY 0 预处理后不含任何风运算（与静态网格同一条顶点路径）
  const g = compiled['meadow-grass-wind'].shaders[0];
  for (const profile of ['glsl1', 'glsl3']) {
    const pre = q => glslang(buildSource(g, 'vert', profile, { WIND_QUALITY: q, USE_INSTANCING: true, USE_INSTANCE_ROOT_COLOR: true, GRASS_LIGHTING: 1 }), 'vert', ['-E']).out;
    const p0 = pre(0), p1 = pre(1), p2 = pre(2);
    const noWind = !/windOffset|cc_time\.|\bsin\s*\(/.test(p0) && /vec4\s+worldPos\s*=\s*matWorld\s*\*\s*position\s*;/.test(p0);
    rec('c-cpu-reference', `${profile}: WIND_QUALITY=0 预处理结果里没有 windOffset / cc_time.x / sin（cc_time 只剩 CCGlobal 里的声明），顶点 = matWorld * position`, noWind, '');
    const sinCount = s => (s.match(/\bsin\s*\(/g) || []).length;
    rec('c-cpu-reference', `${profile}: WIND_QUALITY=1 只有 1 个 sin（单正弦），WIND_QUALITY=2 有 4 个（行波 + 摆动 + 阵风 2 个）`, sinCount(p1) === 1 && sinCount(p2) === 4, `sin count q1=${sinCount(p1)} q2=${sinCount(p2)}`);
  }
}
// 反向对照：故意改坏的 effect 必须被查出来，证明上面的“通过”不是检查形同虚设
if (GLSLANG) {
  const src = fs.readFileSync(EFFECTS[0], 'utf8');
  const mk = (name, from, to) => { const f = ps.join(tmpDir, name + '.effect'); if (!src.includes(from)) throw new Error('neg control anchor missing: ' + from); fs.writeFileSync(f, src.replace(from, to)); return f; };
  // N1 类型错误（float 返回 vec2）：shdc 不做类型检查，glslang 必须在 WIND_QUALITY>0 时报错，WIND_QUALITY=0 时该函数被预处理掉
  const f1 = mk('neg-type', 'return A * r * r * w;', 'return A * r * r * vec2(w);');
  const c1 = compile(f1);
  const e1 = c1.effect ? glslangLink(c1.effect.shaders[0], 'glsl1', { WIND_QUALITY: 1 }) : { ok: true };
  const e1b = c1.effect ? glslangLink(c1.effect.shaders[0], 'glsl3', { WIND_QUALITY: 0 }) : { ok: false };
  rec('harness-sanity', '反向对照 N1：windOffset 返回类型写错 → glslang 在 WIND_QUALITY=1 报错（WIND_QUALITY=0 时被宏去掉，照常通过）', !e1.ok && e1b.ok, e1.out.replace(/\s+/g, ' ').slice(0, 200));
  // N2 UBO 外的松散 uniform → 结构检查必须报
  const f2 = mk('neg-loose', '  uniform sampler2D mainTexture;\n\n  uniform GrassWindFS {', '  uniform sampler2D mainTexture;\n  uniform float looseBad;\n\n  uniform GrassWindFS {');
  const loose = looseUniforms(splitEffect(fs.readFileSync(f2, 'utf8')).progs['grass-fs']);
  const c2 = compile(f2);
  rec('harness-sanity', '反向对照 N2：加一个 UBO 外的 uniform float → 结构检查查出（官方编译器的反应记录在说明里）', loose.length === 1, `structure=${loose.join(',')} shdc_errors=${c2.errors.length} ${c2.errors.join(' ').slice(0, 160)}`);
  // N3 property 指向不存在的成员
  const f3 = mk('neg-prop', 'target: windShape.x,', 'target: windShapeTypo.x,');
  const c3 = compile(f3);
  rec('harness-sanity', '反向对照 N3：property target 写错 → 官方编译器报错', c3.errors.length > 0, c3.errors.join(' ').slice(0, 200));
  // N4 varying 跨阶段类型不一致 → 只有链接能查出
  const f4 = ps.join(tmpDir, 'neg-varying.effect');
  { const i = src.indexOf('CCProgram grass-fs'); fs.writeFileSync(f4, src.slice(0, i) + src.slice(i).replace(/\bv_bend\b/g, 'v_bendX')); }
  const c4 = compile(f4); const sp4 = splitEffect(fs.readFileSync(f4, 'utf8'));
  const e4 = c4.effect ? glslangLink(c4.effect.shaders[0], 'glsl3', { WIND_QUALITY: 1 }) : { ok: false, out: 'shdc rejected' };
  const v4 = varyingIssues(sp4.progs['grass-vs'], sp4.progs['grass-fs']);
  rec('harness-sanity', `反向对照 N4：frag 读一个 vert 没输出的 varying（v_bendX）→ 结构检查查出（记录：官方编译器 ${c4.errors.length} 错误，glslang -l ${e4.ok ? '没有报错' : '报错'}，所以这一项只能靠结构检查）`, v4.issues.length > 0, v4.issues.join('; '));
}
fs.writeFileSync(ps.join(OUT, 'glslang-variants.json'), JSON.stringify({ glslang: glslangVersion, runs: glslLog }, null, 1));

// ---------------------------------------------------------------- (c) CPU 参考
const GRASS = EFFECTS[0];
const rng = (() => { let s = 0x9e3779b9; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; })();
const U = ref.DEFAULTS();
const winds = {}; for (const q of [1, 2]) winds[q] = ref.makeShaderWind(GRASS, q, U).fn;
fs.writeFileSync(ps.join(OUT, 'windOffset.transpiled.js'), ref.makeShaderWind(GRASS, 2, U).body);
const randColor = () => ({ r: rng(), g: rng(), b: 0.419, a: rng() });
const randP = () => ref.vec2((rng() - 0.5) * 160, (rng() - 0.5) * 160);
// C1 根部
{
  let bad = 0, n = 0;
  for (const q of [1, 2]) for (let i = 0; i < 20000; i++) { const c = randColor(); c.r = 0; const t = rng() * 3600; const { d, drop } = ref.displacement(winds[q], q, U, randP(), c, t); n++; if (Math.abs(d) !== 0 || Math.abs(drop) !== 0) bad++; }
  rec('c-cpu-reference', `根部 r=0：位移和下沉恰好为 0（${n} 个随机样本，WIND_QUALITY 1/2）`, bad === 0, `bad=${bad}`);
}
// C2 有界
{
  let worst = 0, n = 0, bad = 0;
  for (const q of [1, 2]) for (let i = 0; i < 100000; i++) {
    const c = randColor(); const t = rng() * 7200; const { d } = ref.displacement(winds[q], q, U, randP(), c, t); n++;
    const wsum = U.windShape.z + (q > 1 ? U.windShape.w + U.gustParams.x : 0);
    const bound = U.windShape.x * U.windShape.y * c.a * c.r * c.r * wsum;
    if (Math.abs(d) > bound + 1e-12) bad++;
    worst = Math.max(worst, Math.abs(d) / (U.windShape.x * U.windShape.y * c.a || 1));
  }
  rec('c-cpu-reference', `有界：|d| ≤ windStrength·amplitudeScale·a·r²·(waveWeight+swayWeight+gustStrength)，默认权重和 0.77 ≤ 1 所以 |d| ≤ windStrength·amplitudeScale·a（${n} 样本）`, bad === 0 && worst <= 1, `bad=${bad} max(|d|/(strength·amp·a))=${worst.toFixed(4)}`);
}
// C3 WIND_QUALITY 0（CPU 侧）
{ const { d } = ref.displacement(null, 0, U, randP(), randColor(), 12.3); rec('c-cpu-reference', 'WIND_QUALITY=0：位移 0（shader 侧见上面的预处理检查）', d === 0, ''); }
// C4 相位
{
  let changed = 0, n = 0;
  for (const q of [1, 2]) for (let i = 0; i < 2000; i++) { const c = { r: 1, g: rng(), b: 0.419, a: 0.5 }; const p = randP(); const t = rng() * 100;
    const d1 = ref.displacement(winds[q], q, U, p, c, t).d; const d2 = ref.displacement(winds[q], q, U, p, { ...c, g: (c.g + 0.25) % 1 }, t).d; n++; if (Math.abs(d1 - d2) > 1e-4) changed++; }
  rec('c-cpu-reference', `相位：COLOR_0.g 改 0.25 后输出改变（${n} 样本中 ≥ 99%）`, changed / n >= 0.99, `${changed}/${n}`);
  // 空间相位：同一时刻，沿风向相距半个波长的两丛草相位相反（WIND_QUALITY 1）
  const c = { r: 1, g: 0, b: 0.419, a: 0.5 }; const L = Math.hypot(U.windDirSpeed.x, U.windDirSpeed.y); const dir = ref.vec2(U.windDirSpeed.x / L, U.windDirSpeed.y / L);
  const pA = ref.vec2(3, 7), pB = ref.vec2(3 + dir.x * 13, 7 + dir.y * 13);
  let maxErr = 0; for (let t = 0; t < 8; t += 0.01) maxErr = Math.max(maxErr, Math.abs(ref.displacement(winds[1], 1, U, pA, c, t).d + ref.displacement(winds[1], 1, U, pB, c, t).d));
  rec('c-cpu-reference', '空间相位：沿风向相距半个波长（13 m）的两丛草位移相反（WIND_QUALITY 1）', maxErr < 1e-9, `max|dA+dB|=${maxErr.toExponential(2)}`);
  // 行波方向：t 增加 Δt 等价于沿风向前移 windSpeed·Δt
  let maxErr2 = 0; for (let t = 0; t < 8; t += 0.01) { const dt = 0.5; const pC = ref.vec2(pA.x - dir.x * U.windDirSpeed.z * dt, pA.y - dir.y * U.windDirSpeed.z * dt);
    maxErr2 = Math.max(maxErr2, Math.abs(ref.displacement(winds[1], 1, U, pA, c, t + dt).d - ref.displacement(winds[1], 1, U, pC, c, t).d)); }
  rec('c-cpu-reference', '行波方向：风浪以 windSpeed 沿 windDir 顺风推进', maxErr2 < 1e-9, `max err=${maxErr2.toExponential(2)}`);
}
// C5 连续性
{
  const dt = 1 / 240; let worstRatio = 0; let n = 0;
  for (const q of [1, 2]) for (let k = 0; k < 400; k++) {
    const c = randColor(); const p = randP(); const A = U.windShape.x * U.windShape.y * c.a * c.r * c.r;
    const omega = 2 * Math.PI * U.windDirSpeed.z / U.windDirSpeed.w; const gw = 2 * Math.PI * U.gustParams.y;
    const lip = A * (U.windShape.z * omega + (q > 1 ? U.windShape.w * omega + U.gustParams.x * (gw * 1.0 + 0.5 * 0.37 * gw) : 0));
    let prev = ref.displacement(winds[q], q, U, p, c, 0).d;
    for (let t = dt; t < 30; t += dt) { const d = ref.displacement(winds[q], q, U, p, c, t).d; n++; if (lip > 0) worstRatio = Math.max(worstRatio, Math.abs(d - prev) / (lip * dt)); prev = d; }
  }
  rec('c-cpu-reference', `时间连续：240 Hz 采样 30 s，相邻帧差 ≤ 解析 Lipschitz 上界（${n} 步）`, worstRatio <= 1.000001, `max(Δd / (L·Δt))=${worstRatio.toFixed(4)}`);
}
// C6 与美术公式等价
{
  const U0 = ref.DEFAULTS(); U0.gustParams.x = 0; const w2 = ref.makeShaderWind(GRASS, 2, U0).fn;
  let maxRaw = 0, maxNorm = 0; const Wlen = Math.hypot(0.944, -0.330);
  for (let i = 0; i < 50000; i++) {
    const c = randColor(); const o = randP(); const t = rng() * 600;
    const dShader = ref.displacement(w2, 2, U0, o, c, t).d;
    maxRaw = Math.max(maxRaw, Math.abs(dShader - ref.artFormula(o, c, t)));
    maxNorm = Math.max(maxNorm, Math.abs(dShader - ref.artFormula(ref.vec2(o.x / Wlen, o.y / Wlen), c, t)));
  }
  rec('c-cpu-reference', '默认参数 + gustStrength=0 + WIND_QUALITY 2 与美术 README 公式一致（W 归一化后误差 < 1e-9 m；按 README 原样未归一化的 W 误差 < 1 mm）', maxNorm < 1e-9 && maxRaw < 1e-3, `max|Δ| normalizedW=${maxNorm.toExponential(2)} m, rawW=${maxRaw.toExponential(2)} m`);
}
// C7 float32 时间精度（cc_time.x 是 float）
{
  const omega = 2 * Math.PI * 6.5 / 26; const ulp = x => { const f = Math.fround(x); const b = new Float32Array([f]); const u = new Uint32Array(b.buffer); u[0] += 1; return b[0] - f; };
  const rows = [60, 3600, 6 * 3600, 24 * 3600].map(t => { const e = ulp(omega * t); const jit = 1.5 * 0.737 * 0.77 * e; return `${t / 3600 >= 1 ? (t / 3600) + 'h' : t + 's'}: ulp(ωt)=${e.toExponential(1)} rad → 草尖抖动 ≤ ${(jit * 1000).toFixed(2)} mm`; });
  rec('c-cpu-reference', 'float32 时间精度估算（信息项）：连续运行 6 h 内草尖量化 < 1 mm', true, rows.join('; '));
}
// C8 真实 GLB 数据
function readGLB (p) {
  const b = fs.readFileSync(p); const jl = b.readUInt32LE(12); const j = JSON.parse(b.slice(20, 20 + jl).toString()); const bin = b.slice(20 + jl + 8);
  const CT = { 5121: [1, 'readUInt8', 255], 5123: [2, 'readUInt16LE', 65535], 5126: [4, 'readFloatLE', 0] }; const NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
  const acc = i => { const a = j.accessors[i], bv = j.bufferViews[a.bufferView], [sz, fn, mx] = CT[a.componentType], n = NC[a.type];
    const stride = bv.byteStride || sz * n, off = (bv.byteOffset || 0) + (a.byteOffset || 0); const out = [];
    for (let k = 0; k < a.count; k++) { const v = []; for (let c = 0; c < n; c++) { let x = bin[fn](off + k * stride + c * sz); if (a.normalized && mx) x /= mx; v.push(x); } out.push(v); } return { a, out }; };
  return { j, acc };
}
if (fs.existsSync(GLB) && fs.existsSync(INST)) {
  const { j, acc } = readGLB(GLB); const inst = JSON.parse(fs.readFileSync(INST, 'utf8'));
  const stats = []; let rootBad = 0, rootN = 0, maxTip = 0, maxDrop = 0, verts = 0;
  for (const m of j.meshes) for (const pr of m.primitives) {
    if (!('COLOR_0' in pr.attributes)) continue;
    const { a, out: col } = acc(pr.attributes.COLOR_0); const pos = acc(pr.attributes.POSITION).out;
    const ch = [0, 1, 2, 3].map(c => { const xs = col.map(v => v[c]); return { min: Math.min(...xs), max: Math.max(...xs), mean: xs.reduce((s, x) => s + x, 0) / xs.length, unique: new Set(xs.map(x => x.toFixed(4))).size }; });
    const rootY = col.filter(v => v[0] === 0).map((v, k) => 0); const ys0 = pos.filter((p, k) => col[k][0] === 0).map(p => p[1]);
    stats.push({ mesh: m.name, verts: col.length, componentType: a.componentType, normalized: !!a.normalized, r: ch[0], g: ch[1], b: ch[2], a: ch[3], rootVertexYRange: [Math.min(...ys0), Math.max(...ys0)] });
    const grp = inst.groups.find(g => g.template === m.name); if (!grp) continue;
    for (let i = 0; i < grp.count; i++) {
      const o = ref.vec2(grp.t[i * 3], grp.t[i * 3 + 2]);
      for (const v of col) { const c = { r: v[0], g: v[1], b: v[2], a: v[3] }; verts++;
        for (const t of [0, 0.7, 1.9, 3.3]) { const { d, drop } = ref.displacement(winds[2], 2, U, o, c, t);
          if (c.r === 0) { rootN++; if (d !== 0 || drop !== 0) rootBad++; } maxTip = Math.max(maxTip, Math.abs(d)); maxDrop = Math.max(maxDrop, Math.abs(drop)); } }
    }
  }
  fs.writeFileSync(ps.join(OUT, 'meadow-COLOR_0-stats.json'), JSON.stringify(stats, null, 1));
  rec('c-cpu-reference', `真实数据：meadow_grass_clump_templates_v0_8.glb 的 COLOR_0 + meadow_instances_v0_8.json 的 1,000 个草实例原点，根部顶点位移恒为 0`, rootBad === 0 && rootN > 0, `instanced verts=${verts} root samples=${rootN} max|d|=${maxTip.toFixed(3)} m max|drop|=${maxDrop.toFixed(3)} m`);
  rec('c-cpu-reference', 'COLOR_0 统计（信息项，见 out/meadow-COLOR_0-stats.json）', true, stats.map(s => `${s.mesh}: r∈[${s.r.min},${s.r.max}] uniq=${s.r.unique}; g∈[${s.g.min.toFixed(3)},${s.g.max.toFixed(3)}]; b=${s.b.min.toFixed(4)}; a∈[${s.a.min.toFixed(3)},${s.a.max.toFixed(3)}]`).join(' | '));
} else rec('c-cpu-reference', '真实 GLB 数据检查', null, `找不到 ${GLB} 或 ${INST}`);

// ---------------------------------------------------------------- (d) GrassWindQuality.ts
{
  const tsPath = ps.join(HERE, '../scripts/GrassWindQuality.ts');
  const tsc = [ps.join(ENGINE, '../../../app.asar.unpacked/node_modules/typescript/bin/tsc'), ps.join(ENGINE, 'node_modules/typescript/bin/tsc')].find(fs.existsSync);
  const ccd = ps.join(ENGINE, 'bin/.declarations/cc.d.ts');
  if (tsc && fs.existsSync(ccd)) {
    const dir = fs.mkdtempSync(ps.join(os.tmpdir(), 'e4-ts-'));
    fs.writeFileSync(ps.join(dir, 'tsconfig.json'), JSON.stringify({ compilerOptions: { target: 'ES2017', module: 'ES2015', moduleResolution: 'node', strict: true, experimentalDecorators: true, noEmit: true, lib: ['ES2017', 'DOM'], skipLibCheck: true, types: [] }, files: [ccd, tsPath] }));
    const r = cp.spawnSync('node', [tsc, '-p', ps.join(dir, 'tsconfig.json')], { encoding: 'utf8' });
    rec('d-typescript', 'GrassWindQuality.ts 用 Creator 3.8.8 自带 TypeScript + cc.d.ts 严格模式类型检查 0 错误', r.status === 0, (r.stdout + r.stderr).slice(0, 600));
    // 逻辑测试：转成 CJS，mock 'cc' 和 wx
    const ts = require(ps.join(ps.dirname(tsc), '../lib/typescript.js'));
    const js = ts.transpileModule(fs.readFileSync(tsPath, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2017, experimentalDecorators: true } }).outputText;
    const Module = require('module');
    const load = (wxMock) => {
      class Material { constructor () { this.passes = [{ defines: {} }]; this.effectAsset = {}; this.effectName = 'x/meadow-grass-wind'; this.name = 'M'; } copy (src, o) { this.effectAsset = src.effectAsset; this.effectName = src.effectName; this.passes = [{ defines: { ...src.passes[0].defines, ...(o && o.defines) } }]; this.copied = true; } }
      class MaterialInstance extends Material { recompileShaders (o) { this.passes[0].defines = { ...this.passes[0].defines, ...o }; } }
      const ccMock = { _decorator: { ccclass: () => (c) => c, property: () => () => {} }, Component: class {}, Node: class {}, MeshRenderer: class {}, Material, renderer: { MaterialInstance } };
      const m = new Module('GrassWindQuality'); m.paths = module.paths;
      const origReq = m.require.bind(m); m.require = (id) => id === 'cc' ? ccMock : origReq(id);
      if (wxMock === undefined) delete global.wx; else global.wx = wxMock;
      m._compile(js, 'GrassWindQuality.js'); return { api: m.exports, ccMock };
    };
    const { api, ccMock } = load(undefined);
    const P = api.pickGrassWindQuality; const Q = api.GrassWindQuality;
    const cases = [
      [{ benchmarkLevel: -1, platform: 'android' }, Q.LOW], [null, Q.LOW], [{}, Q.LOW], [{ benchmarkLevel: NaN }, Q.LOW],
      [{ benchmarkLevel: 0 }, Q.OFF], [{ benchmarkLevel: -2 }, Q.OFF],
      [{ benchmarkLevel: 22, platform: 'android' }, Q.LOW], [{ benchmarkLevel: 29, platform: 'android' }, Q.LOW], [{ benchmarkLevel: 30, platform: 'android' }, Q.HIGH],
      [{ benchmarkLevel: 35, platform: 'ios' }, Q.LOW], [{ benchmarkLevel: 36, platform: 'ios' }, Q.HIGH], [{ benchmarkLevel: -1, modelLevel: 1 }, Q.HIGH], [{ benchmarkLevel: -1, modelLevel: 3 }, Q.LOW],
    ];
    const bad = cases.filter(([i, e]) => P(i) !== e).map(([i, e]) => `${JSON.stringify(i)}→${P(i)}≠${e}`);
    rec('d-typescript', `pickGrassWindQuality 分档表 ${cases.length} 例（-1/未知→低，0/-2→关，Android≥30 / iOS≥36→高）`, bad.length === 0, bad.join('; '));
    (async () => {
      const r0 = await load(undefined).api.queryDeviceBenchmark();
      const r1 = await load({ getDeviceBenchmarkInfo: (o) => setTimeout(() => o.success({ benchmarkLevel: 33, modelLevel: 1 }), 5), getDeviceInfo: () => ({ platform: 'android', benchmarkLevel: 20 }) }).api.queryDeviceBenchmark();
      const r2 = await load({ getDeviceBenchmarkInfo: (o) => o.fail({}), getDeviceInfo: () => ({ platform: 'ios', benchmarkLevel: 31 }) }).api.queryDeviceBenchmark();
      const r3 = await load({ getDeviceBenchmarkInfo: () => {}, getSystemInfoSync: () => ({ platform: 'android', benchmarkLevel: 12 }) }).api.queryDeviceBenchmark(50);
      const r4 = await load({ getDeviceBenchmarkInfo: () => { throw new Error('x'); } }).api.queryDeviceBenchmark();
      const ok = r0.source === 'none' && r0.benchmarkLevel === -1 && r1.source === 'getDeviceBenchmarkInfo' && r1.benchmarkLevel === 33 && r1.platform === 'android'
        && r2.source === 'getDeviceInfo' && r2.benchmarkLevel === 31 && r3.source === 'getSystemInfoSync' && r3.benchmarkLevel === 12 && r4.source === 'none';
      rec('d-typescript', 'queryDeviceBenchmark：无 wx / 异步成功 / fail 回退 / 超时回退 / 抛异常 5 种情况都 resolve 且来源正确', ok, JSON.stringify([r0, r1, r2, r3, r4].map(r => [r.source, r.benchmarkLevel, r.platform])));
      delete global.wx;
      // applyGrassWindQuality：同一 base + 同一档 → 同一个共享材质（实例化合批），非草材质不动，回调触发
      const { api: A2, ccMock: C2 } = load(undefined);
      const base = new C2.Material(); const other = new C2.Material(); other.effectName = 'builtin-standard';
      const mk = () => ({ isValid: true, sharedMaterials: [base, other], setSharedMaterial (m, i) { this.sharedMaterials[i] = m; } });
      const rs = [mk(), mk(), mk()]; let cb = 0;
      const n = A2.applyGrassWindQuality(rs, 2, { onReapplied: () => cb++ });
      const same = rs.every(r => r.sharedMaterials[0] === rs[0].sharedMaterials[0]) && rs[0].sharedMaterials[0] !== base && rs.every(r => r.sharedMaterials[1] === other);
      const q = A2.getGrassWindQuality(rs[0].sharedMaterials[0]);
      const n2 = A2.applyGrassWindQuality(rs, 0); const back = rs.every(r => r.sharedMaterials[0] === base);   // base 默认 0 → 切回原资源
      const inst = new C2.renderer.MaterialInstance(); const okInst = A2.setGrassWindQualityOnInstance(inst, 1) && inst.passes[0].defines.WIND_QUALITY === 1 && A2.setGrassWindQualityOnInstance(base, 1) === false;
      rec('d-typescript', 'applyGrassWindQuality：所有 renderer 拿到同一个运行时共享材质（保住实例化），只换草材质，切回 0 用回原资源，回调每个 renderer 一次；MaterialInstance 走 recompileShaders，共享材质拒绝', n === 3 && same && q === 2 && cb === 3 && n2 === 3 && back && okInst, `changed=${n} same=${same} q=${q} cb=${cb} back=${back} inst=${okInst}`);
      finish();
    })().catch(e => { rec('d-typescript', 'TS 逻辑测试', false, String(e && e.stack)); finish(); });
  } else { rec('d-typescript', 'TypeScript 检查', null, '找不到 tsc 或 cc.d.ts'); finish(); }
}

function finish () {
  for (const [id, why] of [
    ['Creator 编辑器内导入 .effect / 生成 .meta / 材质面板显示', '这台电脑没有可登录运行的 Creator 编辑器；只用了它自带的编译器库'],
    ['Creator 构建微信小游戏 + 压缩纹理（ASTC/ETC2）', '同上'],
    ['微信开发者工具 / 真机上 WebGL1、WebGL2 实际链接和渲染', '无 DevTools / 真机'],
    ['GPU 实例化实际合批（draw call 计数）', '需要 Creator 运行 + Profiler'],
    ['帧时间 / 顶点开销 / 低端机性能', '需要真机'],
    ['画面观感（风幅度、颜色、天空夜间色调）', '需要美术在 Creator 里看'],
  ]) results.push({ group: 'not_run', id, status: 'not_run', detail: why });
  const sum = { passed: 0, failed: 0, not_run: 0 }; for (const r of results) sum[r.status]++;
  const env = { node: process.version, engine: ENGINE, compiler: COMPILER, glslang: glslangVersion, date: new Date().toISOString() };
  fs.writeFileSync(ps.join(OUT, 'selftest-results.json'), JSON.stringify({ env, summary: sum, results }, null, 1));
  const md = ['# E4 自测结果', '', `环境：Node ${env.node}；Cocos 3.8.8 effect 编译器（${COMPILER}）；${glslangVersion || 'glslang 不可用'}；${env.date}`, '',
    `**通过 ${sum.passed} · 失败 ${sum.failed} · 未运行 ${sum.not_run}**`, '', '| 组 | 检查 | 结果 | 说明 |', '|---|---|---|---|',
    ...results.map(r => `| ${r.group} | ${r.id.replace(/\|/g, '\\|')} | ${r.status === 'passed' ? '🟢 passed' : r.status === 'failed' ? '🔴 failed' : '⚪ not_run'} | ${String(r.detail || '').replace(/\|/g, '\\|').replace(/\n/g, ' ').slice(0, 600)} |`)].join('\n');
  fs.writeFileSync(ps.join(OUT, 'selftest-results.md'), md + '\n');
  console.log(md);
  fs.rmSync(tmpDir, { recursive: true, force: true });
  process.exitCode = sum.failed ? 1 : 0;
}
