# 0008 v2 · 微信开发者工具首开 console 审计（基于 Oi finalizer 12ef697）

GGbot（grokbot-2）· 2026-10-09 · Creator 3.8.8 / DevTools Stable 2.02.2608080 / 基础库 3.17.3 / AppID wx3bdd911c5c06f591
替代 0008 v1（v1 的包装器和 B/B1/B2 条件变体全部作废）。只改 `tools/finalize_wechat_local.cjs` + 新增测试工具；不碰游戏脚本、R6 修复、0005b/0006/0007。不上传、不预览、不发布。

## 1. 结论（先说清楚哪些是证据、哪些是假设）

**判定：那条红字是开发者工具自己的编译条件/启动页检查提示，不是游戏错误；对游戏功能无害；目前没有任何证据表明能靠改项目文件消掉。** 因此本版**不在 finalizer 里写任何条件**，回归脚本对这条提示做**精确字符串**分类：默认仍判 FAIL（不掩盖），只有显式 `QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE=1` 时才判 `PASS_WITH_ALLOWLISTED_IDE_NOTICE`（永远不是普通 PASS）。是否接受 allowlist，等 Oi 跑完第 3 节的两项验证再定。

**证据（全部来自 Oi 原始文件，单测逐条断言）：**

| 运行 | condition | enhance | 红字 | LoadScene | 出处 |
|---|---|---|---|---|---|
| Creator 原模板（OI-CFG-001） | 模板：game `{currentL:-1,list:[],current:-1}`，search/conversation/miniprogram `{current:-1,list:[]}` | true | 有 | — | input002 integration-issues.md |
| 同上，删空条件后**手动 工具→编译** | 无 | true | **无** | 开始页 | OI-CFG-001；0004 记录 "Tools→Compile … no visible red error badge" |
| R6 首开 A | 无 | true | 有 | 有 | first-open-a-focused.png |
| R6 audio 当前产物 | 无 | true | 有 | 有 | audio-startup-console-raw.txt |
| D（只关 enhance） | 无 | **false** | 有 | 有 | noenhance-d-settled-console.txt |
| B 重开 | game+miniprogram `{current:-1,list:[]}` | true | 无，**但** game.js:5 先崩（@babel helper），没到 LoadScene | 无 | first-open-b-reopened-console.txt —— **不可作对照**（Oi 结论，同意） |
| B 首开 / C | — | — | 调试器空白，未知 | — | 不采用 |

A/audio/D 的原文（逐字）：
```
WAGame.js:1 {batteryLevel: 100, benchmarkLevel: -1, brand: "devtools", memorySize: 2048, model: "iPhone 12/13 (Pro)", …}
[app.json 或自定义编译条件错误] app.json 中未定义自定义编译中指定的启动页面 (env: macOS,mg,2.02.2608080; lib: 3.17.3)
cc.js? [sm]:1 LoadScene db://assets/scenes/WorldR5Integration.scene: 1176.2919921875 ms
```
由此可确定（证据）：
1. 这行**没有来源位置**（其它行都有 `WAGame.js:1` / `cc.js? [sm]:1`），后缀 `(env: macOS,mg,<工具版本>; lib: <基础库>)` 是开发者工具自己诊断信息的格式（社区里小程序版同一报错是 `(env: Windows,mp,…)`），`mg`=小游戏模式 → **由 IDE 打印，不是游戏代码抛的**。
2. 它说的是 **app.json**（小游戏根本没有 app.json）和“自定义编译中指定的启动页面”，且**页面名为空**（小程序里同一报错会带页面路径或 `undefined`）→ 是 IDE 拿一个空的 pathName 跑了小程序式的启动页检查。
3. 删 condition（A）、关 enhance（D）都不影响它；enhance 只影响 @babel helper 崩溃（D 证明 enhance=false 必须保留）。
4. 每次它后面都紧跟 LoadScene，开始页、房间、海岛、7 个音效、前后台都正常（R6 验收）→ **功能上无害**。
5. 唯一一次“没有红字”的正常启动，是**手动点了编译**之后（OI-CFG-001）。B 重开没有红字不能算，因为游戏在红字通常出现的位置之前就崩了。

## 2. 两个候选原因（都是假设，按证据强弱排序）

- **H1（较强）：CLI 打开时的自动编译走了带空启动页的“自定义编译”检查。** 依据：所有出红字的运行都是 `cli open --project` 首开（官方 CLI 文档：带 project 打开时“每次执行都会自动编译刷新”）；手动 工具→编译（普通编译）后没有红字。弱点：OI-CFG-001 那次“手动编译”和“删条件”同时做了，没有单独隔离。若成立 → 属于 CLI 路径的工具行为，项目文件改不掉 → 用精确 allowlist。
- **H2（中等）：同 AppID 的 IDE 内部状态（编译模式选择）被沿用。** 依据：所有运行都用 wx3bdd911c5c06f591，并且同一个 DevTools 进程里同时开着 6～8 个同 AppID 项目窗口（windows*.json）；目录名唯一但 AppID 相同。若成立 → 状态在工具缓存里，按规定不能改全局偏好/缓存 → 同样用精确 allowlist；改 AppID 只作诊断，不是修复。
- 不提议：C（gameRoot）及其变体、B（手填条件，重开时有 helper 失败）。

## 3. 请 Oi 做的验证（每项都在独立新副本上、不改全局偏好）

前置：仓库根 `npm i -D miniprogram-automator@0.12.1`；打上 `0008-v2-finalize_wechat_local.patch`；把本包 `tools/` 下 4 个文件放进仓库 `tools/`；Creator 新出一份 wechatgame 产物（**不要先跑 finalizer**，脚本会在副本上跑真实 finalizer）。
```bash
export QF_WECHAT_BUILD_DIR=<新 wechatgame 输出>
# V0 基线：干净工具里只开一个窗口，CLI 首开，不点编译
QF_DEVTOOLS_QUIT_FIRST=1 QF_FIRST_OPEN_SCREENCAPTURE=1 QF_FIRST_OPEN_OUT=$PWD/evidence/first-open-0008v2/V0 node tools/wechat_first_open_audit.cjs; echo exit=$?
# V2（H2）：同一产物，额外跑一个只把副本 AppID 换成测试/游客 AppID 的诊断 case
QF_DEVTOOLS_QUIT_FIRST=1 QF_FIRST_OPEN_CASES=default,diag-appid QF_FIRST_OPEN_DIAG_APPID=<可本地打开的测试AppID> \
  QF_FIRST_OPEN_OUT=$PWD/evidence/first-open-0008v2/V2 node tools/wechat_first_open_audit.cjs; echo exit=$?
```
- **V1（H1，手工，脚本无法代替）**：把 V0 留下的副本（verdict.json 里 `projectDir`）再复制一份改个目录名，① 用 DevTools 界面“导入项目”打开（不用 CLI），不点编译，看 Console；② 再用 `cli open --project <该目录>` 打开另一份新副本，先点 Console 的清空，再点一次工具栏“编译”（普通编译），看红字是否再出现。两次都截图 Console（含右上角红/黄计数）。
- 判读：V1① 无红字而 V0 有 → H1 成立；V2 的 diag-appid 无红字而 default 有 → H2 成立；都仍有 → 两个假设都不成立，把三组原始 console 发回。
- 任何结论成立后，**由 Grok Bot/Oi 决定**是否在验收里打开 `QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE=1`。

## 4. 修复后（=本版）首开 Console 的确切预期

按出现顺序（来自 D 的原文）：

| # | 行 | 分类 |
|---|---|---|
| 1 | `Wechat Lib:3.17.3, 2026.10.9 19:51:01` | 预期 |
| 2 | `<日期> GMT+0800 (中国标准时间) 接口提示` | 预期 |
| 3 | `小程序基础库从 3.7.0 起正式支持 HarmonyOS 平台…`（黄色警告） | 允许（基础库通用提示） |
| 4 | `WAGame.js:1 {batteryLevel: …, brand: "devtools", …}`（或折叠成 `Object`） | 预期 |
| 5 | `[app.json 或自定义编译条件错误] app.json 中未定义自定义编译中指定的启动页面 (env: macOS,mg,2.02.2608080; lib: 3.17.3)` | **已知 IDE 提示：默认禁止；仅 allowlist 打开时允许**；精确匹配，带页面名的同类报错仍禁止 |
| 6 | `cc.js? [sm]:1 LoadScene db://assets/scenes/WorldR5Integration.scene: <数字> ms` | **必须出现**（证明游戏真的启动） |
| — | `[QF-AUDIT-HEARTBEAT…] <token>` | 允许（仅测试副本的 shim） |
| — | CLI 输出的 `punycode` DeprecationWarning | 允许（CLI 自身提示） |

**禁止（出现即 FAIL）**：`@babel/runtime/helpers/… is not defined`、`Unable to instantiate virtual:///prerequisite-imports/main`、`MiniProgramError`、`TypeError|ReferenceError|SyntaxError|RangeError|Uncaught|Error: `、`simulator launch failed`、其它任何 `[…错误]` 方括号诊断、`编译失败/编译错误`、任何 `wx.onError` / 未处理 rejection / automator `exception`。
计数：目前 A/D 是“红 1、黄 1”；H1/H2 解决后的目标是“红 0、黄 1”；在 allowlist 下是“红 1（仅第 5 行）、黄 1”。
手头的 console 文本也可直接判：`node tools/first_open_console_rules.cjs <console.txt>` → `ZERO_RED`(0) / `KNOWN_NOTICE_ONLY`(3) / `FAIL`(1) / `INCOMPLETE|REVIEW`(2)。Oi 的 audio、D 文本判为 KNOWN_NOTICE_ONLY，B 重开文本判为 FAIL（单测）。

## 5. finalizer diff（`0008-v2-finalize_wechat_local.patch`，正式 git diff，基于 12ef697，SHA 613273…6b09 已核对）

保留原样：断言 compileType=game、AppID；只删全空条件、非空拒绝（同一条报错信息）；`setting.enhance=false`；输出 JSON 原有字段值不变。改动只有三处：
1. 输出 JSON 增加 `removedCondition`（删掉的原条件原文，如模板的 `currentL`）和 `changed`，方便审计引用；
2. 条件分支是 `null`/非对象时，原版会抛 TypeError，现在用同一条“Preserve active custom compile conditions”拒绝（不再是崩溃）；
3. 只在内容真的变化时写文件（重复执行不碰文件，幂等）。
默认产物与原版**逐字节相同**（在 Oi 的 6 份真实配置 + 模板字段上测过）。`git apply --check` / `-R --check` 均通过。

## 6. 回归脚本 `tools/wechat_first_open_audit.cjs`

新构建 → 复制到唯一目录（唯一 projectname）→ 在副本上跑**真实 finalizer** → 只在副本 game.js 注入 shim（记录 error/warn/log/info、wx.onError、未处理 rejection）→ `cli auto --project … --auto-port …`（不手动编译）→ miniprogram-automator 收 console/exception、读 shim、扫 WeappLog 新增行、扫 CLI 输出 → 按第 4 节规则判定。console 通道用 late heartbeat 自证；必须看到 LoadScene。
判定：`PASS`(0) / `FAIL`(1) / `BLOCKED`(2，附原因) / `PASS_WITH_ALLOWLISTED_IDE_NOTICE`(3)。v1 的“阳性对照 A”取消（每次 default 本身都会出那条提示，就是检测器的现成对照）；若 default 没看到提示，PASS 原因里会注明“只有之前同通道看到过它，这个‘没有’才有意义”。
输出：`run.log`（每步时间戳）、`verdict.json`、每个 case 目录（finalizer-result.json、project.config.json.as-opened、console-transcript.txt、automator-*.json、shim-buffer.json、weapplog-delta.txt、simulator.png、可选 screen.png、build-copy-SHA256SUMS.txt）、`manifest.json`、`SHA256SUMS.txt`。
环境变量见 `tools/qf-wechat-env.cjs`（新增 `QF_FINALIZER`、`QF_FIRST_OPEN_CASES`、`QF_FIRST_OPEN_DIAG_APPID`、`QF_FIRST_OPEN_ALLOW_APPJSON_NOTICE`；删除 v1 的 VARIANT/CONTROL）。

## 7. 请 Oi 回传

V0、V2 整个输出目录（打包 + 外层 SHA256）；V1 两张 Console 截图 + 文字复制；DevTools/基础库版本；运行时开着哪些窗口；**finalize 之前**的原始 project.config.json 一份（确认模板字段与本包 fixture 一致）。

## 8. 自测（Linux）

| 项目 | 结果 |
|---|---|
| 所有 .cjs/.js `node --check`（12 个） | 通过，selftest/syntax-check.txt |
| finalizer diff：`git apply --check`、apply 结果=reference、`-R --check`；与原版在 Oi 6 份真实配置 + 模板字段上逐字节一致；断言/拒绝/enhance 保留；幂等；不写额外文件；console 规则对 Oi 三份真实 console 文本 | **26/26 通过**，selftest/unit-finalizer.txt；规则判读结果 selftest/console-rules-on-oi-transcripts.txt |
| shim 单测（vm 内假 console/wx） | **5/5 通过**，selftest/unit-shim.txt |
| 回归脚本 dry-run（假 CLI + 假自动化服务端，真 miniprogram-automator 0.12.1，真 finalizer+diff；18 个场景 + 唯一目录 + 源产物未被改动） | **20/20 通过**，selftest/dryrun.txt、dryrun-summary.json、示例输出 dryrun-example-01-default-notice/ |
| 真 DevTools 运行、V0/V1/V2 | **not_run** |
| automator 对小游戏 console/exception/evaluate 是否可用；那条提示走哪个通道；Mac WeappLog 路径 | **not_run** |
| H1 / H2 | **假设，未验证** |
| 模板 fixture | 按 Oi 报告的字段重建（分支顺序为假设），不是原始文件 |
