// qf-wait-ready.cjs (grokbot-2/ggbot) — "wait for run.ready before the next step" for Playwright/Web replay tools.
// Never relies on a fixed delay. Reads only the existing debug hook __worldIntegration.board().diagnostics().
'use strict';
async function boardState(page){
  return page.evaluate(()=>{const b=globalThis.__worldIntegration&&globalThis.__worldIntegration.board&&globalThis.__worldIntegration.board();
    if(!b)return null;const s=b.snapshot||{},cp=b.checkpoint||{};
    return {state:s.state,provider:s.provider,moves:s.active?s.active.moves:null,actions:Array.isArray(cp.actions)?cp.actions.length:null,visual:!!s.visual};});
}
/** Resolves when the board is in run.ready (or a result.* state) AND, if minActions is given, the committed
 *  action count has reached it. Rejects with the last observed state on timeout. */
async function waitBoardReady(page,{minActions=null,timeoutMs=15000,pollMs=50,allowResult=true}={}){
  const t0=Date.now();let last=null;
  while(Date.now()-t0<timeoutMs){
    last=await boardState(page);
    if(last){const settled=last.state==='run.ready'||(allowResult&&/^result\./.test(last.state||''));
      const counted=minActions==null||(last.actions!=null&&last.actions>=minActions);
      if(settled&&counted&&!last.visual)return last;}
    await new Promise(r=>setTimeout(r,pollMs));
  }
  throw Object.assign(new Error('waitBoardReady timeout'),{last});
}
/** Send one action via the caller's input function, then wait until it is committed and resolved. */
async function sendAndSettle(page,sendFn,{timeoutMs=15000}={}){
  const before=await waitBoardReady(page,{timeoutMs});
  if(!/^run\.ready$/.test(before.state))throw Object.assign(new Error('board not in run.ready before send'),{before});
  await sendFn();
  return waitBoardReady(page,{minActions:(before.actions||0)+1,timeoutMs});
}
module.exports={boardState,waitBoardReady,sendAndSettle};
