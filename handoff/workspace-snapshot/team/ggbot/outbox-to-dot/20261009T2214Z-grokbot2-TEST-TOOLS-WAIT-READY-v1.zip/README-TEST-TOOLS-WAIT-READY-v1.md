# 测试工具：统一「等 run.ready 再发下一步」v1（grokbot-2/ggbot，对应 OI-INPUT-002）
不改游戏代码，只提供测试工具。原因（Oi 已经分析过）：每次操作有若干个动画帧，每帧约 180 ms；动画锁住期间棋盘会丢弃点击，也不排队。用固定延时发下一步，就会被吞掉。

## Web / Playwright：`qf-wait-ready.cjs`
- `waitBoardReady(page, {minActions, timeoutMs})`：轮询 `__worldIntegration.board()` 的诊断信息，直到状态是 `run.ready`（或者 `result.*`）、没有正在播放的帧，并且已提交的操作数 ≥ `minActions`。超时会抛错，并附上最后一次看到的状态。
- `sendAndSettle(page, sendFn)`：先确认是 `run.ready` → 执行 `sendFn()` 发出这一步 → 等到操作数加 1，并且重新回到稳定状态。
- 用法：在 Oi 现有的 Web 回放循环里，每一步都换成 `await sendAndSettle(page, () => 你的点击函数(a, b))`。

## 原生（CGEvent，读不到游戏状态）：`native-replay-schedule.cjs` 和 `game-native-replay-ready.swift`
- 第 1 步：`node native-replay-schedule.cjs <工程>/assets/scripts route.json > route.schedule.json`。
  脚本用游戏里真实的、确定性的 mainline Session 模拟每一步，统计帧数，算出 `settleMs = 帧数 × 180 + 600`，并写出每一步之后应有的步数、分数和状态（`expect`）。
  如果棋盘是从存档恢复的进行中对局，就在 route 里加上 `prior`（取自 `__worldIntegration.board().checkpoint.actions`），模拟时先把这些操作补上。
- 第 2 步：`game-native-replay-ready.swift route.schedule.json`。和 Oi 原来的发送器相比只改了一处：每次提交以后，等这一步的 `settleMs` 再发下一步，不再固定等 600 ms。格子坐标常数没动，仍然只适用于原来那个窗口。
- 自测：用 Oi 的 `native-stage2-batch-two.json` 跑，第一步 `swap 23-24` 算出 **9 帧**，和 Oi 的分析（9 帧 × 180 ms = 1620 ms）一致；`settleMs` 是 2220 ms。
- 每步发完以后，用截图核对 `expect.moves`，对得上才发下一步。原生回放没有状态回读，所以这一步仍然要靠截图核对。

## 自测范围
- `native-replay-schedule.cjs` 在 Node 下跑通，帧数和 Oi 的分析一致：passed；
- `qf-wait-ready.cjs` 只做了语法检查，没在浏览器里跑：not_run；
- swift 脚本没编译：not_run（这台电脑没有 macOS）。
