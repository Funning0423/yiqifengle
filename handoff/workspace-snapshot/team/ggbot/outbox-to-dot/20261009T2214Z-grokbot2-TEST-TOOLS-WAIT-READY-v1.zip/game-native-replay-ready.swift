// game-native-replay-ready.swift — Oi's native sender, changed only to wait per-action settleMs from
// native-replay-schedule.cjs instead of a fixed 600 ms. Tile geometry constants unchanged (window-specific).
import Foundation
import ApplicationServices
guard AXIsProcessTrusted() else { exit(2) }
let data=try Data(contentsOf: URL(fileURLWithPath:CommandLine.arguments[1]))
let steps=(try JSONSerialization.jsonObject(with:data) as! [[String:Any]])[0]["steps"] as! [[String:Any]]
func tap(_ i:Int){
 let p=CGPoint(x:993+Double(i%7)*39.2,y:371+Double(i/7)*39.2)
 CGEvent(mouseEventSource:nil,mouseType:.mouseMoved,mouseCursorPosition:p,mouseButton:.left)?.post(tap:.cghidEventTap);usleep(80000)
 CGEvent(mouseEventSource:nil,mouseType:.leftMouseDown,mouseCursorPosition:p,mouseButton:.left)?.post(tap:.cghidEventTap);usleep(100000)
 CGEvent(mouseEventSource:nil,mouseType:.leftMouseUp,mouseCursorPosition:p,mouseButton:.left)?.post(tap:.cghidEventTap)
}
for step in steps {
 let action=step["action"] as! [Any]; guard action[0] as! String == "swap" else {exit(3)}
 tap(action[1] as! Int); usleep(600000)            // select first tile (same spacing as original)
 tap(action[2] as! Int)                            // commit
 let settle=step["settleMs"] as! Int; usleep(useconds_t(settle*1000))
 print("Native swap",action,"waited",settle,"ms; expect",step["expect"]!)
}
