// native-replay-schedule.cjs (grokbot-2/ggbot) — for native (CGEvent) replay, which cannot read game state.
// Simulates the real deterministic mainline Session to count each action's visual frames, then writes a schedule
// with settleMs per action = frames x frameMs + marginMs. The native sender must wait settleMs after the commit
// tap before sending the next action's first tap. Usage:
//   node native-replay-schedule.cjs <assets/scripts> <route.json> [frameMs=180] [marginMs=600] > route.schedule.json
// route.json is Oi's format: [{level, seed, actions:[["swap",a,b],...], prior?:[[...]] }]; `prior` = actions already
// committed in a restored attempt (from __worldIntegration.board().checkpoint.actions), replayed silently first.
'use strict';
const path=require('path');
const [,,scripts,routeFile,frameMsArg,marginArg]=process.argv;
const Session=require(path.join(path.resolve(scripts),'mainline-r1/runtime/mainline-session.js'));
const frameMs=Number(frameMsArg||180),marginMs=Number(marginArg||600);
const routes=JSON.parse(require('fs').readFileSync(routeFile,'utf8'));
const out=routes.map(r=>{
  const s=new Session(r.level,r.seed);
  for(const a of r.prior||[])if(!s.act(a,false))throw Error('prior action illegal: '+JSON.stringify(a));
  const steps=r.actions.map((a,i)=>{const ok=s.act(a,true);if(!ok)throw Error(`action ${i} illegal in simulation: ${JSON.stringify(a)}`);
    const frames=s.frames.length;s.frames=[];const st=s.state();
    return {action:a,frames,settleMs:frames*frameMs+marginMs,expect:{moves:st.moves,score:st.score,status:st.status}};});
  return {...r,frameMs,marginMs,steps};
});
process.stdout.write(JSON.stringify(out,null,1)+'\n');
