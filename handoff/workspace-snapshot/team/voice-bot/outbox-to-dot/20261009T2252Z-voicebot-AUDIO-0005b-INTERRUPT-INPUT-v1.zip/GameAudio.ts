// GameAudio.ts — 音频管理脚本 v0.3（Voice Bot，2026-10-09）——给 0005b 用的“打断/挂起”输入
// 基线：Oi R6 版 creator-build-project/assets/scripts/audio/GameAudio.ts（git blob 4b6f0ac，
//       SHA256 a2f40503278f6237c325aabb7816372da37db718b9caacec18b51a830ef7272e），R6 的行为全部保留。
// v0.3 新增：
//   1) 统一的“挂起”状态：原因集合 {hidden, interrupted}。只要还有任何一个原因，就不播新音效、循环声保持暂停；
//      所有原因都清掉后才恢复。重复事件是幂等的（同一个原因加两次/清两次不会重复暂停或恢复）。
//   2) 来电/其他 App 抢音频：wx.onAudioInterruptionBegin / wx.onAudioInterruptionEnd。
//      （Cocos 3.8.8 引擎自己只在 wx.onHide/onShow 时暂停/恢复播放器，不监听 audioInterruption，所以这里要补。）
//   3) 前后台：保留 R6 的 game.on(Game.EVENT_HIDE/EVENT_SHOW)，再加 wx.onHide/wx.onShow 兜底；两路都映射到同一个
//      'hidden' 原因，所以同一次切后台收到两次事件也只算一次。
//   4) 启动时调一次 wx.setInnerAudioOption({ mixWithOther: true, obeyMuteSwitch: true })，理由见 README。
//   5) 每帧兜底：挂起期间如果循环声被引擎自动恢复（引擎 onShow 会恢复它自己暂停的播放器），立刻再暂停。
//   6) 静音存储 key 恢复为正式 key 'qfl.audio.muted'（R6 用的是隔离测试 key 'dot-audio-r1-test-20261009:muted'，不再读写）。
// 所有 wx 调用都先判断 typeof wx !== 'undefined' 且函数存在；Web / 编辑器预览里没有 wx，只走 Cocos 事件。
// 公共 API（ensure / instance / play / setMuted / isMuted / onBoardFrame / onRender / resetRenderBaseline /
// onChestResult / onClaimResult / onButton / onToolTap）与 R6、0005 完全一致，AudioBridge.ts 不用改。
// 资源位置：assets/resources/audio_sfx/sfx_*.mp3（resources 是启动时加载的分包，合计约 88 KB）。
import { _decorator, Component, Node, AudioSource, AudioClip, resources, director, game, Game, sys, isValid } from 'cc';
const { ccclass } = _decorator;

export type SfxName = 'sfx_match_normal' | 'sfx_combo_1' | 'sfx_combo_2' | 'sfx_combo_3'
  | 'sfx_chest_open' | 'sfx_ui_click' | 'sfx_level_clear';

/** 挂起原因：hidden = 切后台；interrupted = 来电/其他 App/系统抢走音频 */
export type SuspendReason = 'hidden' | 'interrupted';

const SFX_DIR = 'audio_sfx';
const MUTE_KEY = 'qfl.audio.muted';   // 正式 key。R6 实测用的是隔离 key 'dot-audio-r1-test-20261009:muted'，那份测试存档不迁移。
const MIN_GAP_MS = 60;        // 同一个音效 60 ms 内只播一次，防止同帧多次触发叠成爆音
const MAX_VOICES = 6;         // 同时最多 6 个音效；微信小游戏同时存在的音频实例数量有限，宁少勿多

type WxFn = (cb: (...a: any[]) => void) => void;
/** 取 wx 上的某个函数；没有 wx（Web/编辑器）或没有这个函数（低版本基础库）就返回 null */
function wxFn(name: string): ((...a: any[]) => any) | null {
  const w: any = (typeof wx !== 'undefined') ? (wx as any) : null;
  if (!w) return null;
  const f = w[name];
  return typeof f === 'function' ? f.bind(w) : null;
}

@ccclass('GameAudio')
export class GameAudio extends Component {
  static instance: GameAudio | null = null;
  private static innerAudioOptionApplied = false;

  private sfxSource!: AudioSource;            // 只用 playOneShot
  private loopSource!: AudioSource;           // 以后放 BGM / 环境声（走远程包，按区域加载）
  private clips = new Map<string, AudioClip>();
  private lastPlay = new Map<string, number>();
  private voices: number[] = [];               // 最近播放的结束时间戳，用来粗略限制同时发声数
  private muted = false;
  private reasons = new Set<SuspendReason>();  // 挂起原因集合；为空 = 正常
  private cascade = 0;                         // 本次操作里第几波消除（0 = 还没消）
  private prevState: string | undefined;       // 上一次 render 的 state；undefined = 还没有基准
  // wx 回调要用同一个函数引用才能 off，所以存成字段
  private readonly wxOnHide = () => this.suspend('hidden');
  private readonly wxOnShow = () => this.onShowEvent();
  private readonly wxOnIntBegin = () => this.suspend('interrupted');
  private readonly wxOnIntEnd = () => this.resume('interrupted');
  private wxRegistered: Array<[string, (...a: any[]) => void]> = [];
  private alive = true;                        // onDestroy 后置 false：低版本基础库没有 wx.off* 时，残留回调直接无效

  /** 在启动场景里调用一次即可：GameAudio.ensure() */
  static ensure(): GameAudio {
    if (GameAudio.instance) return GameAudio.instance;
    const node = new Node('GameAudio');
    director.getScene()!.addChild(node);
    director.addPersistRootNode(node);
    return node.addComponent(GameAudio);
  }

  onLoad() {
    GameAudio.instance = this;
    this.sfxSource = this.node.addComponent(AudioSource);
    this.loopSource = this.node.addComponent(AudioSource);
    this.loopSource.loop = true;
    try { this.muted = sys.localStorage.getItem(MUTE_KEY) === '1'; } catch { this.muted = false; }
    // 资源加载失败不影响游戏：没加载到的音效 play() 时直接跳过
    resources.loadDir(SFX_DIR, AudioClip, (err, list) => {
      if (!isValid(this.node, true) || GameAudio.instance !== this) return;
      if (err) { console.warn('[GameAudio] sfx load failed', err); return; }
      for (const c of list) { c.addRef(); this.clips.set(c.name, c); }
    });
    game.on(Game.EVENT_HIDE, this.onHide, this);
    game.on(Game.EVENT_SHOW, this.onShow, this);
    GameAudio.applyInnerAudioOption();
    this.registerWx('onHide', 'offHide', this.wxOnHide);
    this.registerWx('onShow', 'offShow', this.wxOnShow);
    this.registerWx('onAudioInterruptionBegin', 'offAudioInterruptionBegin', this.wxOnIntBegin);
    this.registerWx('onAudioInterruptionEnd', 'offAudioInterruptionEnd', this.wxOnIntEnd);
  }

  onDestroy() {
    this.alive = false;
    game.off(Game.EVENT_HIDE, this.onHide, this);
    game.off(Game.EVENT_SHOW, this.onShow, this);
    for (const [offName, cb] of this.wxRegistered) {
      const off = wxFn(offName);
      try { off?.(cb); } catch (e) { /* 忽略：残留回调由 alive 标志挡住 */ }
    }
    this.wxRegistered = [];
    this.reasons.clear();
    this.loopSource?.stop();
    for (const c of this.clips.values()) c.decRef();
    this.clips.clear(); this.voices = []; this.lastPlay.clear();
    if (GameAudio.instance === this) GameAudio.instance = null;
  }

  /** 挂起期间兜底：引擎在 onShow 时会自己恢复它暂停过的播放器，可能早于 interruptionEnd，这里再按住 */
  update() {
    if (this.reasons.size > 0 && this.loopSource?.playing) this.loopSource.pause();
  }

  // ---------- 通用 ----------
  play(name: SfxName, volume = 1) {
    if (this.muted || this.reasons.size > 0) return;   // 静音或任何挂起原因：新音效直接丢弃（不排队、不补播）
    const clip = this.clips.get(name);
    if (!clip) return;
    const now = Date.now();
    if (now - (this.lastPlay.get(name) || 0) < MIN_GAP_MS) return;
    this.voices = this.voices.filter(t => t > now);
    if (this.voices.length >= MAX_VOICES) return;
    this.lastPlay.set(name, now);
    this.voices.push(now + clip.getDuration() * 1000);
    this.sfxSource.playOneShot(clip, volume);
  }

  setMuted(m: boolean) {
    this.muted = m;
    try { sys.localStorage.setItem(MUTE_KEY, m ? '1' : '0'); } catch (e) { console.warn('[GameAudio] mute preference not saved', e); }
    if (m) this.loopSource.pause(); else this.resumeLoopIfAllowed();
  }
  isMuted() { return this.muted; }

  /** 只读：当前是否挂起，以及原因（给日志/验收用，AudioBridge 不需要） */
  isSuspended() { return this.reasons.size > 0; }
  suspendReasons(): SuspendReason[] { return Array.from(this.reasons).sort(); }

  // ---------- 挂起 / 恢复 ----------
  private suspend(reason: SuspendReason) {
    if (!this.alive || this.reasons.has(reason)) return;               // 幂等：重复事件不重复处理
    const wasActive = this.reasons.size === 0;
    this.reasons.add(reason);
    if (wasActive) { this.loopSource.pause(); this.voices = []; }
  }
  private resume(reason: SuspendReason) {
    if (!this.alive || !this.reasons.delete(reason)) return;           // 幂等：没有这个原因就什么都不做
    if (this.reasons.size === 0) this.resumeLoopIfAllowed();
  }
  private resumeLoopIfAllowed() {
    if (this.reasons.size === 0 && !this.muted && this.loopSource.clip && !this.loopSource.playing) this.loopSource.play();
  }
  /** 回到前台：清 hidden。interrupted 保持，等 onAudioInterruptionEnd（要求：打断没结束就不出声）。 */
  private onShowEvent() { this.resume('hidden'); }

  // R6 的 Cocos 事件入口（保留名字）
  private onHide() { this.suspend('hidden'); }
  private onShow() { this.onShowEvent(); }

  private registerWx(onName: string, offName: string, cb: (...a: any[]) => void) {
    const on = wxFn(onName) as WxFn | null;
    if (!on) return;
    try { on(cb); this.wxRegistered.push([offName, cb]); } catch (e) { console.warn('[GameAudio] wx.' + onName + ' failed', e); }
  }

  /** 全局只设一次。mixWithOther:true —— 不主动掐掉玩家自己的音乐（注意：官方文档说 speakerOn 为 true 时客户端会
   *  忽略 mixWithOther、强制互斥，所以实际是否混播以真机 I2 为准）；obeyMuteSwitch:true —— iOS 静音拨片拨到静音时游戏不出声。 */
  private static applyInnerAudioOption() {
    if (GameAudio.innerAudioOptionApplied) return;
    const set = wxFn('setInnerAudioOption');
    if (!set) return;
    GameAudio.innerAudioOptionApplied = true;
    try {
      set({ mixWithOther: true, obeyMuteSwitch: true,
        fail: (e: any) => console.warn('[GameAudio] setInnerAudioOption failed', e) });
    } catch (e) { console.warn('[GameAudio] setInnerAudioOption threw', e); }
  }

  // ---------- 棋盘 ----------
  /** 挂在 ManagedMobileBoardUI.bind() 里 animate 回调的开头，回调第一个参数就是 visual：GameAudio.instance?.onBoardFrame(v)
   *  切后台或 cancelAnimations 时剩余帧会被跳过，连击音效少播几下，可以接受（审稿意见 1）。 */
  onBoardFrame(visual: any) {
    const kind = visual?.kind;
    if (kind === 'action') { this.cascade = 0; return; }        // 玩家一次操作开始，连击计数清零
    if (kind === 'clear') {
      this.cascade++;
      const name: SfxName = this.cascade <= 1 ? 'sfx_match_normal'
        : this.cascade === 2 ? 'sfx_combo_1'
        : this.cascade === 3 ? 'sfx_combo_2' : 'sfx_combo_3';
      this.play(name);
      return;
    }
    // 'drop'（下落）、'shuffle'（洗牌）、'tool'（地区道具）暂时没有音效，见对照表
  }

  /** 每次 render 都调用：GameAudio.instance?.onRender(s.state, s.active?.status === 'won')
   *  第一次 render（含冷启动恢复到结算页、重新进入结算页）只记基准，不播（审稿 B）。
   *  只有从非结算状态切到 result.* 的那一下、且赢了，才播过关音效。 */
  onRender(state: string, won: boolean) {
    if (this.prevState === undefined) { this.prevState = state; return; }
    const entering = state.startsWith('result.') && !this.prevState.startsWith('result.');
    this.prevState = state;
    if (entering) { this.cascade = 0; if (won) this.play('sfx_level_clear'); }
  }
  /** 离开棋盘界面（销毁 ManagedMobileBoardUI）时调用，下次进来重新取基准 */
  resetRenderBaseline() { this.prevState = undefined; }

  /** 主线开宝箱：传 mainlineReward('openChest', …) 的返回值。有新发放的奖励才播（审稿 C）。 */
  onChestResult(r: any) { if (r?.newlyGrantedRewards?.length > 0) this.play('sfx_chest_open'); }
  /** 地区首通 claimR5FirstClear() 和四关全通纪念物 claimRegisteredMemento()：r.ok && !r.duplicate 才播（审稿 D）。 */
  onClaimResult(r: any) { if (r?.ok && !r.duplicate) this.play('sfx_chest_open'); }

  onButton() { this.play('sfx_ui_click', 0.8); }
  /** 道具槽只点不拖时：挂在 endToolDrag() 里 !d.moved 的分支（审稿 E） */
  onToolTap() { this.play('sfx_ui_click', 0.8); }
}

declare const wx: any;
