# AUDIO-0005b 打断处理输入包 v1（Voice Bot → GGbot 合入 0005b）

- 内容：`GameAudio.ts` v0.3 = Oi R6 版 + 来电/其他 App 抢音频处理 + 统一“挂起”状态。
- 给谁：GGbot（并进 0005b，和 Oi R6 的切后台修复一起）。Oi 真机验收见第 6 节。
- **AudioBridge.ts 不需要改**：GameAudio 的公共 API 与 R6 / 0005 完全一致（只新增了两个只读方法 `isSuspended()`、`suspendReasons()`）。0005 原版和 Oi R6 版两份 AudioBridge 都对 v0.3 做了 strict 类型检查，0 错误。

## 1. 基线（GGbot diff 用）

| 项 | 值 |
| --- | --- |
| 基线文件 | Oi R6 版 `creator-build-project/assets/scripts/audio/GameAudio.ts` |
| 取自 | `/workspace/wechat-game/team/oi/r6audio/delta-from-5df737a.patch`（R6 增量 head `3bae1926`）里该文件的新增内容，原样还原 |
| 基线 SHA256 | `a2f40503278f6237c325aabb7816372da37db718b9caacec18b51a830ef7272e` |
| 基线 git blob | `4b6f0accaf1a1cab79530813fa721c8ebf6554a2`（和补丁里 `index 0000000..4b6f0ac` 一致，说明还原无误） |
| v0.3 SHA256 | `c81654f7a2562f014fa3b6687762888076e741fc257dfb23d2e67bac0bc147c1` |
| diff | `GameAudio-v0.3-vs-OiR6.diff`（路径 `a/ b/creator-build-project/assets/scripts/audio/GameAudio.ts`，已验证 `patch` 打在基线上结果与 v0.3 逐字节一致） |

注意：GGbot 0005 补丁里的 GameAudio.ts 是 Voice Bot v0.2 原文（没有 R6 的 hidden 拦截），**不是**本包基线。0005b 直接用本包的 `GameAudio.ts` 整体替换即可，R6 的修复已经包含在内。

## 2. 相对 Oi R6 的改动

1. **统一挂起状态**：`hidden: boolean` 换成原因集合 `reasons: Set<'hidden' | 'interrupted'>`。集合非空 = 挂起：新音效直接丢弃（不排队、恢复后不补播），循环声源暂停。只有集合清空、且没静音，循环声才恢复。
2. **来电 / 其他 App 抢音频**：`wx.onAudioInterruptionBegin` → 加 `interrupted`；`wx.onAudioInterruptionEnd` → 清 `interrupted`。查过 Cocos 3.8.8 源码（`pal/audio/minigame/player-minigame.ts`）：引擎只在 `wx.onHide/onShow` 时暂停/恢复它的播放器，**不监听 audioInterruption**，所以这一层必须我们自己做。
3. **前后台**：保留 R6 的 `game.on(Game.EVENT_HIDE/EVENT_SHOW)`，另外直接注册 `wx.onHide/wx.onShow` 兜底。两路都映射到同一个 `hidden` 原因，同一次切后台收到两次事件只处理一次（幂等）。
4. **回前台不清 interrupted**：`onShow` 只清 `hidden`。电话没挂（还没收到 InterruptionEnd）就切回游戏，游戏保持安静，等 End 才恢复。
5. **每帧兜底 `update()`**：挂起期间如果循环声被引擎在 onShow 时自动恢复（引擎会恢复它自己暂停过的播放器，时机可能早于 InterruptionEnd），立刻再暂停。目前没有 BGM，这条暂时只是预防。
6. **`wx.setInnerAudioOption({ mixWithOther: true, obeyMuteSwitch: true })`**：进程内只调一次（理由见第 3 节）。
7. **注销**：`onDestroy` 里 `wx.offHide/offShow/offAudioInterruptionBegin/offAudioInterruptionEnd`（用注册时的同一函数引用）。低版本基础库没有 `off*` 时，残留回调被 `alive` 标志挡住，不会再碰已销毁的声源（自测里发现并修了这个问题）。
8. **全部 wx 调用都有保护**：先判断 `typeof wx !== 'undefined'`，再判断函数存在，调用包在 try 里。Web 构建 / 编辑器预览没有 wx，只走 Cocos 事件，行为和 R6 一样。
9. **静音 key 恢复为正式 key `qfl.audio.muted`**。R6 用的是隔离测试 key `dot-audio-r1-test-20261009:muted`，v0.3 不再读写它（那份测试存档不迁移，正式包里本来也没人写过它）。`setMuted()/isMuted()` 签名和行为不变；`setMuted(false)` 在挂起期间不会把循环声放出来。

没有改的：音效名、60 ms 去重、最多 6 声、连击档位、结算基准（冷启动不播过关音）、宝箱/领奖判断、点击音量 0.8、资源加载和引用计数。

## 3. mixWithOther / obeyMuteSwitch 的决定

- `obeyMuteSwitch: true`（iOS 才生效）：iPhone 静音拨片拨到静音时游戏不出声。休闲游戏一般都这么做，玩家在会议/地铁里拨了静音不该被音效吓一跳。
- `mixWithOther: true`：意图是不主动掐掉玩家自己在听的音乐。**但官方文档写明：`speakerOn` 为 true（默认，外放）时，客户端会忽略 mixWithOther，强制与其他音频互斥。** 我们不能把 speakerOn 改成 false（那是听筒播放），所以真机上很可能仍然是互斥的，也正因如此，InterruptionBegin/End 处理更重要。实际是否混播以 Oi 真机 I2 的结果为准。
- 两个值都等于微信默认值，显式写出来是为了：行为写在代码里可审；以后有别的代码改它时能看出来。
- 限制：文档说该接口不兼容 `createWebAudioContext` / `useWebAudioImplement`。Cocos 3.8.8 微信端用的是 InnerAudioContext，按理生效，但没在真机上验证。

## 4. 事件状态表

R = 挂起原因集合；“循环声”指 loopSource（目前没有 BGM，所以实际只影响新音效能不能播）。

| 当前 R | 事件 | 新 R | 循环声 | 新音效 |
| --- | --- | --- | --- | --- |
| {} | 切后台（Cocos EVENT_HIDE 或 wx.onHide，任一或两个都来） | {hidden} | 暂停一次 | 丢弃 |
| {} | InterruptionBegin | {interrupted} | 暂停一次 | 丢弃 |
| {hidden} | 回前台（任一或两个） | {} | 恢复一次（未静音且有 clip） | 正常 |
| {interrupted} | InterruptionEnd | {} | 恢复一次 | 正常 |
| {interrupted} | 切后台 | {hidden, interrupted} | 不动（已暂停） | 丢弃 |
| {hidden, interrupted} | InterruptionEnd | {hidden} | 不动 | 丢弃 |
| {hidden, interrupted} | 回前台 | {interrupted} | 不动 | 丢弃 |
| {hidden} / {interrupted} | 同一事件重复到达 | 不变 | 不动 | — |
| {} | 多余的 回前台 / InterruptionEnd | {} | 不动（不会重复 play） | 正常 |
| 任意非空 | `setMuted(false)` | 不变 | 不动 | 丢弃 |
| 任意非空 | 引擎自动恢复了循环声 | 不变 | 下一帧 `update()` 再暂停 | 丢弃 |
| 任意 | 组件销毁后残留回调 | — | 不动 | — |

## 5. 自测结果（Node，模拟 wx + 模拟 cc）

复跑：在包根目录 `npm i -D typescript@5`（或已有 tsc），`npx tsc -p test/tsconfig.json`（会编译到 `build/`），再 `node test/test_gameaudio_v03.cjs`。完整输出在 `test/RESULT-v0.3.txt`。

- **类型检查**：`tsc` strict + noUnusedLocals，文件：v0.3 GameAudio.ts、0005 原版 AudioBridge.ts、Oi R6 版 AudioBridge.ts（两份 AudioBridge 只改了 import 路径）、测试用 `cc.d.ts` 桩。**0 错误**。注意 `cc.d.ts` 是我写的最小声明，不是 Cocos 官方声明。
- **行为测试：13 个场景，78/78 断言通过。**
  - S0 初始化：4 个 wx 回调注册、setInnerAudioOption 只调一次且参数正确、读写 `qfl.audio.muted`、不碰 R6 测试 key、重建实例不重复设置
  - S1 hide→show（Cocos + wx 双事件）；S2 Begin→End；S3 Begin→hide→End（仍挂起）→show（恢复）；S3b hide→Begin→show（仍挂起）→End（恢复）
  - S4 重复/多余事件幂等（三次 Begin 只暂停一次、四次 show 只恢复一次等）
  - S5 引擎自动恢复循环声 → update() 再暂停
  - S6 静音与挂起叠加；S7 挂起期间所有音效入口（消除/连击/过关/宝箱/领奖/点击/道具）全部丢弃、恢复后不补播
  - S8 R6 原有行为（连击档位、60 ms 去重、冷启动不播过关音、重复领奖静音、点击 0.8、最多 6 声）
  - S9 销毁时注销 wx 和 Cocos 回调、释放 clip 引用
  - S10 Web 构建：没有 wx 全局，Cocos 事件照常，销毁不报错
  - S11 低版本基础库：没有 onAudioInterruption*、没有 off*、没有 setInnerAudioOption 都不报错；销毁后残留回调不碰声源（**第一版这里失败，已加 alive 标志修复后通过**）
  - S12 wx 接口抛异常时初始化不受影响
- **对照组**：同一套测试跑在 Oi R6 原版上：24 通过 / 20 失败。失败的都是新功能（没有 wx 打断处理、没有 isSuspended 等）；S8（R6 原有行为）在两个版本上都全过，说明 v0.3 没改坏原有逻辑。

## 6. not_run（如实标注）

- Cocos Creator 3.8.8 编译 / 构建（Web 和微信）
- 微信开发者工具运行、console 检查
- 真机：来电、语音消息、其他音乐 App、iOS 静音拨片、耳机插拔
- 真实 Cocos `AudioSource` 和引擎 onHide/onShow 自动恢复的交互顺序（测试里是模拟的）
- `setInnerAudioOption` 在真机上是否生效、mixWithOther 是否被 speakerOn 忽略
- 已知限制（不是本版能解决的）：
  - `playOneShot` 没有取消句柄，挂起那一刻**已经在响**的音效代码停不掉。另外 Cocos 3.8.8 的 OneShotAudio 在 onHide 时 pause、onShow 时会被引擎恢复：后台前正在响的那一下，回前台后可能接着响完剩下的一截（最长 3.5 s 的过关音）。这是清单 H1/H3 要记录的点；如果真机上明显，下一版换成可停止的 AudioSource 池。
  - 如果某些机型来电挂断后**收不到** InterruptionEnd，游戏会一直静音，直到下一次 End。v0.3 按要求不在 onShow 时清 interrupted。真机 I1 若出现“挂断回来没声”，下一版改为 onShow 时也清 interrupted（一行改动）。

## 7. 请 Oi 在真机上跑的 4 项（对应听感清单 I1–I3；清单里原来写的“当前未实现”，换成 0005b 后按下面的预期判定）

| 编号 | 操作 | 预期 | FAIL 条件 |
| --- | --- | --- | --- |
| I1 来电 | 关卡里连续消除时，用另一部手机打微信语音或普通电话；接听 10 秒后挂断回到游戏 | 来电期间游戏不出声；挂断回来后下一次消除/点击有声；不补播通话期间的音效 | 挂断回来彻底没声（P1）；通话中有游戏声；回来冒出一串旧音效 |
| I1b 来电不接 | 来电响铃时直接拒接 | 拒接后游戏音效正常 | 拒接后没声 |
| I2 语音消息 / 音乐 App | (a) 切到微信聊天播放一条语音消息再回游戏；(b) 打开 QQ 音乐/Apple Music 放歌，再切回游戏点几下 | (a) 回来后有声。(b) 记录：音乐是否被游戏停掉（文档预计会被停，因为外放强制互斥）；游戏音效正常 | 回来后游戏没声；音乐和游戏声叠在一起且爆音（记录即可） |
| I3 iOS 静音拨片 | iPhone 拨到静音玩一局，再拨回响铃 | 静音时游戏无声；拨回后有声 | 静音时仍有声（obeyMuteSwitch 没生效）；拨回后没声 |

每项请附微信版本、基础库版本、机型，以及 console 里有没有 `[GameAudio]` 开头的告警。

## 8. 包内文件

- `GameAudio.ts` —— v0.3，放到 `creator-build-project/assets/scripts/audio/GameAudio.ts`（替换，`.meta` 不变）
- `GameAudio-v0.3-vs-OiR6.diff` —— 相对 Oi R6 基线的 unified diff
- `README.md` —— 本文件
- `test/test_gameaudio_v03.cjs` —— 行为测试；`test/mock-cc.cjs` —— cc 运行时模拟；`test/cc.d.ts` —— cc 类型桩；`test/ManagedMobileBoardUI.ts` —— 类型桩；`test/AudioBridge_0005.ts`、`test/AudioBridge_R6.ts` —— 两份 AudioBridge 的类型检查副本（只改 import 路径）；`test/tsconfig.json`；`test/RESULT-v0.3.txt` —— 本次运行输出
