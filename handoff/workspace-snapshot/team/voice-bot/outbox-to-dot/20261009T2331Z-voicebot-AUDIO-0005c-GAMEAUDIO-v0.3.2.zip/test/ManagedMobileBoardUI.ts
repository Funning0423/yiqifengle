// 测试用桩：只为了让 AudioBridge.ts（0005 原文，未改）能做类型检查
import { Component } from 'cc';
export class ManagedMobileBoardUI extends Component { hostPresentation(): unknown { return null; } }
