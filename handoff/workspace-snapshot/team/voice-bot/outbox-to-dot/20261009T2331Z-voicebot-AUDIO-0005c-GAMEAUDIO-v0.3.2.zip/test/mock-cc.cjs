// 测试用的 'cc' 运行时模拟：AudioSource 记录 play/pause/stop/playOneShot 调用。
'use strict';
const log = [];
const store = new Map();
const gameHandlers = new Map();
class Component { destroy() { this.destroyCalled = true; if (typeof this.onDestroy === 'function') this.onDestroy(); return true; } }
class Node {
  constructor(name) { this.name = name || ''; this.children = []; this.components = []; this.valid = true; }
  addChild(n) { this.children.push(n); }
  addComponent(C) { const c = new C(); c.node = this; this.components.push(c); if (typeof c.onLoad === 'function') c.onLoad(); return c; }
  getComponent(C) { return this.components.find(c => c instanceof C) || null; }
  destroy() { this.valid = false; for (const c of this.components) if (typeof c.onDestroy === 'function') c.onDestroy(); }
}
Node.EventType = { TOUCH_START: 'touch-start', TOUCH_END: 'touch-end' };
class AudioClip { constructor(name, dur) { this.name = name; this.dur = dur || 0.3; this.refs = 0; } addRef() { this.refs++; return this; } decRef() { this.refs--; return this; } getDuration() { return this.dur; } }
let srcId = 0;
class AudioSource extends Component {
  constructor() { super(); this.id = ++srcId; this.loop = false; this.clip = null; this._playing = false; }
  get playing() { return this._playing; }
  play() { this._playing = true; log.push(['play', this.id]); }
  pause() { this._playing = false; log.push(['pause', this.id]); }
  stop() { this._playing = false; log.push(['stop', this.id]); }
  playOneShot(clip, v) { log.push(['oneShot', clip.name, v]); }
}
const scene = new Node('Scene');
const loadDirClips = ['sfx_match_normal','sfx_combo_1','sfx_combo_2','sfx_combo_3','sfx_chest_open','sfx_ui_click','sfx_level_clear'].map(n => new AudioClip(n, 0.3));
module.exports = {
  __log: log, __store: store, __gameHandlers: gameHandlers, __scene: scene, __clips: loadDirClips,
  __emitGame(e) { for (const [cb, t] of (gameHandlers.get(e) || []).slice()) cb.call(t); },
  _decorator: { ccclass: () => (c) => c },
  Component, Node, AudioSource, AudioClip,
  resources: { loadDir(dir, T, cb) { cb(null, loadDirClips); } },
  director: { getScene: () => scene, addPersistRootNode() {}, once() {} },
  Director: { EVENT_AFTER_SCENE_LAUNCH: 'after-scene-launch' },
  Game: { EVENT_HIDE: 'game_on_hide', EVENT_SHOW: 'game_on_show' },
  game: {
    on(e, cb, t) { if (!gameHandlers.has(e)) gameHandlers.set(e, []); gameHandlers.get(e).push([cb, t]); },
    off(e, cb, t) { const l = gameHandlers.get(e) || []; gameHandlers.set(e, l.filter(([c, tt]) => !(c === cb && tt === t))); },
  },
  sys: { localStorage: { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k, v) => store.set(k, String(v)) } },
  isValid: (o) => !!o && o.valid !== false,
  Graphics: class extends Component {}, Label: class extends Component {}, EventTouch: class {},
};
