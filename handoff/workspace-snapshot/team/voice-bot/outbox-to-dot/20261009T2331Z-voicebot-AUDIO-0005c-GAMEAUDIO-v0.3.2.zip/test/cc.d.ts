// 测试用的最小 'cc' 类型声明（只覆盖 GameAudio.ts / AudioBridge.ts 用到的部分），不是 Cocos 官方声明。
declare module 'cc' {
  export const _decorator: { ccclass(name: string): <T>(c: T) => T };
  export class Vec2 { x: number; y: number; }
  export class Component { node: Node; static instance?: any; }
  export class Node {
    constructor(name?: string);
    name: string; children: Node[];
    addChild(n: Node): void;
    addComponent<T extends Component>(c: new () => T): T;
    getComponent<T extends Component>(c: abstract new (...a: any[]) => T): T | null;
    getComponentInChildren<T extends Component>(c: abstract new (...a: any[]) => T): T | null;
    getComponentsInChildren<T extends Component>(c: abstract new (...a: any[]) => T): T[];
    getChildByName(n: string): Node | null;
    on(type: string, cb: (...a: any[]) => void, target?: any): void;
    targetOff(t: any): void;
    static EventType: { TOUCH_START: string; TOUCH_END: string };
  }
  export class Scene extends Node {}
  export class AudioClip { name: string; addRef(): this; decRef(): this; getDuration(): number; }
  export class AudioSource extends Component {
    loop: boolean; clip: AudioClip | null; readonly playing: boolean;
    play(): void; pause(): void; stop(): void; playOneShot(c: AudioClip, v?: number): void;
  }
  export const resources: { loadDir<T>(dir: string, type: new () => T, cb: (err: Error | null, list: T[]) => void): void };
  export class Director { static EVENT_AFTER_SCENE_LAUNCH: string; }
  export const director: { getScene(): Scene | null; addPersistRootNode(n: Node): void; once(e: string, cb: () => void): void; on(e: string, cb: () => void): void };
  export class Game { static EVENT_HIDE: string; static EVENT_SHOW: string; }
  export const game: { on(e: string, cb: () => void, t?: any): void; off(e: string, cb: () => void, t?: any): void };
  export const sys: { localStorage: { getItem(k: string): string | null; setItem(k: string, v: string): void } };
  export function isValid(o: any, strict?: boolean): boolean;
  export class Graphics extends Component {}
  export class Label extends Component {}
  export class EventTouch { getUILocation(): Vec2; }
}
