// GameAudio v0.3.2 自测（v0.3.1 用例 + 0005c 审查修复用例 S13–S20）：Node + 模拟 wx + 模拟 cc。用法：先 tsc -p test/tsconfig.json 编译到 build/，再 node test/test_gameaudio_v03.cjs [build目录]
'use strict';
const path = require('path');
const Module = require('module');
const BUILD = path.resolve(process.argv[2] || path.join(__dirname, '../build'));
const MOCK = path.join(__dirname, 'mock-cc.cjs');
const origResolve = Module._resolveFilename;
Module._resolveFilename = function (req, ...rest) { return req === 'cc' ? MOCK : origResolve.call(this, req, ...rest); };

let pass = 0, fail = 0; const failures = [];
function ok(cond, msg) { if (cond) pass++; else { fail++; failures.push(msg); console.log('  FAIL', msg); } }

function makeWx(opts = {}) {
  const h = {}; const calls = [];
  const wx = {};
  const names = ['Hide', 'Show', 'AudioInterruptionBegin', 'AudioInterruptionEnd'];
  for (const n of names) {
    if (opts.missing && opts.missing.includes(n)) continue;
    h[n] = [];
    wx['on' + n] = cb => { calls.push('on' + n); h[n].push(cb); };
    if (!(opts.noOff)) wx['off' + n] = cb => { calls.push('off' + n); h[n] = h[n].filter(c => c !== cb); };
  }
  wx.__optionMode = opts.optionMode || 'success';   // success | fail | throw | none（不回调）
  if (!opts.noInnerOption) wx.setInnerAudioOption = o => {
    calls.push(['setInnerAudioOption', { mixWithOther: o.mixWithOther, obeyMuteSwitch: o.obeyMuteSwitch }]);
    if (wx.__optionMode === 'throw') throw new Error('option-throw');
    if (wx.__optionMode === 'fail') o.fail && o.fail({ errMsg: 'option-fail' });
    if (wx.__optionMode === 'success') o.success && o.success({});
  };
  wx.__emit = n => { for (const cb of (h[n] || []).slice()) cb(); };
  wx.__h = h; wx.__calls = calls;
  return wx;
}

function fresh(wx, { bgm = true, store } = {}) {
  for (const k of Object.keys(require.cache)) if (k === MOCK || k.startsWith(BUILD)) delete require.cache[k];
  if (wx) global.wx = wx; else delete global.wx;
  const cc = require(MOCK);
  if (store) for (const [k, v] of Object.entries(store)) cc.__store.set(k, v);
  const { GameAudio } = require(path.join(BUILD, 'GameAudio.js'));
  const a = GameAudio.ensure();
  const loop = a.loopSource, sfx = a.sfxSource;
  if (bgm) { loop.clip = { name: 'bgm_test' }; loop.play(); }
  cc.__log.length = 0;
  const loopOps = () => cc.__log.filter(e => e[1] === loop.id).map(e => e[0]);
  const shots = () => cc.__log.filter(e => e[0] === 'oneShot').map(e => e[1]);
  const clearLog = () => { cc.__log.length = 0; };
  // 绕开 60 ms 去重：每次测 SFX 前把 lastPlay 清空
  const sfxTry = (fn) => { a.lastPlay.clear(); a.voices = []; const before = shots().length; fn(); return shots().length - before; };
  return { cc, GameAudio, a, loop, sfx, loopOps, shots, clearLog, sfxTry, wx };
}
function scenario(name, fn) { const p0 = pass, f0 = fail; try { fn(); } catch (e) { fail++; failures.push(name + ': threw ' + e.stack); console.log('  THROW', e); } console.log(`[${fail === f0 ? 'PASS' : 'FAIL'}] ${name} (${pass - p0} ok, ${fail - f0} fail)`); }

// S0 初始化：注册、setInnerAudioOption、静音 key
scenario('S0 init: wx handlers + setInnerAudioOption once + mute key', () => {
  const t = fresh(makeWx(), { store: { 'qfl.audio.muted': '1', 'dot-audio-r1-test-20261009:muted': '0' } });
  const c = t.wx.__calls;
  for (const n of ['onHide', 'onShow', 'onAudioInterruptionBegin', 'onAudioInterruptionEnd']) ok(c.includes(n), 'S0 registered ' + n);
  const opt = c.filter(x => Array.isArray(x) && x[0] === 'setInnerAudioOption');
  ok(opt.length === 1, 'S0 setInnerAudioOption called once');
  ok(opt[0] && opt[0][1].mixWithOther === true && opt[0][1].obeyMuteSwitch === true, 'S0 options mixWithOther:true obeyMuteSwitch:true');
  ok(t.a.isMuted() === true, 'S0 reads qfl.audio.muted');
  t.a.setMuted(false);
  ok(t.cc.__store.get('qfl.audio.muted') === '0', 'S0 setMuted writes qfl.audio.muted');
  ok(t.cc.__store.get('dot-audio-r1-test-20261009:muted') === '0', 'S0 R6 test key untouched');
  ok(t.a.isSuspended() === false && t.a.suspendReasons().length === 0, 'S0 not suspended at start');
  // 第二个实例（销毁后重建）不重复设置 setInnerAudioOption（同一进程）
  t.a.node.destroy();
  const { GameAudio } = t; const b = GameAudio.ensure();
  ok(c.filter(x => Array.isArray(x) && x[0] === 'setInnerAudioOption').length === 1, 'S0 setInnerAudioOption not re-applied on re-create');
  ok(b !== t.a && GameAudio.instance === b, 'S0 re-ensure gives new instance');
});

// S1 hide→show（Cocos 事件 + wx 事件都来）
scenario('S1 hide -> show', () => {
  const t = fresh(makeWx());
  t.cc.__emitGame('game_on_hide'); t.wx.__emit('Hide');
  ok(t.a.isSuspended() && t.a.suspendReasons().join() === 'hidden', 'S1 suspended(hidden)');
  ok(t.loopOps().filter(x => x === 'pause').length === 1, 'S1 loop paused exactly once despite 2 hide events');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S1 SFX dropped while hidden');
  t.clearLog();
  t.wx.__emit('Show'); t.cc.__emitGame('game_on_show');
  ok(!t.a.isSuspended(), 'S1 resumed');
  ok(t.loopOps().filter(x => x === 'play').length === 1, 'S1 loop played exactly once despite 2 show events');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S1 SFX plays after show');
  ok(t.shots().length === 1, 'S1 no catch-up of dropped SFX');
});

// S2 interrupt begin→end
scenario('S2 interruption begin -> end', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');
  ok(t.a.suspendReasons().join() === 'interrupted', 'S2 suspended(interrupted)');
  ok(t.loopOps().join() === 'pause', 'S2 loop paused');
  ok(t.sfxTry(() => t.a.onBoardFrame({ kind: 'clear' })) === 0, 'S2 SFX dropped while interrupted');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended(), 'S2 resumed');
  ok(t.loopOps().join() === 'play', 'S2 loop resumed once');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S2 SFX plays after end');
});

// S3 interrupt begin→hide→interrupt end(仍挂起)→show(恢复)
scenario('S3 begin -> hide -> end (stay) -> show (resume)', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');
  t.cc.__emitGame('game_on_hide'); t.wx.__emit('Hide');
  ok(t.a.suspendReasons().join() === 'hidden,interrupted', 'S3 both reasons');
  ok(t.loopOps().filter(x => x === 'pause').length === 1, 'S3 paused once total');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(t.a.suspendReasons().join() === 'hidden', 'S3 still suspended(hidden) after interruption end');
  ok(t.loopOps().length === 0, 'S3 no loop play while still hidden');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S3 SFX still dropped');
  t.wx.__emit('Show'); t.cc.__emitGame('game_on_show');
  ok(!t.a.isSuspended(), 'S3 resumed after show');
  ok(t.loopOps().join() === 'play', 'S3 loop played once');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S3 SFX plays');
});

// S2b 前台开始的打断、没有切后台：只能等 End（只有 show 会额外清它）
scenario('S2b foreground interruption, no hide: waits for End', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');
  t.a.update();
  ok(t.a.suspendReasons().join() === 'interrupted', 'S2b still interrupted without End/show');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S2b SFX dropped until End');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended() && t.loopOps().join() === 'play', 'S2b End resumes once');
});

// S3b v0.3.1：hide→begin→show 直接恢复（show 清 interrupted）；之后迟到的 End 不重复恢复
scenario('S3b hide -> begin -> show (resume, v0.3.1) -> late end (no-op)', () => {
  const t = fresh(makeWx());
  t.cc.__emitGame('game_on_hide'); t.wx.__emit('AudioInterruptionBegin');
  ok(t.a.suspendReasons().join() === 'hidden,interrupted', 'S3b both reasons');
  t.clearLog();
  t.cc.__emitGame('game_on_show'); t.wx.__emit('Show');
  ok(!t.a.isSuspended(), 'S3b show clears interrupted too');
  ok(t.loopOps().join() === 'play', 'S3b loop played exactly once despite 2 show events');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S3b SFX plays after show');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended() && t.loopOps().length === 0, 'S3b late End is a no-op');
});

// S3c v0.3.1：前台开始打断，始终没有 End，然后切后台再回来 → 恢复出声
scenario('S3c interrupt begin, no end, hide -> show -> sound resumes', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');
  t.cc.__emitGame('game_on_hide'); t.wx.__emit('Hide');
  ok(t.loopOps().filter(x => x === 'pause').length === 1, 'S3c paused once');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S3c SFX dropped while hidden+interrupted');
  t.clearLog();
  t.wx.__emit('Show'); t.cc.__emitGame('game_on_show');
  ok(!t.a.isSuspended() && t.a.suspendReasons().length === 0, 'S3c no reasons left after show');
  ok(t.loopOps().join() === 'play', 'S3c loop resumed once');
  ok(t.sfxTry(() => t.a.onBoardFrame({ kind: 'clear' })) === 1, 'S3c SFX plays again (no permanent silence)');
});

// S4 重复/乱序事件
scenario('S4 duplicate and stray events are idempotent', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionEnd'); t.wx.__emit('Show'); t.cc.__emitGame('game_on_show');
  ok(!t.a.isSuspended() && t.loopOps().length === 0, 'S4 stray end/show before any begin: no-op (loop already playing, no double play)');
  for (let i = 0; i < 3; i++) t.wx.__emit('AudioInterruptionBegin');
  ok(t.loopOps().filter(x => x === 'pause').length === 1, 'S4 triple begin pauses once');
  t.clearLog();
  for (let i = 0; i < 3; i++) t.wx.__emit('AudioInterruptionEnd');
  ok(t.loopOps().filter(x => x === 'play').length === 1, 'S4 triple end plays once');
  t.clearLog();
  for (let i = 0; i < 2; i++) { t.cc.__emitGame('game_on_hide'); t.wx.__emit('Hide'); }
  ok(t.loopOps().filter(x => x === 'pause').length === 1, 'S4 4x hide pauses once');
  t.clearLog();
  for (let i = 0; i < 2; i++) { t.cc.__emitGame('game_on_show'); t.wx.__emit('Show'); }
  ok(t.loopOps().filter(x => x === 'play').length === 1, 'S4 4x show plays once');
});

// S5 挂起期间引擎自动恢复循环声 → update() 兜底再暂停
scenario('S5 engine auto-resume during suspension is re-paused by update()', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');
  t.loop.play();                      // 模拟引擎 onShow 恢复了它暂停的播放器
  t.a.update();
  ok(t.loop.playing === false, 'S5 loop re-paused in update while suspended');
  t.wx.__emit('AudioInterruptionEnd');
  t.a.update();
  ok(t.loop.playing === true, 'S5 loop playing after resume and update does not pause it');
});

// S6 静音 × 挂起
scenario('S6 mute interplay', () => {
  const t = fresh(makeWx());
  t.a.setMuted(true);
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('AudioInterruptionEnd');
  ok(t.loop.playing === false, 'S6 muted: interruption end does not resume loop');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S6 muted: SFX dropped');
  t.wx.__emit('AudioInterruptionBegin');
  t.a.setMuted(false);
  ok(t.loop.playing === false, 'S6 unmute while interrupted: loop stays paused');
  t.wx.__emit('AudioInterruptionEnd');
  ok(t.loop.playing === true, 'S6 loop resumes after unmute + end');
});

// S7 挂起期间各类 SFX 入口全部丢弃
scenario('S7 all SFX entry points dropped during suspension', () => {
  const t = fresh(makeWx());
  t.a.onRender('run.ready', false);
  t.wx.__emit('AudioInterruptionBegin');
  const n = t.sfxTry(() => {
    t.a.onBoardFrame({ kind: 'action' }); t.a.onBoardFrame({ kind: 'clear' }); t.a.lastPlay.clear(); t.a.onBoardFrame({ kind: 'clear' });
    t.a.onRender('result.won', true); t.a.onChestResult({ newlyGrantedRewards: [1] }); t.a.lastPlay.clear();
    t.a.onClaimResult({ ok: true, duplicate: false }); t.a.onButton(); t.a.lastPlay.clear(); t.a.onToolTap(); t.a.play('sfx_combo_3');
  });
  ok(n === 0, 'S7 zero one-shots while interrupted');
  t.wx.__emit('AudioInterruptionEnd');
  ok(t.shots().length === 0, 'S7 nothing replayed on resume');
  ok(t.sfxTry(() => t.a.onChestResult({ newlyGrantedRewards: [1] })) === 1, 'S7 chest sound after resume');
});

// S8 R6 行为保留（未挂起时）
scenario('S8 R6 behaviour preserved when not suspended', () => {
  const t = fresh(makeWx());
  const seq = [];
  t.a.onBoardFrame({ kind: 'action' });
  for (let i = 0; i < 5; i++) { t.a.lastPlay.clear(); t.a.voices = []; t.a.onBoardFrame({ kind: 'clear' }); }
  ok(t.shots().join() === 'sfx_match_normal,sfx_combo_1,sfx_combo_2,sfx_combo_3,sfx_combo_3', 'S8 cascade mapping');
  t.clearLog(); t.a.lastPlay.clear();
  t.a.onButton(); t.a.onButton();
  ok(t.shots().length === 1, 'S8 60ms dedupe');
  t.clearLog(); t.a.resetRenderBaseline();
  t.a.onRender('result.won', true);
  ok(t.shots().length === 0, 'S8 cold restore to result: no level_clear');
  t.a.onRender('run.ready', false); t.a.onRender('result.won', true);
  ok(t.shots().join() === 'sfx_level_clear', 'S8 entering result & won plays level_clear');
  t.clearLog(); t.a.lastPlay.clear(); t.a.voices = [];
  t.a.onClaimResult({ ok: true, duplicate: true }); t.a.onChestResult({ newlyGrantedRewards: [] });
  ok(t.shots().length === 0, 'S8 duplicate claim / empty chest silent');
  const vol = t.cc.__log.filter(e => e[0] === 'oneShot');
  t.a.lastPlay.clear(); t.a.onToolTap();
  ok(t.cc.__log.filter(e => e[0] === 'oneShot').pop()[2] === 0.8, 'S8 click volume 0.8');
  t.a.voices = []; t.a.lastPlay.clear(); t.clearLog();
  const names = ['sfx_match_normal','sfx_combo_1','sfx_combo_2','sfx_combo_3','sfx_chest_open','sfx_ui_click','sfx_level_clear'];
  for (const nm of names) t.a.play(nm);
  ok(t.shots().length === 6, 'S8 MAX_VOICES=6');
  void vol; void seq;
});

// S9 销毁时注销
scenario('S9 destroy unregisters wx + cocos handlers', () => {
  const t = fresh(makeWx());
  const a = t.a;
  a.node.destroy();
  for (const n of ['Hide', 'Show', 'AudioInterruptionBegin', 'AudioInterruptionEnd']) ok(t.wx.__h[n].length === 0, 'S9 wx ' + n + ' unregistered');
  ok((t.cc.__gameHandlers.get('game_on_hide') || []).length === 0 && (t.cc.__gameHandlers.get('game_on_show') || []).length === 0, 'S9 cocos handlers off');
  ok(t.GameAudio.instance === null, 'S9 instance cleared');
  t.clearLog();
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('Hide');
  ok(t.cc.__log.length === 0, 'S9 events after destroy do nothing');
  ok(t.cc.__clips.every(c => c.refs === 0), 'S9 clip refs released');
});

// S10 Web/编辑器：没有 wx
scenario('S10 Web build: no wx global', () => {
  const t = fresh(null);
  ok(typeof global.wx === 'undefined', 'S10 wx undefined');
  t.cc.__emitGame('game_on_hide');
  ok(t.a.suspendReasons().join() === 'hidden', 'S10 cocos hide still works');
  t.cc.__emitGame('game_on_show');
  ok(!t.a.isSuspended() && t.loop.playing, 'S10 cocos show resumes');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S10 SFX plays');
  let threw = false; try { t.a.node.destroy(); } catch (e) { threw = true; }
  ok(!threw, 'S10 destroy without wx does not throw');
});

// S11 低版本基础库：缺 onAudioInterruption*、缺 off*、缺 setInnerAudioOption
scenario('S11 old base library: missing APIs tolerated', () => {
  const t = fresh(makeWx({ missing: ['AudioInterruptionBegin', 'AudioInterruptionEnd'], noOff: true, noInnerOption: true }));
  ok(!t.wx.__calls.includes('onAudioInterruptionBegin'), 'S11 no interruption registration attempted');
  t.wx.__emit('Hide');
  ok(t.a.isSuspended(), 'S11 wx hide works');
  t.wx.__emit('Show');
  ok(!t.a.isSuspended(), 'S11 wx show works');
  let threw = false; try { t.a.node.destroy(); } catch (e) { threw = true; }
  ok(!threw, 'S11 destroy without off* does not throw');
  t.clearLog(); t.wx.__emit('Hide');
  ok(t.cc.__log.length === 0, 'S11 stale wx handler after destroy (no off available) touches no audio source');
});

// S12 wx API 抛异常
scenario('S12 throwing wx APIs do not break init', () => {
  const wx = makeWx();
  wx.onAudioInterruptionBegin = () => { throw new Error('boom'); };
  wx.setInnerAudioOption = () => { throw new Error('boom'); };
  const warn = console.warn; console.warn = () => {};
  let t; let threw = false; try { t = fresh(wx); } catch (e) { threw = true; } finally { console.warn = warn; }
  ok(!threw && t && t.GameAudio.instance === t.a, 'S12 init survives');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S12 SFX works');
});

const optCalls = (t) => t.wx.__calls.filter(x => Array.isArray(x) && x[0] === 'setInnerAudioOption').length;

// S13 审查 #1：回前台后新开始的打断，不会被迟到的重复 Show 吞掉
scenario('S13 review#1 duplicate Show after a new foreground Begin keeps the interruption', () => {
  const t = fresh(makeWx());
  t.cc.__emitGame('game_on_hide'); t.wx.__emit('Hide');
  t.cc.__emitGame('game_on_show');                      // 第一次 Show：真正回前台
  ok(!t.a.isSuspended(), 'S13 resumed by first show');
  t.wx.__emit('AudioInterruptionBegin');                // 回前台后新打断
  t.wx.__emit('Show');                                  // 重复的 wx Show
  ok(t.a.suspendReasons().join() === 'interrupted', 'S13 duplicate show does not clear new interruption');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S13 SFX still dropped before End');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended() && t.loopOps().join() === 'play', 'S13 End resumes once');
});

// S14 审查 #2：被回前台提前结束的旧打断，它迟到的 End 不会清掉新打断
scenario('S14 review#2 late End of a show-cleared interruption does not clear a newer Begin', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin');                // gen1
  t.wx.__emit('Hide'); t.wx.__emit('Show');             // 回前台：gen1 强制结束，staleGen=1
  ok(!t.a.isSuspended(), 'S14 show resumed without End (Grok Bot decision kept)');
  ok(JSON.stringify(t.a.interruptionState()) === '{"gen":1,"activeGen":0,"staleGen":1}', 'S14 staleGen=1 after show');
  t.wx.__emit('AudioInterruptionBegin');                // gen2
  t.wx.__emit('AudioInterruptionEnd');                  // gen1 迟到的 End
  ok(t.a.suspendReasons().join() === 'interrupted', 'S14 newer interruption still active after late End');
  ok(JSON.stringify(t.a.interruptionState()) === '{"gen":2,"activeGen":2,"staleGen":0}', 'S14 late End consumed staleGen only');
  ok(t.sfxTry(() => t.a.onButton()) === 0, 'S14 SFX dropped');
  t.wx.__emit('AudioInterruptionEnd');                  // gen2 的 End
  ok(!t.a.isSuspended(), 'S14 second End clears gen2');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S14 SFX plays');
});

// S15 欠着的 End 到了、但没有新打断：只消耗，不改变状态；之后前台打断照常
scenario('S15 stale End with no new Begin is consumed harmlessly', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin'); t.cc.__emitGame('game_on_hide'); t.cc.__emitGame('game_on_show');
  t.clearLog();
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended() && t.loopOps().length === 0 && t.a.interruptionState().staleGen === 0, 'S15 stale End consumed, no audio change');
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended(), 'S15 later foreground Begin/End works normally');
});

// S16 欠着的 End 最多活到下一次回前台（限制“吞掉新 End 导致没声”的时长）
scenario('S16 staleGen expires on the next hide->show', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('Hide'); t.wx.__emit('Show');
  ok(t.a.interruptionState().staleGen === 1, 'S16 stale set');
  t.wx.__emit('Hide'); t.wx.__emit('Show');
  ok(t.a.interruptionState().staleGen === 0, 'S16 stale cleared by next foreground return without interruption');
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended(), 'S16 End after expiry clears current interruption (documented trade-off)');
  // 吞掉的情况也能靠回前台恢复：stale 存在时前台打断的 End 被算给旧代 → 切一次后台再回来恢复
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('Hide'); t.wx.__emit('Show');   // stale=2
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('AudioInterruptionEnd');         // 这个 End 被当成旧代的
  ok(t.a.isSuspended(), 'S16 worst case: End assigned to stale gen, still suspended');
  t.wx.__emit('Hide'); t.wx.__emit('Show');
  ok(!t.a.isSuspended() && t.sfxTry(() => t.a.onButton()) === 1, 'S16 next foreground return always restores sound');
});

// S17 重复 Begin 不开新的一代；一个 End 就够
scenario('S17 duplicate Begin is ignored', () => {
  const t = fresh(makeWx());
  t.wx.__emit('AudioInterruptionBegin'); t.wx.__emit('AudioInterruptionBegin');
  ok(t.a.interruptionState().gen === 1, 'S17 one generation');
  t.wx.__emit('AudioInterruptionEnd');
  ok(!t.a.isSuspended(), 'S17 one End resumes');
});

// S18 审查 #3：setInnerAudioOption 只在 success 后算成功，失败可重试
scenario('S18 review#3 setInnerAudioOption success/fail/throw/pending', () => {
  const warn = console.warn; console.warn = () => {};
  let t;
  try {
    t = fresh(makeWx({ optionMode: 'fail' }));
    ok(t.GameAudio.innerAudioOptionApplied === false, 'S18 fail: not marked applied');
    t.a.node.destroy(); t.GameAudio.ensure();
    ok(optCalls(t) === 2, 'S18 fail: retried on next init');
    t.wx.__optionMode = 'success'; t.wx.__emit('Hide'); t.wx.__emit('Show');
    ok(optCalls(t) === 3 && t.GameAudio.innerAudioOptionApplied === true, 'S18 retried on show and succeeded');
    t.wx.__emit('Hide'); t.wx.__emit('Show'); t.GameAudio.instance.node.destroy(); t.GameAudio.ensure();
    ok(optCalls(t) === 3, 'S18 no more calls after success');
    t = fresh(makeWx({ optionMode: 'throw' }));
    ok(t.GameAudio.innerAudioOptionApplied === false, 'S18 throw: not marked applied');
    t.wx.__optionMode = 'success'; t.wx.__emit('Hide'); t.wx.__emit('Show');
    ok(optCalls(t) === 2 && t.GameAudio.innerAudioOptionApplied === true, 'S18 throw: retried on show');
    t = fresh(makeWx({ optionMode: 'none' }));
    t.wx.__emit('Hide'); t.wx.__emit('Show'); t.a.node.destroy(); t.GameAudio.ensure();
    ok(optCalls(t) === 1 && t.GameAudio.innerAudioOptionApplied === false, 'S18 pending (no callback): not re-sent, not marked applied');
  } finally { console.warn = warn; }
});

// S19 审查 #4：第二个组件被拒绝
scenario('S19 review#4 second GameAudio component rejected', () => {
  const t = fresh(makeWx());
  const before = Object.values(t.wx.__h).reduce((n, a) => n + a.length, 0);
  const gameBefore = [...t.cc.__gameHandlers.values()].reduce((n, a) => n + a.length, 0);
  const warn = console.warn; let warned = 0; console.warn = () => { warned++; };
  let b; try { b = new t.cc.Node('manual').addComponent(t.GameAudio); } finally { console.warn = warn; }
  ok(t.GameAudio.instance === t.a, 'S19 instance not overwritten');
  ok(Object.values(t.wx.__h).reduce((n, a) => n + a.length, 0) === before, 'S19 no extra wx callbacks');
  ok([...t.cc.__gameHandlers.values()].reduce((n, a) => n + a.length, 0) === gameBefore, 'S19 no extra cocos callbacks');
  ok(b.destroyCalled === true && warned === 1, 'S19 duplicate component destroyed with one warning');
  ok(b.node.components.filter(c => c instanceof t.cc.AudioSource).length === 0, 'S19 duplicate created no AudioSource');
  ok(t.sfxTry(() => { b.onButton(); }) === 0, 'S19 duplicate cannot play');
  ok(t.sfxTry(() => t.a.onButton()) === 1, 'S19 original still plays');
  t.wx.__emit('AudioInterruptionBegin');
  ok(t.a.isSuspended(), 'S19 original still receives events');
  ok(t.GameAudio.ensure() === t.a, 'S19 ensure returns original');
  t.a.node.destroy();
  const c = t.GameAudio.ensure();
  ok(c !== t.a && t.GameAudio.instance === c, 'S19 after original destroyed, a new instance is accepted');
});

// S20 审查 #5：静音时 update 也按住循环声
scenario('S20 review#5 update holds loop silent while muted', () => {
  const t = fresh(makeWx());
  t.cc.__emitGame('game_on_hide'); t.a.setMuted(true); t.cc.__emitGame('game_on_show');
  t.loop.play();                                         // 模拟引擎在 Show 后恢复循环声
  t.a.update();
  ok(t.loop.playing === false, 'S20 muted: engine-resumed loop re-paused');
  t.a.setMuted(false);
  ok(t.loop.playing === true, 'S20 unmute resumes loop');
  t.a.update();
  ok(t.loop.playing === true, 'S20 update leaves loop playing when unmuted and not suspended');
});

console.log(`\nTOTAL: ${pass} passed, ${fail} failed`);
if (fail) { console.log(failures.join('\n')); process.exit(1); }
