'use strict';
// 用 Oi 云端审查的原版脚本（test_audio_review.cjs，SHA256 b7fb2e33…6720，逐字复制）跑任意一个 GameAudio.ts。
// 只做四处字符串替换：源文件路径、期望 SHA256（改成被测文件自己的）、结果输出路径，以及（Grok Bot 决定 a）
// 用“旧节点已销毁，再建新实例”的变体替换正常用例 new_instance_old_load_result_ignored —— 原用例要求“第二个活着的
// 实例接管”，和修复 #4 / defect 用例 manual_duplicate_component_is_not_prevented 正面冲突。其余 21 个用例一字不改。
// 另外追加 6 个“修好后应有的行为”用例（defect_fixed:*），复用原脚本的 make() 模拟环境，对应 6 个 defect 用例的同一事件序列。
// 用法：node review/run_review.cjs <GameAudio.ts> <out.json>
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), cp = require('node:child_process');
const [src, out] = process.argv.slice(2).map(p => path.resolve(p));
const orig = fs.readFileSync(path.join(__dirname, 'test_audio_review.cjs'), 'utf8');
const origSha = crypto.createHash('sha256').update(orig).digest('hex');
if (origSha !== 'b7fb2e3321a34955732262b5544279cd16da4341c7eedcb5da4aec205fe26720') throw new Error('review script changed: ' + origSha);
const srcSha = crypto.createHash('sha256').update(fs.readFileSync(src)).digest('hex');
function rep(s, a, b) { if (s.split(a).length !== 2) throw new Error('replace target not unique: ' + a); return s.replace(a, b); }
let s = orig;
s = rep(s, "root+'/candidate-0005b/creator-build-project/assets/scripts/audio/GameAudio.ts'", JSON.stringify(src));
s = rep(s, "'7f6b580822dae4986f3217ecd70af34ad3b19153e2ffd6e8d3120e37bba3d377'", JSON.stringify(srcSha));
s = rep(s, "root+'/evidence/audio-review-results.json'", JSON.stringify(out));
const ORIG_CASE = "test('new_instance_old_load_result_ignored','pass',()=>{const h=make(),a=h.G.ensure(),b=h.spawn(),old=h.clip(),fresh=h.clip();h.loads[0](null,[old]);h.loads[1](null,[fresh]);assert.equal(old.refs,0);assert.equal(fresh.refs,1);return 'Instance identity guard rejects old asynchronous load callback.';});";
const REPLACEMENT = "test('new_instance_old_load_result_ignored__REPLACED_BY__old_node_destroyed_then_new_instance','pass',()=>{const h=make(),a=h.G.ensure();a.node.valid=false;const b=h.spawn(),old=h.clip(),fresh=h.clip();h.loads[0](null,[old]);h.loads[1](null,[fresh]);assert.equal(old.refs,0);assert.equal(fresh.refs,1);assert.equal(h.G.instance,b);return 'Replacement (Grok Bot option a): old node destroyed first, new instance accepted; old async load ignored, new load kept.';});";
s = rep(s, ORIG_CASE, REPLACEMENT);
const fixed = `
// ---- 追加：6 个 defect 用例修好后应有的行为（同一事件序列，断言反过来） ----
test('defect_fixed:duplicate_show_keeps_new_foreground_interruption','fixed_check',()=>{const h=make(),a=h.G.ensure();h.ready(a);h.game.emit('HIDE');h.wxe.emit('HIDE');h.game.emit('SHOW');h.wxe.emit('BEGIN');assert.equal(a.isSuspended(),true);h.wxe.emit('SHOW');assert.equal(a.isSuspended(),true);a.onButton();assert.equal(h.shots.length,0);h.wxe.emit('END');a.onButton();assert.equal(h.shots.length,1);});
test('defect_fixed:old_end_does_not_clear_new_interruption','fixed_check',()=>{const h=make(),a=h.G.ensure();h.ready(a);h.wxe.emit('BEGIN');h.wxe.emit('HIDE');h.wxe.emit('SHOW');h.wxe.emit('BEGIN');h.wxe.emit('END');a.onButton();assert.equal(h.shots.length,0);assert.equal(a.isSuspended(),true);h.wxe.emit('END');a.onButton();assert.equal(h.shots.length,1);});
test('defect_fixed:mute_repauses_engine_resumed_loop','fixed_check',()=>{const h=make(),a=h.G.ensure();a.loopSource.clip={};a.loopSource.play();h.game.emit('HIDE');a.setMuted(true);h.game.emit('SHOW');a.loopSource.playing=true;a.update();assert.equal(a.isMuted(),true);assert.equal(a.loopSource.playing,false);});
test('defect_fixed:manual_duplicate_component_rejected','fixed_check',()=>{const h=make(),a=h.G.ensure();h.ready(a);const b=h.spawn();assert.equal(h.wxe.count(),4);assert.equal(h.game.count(),2);assert.equal(h.G.instance,a);a.onButton();b.onButton();assert.equal(h.shots.length,1);assert.equal(h.G.ensure(),a);});
test('defect_fixed:setInnerAudioOption_fail_retries','fixed_check',()=>{const h=make({optionFail:true}),a=h.G.ensure();assert.equal(h.G.innerAudioOptionApplied,false);a.onDestroy();h.G.ensure();assert.equal(h.optsCalls.length,2);assert.equal(h.G.innerAudioOptionApplied,false);});
test('defect_fixed:setInnerAudioOption_throw_retries','fixed_check',()=>{const h=make({optionThrow:true}),a=h.G.ensure();assert.equal(h.G.innerAudioOptionApplied,false);a.onDestroy();h.G.ensure();assert.equal(h.optsCalls.length,2);assert.equal(h.G.innerAudioOptionApplied,false);});
`;
s = rep(s, "const out={method:", fixed + "const out={method:");
const tmp = path.join(path.dirname(out), '.run_review_tmp_' + process.pid + '.cjs');
fs.writeFileSync(tmp, s);
try { cp.execFileSync(process.execPath, ['--no-warnings', tmp], { stdio: ['ignore', 'ignore', 'inherit'] }); } catch (e) { /* 原脚本有 harness_failed 时 exitCode=1，结果仍已写出 */ }
finally { fs.unlinkSync(tmp); }
const r = JSON.parse(fs.readFileSync(out, 'utf8'));
// 判定：pass 用例 reproduced = 正常；limitation reproduced = 有意取舍；defect reproduced = 缺陷仍在，harness_failed = 缺陷序列不再复现；
// fixed_check reproduced = 修好后的行为成立。
const sum = { normal_ok: 0, normal_regressed: [], limitation_reproduced: 0, defect_still_reproduced: [], defect_not_reproduced: 0, fixed_check_ok: 0, fixed_check_failed: [] };
for (const x of r.results) {
  const okr = x.status === 'reproduced';
  if (x.kind === 'pass') okr ? sum.normal_ok++ : sum.normal_regressed.push(x.name);
  else if (x.kind === 'limitation') { if (okr) sum.limitation_reproduced++; }
  else if (x.kind === 'defect') okr ? sum.defect_still_reproduced.push(x.name) : sum.defect_not_reproduced++;
  else if (x.kind === 'fixed_check') okr ? sum.fixed_check_ok++ : sum.fixed_check_failed.push(x.name + ': ' + String(x.error).split('\n')[0]);
}
r.verdict = sum; r.harness = { reviewScriptSha256: origSha, reviewScriptCasesUnchanged: 21, replacedCases: [{ original: 'new_instance_old_load_result_ignored', replacement: 'new_instance_old_load_result_ignored__REPLACED_BY__old_node_destroyed_then_new_instance', reason: 'conflicts with fix #4 / defect manual_duplicate_component_is_not_prevented (Grok Bot option a)' }], addedFixedChecks: 6 };
fs.writeFileSync(out, JSON.stringify(r, null, 2));
console.log(JSON.stringify({ source: src, sourceSha256: srcSha, ...sum }, null, 2));
