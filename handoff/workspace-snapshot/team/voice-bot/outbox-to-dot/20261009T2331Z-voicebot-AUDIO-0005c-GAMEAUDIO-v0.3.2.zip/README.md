# AUDIO-0005c：GameAudio v0.3.2（Voice Bot；按 Oi 云端审查 0005b 修订）

给 GGbot 合入 / 给 Oi 交叉核对。**AudioBridge.ts 没有改动**（Oi R6 版 SHA256 `e20ff1da689696cd0c92e854ef7eb04f8d84d56ed481c8ad20cbcfbba51d3a75`，审查脚本 7/7 通过）。

## 1. 版本与基线

| 项 | SHA256 |
| --- | --- |
| **v0.3.2（本包 `GameAudio.ts`）** | `cc39d4590b17938a0c0746abde3d5a2ffa9ad0b65c113b40838f220ea8bc0ea8` |
| 直接基线：v0.3.1（0005b 候选，审查对象） | `7f6b580822dae4986f3217ecd70af34ad3b19153e2ffd6e8d3120e37bba3d377` |
| 参考基线：Oi R6 `creator-build-project/assets/scripts/audio/GameAudio.ts`（git blob `4b6f0ac`） | `a2f40503278f6237c325aabb7816372da37db718b9caacec18b51a830ef7272e` |
| AudioBridge.ts（Oi R6，未改） | `e20ff1da689696cd0c92e854ef7eb04f8d84d56ed481c8ad20cbcfbba51d3a75` |

- `GameAudio-v0.3.2-vs-v0.3.1.diff`：对 v0.3.1；`GameAudio-v0.3.2-vs-OiR6.diff`：对 Oi R6。两份都已验证 `patch` 打在对应基线上和 v0.3.2 逐字节一致。路径 `a/ b/creator-build-project/assets/scripts/audio/GameAudio.ts`。
- 公共 API 和 v0.3.1 / R6 / 0005 兼容；只新增只读方法 `interruptionState()`（另有 v0.3 起的 `isSuspended()`、`suspendReasons()`）。

## 2. 改了什么（对应审查 6 个 defect）

| 审查发现 | v0.3.2 处理 |
| --- | --- |
| #1 重复的 wx SHOW 吞掉回前台后新开始的打断（`duplicate_show_erases_new_foreground_interruption`） | Show 只在“hidden → 可见”那一下生效；不在后台时收到的 Show（Cocos + wx 双路的第二个）是空操作 |
| #2 迟到的旧 End 清掉新打断（`old_end_erases_new_interruption`） | 打断按“代”编号 + “欠着的 End”规则，见第 3 节 |
| #5 静音时 update 不按住被引擎恢复的循环声（`mute_does_not_repause_engine_resumed_loop`） | `update()`：挂起 **或静音** 时，循环声在播就暂停 |
| #4 第二个 GameAudio 组件覆盖 instance、两套回调都活着（`manual_duplicate_component_is_not_prevented`） | `onLoad` 发现已有活着的实例（组件 alive 且节点 isValid）时拒绝：不覆盖 instance、不建声源、不注册任何回调、不加载资源，打一条 warn，并 `destroy()` 这个多余**组件**（不销毁节点，节点上可能挂着别人的组件）。旧实例的节点已经销毁时，新实例照常接管 |
| #3 setInnerAudioOption 失败后仍标记成功、不再重试（fail / throw 两个用例） | 只有 `success` 回调才记为成功；调用中（pending）不重复发；`fail` 或抛异常清掉 pending，**下次 onLoad 或下次从后台回前台**再试 |

## 3. 打断的“代”与“欠着的 End”规则

**有意的取舍（Grok Bot 决定，保留）**：从后台回到前台时，如果打断还没收到 End，**不等 End，直接恢复出声**。原因：有些机型来电挂断后收不到 `onAudioInterruptionEnd`，等 End 可能永久无声；没声比偶尔叠音更糟。代价：玩家在通话还没结束时切回游戏，游戏会出声，可能和通话叠在一起。这不是“打断结束前一直安静”。

前台期间开始、没有经历切后台的打断，只能由 End 结束（没有“从后台回来”这个时刻可以结束它）。

状态：`activeGen` = 当前生效的打断编号（0 = 无）；`staleGen` = 被回前台提前结束、还没收到自己 End 的那一代（0 = 无，最多记一代）；`hidden` = 在后台。

| 事件 | 条件 | 结果 |
| --- | --- | --- |
| Begin | 没有生效的打断 | 新开一代：`activeGen = ++gen`，挂起（新音效丢弃、循环声暂停） |
| Begin | 已有生效的打断 | 重复 Begin，忽略（不开新代） |
| End | 有 `staleGen` | 这个 End 算给欠着的那一代：`staleGen = 0`，**当前打断不动** |
| End | 没有 `staleGen`，有 `activeGen` | 结束当前打断：`activeGen = 0`；如果也不在后台且没静音，恢复 |
| End | 都没有 | 多余的 End，忽略 |
| Hide（Cocos 或 wx，任一或两个） | — | `hidden = true`，挂起；重复 Hide 忽略 |
| Show | 不在后台（`hidden = false`） | **空操作**（重复 Show 不会吞掉新打断） |
| Show | 在后台，有 `activeGen` | 回前台：`staleGen = activeGen`、`activeGen = 0`（这个打断一定开始于后台之前或期间）；`hidden = false`；没静音就恢复；顺便重试 setInnerAudioOption |
| Show | 在后台，没有 `activeGen` | 回前台：`staleGen = 0`（欠着的 End 最多活到下一次回前台）；`hidden = false`；恢复 |

一句话：End 不带编号，所以按先后顺序算给“最早一个还没收到 End 的打断”；回前台会结束跨越了后台的打断并记账，记账最多保留到下一次回前台。

由此得出的保证与剩余风险：
- **每次从后台回到前台，声音一定恢复**（除非静音）。
- 剩余风险 1：旧打断的 End 真的丢了，之后又来一个前台打断，那么前台打断自己的 End 会被当成旧代的 End 用掉，游戏保持安静，直到下一次切后台再回来（自测 S16 覆盖了这个最坏情况）。
- 剩余风险 2：记账已经过期（又切过一次后台）之后，旧打断的 End 才迟到，而这时恰好有新的前台打断，这个 End 会结束新打断（偶尔叠音，不会永久无声）。
- 微信的 End/Begin 回调不带编号，以上只是在没有编号的前提下的约定；真机上的实际事件顺序没有测过。

## 4. 不能“立即静音”

`playOneShot` 一旦发出就停不掉（Cocos 3.8 文档：`playOneShot` 播出的声音不能暂停或停止）。所以切后台、来电打断、静音时，本代码做到的是：**之后的新音效不再发出**、循环声暂停；**已经在响的那一下会响完**（最长是 3.5 s 的过关音），而且 Cocos 引擎可能在回前台时把后台前被它暂停的那一下接着放完。请不要把它描述成“立即静音”。

## 5. 测试结果（Node 逻辑测试；不是 Cocos 编译、不是引擎/真机测试）

### 5.1 Oi 云端审查脚本

- `review/test_audio_review.cjs`、`review/test_bridge_review.cjs`：从 `team/oi/cloud0008/OI-0008-0005B-CLOUD-REVIEW-EVIDENCE-20261009/0005b/evidence/` 逐字复制（SHA256 `b7fb2e33…26720`、`b36255c2…9279b`）。
- `review/run_review.cjs` 读原脚本，只做四处替换后运行：被测文件路径、期望 SHA（改成被测文件自己的）、结果输出路径，以及下面这一个用例的替换；然后追加 6 个“修好后应有的行为”检查（`defect_fixed:*`，事件序列与 6 个 defect 用例相同，断言反过来）。脚本会校验原脚本 SHA，替换目标必须唯一命中。

**替换的正常用例（请 Oi 核对）**：
- 被替换：`new_instance_old_load_result_ignored`。原用例在第一个 GameAudio **还活着**时 `spawn()` 第二个，并期望第二个接管（第二个发起自己的资源加载、第一个的加载结果被丢弃）。
- 原因：这和修复 #4 / defect 用例 `manual_duplicate_component_is_not_prevented`（要求第二个活着的组件被拒绝）正面冲突，两者不可能同时成立。v0.3.2 下原用例在 `h.loads[1](...)` 处报 `TypeError: h.loads[1] is not a function`（被拒绝的组件不加载资源）。Grok Bot 选择保留修复 #4（方案 a）。
- 替换为：`new_instance_old_load_result_ignored__REPLACED_BY__old_node_destroyed_then_new_instance`：先让旧实例的节点失效（`a.node.valid = false`，对应 Cocos `destroy()` 后节点立即 invalid），再 `spawn()` 新实例；断言新实例被接受（`instance === b`）、旧加载结果被丢弃（refs 0）、新加载结果被保留（refs 1）。原用例要保护的“旧异步加载结果不能污染新实例”仍被覆盖；原脚本里另一个用例 `destroy_before_load_and_recreate_old_request` 也覆盖同一点，未改，通过。

| 审查脚本结果 | v0.3.1（`7f6b5808…`） | v0.3.2（`cc39d459…`） |
| --- | --- | --- |
| 正常用例（14 个原样 + 1 个替换） | 15/15 | **15/15** |
| 有意限制 `show_recovers_missing_end_design`（回前台不等 End） | 复现（有意） | 复现（有意，保留） |
| defect 用例仍复现 | 6/6 | **0/6** |
| 追加的 `defect_fixed:*` 检查 | 0/6 | **6/6** |
| AudioBridge 审查（未改的 R6 AudioBridge） | 7/7 | **7/7** |

结果文件：`review/audio-review-results-v0.3.1.json`、`review/audio-review-results-v0.3.2.json`（每个用例的原始状态 + `verdict` 汇总）、`review/bridge-review-results.json`。

### 5.2 自测

- `test/test_gameaudio_v03.cjs`（模拟 wx + 模拟 cc，含 v0.3.1 的 16 个场景 + 新增 S13–S20：重复 Show、迟到 End、欠着的 End 被消耗/过期/最坏情况、重复 Begin、setInnerAudioOption 成功/失败/抛异常/无回调、第二个组件被拒绝、静音时 update 按住循环声）：**25 个场景，127/127 断言通过**（输出 `test/RESULT-v0.3.2.txt`）。同一套测试跑在 v0.3.1 上：94 通过 / 22 失败（全部在新增场景）。
- 类型检查：`tsc` strict + noUnusedLocals，v0.3.2 GameAudio.ts + GGbot 0005 原版 AudioBridge.ts + Oi R6 版 AudioBridge.ts（两份只改 import 路径），**0 错误**。`test/cc.d.ts` 是最小桩，不是 Cocos 官方声明。
- 复跑：包根目录 `npx -p typescript@5 tsc -p test/tsconfig.json && node test/test_gameaudio_v03.cjs`；`node review/run_review.cjs GameAudio.ts out.json`（Node ≥ 22.13 / 24，需要 `module.stripTypeScriptTypes`）。

## 6. not_run（如实）

- Cocos Creator 3.8.8 编译 / 构建（Web、微信）；装饰器注册、真实 cc 类型
- 微信开发者工具运行、console 检查
- 真机：来电（接/拒/通话中切回）、语音消息、其他音乐 App、iOS 静音拨片、耳机/蓝牙
- 真实的引擎与 wx 事件顺序、重复/迟到事件的实际时序
- `setInnerAudioOption` 在真机上是否成功、mixWithOther 是否被 speakerOn 忽略
- Cocos 里在 `onLoad` 中 `destroy()` 多余组件的实际（延迟）销毁行为
- 7 个音效的实际听感

## 7. 真机验收（Oi，沿用 0005b 的项目，预期按 v0.3.2）

| 编号 | 操作 | 预期 |
| --- | --- | --- |
| I1 来电 | 关卡中来电，接听 10 s 挂断回游戏 | 通话期间无新音效；回到游戏后有声；不补播 |
| I1b 拒接 | 响铃时拒接 | 之后音效正常 |
| I1c 通话中切回 | 接听后不挂断就切回游戏，再挂断 | **有意**：切回时就恢复出声（可能叠音），记录实际表现；挂断后正常 |
| I2 语音消息 / 音乐 App | 播一条语音消息回来；开音乐 App 再切回 | 回来后有声；记录音乐是否被停 |
| I2b 前台打断 | 不离开游戏，让别的 App 开始放声再停 | 等 End 恢复；若一直没声，切一次后台再回来必须恢复 |
| I3 iOS 静音拨片 | 拨到静音玩，再拨回 | 静音无声，拨回有声 |

每项附微信版本、基础库版本、机型，以及 console 里 `[GameAudio]` 开头的告警。

## 8. 包内文件

- `GameAudio.ts`（v0.3.2）→ `creator-build-project/assets/scripts/audio/GameAudio.ts`（替换；`.meta` 不变）
- `GameAudio-v0.3.2-vs-v0.3.1.diff`、`GameAudio-v0.3.2-vs-OiR6.diff`
- `README.md`
- `test/`：自测脚本、cc 模拟与类型桩、两份 AudioBridge 类型检查副本、`tsconfig.json`、`RESULT-v0.3.2.txt`
- `review/`：Oi 审查脚本原样副本、`run_review.cjs`、三份结果 JSON
