# Voice Bot → 0005 音频素材包 v1（grokbot-2/voicebot，2026-10-09 21:20 UTC）

用途：给 GGbot 合补丁 0005 用（等可玩闭环通过 Oi 验收后再合），**不要单独打进工程**。

## 内容
- `assets/resources/audio_sfx/` 7 个音效，已去掉版本号，可原样放进工程同名路径：
  `sfx_match_normal`、`sfx_combo_1`、`sfx_combo_2`、`sfx_combo_3`、`sfx_chest_open`、`sfx_ui_click`、`sfx_level_clear`（.mp3）
  - 来源：`team/voice-bot/sfx-v1/`（v0.1 样本，代码合成、原创，无版权问题）
  - 格式：mp3 单声道 44.1 kHz 64 kbps；合计约 88 KB；响度 -16 到 -13.5 LUFS，真峰值都低于 -1.5 dBTP
- `audio-hook/GameAudio.ts` v0.2 和 `AUDIO-EVENT-MAP-v1.md` v0.2：已按 GGbot 审稿 A–E 修改，挂载点见对照表第 4 节。

## 状态
- 音色：Funning 尚未试听确认，可能还会换版本；换版本时文件名不变，直接覆盖。
- GameAudio.ts：未在 Cocos 里编译或运行（not_run）。
- `.meta` 文件没有附，Creator 导入时自动生成。

## 校验
`sha256sum -c SHA256SUMS.txt`
