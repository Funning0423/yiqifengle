// Generated from immutable metre-space GLB and sidecars. Do not hand-edit.
export const FIRSTSLICE = {
  "schema": 1,
  "units": "m",
  "up": "+Y",
  "outdoorForward": "+Z",
  "anchors": {
    "door_handle": {
      "path": "scene_root/env_lighthouse_door/door_handle",
      "position": [
        -0.43000006675720215,
        1.1287000179290771,
        -0.042399998754262924
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.43000006675720215,
        1.1287000179290771,
        -0.042399998754262924,
        1.0
      ],
      "properties": {
        "anchor": "door_handle",
        "open_864_position_m": [
          0.6057,
          1.1287,
          1.1453
        ],
        "ring_radius_m": 0.07,
        "note": "Interior brass ring grip point (door-hand-contact target, door closed) = CommonR2 door-interaction handleAtAngle(0).point. Child of the door leaf, so it follows the swing. v2.1: the ring mesh of env_lighthouse_door now passes exactly through this point (v2.0 ring centre was 0.163 m away).",
        "handle_source": "CommonR2 door-interaction handleAt",
        "v2_1_mesh_aligned": true,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets",
        "ring_centerline_radius_m": 0.07,
        "tube_radius_m": 0.012,
        "radius_semantics": "ring_radius_m is centreline radius, not tube or hand-contact radius",
        "metadata_correction": "dot isolated v0.1: replaces stale .016 after geometry measurement .07000136m midpoint / .012m half-depth; geometry unchanged"
      }
    },
    "collision_proxies": {
      "path": "scene_root/interaction_anchors/collision_proxies",
      "position": [
        0.0,
        0.0,
        0.0
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0
      ],
      "properties": {
        "anchor": "collision_proxies",
        "note": "All col_* collision meshes. Do not render (hide / disable MeshRenderer in engine). col_lighthouse_door_leaf is parented to the door leaf.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "door_hinge": {
      "path": "scene_root/interaction_anchors/door_hinge",
      "position": [
        0.7202200293540955,
        0.0,
        0.0
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.7202200293540955,
        0.0,
        0.0,
        1.0
      ],
      "properties": {
        "anchor": "door_hinge",
        "axis": "+Y",
        "open_angle_deg": 86.4,
        "max_angle_deg": 105.0,
        "swing": "outward (+Z)",
        "width_m": 1.4404,
        "height_m": 2.4023,
        "note": "Hinge axis of env_lighthouse_door (+X edge of the 1.44 m opening). Rotate the door about +Y through this point.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "door_stand_point": {
      "path": "scene_root/interaction_anchors/door_stand_point",
      "position": [
        -0.21199999749660492,
        0.0,
        -0.3321000039577484
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.21199999749660492,
        0.0,
        -0.3321000039577484,
        1.0
      ],
      "properties": {
        "anchor": "door_stand_point",
        "note": "where the girl stops to reach for the ring (door-interaction standWorld)",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "entrance_point": {
      "path": "scene_root/interaction_anchors/entrance_point",
      "position": [
        -0.21809999644756317,
        0.0,
        -0.36739999055862427
      ],
      "matrix": [
        -1.0,
        0.0,
        8.742277657347586e-08,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        -8.742277657347586e-08,
        0.0,
        -1.0,
        0.0,
        -0.21809999644756317,
        0.0,
        -0.36739999055862427,
        1.0
      ],
      "properties": {
        "anchor": "entrance_point",
        "note": "First root inside the threshold on return (continuous-return-motion insideRoot); facing into the room.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_00": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_00",
      "position": [
        0.6074000000953674,
        0.0,
        -3.8232998847961426
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.6074000000953674,
        0.0,
        -3.8232998847961426,
        1.0
      ],
      "properties": {
        "t_s": 0,
        "index": 0,
        "door_angle_deg": 0,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_01": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_01",
      "position": [
        0.4848000109195709,
        0.0,
        -3.9140000343322754
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.4848000109195709,
        0.0,
        -3.9140000343322754,
        1.0
      ],
      "properties": {
        "t_s": 1,
        "index": 1,
        "door_angle_deg": 0,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_02": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_02",
      "position": [
        0.3767000138759613,
        0.0,
        -3.1208999156951904
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.3767000138759613,
        0.0,
        -3.1208999156951904,
        1.0
      ],
      "properties": {
        "t_s": 2,
        "index": 2,
        "door_angle_deg": 0,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_03": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_03",
      "position": [
        0.22949999570846558,
        0.0,
        -2.0004000663757324
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.22949999570846558,
        0.0,
        -2.0004000663757324,
        1.0
      ],
      "properties": {
        "t_s": 3,
        "index": 3,
        "door_angle_deg": 0,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_04": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_04",
      "position": [
        -0.06529998779296875,
        0.0,
        -0.7730000019073486
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.06529998779296875,
        0.0,
        -0.7730000019073486,
        1.0
      ],
      "properties": {
        "t_s": 4,
        "index": 4,
        "door_angle_deg": 0,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_05": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_05",
      "position": [
        -0.2120000123977661,
        0.0,
        -0.1466999053955078
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.2120000123977661,
        0.0,
        -0.1466999053955078,
        1.0
      ],
      "properties": {
        "t_s": 5,
        "index": 5,
        "door_angle_deg": 12.78,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_06": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_06",
      "position": [
        -0.048200011253356934,
        0.0,
        0.6891999244689941
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.048200011253356934,
        0.0,
        0.6891999244689941,
        1.0
      ],
      "properties": {
        "t_s": 6,
        "index": 6,
        "door_angle_deg": 86.4,
        "ground": "env_lighthouse_ext",
        "ground_y_m": 0.012,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_07": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_07",
      "position": [
        -0.43759995698928833,
        0.0,
        1.5469002723693848
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.43759995698928833,
        0.0,
        1.5469002723693848,
        1.0
      ],
      "properties": {
        "t_s": 7,
        "index": 7,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_08": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_08",
      "position": [
        -0.8784000277519226,
        0.0,
        2.118000030517578
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.8784000277519226,
        0.0,
        2.118000030517578,
        1.0
      ],
      "properties": {
        "t_s": 8,
        "index": 8,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_09": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_09",
      "position": [
        -1.147700011730194,
        0.0,
        2.434500217437744
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.147700011730194,
        0.0,
        2.434500217437744,
        1.0
      ],
      "properties": {
        "t_s": 9,
        "index": 9,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_10": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_10",
      "position": [
        -1.417400062084198,
        0.0,
        2.7506003379821777
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.417400062084198,
        0.0,
        2.7506003379821777,
        1.0
      ],
      "properties": {
        "t_s": 10,
        "index": 10,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_11": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_11",
      "position": [
        -1.6792001128196716,
        0.0,
        3.0731000900268555
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.6792001128196716,
        0.0,
        3.0731000900268555,
        1.0
      ],
      "properties": {
        "t_s": 11,
        "index": 11,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_12": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_12",
      "position": [
        -1.9228999018669128,
        0.0,
        3.4094996452331543
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.9228999018669128,
        0.0,
        3.4094996452331543,
        1.0
      ],
      "properties": {
        "t_s": 12,
        "index": 12,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_13": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_13",
      "position": [
        -2.1326999068260193,
        0.0,
        3.7677998542785645
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.1326999068260193,
        0.0,
        3.7677998542785645,
        1.0
      ],
      "properties": {
        "t_s": 13,
        "index": 13,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_14": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_14",
      "position": [
        -2.2829999327659607,
        0.0,
        4.154399871826172
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.2829999327659607,
        0.0,
        4.154399871826172,
        1.0
      ],
      "properties": {
        "t_s": 14,
        "index": 14,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_15": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_15",
      "position": [
        -2.336199939250946,
        0.0,
        4.565100193023682
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.336199939250946,
        0.0,
        4.565100193023682,
        1.0
      ],
      "properties": {
        "t_s": 15,
        "index": 15,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_16": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_16",
      "position": [
        -2.2627000212669373,
        0.0,
        4.9721999168396
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.2627000212669373,
        0.0,
        4.9721999168396,
        1.0
      ],
      "properties": {
        "t_s": 16,
        "index": 16,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path_17": {
      "path": "scene_root/interaction_anchors/exit_path/exit_path_17",
      "position": [
        -2.1135000586509705,
        0.0,
        5.281400203704834
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.1135000586509705,
        0.0,
        5.281400203704834,
        1.0
      ],
      "properties": {
        "t_s": 17,
        "index": 17,
        "door_angle_deg": 86.4,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_path": {
      "path": "scene_root/interaction_anchors/exit_path",
      "position": [
        0.6074000000953674,
        0.0,
        -3.8232998847961426
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.6074000000953674,
        0.0,
        -3.8232998847961426,
        1.0
      ],
      "properties": {
        "anchor": "exit_path",
        "note": "Outbound route chair -> door -> island (door-interaction positionAt, 1 s samples)",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "exit_point": {
      "path": "scene_root/interaction_anchors/exit_point",
      "position": [
        -0.21199999749660492,
        0.0,
        0.1412999927997589
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.21199999749660492,
        0.0,
        0.1412999927997589,
        1.0
      ],
      "properties": {
        "anchor": "exit_point",
        "note": "Root just outside the threshold where the door is released on the way out (door-interaction releaseWorld).",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "interior_spawn": {
      "path": "scene_root/interaction_anchors/interior_spawn",
      "position": [
        0.6074000000953674,
        0.0,
        -3.8232998847961426
      ],
      "matrix": [
        -0.4161469429061029,
        0.0,
        0.9092975120454767,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        -0.9092975120454767,
        0.0,
        -0.4161469429061029,
        0.0,
        0.6074000000953674,
        0.0,
        -3.8232998847961426,
        1.0
      ],
      "properties": {
        "anchor": "interior_spawn",
        "state": "seated_reading",
        "note": "Start of the outbound route (girl seated in the reading chair, root on the floor). Seat via seat_anchor.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_00": {
      "path": "scene_root/interaction_anchors/return_path/return_path_00",
      "position": [
        -2.1119000911712646,
        0.0,
        5.283899784088135
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.1119000911712646,
        0.0,
        5.283899784088135,
        1.0
      ],
      "properties": {
        "t_s": 0,
        "index": 0,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 0.5554,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_01": {
      "path": "scene_root/interaction_anchors/return_path/return_path_01",
      "position": [
        -2.333899974822998,
        0.0,
        4.6209001541137695
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.333899974822998,
        0.0,
        4.6209001541137695,
        1.0
      ],
      "properties": {
        "t_s": 1,
        "index": 1,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 3.6893,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_02": {
      "path": "scene_root/interaction_anchors/return_path/return_path_02",
      "position": [
        -2.207200050354004,
        0.0,
        3.9319000244140625
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.207200050354004,
        0.0,
        3.9319000244140625,
        1.0
      ],
      "properties": {
        "t_s": 2,
        "index": 2,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 3.0688,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_03": {
      "path": "scene_root/interaction_anchors/return_path/return_path_03",
      "position": [
        -1.8603999614715576,
        0.0,
        3.318000078201294
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.8603999614715576,
        0.0,
        3.318000078201294,
        1.0
      ],
      "properties": {
        "t_s": 3,
        "index": 3,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 2.5676,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_04": {
      "path": "scene_root/interaction_anchors/return_path/return_path_04",
      "position": [
        -1.4259999990463257,
        0.0,
        2.760999917984009
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -1.4259999990463257,
        0.0,
        2.760999917984009,
        1.0
      ],
      "properties": {
        "t_s": 4,
        "index": 4,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 2.4349,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_05": {
      "path": "scene_root/interaction_anchors/return_path/return_path_05",
      "position": [
        -0.9672999382019043,
        0.0,
        2.223599910736084
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.9672999382019043,
        0.0,
        2.223599910736084,
        1.0
      ],
      "properties": {
        "t_s": 5,
        "index": 5,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 2.4876,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_06": {
      "path": "scene_root/interaction_anchors/return_path/return_path_06",
      "position": [
        -0.5262000560760498,
        0.0,
        1.671800136566162
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.5262000560760498,
        0.0,
        1.671800136566162,
        1.0
      ],
      "properties": {
        "t_s": 6,
        "index": 6,
        "door_angle_deg": 86.4,
        "source_yaw_rad": 1.7118,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_07": {
      "path": "scene_root/interaction_anchors/return_path/return_path_07",
      "position": [
        -0.15810000896453857,
        0.0,
        1.0699000358581543
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.15810000896453857,
        0.0,
        1.0699000358581543,
        1.0
      ],
      "properties": {
        "t_s": 7,
        "index": 7,
        "door_angle_deg": 84.43,
        "source_yaw_rad": 1.4735,
        "ground": "env_island_main",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_08": {
      "path": "scene_root/interaction_anchors/return_path/return_path_08",
      "position": [
        -0.1444000005722046,
        0.0,
        0.4008002281188965
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.1444000005722046,
        0.0,
        0.4008002281188965,
        1.0
      ],
      "properties": {
        "t_s": 8,
        "index": 8,
        "door_angle_deg": 49.37,
        "source_yaw_rad": 0.8617,
        "ground": "env_lighthouse_ext",
        "ground_y_m": -0.004,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_09": {
      "path": "scene_root/interaction_anchors/return_path/return_path_09",
      "position": [
        -0.2120000123977661,
        0.0,
        -0.2950000762939453
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.2120000123977661,
        0.0,
        -0.2950000762939453,
        1.0
      ],
      "properties": {
        "t_s": 9,
        "index": 9,
        "door_angle_deg": 14.11,
        "source_yaw_rad": 0.2462,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_10": {
      "path": "scene_root/interaction_anchors/return_path/return_path_10",
      "position": [
        0.006200075149536133,
        0.0,
        -0.9647998809814453
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.006200075149536133,
        0.0,
        -0.9647998809814453,
        1.0
      ],
      "properties": {
        "t_s": 10,
        "index": 10,
        "door_angle_deg": 0,
        "source_yaw_rad": 0.0885,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_11": {
      "path": "scene_root/interaction_anchors/return_path/return_path_11",
      "position": [
        0.174299955368042,
        0.0,
        -1.6487998962402344
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.174299955368042,
        0.0,
        -1.6487998962402344,
        1.0
      ],
      "properties": {
        "t_s": 11,
        "index": 11,
        "door_angle_deg": 0,
        "source_yaw_rad": 3.1009,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_12": {
      "path": "scene_root/interaction_anchors/return_path/return_path_12",
      "position": [
        0.1278998851776123,
        0.0,
        -2.3522000312805176
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.1278998851776123,
        0.0,
        -2.3522000312805176,
        1.0
      ],
      "properties": {
        "t_s": 12,
        "index": 12,
        "door_angle_deg": 0,
        "source_yaw_rad": 3.1009,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_13": {
      "path": "scene_root/interaction_anchors/return_path/return_path_13",
      "position": [
        -0.0039000511169433594,
        0.0,
        -3.0463004112243652
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.0039000511169433594,
        0.0,
        -3.0463004112243652,
        1.0
      ],
      "properties": {
        "t_s": 13,
        "index": 13,
        "door_angle_deg": 0,
        "source_yaw_rad": 3.1009,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_14": {
      "path": "scene_root/interaction_anchors/return_path/return_path_14",
      "position": [
        -0.0764000415802002,
        0.0,
        -3.7472996711730957
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.0764000415802002,
        0.0,
        -3.7472996711730957,
        1.0
      ],
      "properties": {
        "t_s": 14,
        "index": 14,
        "door_angle_deg": 0,
        "source_yaw_rad": 3.1009,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path_15": {
      "path": "scene_root/interaction_anchors/return_path/return_path_15",
      "position": [
        -0.056099891662597656,
        0.0,
        -4.349799633026123
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.056099891662597656,
        0.0,
        -4.349799633026123,
        1.0
      ],
      "properties": {
        "t_s": 15,
        "index": 15,
        "door_angle_deg": 0,
        "source_yaw_rad": 3.1009,
        "ground": "env_interior_shell",
        "ground_y_m": 0.0,
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "return_path": {
      "path": "scene_root/interaction_anchors/return_path",
      "position": [
        -2.1119000911712646,
        0.0,
        5.283899784088135
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -2.1119000911712646,
        0.0,
        5.283899784088135,
        1.0
      ],
      "properties": {
        "anchor": "return_path",
        "note": "Return route island -> door -> chair (continuous-return-motion positionAt, 1 s samples); ends at the seat turn",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "seat_anchor": {
      "path": "scene_root/interaction_anchors/seat_anchor",
      "position": [
        0.4203000068664551,
        0.3799999952316284,
        -4.2133002281188965
      ],
      "matrix": [
        -0.4161469429061029,
        0.0,
        0.9092975120454767,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        -0.9092975120454767,
        0.0,
        -0.4161469429061029,
        0.0,
        0.4203000068664551,
        0.3799999952316284,
        -4.2133002281188965,
        1.0
      ],
      "properties": {
        "anchor": "seat",
        "seat_top_y_m": 0.38,
        "yaw_rad": -2,
        "chair_spec": "{\"width_m\": 0.4946, \"depth_m\": 0.3815, \"thickness_m\": 0.0389, \"back_height_m\": 0.862}",
        "note": "Seat top centre of env_int_prop_reading_chair (= reading-chair.js registration, shiftX applied). Local +Z = chair front. Interface for sit/stand animation - geometry fixed to source.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "seated_foot_anchor": {
      "path": "scene_root/interaction_anchors/seated_foot_anchor",
      "position": [
        0.4943999946117401,
        0.0,
        -3.8232998847961426
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.4943999946117401,
        0.0,
        -3.8232998847961426,
        1.0
      ],
      "properties": {
        "anchor": "seated_foot",
        "note": "registered seated foot (shiftX applied)",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "stand_up_foot_anchor": {
      "path": "scene_root/interaction_anchors/stand_up_foot_anchor",
      "position": [
        -0.15199999511241913,
        0.0,
        -4.260300159454346
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        -0.15199999511241913,
        0.0,
        -4.260300159454346,
        1.0
      ],
      "properties": {
        "anchor": "stand_up_foot",
        "note": "continuous-seat-stand standingFoot (after rising); turnStartFoot=[-0.0561, 0, -4.3498]",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "walkable_area": {
      "path": "scene_root/interaction_anchors/walkable_area",
      "position": [
        0.0,
        0.0,
        0.0
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0
      ],
      "properties": {
        "anchor": "walkable_area",
        "walkable_nodes": "col_int_floor_walkable, col_int_stairs",
        "note": "Navmesh source: child col_int_floor_walkable (floor outline + threshold to z=+0.12 minus furniture footprints). col_int_stairs is also walkable.",
        "source_license": "Original work created by Grok Bot for \u54a6\uff0c\u8d77\u98ce\u4e86; no third-party assets"
      }
    },
    "seat_back": {
      "path": "scene_root/interaction_anchors/seat_back",
      "position": [
        0.641957284186555,
        0.862018779342723,
        -4.111857084254849
      ],
      "matrix": [
        -0.4161469429061029,
        0.0,
        0.9092975120454767,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        -0.9092975120454767,
        0.0,
        -0.4161469429061029,
        0.0,
        0.641957284186555,
        0.862018779342723,
        -4.111857084254849,
        1.0
      ],
      "properties": {
        "anchor": "seat_back",
        "semantic": "upper_back_rail_centerline_reference",
        "source_geometry": "env_int_prop_reading_chair source top-rail centreline",
        "chair_local_position_m": [
          0.0,
          0.862018779342723,
          -0.24376760563380284
        ],
        "body_contact_validated": false,
        "collision_proxy": "col_int_chair_back",
        "note": "Distinct empty reference node. Collider is not renamed or used as implicit anchor. Geometry, seat height and proportions unchanged."
      }
    },
    "scene_root": {
      "path": "scene_root",
      "position": [
        0.0,
        0.0,
        0.0
      ],
      "matrix": [
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.0
      ],
      "properties": {
        "unit": "metre",
        "candidate_version": "dot-firstslice-v0.1",
        "root_mapping": "All unskinned roots parented here; skinned mesh roots remain siblings as in original validated source. Keep this node identity.",
        "source_package": "GROKBOT-ART-001-ISLAND-EXTERIOR-v2.1.0",
        "character_height_calibrated": false
      }
    }
  },
  "renderers": [
    {
      "path": "scene_root/env_island_main",
      "name": "env_island_main",
      "layer": "exterior"
    },
    {
      "path": "scene_root/env_lighthouse_ext",
      "name": "env_lighthouse_ext",
      "layer": "exterior"
    },
    {
      "path": "scene_root/env_lighthouse_door",
      "name": "env_lighthouse_door",
      "layer": "door"
    },
    {
      "path": "scene_root/env_sea_surface",
      "name": "env_sea_surface",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_sea_foam",
      "name": "env_sea_foam",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_sky_dome",
      "name": "env_sky_dome",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_island_props_merged",
      "name": "env_island_props_merged",
      "layer": "exterior"
    },
    {
      "path": "scene_root/env_cloud_layer",
      "name": "env_cloud_layer",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_interior_shell",
      "name": "env_interior_shell",
      "layer": "interior"
    },
    {
      "path": "scene_root/env_interior_glass",
      "name": "env_interior_glass",
      "layer": "interior"
    },
    {
      "path": "scene_root/env_interior_props_merged",
      "name": "env_interior_props_merged",
      "layer": "interior"
    },
    {
      "path": "env_int_anim_cat",
      "name": "env_int_anim_cat",
      "layer": "interior"
    },
    {
      "path": "env_int_anim_hanging_plants",
      "name": "env_int_anim_hanging_plants",
      "layer": "interior"
    },
    {
      "path": "env_int_anim_window_breeze",
      "name": "env_int_anim_window_breeze",
      "layer": "interior"
    },
    {
      "path": "env_int_anim_small_props",
      "name": "env_int_anim_small_props",
      "layer": "interior"
    },
    {
      "path": "env_int_anim_ship_mobile",
      "name": "env_int_anim_ship_mobile",
      "layer": "interior"
    },
    {
      "path": "scene_root/env_window_blind_cards",
      "name": "env_window_blind_cards",
      "layer": "interior"
    },
    {
      "path": "env_prop_palm_tall_01",
      "name": "env_prop_palm_tall_01",
      "layer": "exterior"
    },
    {
      "path": "env_prop_palm_lean_01",
      "name": "env_prop_palm_lean_01",
      "layer": "exterior"
    },
    {
      "path": "env_prop_palm_young_01",
      "name": "env_prop_palm_young_01",
      "layer": "exterior"
    },
    {
      "path": "env_anim_seagull_01",
      "name": "env_anim_seagull_01",
      "layer": "exterior"
    },
    {
      "path": "env_anim_crab_01",
      "name": "env_anim_crab_01",
      "layer": "exterior"
    },
    {
      "path": "env_anim_cat_tuxedo_01",
      "name": "env_anim_cat_tuxedo_01",
      "layer": "exterior"
    },
    {
      "path": "env_anim_turtle_01",
      "name": "env_anim_turtle_01",
      "layer": "exterior"
    },
    {
      "path": "scene_root/env_rear_window_detail",
      "name": "env_rear_window_detail",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_rear_window_glass",
      "name": "env_rear_window_glass",
      "layer": "backdrop"
    },
    {
      "path": "scene_root/env_rear_window_plant",
      "name": "env_rear_window_plant",
      "layer": "backdrop"
    },
    {
      "path": "env_rear_window_palm",
      "name": "env_rear_window_palm",
      "layer": "backdrop"
    }
  ],
  "door": {
    "path": "scene_root/env_lighthouse_door",
    "hinge": [
      0.7202203273773193,
      0.0,
      0.0
    ],
    "bounds": [
      [
        -1.4404406547546387,
        0.0
      ],
      [
        0.0,
        2.4023473262786865
      ],
      [
        -0.005699999630451202,
        0.08500000089406967
      ]
    ],
    "openDeg": 86.4,
    "maxDeg": 105
  },
  "source": {
    "combined_visual_m.glb": "77bff8b3cb33c92a43cb02a4ad00f0f8e65f07e07052b9c870bea171194a9748",
    "combined_anchors_m.json": "e3b2684e6e7009ced805d2925b5cedef52cbd4213d3c46e7a41fa788467275cb",
    "combined_collision_proxies.json": "c5e2b578e4bd0bf5408178f7613f864c54cab103be9e04c9667944ff8ceceff2"
  }
} as const;
