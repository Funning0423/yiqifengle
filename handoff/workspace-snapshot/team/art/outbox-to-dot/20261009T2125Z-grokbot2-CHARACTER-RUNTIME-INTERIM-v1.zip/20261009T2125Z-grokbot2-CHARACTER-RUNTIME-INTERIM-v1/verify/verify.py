import bpy,sys,json,numpy as np
a=sys.argv[sys.argv.index("--")+1:]
def load(p):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=p)
    sc=bpy.context.scene
    arm=[o for o in bpy.data.objects if o.type=='ARMATURE'][0]
    meshes=sorted([o for o in bpy.data.objects if o.type=='MESH' and o.name!='Icosphere'],key=lambda o:o.name)
    res={}
    root=bpy.data.objects['B_SINGLE_WORLD_ROOT_SOURCE_K']
    info={'root_scale':list(root.scale),'objects':sorted((o.name,o.type,[c.name for c in o.users_collection][0]) for o in bpy.data.objects),
          'bones':len(arm.data.bones),'actions':sorted(x.name for x in bpy.data.actions)}
    for act in ['idle_breathing_loop','wind_sway_loop']:
        arm.animation_data.action=bpy.data.actions[act]
        for f in [1,31,61,91,121]:
            sc.frame_set(f); dg=bpy.context.evaluated_depsgraph_get()
            P=[]
            for o in meshes:
                e=o.evaluated_get(dg); m=np.array(o.matrix_world)
                co=np.array([v.co[:] for v in e.data.vertices]); P.append(co@m[:3,:3].T+m[:3,3])
            res[(act,f)]=np.concatenate(P)
    arm.animation_data.action=None
    for pb in arm.pose.bones: pb.matrix_basis.identity()
    sc.frame_set(1); dg=bpy.context.evaluated_depsgraph_get()
    P=np.concatenate([np.array([ (o.matrix_world@v.co)[:] for v in o.evaluated_get(dg).data.vertices]) for o in meshes])
    info['rest_bbox_min']=P.min(0).round(4).tolist(); info['rest_bbox_max']=P.max(0).round(4).tolist()
    info['rest_height']=round(float(P[:,2].max()-P[:,2].min()),4)
    ap=[o for o in meshes if 'APRON' in o.name][0]
    info['apron_mean_y']=round(float(np.mean([(ap.matrix_world@v.co).y for v in ap.data.vertices])),4)
    return res,info
A,ia=load(a[0]); B,ib=load(a[1])
d=max(float(np.abs(A[k]-B[k]).max()) for k in A)
print("RESULT",json.dumps({'orig':ia,'interim':ib,'max_world_vertex_diff_m_over_10_frames':d}))
