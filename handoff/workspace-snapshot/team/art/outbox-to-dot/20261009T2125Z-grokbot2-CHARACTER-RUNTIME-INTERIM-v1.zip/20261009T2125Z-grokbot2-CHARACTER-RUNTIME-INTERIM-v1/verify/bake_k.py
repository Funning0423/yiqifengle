import json,struct,sys,numpy as np
src,dst=sys.argv[1],sys.argv[2]
b=open(src,'rb').read()
L=struct.unpack('<I',b[12:16])[0]; j=json.loads(b[20:20+L])
o=20+L; BL,BT=struct.unpack('<II',b[o:o+8]); assert BT==0x004E4942
bin_=bytearray(b[o+8:o+8+BL])
root=[n for n in j['nodes'] if n.get('name')=='B_SINGLE_WORLD_ROOT_SOURCE_K'][0]
K=root['scale'][0]; assert root['scale']==[K,K,K] and 'rotation' not in root and 'translation' not in root
assert all('targets' not in p for m in j['meshes'] for p in m['primitives'])
NC={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}
def view(ai):
    a=j['accessors'][ai]; assert a['componentType']==5126 and not a.get('sparse')
    bv=j['bufferViews'][a['bufferView']]; n=NC[a['type']]
    assert bv.get('byteStride',n*4)==n*4
    off=bv.get('byteOffset',0)+a.get('byteOffset',0)
    arr=np.frombuffer(bin_,dtype='<f4',count=a['count']*n,offset=off).reshape(a['count'],n).copy()
    return a,arr,off
def write(off,arr): bin_[off:off+arr.nbytes]=arr.astype('<f4').tobytes()
done=set()
pos=set(p['attributes']['POSITION'] for m in j['meshes'] for p in m['primitives'])
for ai in pos:
    a,arr,off=view(ai); arr*=K; write(off,arr)
    a['min']=arr.min(0).tolist(); a['max']=arr.max(0).tolist()
for s in j['skins']:
    a,arr,off=view(s['inverseBindMatrices'])
    m=arr.reshape(-1,4,4)  # column-major: elements 12,13,14 are translation
    arr[:,12:15]*=K; write(off,arr)
tr=set(ch_s for an in j['animations'] for ch in an['channels'] if ch['target']['path']=='translation' for ch_s in [an['samplers'][ch['sampler']]['output']])
for ai in tr:
    a,arr,off=view(ai); arr*=K; write(off,arr)
    if 'min' in a: a['min']=arr.min(0).tolist(); a['max']=arr.max(0).tolist()
for n in j['nodes']:
    if n is root: continue
    if 'translation' in n: n['translation']=[t*K for t in n['translation']]
del root['scale']
root.setdefault('extras',{})['grokbot2_interim']=f"root scale K={K} baked into vertices/IBM/node+anim translations (world-space identical); root scale now 1. INTERIM runtime package, to be replaced by pass2b."
js=json.dumps(j,separators=(',',':')).encode(); js+=b' '*((4-len(js)%4)%4)
out=bytearray(); out+=struct.pack('<III',0x46546C67,2,0)
out+=struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(bin_),0x004E4942)+bin_
struct.pack_into('<I',out,8,len(out)); open(dst,'wb').write(out)
print("K",K,"pos",len(pos),"trans_acc",len(tr),"bytes",len(out))
