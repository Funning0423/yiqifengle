import bpy,sys
p=sys.argv[sys.argv.index("--")+1]
bpy.ops.wm.read_factory_settings(use_empty=True)
print("BEFORE",[o.name for o in bpy.data.objects])
bpy.ops.import_scene.gltf(filepath=p)
for o in bpy.data.objects:
    print("OBJ",o.name,o.type,"collections=",[c.name for c in o.users_collection],"users=",o.users, "verts=",len(o.data.vertices) if o.type=='MESH' else '')
arm=[o for o in bpy.data.objects if o.type=='ARMATURE'][0]
print("custom_shapes",{pb.custom_shape.name if pb.custom_shape else None for pb in arm.pose.bones})
