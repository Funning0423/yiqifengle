import bpy, json, sys, math, os
from mathutils import Vector
args=json.loads(sys.argv[sys.argv.index('--')+1])
s=bpy.context.scene
eng=args.get('engine','CYCLES')
s.render.engine='BLENDER_EEVEE' if eng=='EEVEE' else 'CYCLES'
if eng!='EEVEE':
    s.cycles.device='CPU'; s.cycles.samples=args.get('samples',24); s.cycles.use_denoising=True
    s.cycles.max_bounces=4
W,H=args['res']; s.render.resolution_x=W; s.render.resolution_y=H; s.render.resolution_percentage=100
s.render.film_transparent=False
# camera
cd=bpy.data.cameras.new('QA'); cam=bpy.data.objects.new('QA_CAM',cd); s.collection.objects.link(cam)
cd.sensor_fit='VERTICAL'; cd.sensor_height=24.0
cd.lens=12.0/math.tan(math.radians(args['fov'])/2); cd.clip_start=0.05; cd.clip_end=1000
p=Vector(args['pos']); t=Vector(args['target']); cam.location=p
d=(t-p).normalized(); cam.rotation_mode='QUATERNION'; cam.rotation_quaternion=d.to_track_quat('-Z','Y')
s.camera=cam
grass=[o for o in bpy.data.objects if o.parent and o.parent.name=='meadow_grass_instances']
flow=[o for o in bpy.data.objects if o.parent and o.parent.name=='meadow_flower_instances']
gk=args.get('grass_keep')  # None=all, list of names or 'off'
if args.get('grass')=='off':
    for o in grass: o.hide_render=True
elif isinstance(args.get('grass'),list):
    keep=set(args['grass'])
    for o in grass: o.hide_render=o.name not in keep
if isinstance(args.get('flowers'),list):
    keep=set(args['flowers'])
    for o in flow: o.hide_render=o.name not in keep
if args.get('ground'):
    img=bpy.data.images.load(args['ground'])
    m=bpy.data.materials['M_meadow_terrain']; m.node_tree.nodes['ground'].image=img
s.render.filepath=args['out']; s.render.image_settings.file_format='PNG'
bpy.ops.render.render(write_still=True)
print("DONE",args['out'])
