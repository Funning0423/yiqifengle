import bpy, numpy as np
o=bpy.data.objects['meadow_terrain']; me=o.data
print(o.matrix_world)
uv=me.uv_layers['UVMap'].data
err=0;n=0
for l in me.loops:
    v=me.vertices[l.vertex_index].co; u=uv[l.index].uv
    eu=abs(u[0]-(v.x+80)/160); ev=abs(u[1]-(v.y+80)/160); err=max(err,eu,ev); n+=1
print("terrain uv maxerr",err,n)
xs=[v.co.x for v in me.vertices]; ys=[v.co.y for v in me.vertices]; zs=[v.co.z for v in me.vertices]
print("bounds",min(xs),max(xs),min(ys),max(ys),min(zs),max(zs))
o=bpy.data.objects['meadow_path']; me=o.data
print("path verts sample",[tuple(round(c,2) for c in v.co) for v in me.vertices[:12]])
o=bpy.data.objects['meadow_river_bank']; me=o.data; uv=me.uv_layers['UVMap'].data
err=0
for l in me.loops:
    v=me.vertices[l.vertex_index].co; u=uv[l.index].uv
    err=max(err,abs(u[0]-(v.x+80)/160),abs(u[1]-(v.y+80)/160))
print("bank uv maxerr",err)
m=bpy.data.materials['M_meadow_terrain']
for nd in m.node_tree.nodes: print(" node",nd.type,nd.name,getattr(nd,'image',None))
s=bpy.context.scene; print("world",s.world.name if s.world else None, "view",s.view_settings.view_transform,s.view_settings.look)
sun=bpy.data.objects['sun']; print("sun",sun.rotation_euler[:],sun.data.energy,sun.data.color[:])
