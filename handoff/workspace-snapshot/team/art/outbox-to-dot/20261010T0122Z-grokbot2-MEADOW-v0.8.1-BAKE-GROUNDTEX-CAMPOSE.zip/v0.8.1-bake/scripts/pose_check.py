import bpy, json, math, sys
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
a=json.loads(sys.argv[sys.argv.index('--')+1])
s=bpy.context.scene; dg=bpy.context.evaluated_depsgraph_get()
p=Vector(a['pos']); t0=Vector(a['aim']); d=(t0-p).normalized()
ter=bpy.data.objects['meadow_terrain']
hit,loc,nrm,idx,obj,mat=s.ray_cast(dg,p,d)
print("HIT",obj.name if obj else None,tuple(round(c,4) for c in loc))
cd=bpy.data.cameras.new('Q'); cam=bpy.data.objects.new('Q',cd); s.collection.objects.link(cam)
cd.sensor_fit='VERTICAL'; cd.sensor_height=24; cd.lens=12/math.tan(math.radians(a['fov'])/2)
cam.location=p; cam.rotation_mode='QUATERNION'; cam.rotation_quaternion=d.to_track_quat('-Z','Y')
bpy.context.view_layer.update()
O=bpy.data.objects
pts={'player_spawn':O['player_spawn'].matrix_world.translation,'windmill_door_point':O['windmill_door_point'].matrix_world.translation,
 'region_interaction_point':O['region_interaction_point'].matrix_world.translation,'bell_01':O['bell_01'].matrix_world.translation,
 'windmill_sail_hub':O['windmill_sail_hub'].matrix_world.translation,'walk_path_05':O['walk_path_05'].matrix_world.translation,'walk_path_12':O['walk_path_12'].matrix_world.translation}
sails=O['windmill_sails']; sv=[sails.matrix_world@v.co for v in sails.data.vertices]
wm=O['windmill_static_merged']; wv=[wm.matrix_world@v.co for v in wm.data.vertices]
pv=[O['meadow_path'].matrix_world@v.co for v in O['meadow_path'].data.vertices]
hub=O['windmill_sail_hub'].matrix_world
hubp=hub.translation; R=max((v-hubp).length for v in sv)
ax=(hub.to_3x3()@Vector((0,1,0))).normalized(); e1=ax.cross(Vector((0,0,1))).normalized(); e2=ax.cross(e1)
circ=[hubp+R*(math.cos(2*math.pi*i/72)*e1+math.sin(2*math.pi*i/72)*e2) for i in range(72)]
print('SAIL_R',R)
res={}
for asp,(W,H) in {'0.46':(540,1174),'0.75':(600,800)}.items():
    s.render.resolution_x=W; s.render.resolution_y=H
    def ndc(v):
        c=world_to_camera_view(s,cam,v); return [round(2*c.x-1,3),round(2*c.y-1,3)]
    r={k:ndc(v) for k,v in pts.items()}
    for nm,vs in [('sail_sweep',circ),('sails',sv),('windmill_body',wv),('path_mesh',pv)]:
        q=[ndc(v) for v in vs]; r[nm+'_bbox']=[min(x for x,_ in q),max(x for x,_ in q),min(y for _,y in q),max(y for _,y in q)]
    res[asp]=r
fw=d; up=fw.cross(Vector((0,0,1))).cross(fw).normalized()
out=dict(hit=list(loc),forward=list(fw),up=list(up),eul=[math.degrees(x) for x in cam.rotation_quaternion.to_euler('XYZ')],proj=res)
json.dump(out,open(a['out'],'w'),indent=1); print(json.dumps(out))
