import sys
from PIL import Image, ImageDraw
fs=sys.argv[2:]; ims=[Image.open(f).convert('RGB') for f in fs]
H=max(i.height for i in ims); W=sum(i.width for i in ims)+10*(len(ims)-1)
out=Image.new('RGB',(W,H+16),'white'); x=0; d=ImageDraw.Draw(out)
for f,i in zip(fs,ims):
    out.paste(i,(x,16)); d.text((x+2,2),f.split('/')[-1],fill='black'); x+=i.width+10
out.save(sys.argv[1])
