import json,math
g=json.load(open('/workspace/meadow_bake/geo.json'))
path=[(0.0,-20.0),(1.47,-17.98),(2.33,-15.91),(2.67,-13.81),(2.58,-11.69),(2.15,-9.56),(1.46,-7.42),(0.59,-5.3),(-0.35,-3.2),(-1.3,-1.14),(-2.15,0.89),(-2.82,2.86),(-3.31,5.69),(-2.91,8.35),(-1.23,10.61),(0.69,12.49),(2.07,14.42),(2.96,16.36),(3.48,18.85),(3.33,21.15),(2.62,23.11),(1.13,24.94),(0.0,25.6)]
views=[(0,-20),(6.7,21.1),(0,25.6)]
def dseg(p,a,b):
    ax,ay=a;bx,by=b;px,py=p;dx,dy=bx-ax,by-ay;t=max(0,min(1,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy)))
    return math.hypot(px-ax-t*dx,py-ay-t*dy)
def pri(x,y):
    dp=min(dseg((x,y),path[i],path[i+1]) for i in range(len(path)-1))
    return min(abs(dp-1.0),min(math.hypot(x-a,y-b) for a,b in views))
def keep(items,ratio):
    n=round(len(items)*ratio); r=sorted(range(len(items)),key=lambda i:(pri(items[i][1],items[i][2]),i))
    return [items[i][0] for i in r[:n]]
json.dump({'flowers50':keep(g['flowers'],0.5),'grass30':keep(g['grass'],0.3)},open('/workspace/meadow_bake/sel.json','w'))
print('ok')
