import bpy
s=bpy.context.scene
print("render",s.render.engine,s.render.resolution_x,s.render.resolution_y)
for o in bpy.data.objects:
    extra=""
    if o.type=='MESH':
        me=o.data
        extra=f"v={len(me.vertices)} uv={[u.name for u in me.uv_layers]} mats={[m.name for m in me.materials if m]} attrs={[a.name for a in me.attributes][:8]}"
    if o.type=='CAMERA':
        extra=f"lens={o.data.lens} sensor={o.data.sensor_width} fit={o.data.sensor_fit} rot={tuple(round(x,3) for x in o.rotation_euler)}"
    print(o.name,o.type,tuple(round(x,2) for x in o.location),o.parent.name if o.parent else "",o.hide_render,extra)
for c in bpy.data.collections: print("COL",c.name,len(c.objects),c.hide_render)
for m in bpy.data.materials: print("MAT",m.name)
for i in bpy.data.images: print("IMG",i.name,i.size[:],i.filepath)
