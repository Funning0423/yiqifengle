import sys
from PIL import Image, ImageDraw
for f in sys.argv[1:]:
    im=Image.open(f).convert('RGBA'); W,H=im.size
    ov=Image.new('RGBA',im.size,(0,0,0,0)); d=ImageDraw.Draw(ov)
    y0=int(H*0.75); d.rectangle([0,y0,W,H],fill=(20,20,40,110)); d.line([0,y0,W,y0],fill=(255,220,80,255),width=2)
    d.text((8,y0+6),'UI reserve: bottom 25% (NDC y < -0.5)',fill=(255,240,200,255))
    xm=int(W*0.15); d.line([xm,0,xm,H],fill=(255,255,255,70)); d.line([W-xm,0,W-xm,H],fill=(255,255,255,70))
    d.text((8,8),f.split('/')[-1].replace('.png','')+f'  {W}x{H} aspect {W/H:.3f}',fill=(255,255,255,255))
    Image.alpha_composite(im,ov).convert('RGB').save(f.replace('.png','_overlay.png'))
