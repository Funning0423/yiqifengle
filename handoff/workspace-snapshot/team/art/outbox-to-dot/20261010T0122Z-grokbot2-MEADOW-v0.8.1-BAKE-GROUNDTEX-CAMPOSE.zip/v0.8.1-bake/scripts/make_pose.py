import json, math, numpy as np
B_pos=np.array([-8.0,-62.0,24.0]); B_tgt=np.array([0.3151,0.6059,3.4577]); FOV=45.0
def b2c(v): return [round(float(v[0]),4),round(float(v[2]),4),round(float(-v[1]),4)]
C_pos=np.array(b2c(B_pos)); C_tgt=np.array(b2c(B_tgt))
# Cocos Node.lookAt(target, +Y): camera looks down local -Z; z axis = normalize(pos - target)
z=C_pos-C_tgt; z/=np.linalg.norm(z); up=np.array([0,1.0,0]); x=np.cross(up,z); x/=np.linalg.norm(x); y=np.cross(z,x)
fwd=-z
geo=json.load(open('/workspace/meadow_bake/geo.json')); ter=np.array(geo['terrain'])
i=np.argmin((ter[:,0]-B_pos[0])**2+(ter[:,1]-B_pos[1])**2)
pc=json.load(open('/workspace/meadow_bake/pose_check_final.json'))
proj={}
for a,p in pc['proj'].items():
    q={k:v for k,v in p.items() if k in('player_spawn','windmill_door_point','region_interaction_point','bell_01','windmill_sail_hub','walk_path_05','walk_path_12')}
    q['path_mesh_bbox_ndc_xmin_xmax_ymin_ymax']=p['path_mesh_bbox']; q['windmill_body_bbox_ndc']=p['windmill_body_bbox']; q['sail_sweep_bbox_ndc (6.2 m radius, any rotation)']=p['sail_sweep_bbox']
    q['path_above_ui_band']=p['path_mesh_bbox'][2]>-0.5; q['spawn_above_ui_band']=p['player_spawn'][1]>-0.5
    q['all_key_points_inside_maxAbsX_0.7']=all(abs(v[0])<=0.7 for k,v in p.items() if not k.endswith('bbox')) and max(abs(p['sail_sweep_bbox'][0]),abs(p['sail_sweep_bbox'][1]))<=0.7
    proj[a]=q
doc={
 "name":"meadow_v0_8_region_pan_camera",
 "pose":{"position":C_pos.tolist(),"target":C_tgt.tolist(),"fovVerticalDeg":FOV},
 "metadata":{
  "author":"grokbot-2 (art)","date":"2026-10-09","for":"0007 RegionCameraData stops[id=meadow].pose (AuthoredPose: position + target + fovVerticalDeg; rotation derived by fromLookAt(up=+Y), roll 0)",
  "coordinates":"Cocos world, +Y up, metres, meadow scene local: meadow_greybox_v0_8.glb root (scene_root) at the origin with identity transform. If the meadow region root is placed elsewhere in the region world, transform position and target by that root.",
  "conversion":"cocos = (x_b, z_b, -y_b) (glTF export default, +Y up)",
  "projection":"perspective, fovAxis vertical, near 0.05, far 1000 (0007 fixed params), aspect follows the screen",
  "target_note":"target = optical-axis hit on the terrain (screen centre), raycast in Blender on meadow_terrain",
  "derived_check":{"forward":[round(float(v),5) for v in fwd],"right":[round(float(v),5) for v in x],"up":[round(float(v),5) for v in y],
     "right_axis_y":round(float(x[1]),8),"roll_ok_lt_0.001":abs(float(x[1]))<0.001,"pitch_deg":round(math.degrees(math.asin(fwd[1])),3),
     "yaw_deg_from_minusZ_toward_plusX":round(math.degrees(math.atan2(fwd[0],-fwd[2])),3),"target_distance_m":round(float(np.linalg.norm(C_pos-C_tgt)),3),
     "camera_height_above_terrain_m":round(float(B_pos[2]-ter[i,2]),2),"fov_in_range_30_75":30<=FOV<=75,"all_finite":bool(np.all(np.isfinite(np.r_[C_pos,C_tgt])))},
  "ndc_projection_check":{"note":"NDC x right, y up, [-1,1]; computed in Blender with the exact pose; 0.46 = 540x1174, 0.75 = 600x800. UI reserve = bottom 25% = NDC y < -0.5. Bounding boxes only: not an occlusion or HUD test.","aspect_0.46":proj['0.46'],"aspect_0.75":proj['0.75']},
  "framing":"Windmill + sail sweep in the upper third (left of centre), wind-bell frame / region_interaction_point right of the door, tree on the right, path winds from player_spawn (just above the UI band) to the windmill door. Bottom 25% is plain grass for the board/UI buttons. Level horizon (roll 0), looking roughly north: yaw ~7.6 deg, pitch ~-18.0 deg, 66.4 m to target, 24.8 m above the terrain.",
  "blender_z_up":{"position":B_pos.tolist(),"target":B_tgt.tolist(),"fovVerticalDeg":FOV,"lens_mm_at_sensor_height_24":round(12/math.tan(math.radians(FOV/2)),4),"sensor_fit":"VERTICAL"}
 }}
json.dump(doc,open('/workspace/meadow_bake/meadow_camera_pose.json','w'),indent=1)
print(json.dumps(doc['pose']),json.dumps(doc['metadata']['derived_check']))
