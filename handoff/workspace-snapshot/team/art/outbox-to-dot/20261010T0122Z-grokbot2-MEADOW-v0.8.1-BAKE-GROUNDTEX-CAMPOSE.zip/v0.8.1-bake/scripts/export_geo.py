import bpy, json
from mathutils import Vector
out={}
def tris(name):
    o=bpy.data.objects[name]; me=o.data; me.calc_loop_triangles(); mw=o.matrix_world
    return [[list((mw@me.vertices[i].co).xy) for i in t.vertices] for t in me.loop_triangles]
for n in ['meadow_path','meadow_river','meadow_river_bank','meadow_fence_merged']:
    out[n]=tris(n)
o=bpy.data.objects['meadow_terrain']; me=o.data
out['terrain']=[list(v.co) for v in me.vertices]
o=bpy.data.objects['meadow_trees_merged']; mw=o.matrix_world
out['trees']=[list(mw@v.co) for v in o.data.vertices]
o=bpy.data.objects['windmill_static_merged']; mw=o.matrix_world
out['windmill']=[list(mw@v.co) for v in o.data.vertices]
o=bpy.data.objects['wind_bell_frame']; mw=o.matrix_world
out['bellframe']=[list(mw@v.co) for v in o.data.vertices]
sun=bpy.data.objects['sun']; out['sun_dir']=list(sun.matrix_world.to_3x3()@Vector((0,0,-1)))
fl=[o for o in bpy.data.objects if o.parent and o.parent.name=='meadow_flower_instances']
out['flowers']=[[o.name]+list(o.matrix_world.translation) for o in fl]
gr=[o for o in bpy.data.objects if o.parent and o.parent.name=='meadow_grass_instances']
out['grass']=[[o.name]+list(o.matrix_world.translation) for o in gr]
json.dump(out,open('/workspace/meadow_bake/geo.json','w'))
print("ok",{k:len(v) for k,v in out.items()})
