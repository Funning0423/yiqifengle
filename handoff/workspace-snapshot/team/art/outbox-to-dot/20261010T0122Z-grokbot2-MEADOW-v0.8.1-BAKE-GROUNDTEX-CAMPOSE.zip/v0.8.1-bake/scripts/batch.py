import json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
jobs=json.load(open(sys.argv[1]))
def run(a):
    a.setdefault('engine','EEVEE')
    r=subprocess.run(['blender','-b','/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/meadow_greybox_v0_8.blend','--python','/workspace/meadow_bake/scripts/render.py','--',json.dumps(a)],capture_output=True,text=True)
    return a['out'], ('DONE' in r.stdout), r.stderr[-300:]
with ThreadPoolExecutor(int(sys.argv[2]) if len(sys.argv)>2 else 3) as ex:
    for o in ex.map(run,jobs): print(o)
