"""Bake the grass-off ground texture for the meadow v0.8 terrain (grokbot-2).
UV layout = meadow_ground_v0_8_1024.jpg: u=(x_b+80)/160, v=(y_b+80)/160 (Blender XY, image top row = y_b=+80 = game z=-80).
Painted at 2048, downsampled to 1024 (Lanczos)."""
import json, math, sys, numpy as np
from PIL import Image, ImageDraw
rng=np.random.default_rng(20261009)
SRC='/workspace/wechat-game/art/x/GROKBOT-MEADOW-v0.8.0/meadow_v0_8/'
geo=json.load(open('/workspace/meadow_bake/geo.json'))
lay=json.load(open(SRC+'data/meadow_layout_v0_8.json'))
N=2048; M=160.0; px=N/M  # 12.8 px per metre
def w2p(x,y): return ((x+80)*px, (80-y)*px)
jj,ii=np.meshgrid(np.arange(N),np.arange(N))
XB=(jj+0.5)/px-80; YB=80-(ii+0.5)/px
def hexc(h): h=h.lstrip('#'); return np.array([int(h[i:i+2],16)/255 for i in (0,2,4)])
def s2l(c): c=np.asarray(c,float); return np.where(c<=0.04045,c/12.92,((c+0.055)/1.055)**2.4)
def l2s(c): c=np.clip(c,0,1); return np.where(c<=0.0031308,c*12.92,1.055*c**(1/2.4)-0.055)
def blur(a,sig_px):
    if sig_px<=0: return a
    f=np.fft.fftfreq(N); g=np.exp(-2*(math.pi*sig_px)**2*(f[:,None]**2+f[None,:]**2))
    return np.real(np.fft.ifft2(np.fft.fft2(a)*g))
def vnoise(cell_m,seed):
    r=np.random.default_rng(seed); n=max(2,int(M/cell_m)+3)
    g=r.random((n,n)).astype(np.float32)
    im=Image.fromarray(g,'F').resize((int(N*(n)/(M/cell_m)),)*2,Image.BICUBIC)
    a=np.asarray(im)[:N,:N]; return (a-a.mean())/(a.std()+1e-6)
def mask_from_tris(tris,dil_m=0.0):
    im=Image.new('L',(N,N),0); d=ImageDraw.Draw(im)
    for t in tris: d.polygon([w2p(*p) for p in t],fill=255)
    a=np.asarray(im,np.float32)/255
    return a
# palette (sRGB hex -> linear)
C=dict(deep=hexc('#2E6A2C'),dark=hexc('#3F8A2E'),mid=hexc('#60AE32'),light=hexc('#86C540'),sun=hexc('#9FD048'),tip=hexc('#C4E65A'),
       dirt=hexc('#C9B48A'),dirt_edge=hexc('#9C8A5E'),pink=hexc('#F084AA'),white=hexc('#FBF7EA'),shadow_tint=np.array([0.62,0.72,0.88]))
L={k:s2l(v) if k!='shadow_tint' else v for k,v in C.items()}
# --- 1. tonal field: sunlit patches / dark clumps (value 0=deep .. 1=sun)
n1=vnoise(26,1); n2=vnoise(9,2); n3=vnoise(3.5,3)
t=0.52+0.19*n1+0.11*n2+0.06*n3
# terrain slope lighting (subtle; engine lights terrain too)
ter=np.array(geo['terrain']); g=int(round(math.sqrt(len(ter))))
order=np.lexsort((ter[:,0],ter[:,1])); Z=ter[order,2].reshape(g,g)  # rows: y ascending
Zimg=np.asarray(Image.fromarray(Z[::-1].astype(np.float32),'F').resize((N,N),Image.BICUBIC))
dzdx=np.gradient(Zimg,axis=1)*px; dzdy=-np.gradient(Zimg,axis=0)*px
nrm=np.stack([-dzdx,-dzdy,np.ones_like(Zimg)]); nrm/=np.linalg.norm(nrm,axis=0)
sd=-np.array(geo['sun_dir']); sd/=np.linalg.norm(sd)
ndl=np.tensordot(sd,nrm,axes=1); ndl0=sd[2]
t+=0.40*(ndl-ndl0)
# grass-band density (where the real clumps stood): darker roots + bright tips
cl=np.array([[c[1],c[2],c[3]] for c in lay['grass_clumps']])
dens=np.zeros((N,N),np.float32)
for x,y,s in cl:
    pj,pi=w2p(x,y); pi=int(pi); pj=int(pj)
    if 0<=pi<N and 0<=pj<N: dens[pi,pj]+=s
dens=blur(dens,0.9*px); dens=np.clip(dens/ (dens.max()*0.35),0,1)
t-=0.18*dens
t=np.clip(t,0,1)
# map tone to colour ramp (linear space)
stops=[(0.0,L['deep']),(0.28,L['dark']),(0.52,L['mid']),(0.74,L['light']),(1.0,L['sun'])]
col=np.zeros((N,N,3))
for (a,ca),(b,cb) in zip(stops[:-1],stops[1:]):
    m=(t>=a)&(t<=b); w=((t-a)/(b-a))[m][:,None]; col[m]=ca*(1-w)+cb*w
# --- 2. cloud shadows (same two as v0.8 layout; cool tint like the scrolling formula, 0.4)
cs=np.zeros((N,N))
W_b=np.array([0.944,0.330]); W_b/=np.linalg.norm(W_b)
for c in lay['cloud_shadows']:
    dx=XB-c['x']; dy=YB-c['y']; a=dx*W_b[0]+dy*W_b[1]; b=-dx*W_b[1]+dy*W_b[0]
    r=np.sqrt((a/c['half_len'])**2+(b/c['half_wid'])**2)+0.25*vnoise(5,10+c['seed'])
    cs=np.maximum(cs,np.clip((1.0-r)/0.35,0,1))
cs=blur(cs,1.0*px)
col*=(1-0.40*cs[...,None]*(1-L['shadow_tint']))
# --- 3. tree shadows (painted, cast along sun on ground)
tr=np.array(geo['trees']); hi=tr[tr[:,2]>tr[:,2].min()+0.0]
tsh=Image.new('L',(N,N),0); d=ImageDraw.Draw(tsh)
sdir=np.array(geo['sun_dir']);  # direction light travels
for x,y,z in tr:
    gz=Zimg[min(N-1,max(0,int((80-y)*px))),min(N-1,max(0,int((x+80)*px)))]
    hgt=max(0,z-gz); k=hgt/max(1e-3,-sdir[2])
    sx,sy=x+sdir[0]*k,y+sdir[1]*k; pj,pi=w2p(sx,sy); rr=0.9*px
    d.ellipse([pj-rr,pi-rr,pj+rr,pi+rr],fill=255)
tsh=blur(np.asarray(tsh,np.float32)/255,0.6*px); tsh=np.clip(tsh*1.3,0,1)
col*=(1-0.38*tsh[...,None]*(1-L['shadow_tint']*0.8))
# --- 4. blade strokes along the wind (image dir = (0.944,-0.330))
lum=Image.new('L',(N,N),128); d=ImageDraw.Draw(lum)
ux,uy=0.944,-0.330
# mid-scale clumps (0.6-1.6 m), elongated along the wind: dark body + sunlit cap toward the sun (south-west)
hx,hy=-0.327,0.747; hn=math.hypot(hx,hy); hx,hy=hx/hn,hy/hn
cn=vnoise(7,30)
NC=26000
cxs=rng.random(NC)*N; cys=rng.random(NC)*N
def rell(cx,cy,a,b,ang,k=10):
    ca,sa=math.cos(ang),math.sin(ang); return [(cx+a*math.cos(2*math.pi*i/k)*ca-b*math.sin(2*math.pi*i/k)*sa, cy+a*math.cos(2*math.pi*i/k)*sa+b*math.sin(2*math.pi*i/k)*ca) for i in range(k)]
wang=math.atan2(uy,ux)
for k in range(NC):
    cx,cy=cxs[k],cys[k]
    if cn[int(cy),int(cx)]<-0.6 and rng.random()<0.7: continue
    sz=(0.6+rng.random()*1.0)*px*(1+0.6*dens[int(cy),int(cx)])
    ang=wang+rng.normal(0,0.3)
    d.polygon(rell(cx,cy,sz*0.55,sz*0.24,ang),fill=int(128-24-14*rng.random()))
    d.polygon(rell(cx+hx*sz*0.16,cy+hy*sz*0.16,sz*0.40,sz*0.13,ang),fill=int(128+22+14*rng.random()))
NS=260000
xs=rng.random(NS)*N; ys=rng.random(NS)*N
dc=dens[ys.astype(int),xs.astype(int)]
ln=(4+rng.random(NS)*7)*(1+1.2*dc)
ang=rng.normal(0,0.35,NS)
for k in range(NS):
    ca,sa=math.cos(ang[k]),math.sin(ang[k]); dx=(ux*ca-uy*sa)*ln[k]; dy=(ux*sa+uy*ca)*ln[k]
    v=int(128+rng.choice([-1,1],p=[0.45,0.55])*(22+28*rng.random()))
    d.line([(xs[k],ys[k]),(xs[k]+dx,ys[k]+dy)],fill=v,width=1 if rng.random()<0.7 else 2)
# tufts on the real grass clumps: dark root + bright tips downwind
for x,y,s in cl:
    pj,pi=w2p(x,y)
    for b in range(int(16*s)+6):
        ox,oy=rng.normal(0,0.35*px*s,2); a=rng.normal(0,0.45); l=(0.7+0.8*rng.random())*px*s
        ca,sa=math.cos(a),math.sin(a); dx=(ux*ca-uy*sa)*l; dy=(ux*sa+uy*ca)*l
        d.line([(pj+ox,pi+oy),(pj+ox+dx*0.5,pi+oy+dy*0.5)],fill=55,width=3)
        d.line([(pj+ox+dx*0.45,pi+oy+dy*0.45),(pj+ox+dx,pi+oy+dy)],fill=215,width=2)
lumA=(np.asarray(lum,np.float32)-128)/128
lumA=lumA*0.85+0.15*blur(lumA,1.2)
col*=(1+0.42*lumA[...,None])
# tips tint: bright strokes lean toward the grass tip colour
tipw=np.clip(lumA,0,1)[...,None]*0.22
col=col*(1-tipw)+L['tip']*tipw*np.clip(col.mean(-1,keepdims=True)/L['mid'].mean(),0.5,1.3)
# --- 5. flower drifts: sparse pink/white dots (flowers stay at 50% in fallback)
fl=Image.new('RGBA',(N,N),(0,0,0,0)); d=ImageDraw.Draw(fl)
for e in lay['flower_drifts']:
    area=math.pi*e['half_len']*e['half_wid']; nd=int(area*4.5)
    for k in range(nd):
        r=math.sqrt(rng.random()); th=rng.random()*2*math.pi
        a=r*math.cos(th)*e['half_len']; b=r*math.sin(th)*e['half_wid']
        x=e['x']+a*W_b[0]-b*W_b[1]; y=e['y']+a*W_b[1]+b*W_b[0]
        if rng.random()>1.0-0.85*(1-r*r): 
            pj,pi=w2p(x,y); c=C['pink'] if rng.random()<e['pink_share'] else C['white']
            rr=1.3+rng.random()*1.3
            d.ellipse([pj-rr,pi-rr,pj+rr,pi+rr],fill=tuple(int(v*255) for v in c)+(int(200+55*rng.random()),))
flA=np.asarray(fl,np.float32)/255
col=col*(1-flA[...,3:4])+s2l(flA[...,:3])*flA[...,3:4]
# --- 6. walk path: dirt under the path mesh + worn fringe
pm=mask_from_tris(geo['meadow_path'])
fringe=np.clip(blur(pm,0.45*px)*1.6,0,1)
worn=np.clip(fringe+0.25*vnoise(1.2,20)*fringe*(1-fringe)*4,0,1)
dirt=L['dirt']*(1+0.10*vnoise(0.8,21)[...,None])
col=col*(1-worn[...,None]*0.35)+L['dirt_edge']*worn[...,None]*0.35   # trodden edge
col=col*(1-pm[...,None])+dirt*pm[...,None]
# --- 7. river + bank: keep the v0.8 ground texture there (bank mesh still samples the old texture)
old=np.asarray(Image.open(SRC+'textures/meadow_ground_v0_8_1024.jpg').convert('RGB').resize((N,N),Image.BICUBIC),np.float32)/255
rb=np.maximum(mask_from_tris(geo['meadow_river']),mask_from_tris(geo['meadow_river_bank']))
rbm=np.clip(blur(rb,0.35*px)*3.0,0,1)
col=col*(1-rbm[...,None])+s2l(old)*rbm[...,None]
# final grade: a little more chroma (linear), keeps luminance
gm=(1-pm-rbm).clip(0,1)[...,None]   # grade the grass only (not path / river)
out=l2s(col); lumv=out.mean(-1,keepdims=True)
out=np.clip(out*(1-gm)+(lumv+(out-lumv)*1.10)*gm,0,1)
img=Image.fromarray((out*255+0.5).astype(np.uint8),'RGB')
img.save('/workspace/meadow_bake/bake_2048.png')
small=img.resize((1024,1024),Image.LANCZOS)
small.save('/workspace/meadow_bake/bake_1024.png',optimize=True)
small.save('/workspace/meadow_bake/bake_1024.jpg',quality=90,subsampling=0)
m=np.asarray(small,np.float32)/255
print('mean sRGB',m.reshape(-1,3).mean(0)*255, 'central 80m mean', m[256:768,256:768].reshape(-1,3).mean(0)*255)
