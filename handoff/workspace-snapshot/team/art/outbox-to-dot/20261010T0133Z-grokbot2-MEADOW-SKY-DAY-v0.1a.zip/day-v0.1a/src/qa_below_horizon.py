#!/usr/bin/env python3
"""QA for meadow sky v0.1a below-horizon fix. Usage: qa_below_horizon.py <label> <before> <after> <outdir> [after_jpg]"""
import sys, json, numpy as np
from PIL import Image, ImageDraw
lab, BEF, AFT, OUT = sys.argv[1:5]; AJ = sys.argv[5] if len(sys.argv) > 5 else None
H, W, HR = 1024, 2048, 878
ld = lambda p: np.asarray(Image.open(p).convert('RGB')).astype(float)
L = lambda a: a @ np.array([0.2126, 0.7152, 0.0722])
b, a = ld(BEF), ld(AFT)
R = {'label': lab, 'horizon_row': 877.7, 'constant_rows': [HR, H - 1]}
def stats(arr, tag):
    l = L(arr); rm = l.mean(1)
    below = rm[HR:]
    ref = below[0]
    # per-column flatness on 8x8 box (removes the ordered dither pattern): deviation from that column's row-878..885 block
    lb = l[HR - 6:HR - 6 + 144 + 0].reshape(18, 8, W // 8, 8).mean((1, 3))[1:]   # rows 878..1021 in 8-row blocks
    R[tag] = {
        'row_mean_lum_below_min_max': [round(float(below.min()), 3), round(float(below.max()), 3)],
        'row_mean_lum_below_dev_from_row878_max': round(float(np.abs(below - ref).max()), 3),
        'per_pixel_lum_dev_from_col_median_max': round(float(np.abs(l[HR:] - np.median(l[HR:], 0)).max()), 3),
        'per_block8_lum_dev_from_col_median_max': round(float(np.abs(lb - np.median(lb, 0)).max()), 3),
        'boundary_rowmean_step_max_rows_860_900': round(float(np.abs(np.diff(rm[860:900])).max()), 3),
        'seam_wrap_vs_inner_meanabs_all': [round(float(np.abs(arr[:, 0] - arr[:, -1]).mean()), 3), round(float(np.abs(np.diff(arr, axis=1)).mean()), 3)],
        'seam_wrap_vs_inner_meanabs_below': [round(float(np.abs(arr[HR:, 0] - arr[HR:, -1]).mean()), 3), round(float(np.abs(np.diff(arr[HR:], axis=1)).mean()), 3)],
        'rows_above_870_changed_vs_before_max_abs': round(float(np.abs(arr[:866] - b[:866]).max()), 3),
    }
    return rm
rb = stats(b, 'before'); ra = stats(a, 'after')
curves = [('before', rb, (220, 60, 60)), ('after', ra, (40, 160, 60))]
if AJ: rj = stats(ld(AJ), 'after_jpg_q90'); curves.append(('after JPG q90', rj, (60, 90, 220)))
af = R['after']['row_mean_lum_below_dev_from_row878_max']
R['PASS_flat_within_1_level'] = bool(af <= 1.0 and R['after']['per_block8_lum_dev_from_col_median_max'] <= 1.0)
json.dump(R, open(f'{OUT}/qa_results.json', 'w'), indent=1); print(json.dumps(R, indent=1))

# plot rows 820..1023, row-mean luminance
PW, PH, M = 1000, 520, 60
r0 = 820; rows = np.arange(r0, H)
allv = np.concatenate([c[1][r0:] for c in curves]); lo, hi = np.floor(allv.min()) - 3, np.ceil(allv.max()) + 3
im = Image.new('RGB', (PW + 2 * M, PH + 2 * M), 'white'); d = ImageDraw.Draw(im)
X = lambda r: M + (r - r0) / (H - 1 - r0) * PW; Y = lambda v: M + PH - (v - lo) / (hi - lo) * PH
d.rectangle((M, M, M + PW, M + PH), outline='black')
for v in np.arange(np.ceil(lo), hi + 1, max(1, int((hi - lo) / 12))): d.line((M, Y(v), M + PW, Y(v)), fill=(225, 225, 225)); d.text((5, Y(v) - 6), f'{v:.0f}', fill='black')
for r in range(r0, H, 20): d.text((X(r) - 10, M + PH + 5), str(r), fill='black')
d.line((X(877.7), M, X(877.7), M + PH), fill=(0, 0, 0), width=1); d.text((X(877.7) + 4, M + 4), 'horizon v=0.857 (row 877.7)', fill='black')
ref = ra[HR]
d.rectangle((X(HR), Y(ref + 1), M + PW, Y(ref - 1)), outline=(120, 120, 120))
d.text((X(HR) + 4, Y(ref + 1) - 14), '+-1 level band around after@878', fill=(90, 90, 90))
for i, (n, c, col) in enumerate(curves):
    pts = [(X(r), Y(c[r])) for r in rows]; d.line(pts, fill=col, width=2)
    d.text((M + 10, M + PH - 20 - 14 * i), n, fill=col)
d.text((M, 15), f'{lab}: row-mean luminance (Rec.709, 8-bit levels) rows {r0}-1023  |  after max dev below horizon = {af:.3f}', fill='black')
d.text((M, M + PH + 25), 'image row (top=0)', fill='black')
im.save(f'{OUT}/qa_row_luminance_below_horizon.png')

# before/after preview: full images at half res stacked + horizon crop at full res with x3 vertical contrast stretch
def half(x): return Image.fromarray(x.astype(np.uint8)).resize((1024, 512), Image.LANCZOS)
pv = Image.new('RGB', (2048 + 8, 512 + 8 + 200), 'white')
pv.paste(half(b), (0, 0)); pv.paste(half(a), (1032, 0))
cb, ca = b[780:980, 0:1024], a[780:980, 0:1024]
# contrast-stretched (x4 around the horizon colour) to make any band visible
mid = np.median(a[HR:HR + 20, 0:1024], axis=(0, 1))
st = lambda x: np.clip((x - mid) * 4 + 128, 0, 255)
pv.paste(Image.fromarray(st(cb).astype(np.uint8)), (0, 520)); pv.paste(Image.fromarray(st(ca).astype(np.uint8)), (1032, 520))
pv.paste(Image.fromarray(cb[:, :].astype(np.uint8)).crop((0, 0, 1024, 200)).resize((1024, 200)), (0, 720)) if False else None
d = ImageDraw.Draw(pv)
for x0 in (0, 1032):
    d.line((x0, 877.7 / 2, x0 + 1024, 877.7 / 2), fill=(255, 0, 0)); d.line((x0, 520 + 97.7, x0 + 1024, 520 + 97.7), fill=(255, 0, 0))
for x0, t in ((0, 'BEFORE'), (1032, 'AFTER')):
    d.rectangle((x0, 0, x0 + 260, 16), fill='black'); d.text((x0 + 4, 3), f'{lab} {t} (half res, red=horizon)', fill='white')
    d.rectangle((x0, 520, x0 + 420, 536), fill='black'); d.text((x0 + 4, 523), f'{t} rows 780-979, u 0-0.5, full res, contrast x4', fill='white')
pv.save(f'{OUT}/preview_before_after.png')
# seam preview below horizon: u 0.9..1 | 0..0.1 rows 780..1023 contrast x4
sm = np.concatenate([a[780:, -205:], a[780:, :205]], 1)
Image.fromarray(st(sm).astype(np.uint8)).save(f'{OUT}/preview_seam_wrap_below_horizon_x4.png')
