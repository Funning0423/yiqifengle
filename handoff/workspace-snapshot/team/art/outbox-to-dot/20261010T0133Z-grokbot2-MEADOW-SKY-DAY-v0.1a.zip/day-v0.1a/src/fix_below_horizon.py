#!/usr/bin/env python3
"""QIFENGLE meadow sky v0.1a below-horizon fix (grokbot-2).
Horizon (0 deg elevation) on meadow_sky_dome = glTF v 0.857143 = image row 877.7 of 1024.
Per column: horizon colour = median of rows 866..877 (12 rows just above v=0.857), then circular
(wrap-around) Gaussian smoothing along u (sigma 6 px) so u=0/u=1 stays seamless.
Rows 878..1023 = that colour exactly; rows 870..877 smoothstep-blend original -> horizon colour (8 rows).
Usage:
  fix_below_horizon.py day   <in.jpg>  <out.jpg>
  fix_below_horizon.py night <night_float.npy from make_night_sky.py> <out.png> <out.jpg>
The night path works on the pre-dither float master and re-applies the same 8x8 Bayer dither (+-0.5 LSB).
"""
import sys, numpy as np
from PIL import Image
H, W = 1024, 2048
S0, S1 = 866, 878          # sample rows [S0, S1)
B0, B1 = 870, 878          # blend rows [B0, B1); rows >= B1 constant
SIG = 6.0

def horizon_fix(a):
    a = a.astype(np.float64).copy()
    hc = np.median(a[S0:S1], axis=0)                       # (W,3)
    r = int(4 * SIG); k = np.exp(-0.5 * (np.arange(-r, r + 1) / SIG) ** 2); k /= k.sum()
    hp = np.concatenate([hc[-r:], hc, hc[:r]], 0)          # circular pad -> seamless wrap
    hc = np.stack([np.convolve(hp[:, c], k, mode='valid') for c in range(3)], -1)
    t = (np.arange(B0, B1) - B0 + 1) / (B1 - B0 + 1)
    t = t * t * (3 - 2 * t)
    a[B0:B1] = a[B0:B1] * (1 - t[:, None, None]) + hc[None] * t[:, None, None]
    a[B1:] = hc[None]
    return a

BAYER = (np.array([[0,32,8,40,2,34,10,42],[48,16,56,24,50,18,58,26],[12,44,4,36,14,46,6,38],[60,28,52,20,62,30,54,22],
                   [3,35,11,43,1,33,9,41],[51,19,59,27,49,17,57,25],[15,47,7,39,13,45,5,37],[63,31,55,23,61,29,53,21]]) + 0.5) / 64 - 0.5

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'day':
        src = np.asarray(Image.open(sys.argv[2]).convert('RGB'))
        out = np.clip(np.round(horizon_fix(src)), 0, 255).astype(np.uint8)
        Image.fromarray(out, 'RGB').save(sys.argv[3], quality=90, subsampling=2, optimize=True)
    elif mode == 'night':
        f = np.load(sys.argv[2]).astype(np.float64)
        g = horizon_fix(f)
        g = g + np.tile(BAYER, (H // 8, W // 8))[..., None]
        out = np.clip(np.round(g), 0, 255).astype(np.uint8)
        im = Image.fromarray(out, 'RGB')
        im.save(sys.argv[3], optimize=True, compress_level=9)
        im.save(sys.argv[4], quality=90, subsampling=2, optimize=True)
    print('ok', sys.argv[1:])
