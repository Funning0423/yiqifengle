# 草甸白天天空 meadow_sky v0.1a（grokbot-2）

修复：地平线以下（v > 0.857，第 878–1023 行）原图越往下越亮（行均亮度 166 → 189），会在地形山脊下方露出一条亮带。v0.1a 把地平线以下统一成地平线颜色。
引擎里仍以 `tex_meadow_sky_2048x1024.jpg` 导入，直接替换原图即可，UV 布局不变。

源：`team/ggbot/reports/meadow/sky/meadow_sky_2048x1024.jpg`（cc4dafd699608f3eef25968a09d81628b5e5d188f66c84fd8d016a4f77bc4e9e）

## 做法（`src/fix_below_horizon.py day`）
- 地平线（仰角 0°）= glTF v 0.857143 = 第 877.7 行。
- 每一列取第 866–877 行（地平线上方 12 行）的中位数作为地平线颜色，再沿 u 方向做环绕高斯平滑（σ = 6 px，首尾相接），所以 u=0/1 不会产生接缝。
- 第 878–1023 行 = 该颜色，完全恒定；第 870–877 行用 smoothstep 从原图过渡到地平线颜色（8 行），没有台阶。
- 第 866 行以上不改动（只有 JPG 重新压缩带来的误差，平均 0.06 级）。
- 原图每一列都相同，所以结果是单一颜色 sRGB (97, 181, 209) = #61B5D1。
- 输出 JPG q90、4:2:0，57,542 B（原图 79,489 B）。

## QA（`qa_results.json`，`src/qa_below_horizon.py`）
- 地平线以下行均亮度：之前 166.0–188.8（偏差 22.6 级），之后 165.163 恒定，偏差 0.000，逐像素偏差 0 → 在 ±1 级以内，PASS。
- 边界处相邻行最大跳变 0.99 级（之前 2.0）。
- 地平线以下的左右接缝差 0.000。整图 u=1→0 接缝 0.80 对普通相邻列 0.31：这是原图上方天空本身就有的轻微接缝（原图 0.76 对 0.31），不在本次范围，未处理。
- `preview_before_after.png`：上排为半分辨率前/后（红线 = 地平线）；下排为第 780–979 行全分辨率、对比度 ×4，原来的亮带在修后消失。
- `qa_row_luminance_below_horizon.png`：第 820–1023 行的行均亮度曲线，灰框是 ±1 级带。
- `preview_seam_wrap_below_horizon_x4.png`：u 0.9–1 接 0–0.1，第 780 行以下，对比度 ×4。

## 未做
Creator 导入、DevTools / 真机渲染；和地形山脊一起的实际观感。

## 复现
```
python3 src/fix_below_horizon.py day <源 jpg> meadow_sky_2048x1024.jpg
python3 src/qa_below_horizon.py DAY <源 jpg> meadow_sky_2048x1024.jpg .
```
