#!/usr/bin/env python3
"""QIFENGLE meadow night sky v0.1 (grokbot-2). Fully procedural (numpy), no reference frames.
UV layout identical to meadow_sky (day): u = azimuth/360, glTF v (image row from top) with
elevation = 90 - 105*v  ->  horizon (0 deg) at v = 0.857143 (row 877.7 of 1024), bottom = -15 deg.
Everything is computed from 3D directions on the dome, so u=0 and u=1 are continuous by construction.
"""
import numpy as np, sys
from PIL import Image

W, H = 2048, 1024
SEED = 20261009
rng = np.random.default_rng(SEED)

u = (np.arange(W) + 0.5) / W
v = (np.arange(H) + 0.5) / H
az = u * 2 * np.pi                       # azimuth
el = np.radians(90.0 - 105.0 * v)        # elevation per row
AZ, EL = np.meshgrid(az, el)
D = np.stack([np.cos(EL) * np.cos(AZ), np.sin(EL), np.cos(EL) * np.sin(AZ)], -1)  # unit dirs (y up)
eld = np.degrees(EL)

def srgb2lin(c): c = np.asarray(c, float) / 255.0; return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
def lin2srgb(x): x = np.clip(x, 0, 1); return np.where(x <= 0.0031308, x * 12.92, 1.055 * x ** (1 / 2.4) - 0.055)
def ss(a, b, x): t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

# ---------- 1. base gradient (sRGB keyed by elevation, interpolated in linear) ----------
keys = [  # elevation deg, sRGB
    (90, (14, 18, 46)),     # zenith: deep indigo
    (60, (20, 28, 66)),
    (35, (28, 44, 92)),     # deep blue
    (18, (40, 64, 118)),
    (8,  (62, 92, 146)),
    (2,  (98, 124, 172)),   # lighter horizon glow
    (0,  (116, 138, 180)),  # horizon line
    (-4, (96, 116, 158)),
    (-8, (82, 100, 142)),   # below-horizon fog band (flat, like the day texture)
    (-15, (82, 100, 142)),
]
ke = np.array([k[0] for k in keys][::-1], float)
kc = srgb2lin([k[1] for k in keys][::-1])
grad = np.stack([np.interp(eld[:, 0], ke, kc[:, i]) for i in range(3)], -1)
# smooth the piecewise-linear keys a little (rows only) to avoid Mach bands at the keys
k = np.exp(-0.5 * (np.arange(-24, 25) / 8.0) ** 2); k /= k.sum()
gp = np.pad(grad, ((24, 24), (0, 0)), mode='edge')
grad = np.stack([np.convolve(gp[:, i], k, mode='valid') for i in range(3)], -1)
img = np.broadcast_to(grad[:, None, :], (H, W, 3)).copy()

# ---------- 2. moon (well above the horizon) + moonlight glow ----------
MOON_AZ, MOON_EL = 0.30 * 360.0, 40.0     # u = 0.30, elevation 40 deg  (row ~ 0.476*1024)
ma, me = np.radians(MOON_AZ), np.radians(MOON_EL)
M = np.array([np.cos(me) * np.cos(ma), np.sin(me), np.cos(me) * np.sin(ma)])
ang = np.degrees(np.arccos(np.clip(D @ M, -1, 1)))     # great-circle distance to moon (deg)
glow = 0.10 * np.exp(-ang / 9.0) + 0.05 * np.exp(-(ang / 28.0) ** 2)
img += glow[..., None] * srgb2lin((150, 170, 215))[None, None, :] * 1.2
# horizon glow slightly stronger under the moon's azimuth
daz = np.angle(np.exp(1j * (AZ - ma)))
img += (0.035 * np.exp(-(daz / 0.9) ** 2) * np.exp(-np.abs(eld) / 6.0))[..., None] * srgb2lin((170, 180, 215))
R_MOON = 1.9                                       # deg
disc = ss(R_MOON + 0.12, R_MOON - 0.12, ang)       # soft-edged disc (anti-aliased)
# subtle painterly maria: low-freq tint across the disc, in moon-local coords
e1 = np.cross(M, [0, 1, 0]); e1 /= np.linalg.norm(e1); e2 = np.cross(e1, M)
lx, ly = D @ e1, D @ e2
MOON_MARIA = True   # placeholder; filled after noise helpers are defined


# ---------- 3. smooth 3D value noise (periodic-free on the sphere -> seamless) ----------
def vnoise3(p, seed):
    r = np.random.default_rng(seed)
    perm = r.permutation(256); perm = np.concatenate([perm, perm])
    vals = r.random(256)
    pi = np.floor(p).astype(np.int64); pf = p - pi
    f = pf * pf * (3 - 2 * pf)
    def h(ix, iy, iz): return vals[perm[(perm[(perm[ix & 255] + iy) & 255] + iz) & 255]]
    x0, y0, z0 = pi[..., 0], pi[..., 1], pi[..., 2]
    out = 0
    for dx in (0, 1):
        wx = f[..., 0] if dx else 1 - f[..., 0]
        for dy in (0, 1):
            wy = f[..., 1] if dy else 1 - f[..., 1]
            for dz in (0, 1):
                wz = f[..., 2] if dz else 1 - f[..., 2]
                out = out + wx * wy * wz * h(x0 + dx, y0 + dy, z0 + dz)
    return out
def fbm(p, seed, oct=5):
    s, a, n = 0, 0.5, 0
    for o in range(oct):
        s = s + a * vnoise3(p * (2 ** o), seed + o); n += a; a *= 0.5
    return s / n

# moon disc with soft painterly maria (low-frequency noise in moon-local coords)
near = ang < R_MOON + 0.5
mar = np.zeros((H, W))
q = np.stack([lx[near] / np.radians(R_MOON) * 1.6, ly[near] / np.radians(R_MOON) * 1.6, np.full(near.sum(), 0.37)], -1)
mar[near] = fbm(q + 5.0, SEED + 71, 3)
limb = np.clip(1 - (ang / R_MOON) ** 2, 0, 1) ** 0.25
moon_c = srgb2lin((248, 243, 222))[None, None, :] * ((0.80 + 0.20 * ss(0.35, 0.65, mar)) * (0.88 + 0.12 * limb))[..., None]
img = img * (1 - disc[..., None]) + moon_c * disc[..., None]
img += (0.05 * np.exp(-((ang - R_MOON) / 1.2) ** 2) * (ang > R_MOON))[..., None] * srgb2lin((200, 205, 230))  # tight halo

# ---------- 4. a few faint painterly moonlit clouds (horizontal streaks, low on the sky) ----------
# stretched coords: azimuth around a big circle (seamless), elevation scaled up -> long soft bands
RC = 2.2
P = np.stack([RC * np.cos(AZ), RC * np.sin(AZ), eld / 6.0], -1)
n1 = fbm(P, SEED + 11, 4)
n2 = fbm(P * np.array([1.0, 1.0, 1.6]) + 7.3, SEED + 31, 3)
band = ss(3, 9, eld) * (1 - ss(24, 34, eld))                    # clouds live between ~5 and ~30 deg
cov = ss(0.52, 0.80, n1 * 0.75 + n2 * 0.35) * band
cov = cov * (0.55 + 0.45 * ss(0.3, 0.7, fbm(P * 0.5 + 3.1, SEED + 51, 2)))   # only "a few": patchy
# moonlit top edge: compare with coverage slightly lower in elevation (rim light from above / toward moon)
Pup = np.stack([RC * np.cos(AZ), RC * np.sin(AZ), (eld - 1.2) / 6.0], -1)
cov_below = ss(0.52, 0.80, fbm(Pup, SEED + 11, 4) * 0.75 + fbm(Pup * np.array([1.0, 1.0, 1.6]) + 7.3, SEED + 31, 3) * 0.35) * band
rim = np.clip(cov - cov_below, 0, 1) * 3.0
moonside = 0.35 + 0.65 * np.exp(-(daz / 1.2) ** 2)
cloud_body = srgb2lin((54, 68, 112))
cloud_lit = srgb2lin((168, 178, 214))
cc = cloud_body[None, None, :] * (1 + 0.6 * glow[..., None] * 6) + cloud_lit * (np.clip(rim, 0, 1) * moonside)[..., None] * 0.7
alpha = (cov * 0.65)[..., None]
img = img * (1 - alpha) + cc * alpha

# ---------- 5. sparse soft stars (none below the horizon fog band) ----------
N = 620
# uniform on the upper sphere
zs = rng.uniform(np.sin(np.radians(10)), 1.0, N)
phis = rng.uniform(0, 2 * np.pi, N)
S = np.stack([np.sqrt(1 - zs ** 2) * np.cos(phis), zs, np.sqrt(1 - zs ** 2) * np.sin(phis)], -1)
mag = rng.power(0.35, N)                              # mostly faint, few bright
bright = 0.10 + 0.55 * mag
size = 0.055 + 0.07 * mag                             # gaussian sigma, degrees (~1-2 px on screen)
tints = np.where(rng.random(N)[:, None] < 0.25, srgb2lin((255, 236, 205)), srgb2lin((215, 228, 255)))
star = np.zeros((H, W, 3))
for i in range(N):
    sel = np.degrees(np.arcsin(S[i, 1])); saz = np.arctan2(S[i, 2], S[i, 0]) % (2 * np.pi)
    row = (90 - sel) / 105 * H
    r0, r1 = int(max(0, row - 8)), int(min(H, row + 9))
    span = int(min(W // 2 - 1, 8 / max(np.cos(np.radians(sel)), 0.02)))
    c0 = int(saz / (2 * np.pi) * W)
    cols = np.arange(c0 - span, c0 + span + 1) % W                 # wraps across u=0/1
    dd = np.degrees(np.arccos(np.clip(D[r0:r1][:, cols] @ S[i], -1, 1)))
    star[r0:r1][:, cols] += (bright[i] * np.exp(-0.5 * (dd / size[i]) ** 2))[..., None] * tints[i]
star_mask = ss(12, 20, eld)          # no stars below 12 deg (well clear of the horizon fog band)
star_mask *= ss(4.0, 14.0, ang)       # none in the moon's glare
star_mask *= (1 - 0.85 * cov)                       # clouds veil stars
img += star * star_mask[..., None]

# ---------- 6. to sRGB 8-bit with dither ----------
# default: 8x8 ordered (Bayer) dither, +-0.5 LSB, same offset on R/G/B. Kills gradient banding and
# compresses ~3x better than random dither (PNG ~0.45 MB vs ~1.45 MB). 'tpdf' = random +-1 LSB alternative.
out = lin2srgb(img) * 255.0
dmode = sys.argv[1] if len(sys.argv) > 1 else 'bayer'
if dmode == 'bayer':
    b8 = (np.array([[0,32,8,40,2,34,10,42],[48,16,56,24,50,18,58,26],[12,44,4,36,14,46,6,38],[60,28,52,20,62,30,54,22],
                    [3,35,11,43,1,33,9,41],[51,19,59,27,49,17,57,25],[15,47,7,39,13,45,5,37],[63,31,55,23,61,29,53,21]]) + 0.5) / 64 - 0.5
    out = out + np.tile(b8, (H // 8, W // 8))[..., None]
elif dmode == 'tpdf':
    out = out + (rng.random((H, W, 3)) - rng.random((H, W, 3)))
elif dmode == 'tpdf_mono':
    d = rng.random((H, W, 1)) - rng.random((H, W, 1)); out = out + d
out8 = np.clip(np.round(out), 0, 255).astype(np.uint8)
dst = sys.argv[2] if len(sys.argv) > 2 else 'meadow_sky_night_2048x1024.png'
Image.fromarray(out8, 'RGB').save(dst, optimize=True, compress_level=9)
np.save(sys.argv[3] if len(sys.argv) > 3 else '/tmp/night_float.npy', (lin2srgb(img) * 255).astype(np.float32))
print('wrote', dst)
