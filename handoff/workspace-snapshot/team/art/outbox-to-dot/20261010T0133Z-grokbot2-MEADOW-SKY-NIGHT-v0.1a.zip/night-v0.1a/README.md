# 草甸夜空 meadow_sky_night v0.1a（grokbot-2）

修复：地平线以下（v > 0.857，第 878–1023 行）原图越往下越暗（行均亮度 134 → 99），会在地形山脊下方露出一条暗带。v0.1a 把地平线以下统一成每列的地平线颜色。其余内容（月亮、星星、云、天顶渐变）与 v0.1 相同，替代 v0.1。
用法同 v0.1：`sky-unlit.effect` 开 `USE_NIGHT_TEXTURE`，拖到 `nightTexture`。

源：`art/sky/night-v0.1/`，`src/make_night_sky.py` 原样重跑，得到的 PNG 与 v0.1 逐字节一致（57b4f29d…3d4d2f），同时输出抖动前的浮点母版 `night_float.npy`（float32，f63c12de…c8843a，未随包交付，可用脚本重建）。

## 文件
| 文件 | 说明 |
|---|---|
| `meadow_sky_night_2048x1024.png` | 主交付，2048×1024 RGB 8-bit，无 alpha，446,676 B |
| `meadow_sky_night_2048x1024.jpg` | JPG q90 变体，62,291 B（见下方关于抖动的说明） |
| `preview_before_after.png` / `qa_row_luminance_below_horizon.png` / `preview_seam_wrap_below_horizon_x4.png` / `qa_results.json` | QA |
| `src/make_night_sky.py`（v0.1 原样）、`src/fix_below_horizon.py`、`src/qa_below_horizon.py` | 脚本 |

## 做法（`src/fix_below_horizon.py night`）
- 在抖动前的浮点母版上修，修完再加同一张 8×8 Bayer 有序抖动（±0.5 LSB，RGB 同偏移），然后量化，所以抖动保留，不会出色带。
- 每列取第 866–877 行的中位数作为地平线颜色，沿 u 环绕高斯平滑（σ = 6 px）→ 左右无缝。月亮方位下地平线略亮的那一点横向变化保留（这是按列的颜色，不是竖向渐变）。
- 第 878–1023 行 = 该颜色（加抖动）；第 870–877 行 smoothstep 过渡 8 行。
- 第 866 行以上：与 v0.1 相比只有 20 个像素差 1 LSB（float32 母版的舍入），其余逐像素一致。
- 地平线颜色约 sRGB (110, 133, 177) ≈ #6E85B1（u=0 附近，按列略有变化）。

## QA
- PNG 地平线以下行均亮度：之前 99.3–134.0（偏差 34.4 级），之后 131.95–132.34，最大偏差 0.29 级；8×8 块平均后每列偏差 0.000；逐像素偏差只有抖动的 ±1 → ±1 级以内，PASS。
- JPG q90：行均偏差 0.06 级，同样 PASS。注意 JPG 压缩会把大部分 8×8 抖动抹掉（地平线以下的平坦区本来就不需要抖动；上方渐变区可能出现轻微色带），所以引擎里优先用 PNG（再由 Creator 压 ASTC/ETC2）。
- 边界相邻行最大跳变 0.94 级（与原图相同量级）。
- 接缝：地平线以下 u=1→0 差 0.42，普通相邻列 0.52（都是抖动）；整图 0.60 对 0.59，无接缝。
- 预览已目视检查：暗带消失，对比度 ×4 的放大图里地平线以下平坦、接缝处看不出断开。

## 未做
Creator 导入、DevTools / 真机渲染、昼夜混合实际观感。

## 复现
```
python3 src/make_night_sky.py bayer /tmp/v01.png /tmp/night_float.npy
python3 src/fix_below_horizon.py night /tmp/night_float.npy meadow_sky_night_2048x1024.png meadow_sky_night_2048x1024.jpg
python3 src/qa_below_horizon.py NIGHT <v0.1 png> meadow_sky_night_2048x1024.png . meadow_sky_night_2048x1024.jpg
```
